sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"sap/ui/core/Fragment",
		"sap/m/MessageBox",
		"com/agi/customapproval/model/models",
		"sap/ui/model/json/JSONModel",
	
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator"
	],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function(Controller,
		Fragment,
		MessageBox, Formatter, 
		JSONModel, Filter, FilterOperator) {
		"use strict";

		return Controller.extend("com.agi.customapproval.controller.Main", {
			onInit: function() {
				jQuery.sap.require("com.agi.customapprova.libs.xlsx.full.min");
			},
			_oVHs: {},

			// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
			onVHMatnr: function(oEvent) {
				this._bIsMatnrVH = true;
				this._oInputVH = oEvent.getSource();
				this._openVH("com.agi.customapproval.view.fragments.Materials");
			},

			onVHSalesOrg: function(oEvent) {
				this._bIsMatnrVH = false;
				this._oInputVH = oEvent.getSource();
				this._openVH("com.agi.customapproval.view.fragments.SalesOrg");
			},

			onPlantSubmit: function(oEvent) {
				var sPlant = this._oAppView.getProperty("/plant");
				var sMaterial = this._oAppView.getProperty("/Material");
				var sMatType = this._oAppView.getProperty("/MatType");
				var sMatGroup = this._oAppView.getProperty("/MatGroup");
				var sDescription = this._oAppView.getProperty("/Description");
				this._getFilteredData(sPlant, sMaterial, sMatType, sMatGroup, sDescription);
			},

			// onMaterialSubmit: function(oEvent) {
			// 	var sMaterial = this._oAppView.getProperty("/Material");
			// 	var sPlant = this._oAppView.getProperty("/plant");
			// 	var sMatType = this._oAppView.getProperty("/MatType");
			// 	var sMatGroup = this._oAppView.getProperty("/MatGroup");
			// 	var sDescription = this._oAppView.getProperty("/Description");
			// 	this._getFilteredData(sPlant, sMaterial, sMatType, sMatGroup, sDescription);
			// },
			onVHCustomer: function(oEvent) {
				this._bIsMatnrVH = false;
				this._oInputVH = oEvent.getSource();
				this._openVH("com.agi.customapproval.view.fragments.Customer");
			},

			//SOC by Bhavesh, Incresol, 02/07/2024//
			onVHCustomerName: function(oEvent) {
				this._bIsMatnrVH = false;
				this._oInputVH = oEvent.getSource();
				this._openVH("com.agi.customapproval.view.fragments.Customername");
			},
			// onVHCustomerGroupName: function(oEvent) {
			// 	this._bIsMatnrVH = false;
			// 	this._oInputVH = oEvent.getSource();
			// 	this._openVH("com.agi.customapproval.view.fragments.CustomerGroupName");
			// },
			//EOC by Bhavesh, Incresol, 02/07/2024//
			onVHDistChannel: function(oEvent) {
				this._bIsMatnrVH = false;
				this._oInputVH = oEvent.getSource();
				this._openVH("com.agi.customapproval.view.fragments.DistributionChannel");
			},

			onVHCustomerGroup: function(oEvent) {
				this._bIsMatnrVH = false;
				this._oInputVH = oEvent.getSource();
				this._openVH("com.agi.customapproval.view.fragments.CustomerGroup");
			},

			_openVH: function(sPath) {
				this._sPath = sPath;
				if (!this._oVHs[sPath]) {
					var oFragment = sap.ui.xmlfragment(sPath, this);
					this._oVHs[sPath] = oFragment;
					this.getView().addDependent(this._oVHs[sPath]);
					this._oVHs[sPath].open();
				} else {
					this._oVHs[sPath].open();
				}
			},

			onMatnrClose: function() {
				this._oVHs[this._sPath].close();
			},
			//SOC by Bhavesh, Incresol, 03/07/2024//
			onVHConfirm: function(oEvent) {
				let sSelectedValue = oEvent.getParameter("selectedItem").getTitle();
				let sSelectedDescription = oEvent.getParameter("selectedItem").getDescription();

				// Set the value to the input field
				this._oInputVH.setValue(sSelectedValue);

				// Assuming the description field is identified by an ID in your view
				let oDescriptionField = this.byId("descriptionFieldId");

				if (oDescriptionField) {
					// Set the description to the description field
					oDescriptionField.setValue(sSelectedDescription);
				}
			},
			onFileUploadChange: function(event) {
				const file = event.getParameter("files")[0];
				if (file && window.FileReader) {
					const reader = new FileReader();

					reader.onload = (e) => {
						const data = e.target.result;
						const workbook = XLSX.read(data, {
							type: 'binary'
						});

						// Extract the first sheet name
						const sheetName = workbook.SheetNames[0];

						// Convert sheet data to JSON format
						const excelData = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);

						// Bind the data to the table model
						const materialsModel = this.getView().getModel("AppView");
						materialsModel.setProperty("/materials", excelData);
					};

					// Read file as binary string
					reader.readAsBinaryString(file);
				}
			},
			onVHConfirmGroup: function(oEvent) {
				let sSelectedValue = oEvent.getParameter("selectedItem").getTitle();
				let sSelectedDescription = oEvent.getParameter("selectedItem").getDescription();

				// Set the value to the input field
				this._oInputVH.setValue(sSelectedValue);

				// Assuming the description field is identified by an ID in your view
				let oDescriptionField = this.byId("descriptionGroupFieldId");

				if (oDescriptionField) {
					// Set the description to the description field
					oDescriptionField.setValue(sSelectedDescription);
				}
			},
			//EOC by Bhavesh, Incresol, 03/07/2024//
			onVHConfirmname: function(oEvent) {
				let sSelectedValue = oEvent.getParameter("selectedItem").getTitle();
				this._oInputVH.setValue(sSelectedValue);
			},

			onVHSearchCustomer: function(oEvent) {
				this._searchVH(oEvent, "Kunnr");
			},
			onVHSearchCustomername: function(oEvent) {
				this._searchVH(oEvent, "Name1");
			},

			onVHSearchCustomerGroup: function(oEvent) {
				this._searchVH(oEvent, "Kdgrp");
			},

			onVHSearchSalesOrg: function(oEvent) {
				this._searchVH(oEvent, "Vkorg");
			},
			onVHSearchMatnr: function(oEvent) {
				this._searchVH(oEvent, "Matnr");
			},
			onVHSearchDistChannel: function(oEvent) {
				this._searchVH(oEvent, "Vtweg");
			},

			_searchVH: function(oEvent, sKey) {
				var sQuery = oEvent.getParameter("value"),
					aFilters = [];
				if (sQuery) {
					aFilters.push(
						new Filter(sKey, FilterOperator.Contains, sQuery)
					);
				}
				oEvent.getSource().getBinding("items").filter(aFilters);
			},

			// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

			_sCustomerPriceSet: "CustomerPriceSet",
			formatter: Formatter,
			onInit: function() {
				this._oAppView = this.getOwnerComponent().getModel("AppView");
				this._oAppView.setSizeLimit(10000);
				this._oODataModel = this.getOwnerComponent().getModel();
				this._setDefaults();
				this._getLoggedInUser();
				this._getValueHelps();
			},

			_getValueHelps: function() {
				this._getCustomers();
				this._getCustomerGroup();
				this._getSalesOrg();
				this._getDistChannel();
			},
			//SOC by Bhavesh, Incresol, 02/07/2024//
			// _getMatnrVH: function(sPlant) {
			// 	sap.ui.core.BusyIndicator.show(0);
			// 	this._oODataModel.read("/Mat1wSet", {
			// 		filters: [
			// 			new sap.ui.model.Filter({
			// 				path: "Werks",
			// 				operator: "EQ",
			// 				value1: sPlant
			// 			})
			// 		],
			// 		urlParameters: {
			// 			"$skip": 0,
			// 			"$top": 2000
			// 		},
			// 		success: (oData) => {
			// 			sap.ui.core.BusyIndicator.hide();
			// 			if (oData.results.length > 0) {
			// 				this._oAppView.setProperty("/MatnrVH", oData.results);
			// 			} else {
			// 				this._oAppView.setProperty("/MatnrVH", []);
			// 			}
			// 		},
			// 		error: (oError) => {
			// 			sap.ui.core.BusyIndicator.hide();
			// 			MessageBox.error(JSON.stringify(oError));
			// 		}
			// 	});
			// },

			_getFilteredData: function(sPlant, sMaterial, sMatType, sMatGroup, sDescription) {
				sap.ui.core.BusyIndicator.show(0);
				var aFilters = [];

				if (sPlant) {
					aFilters.push(new sap.ui.model.Filter({
						path: "Werks",
						operator: "EQ",
						value1: sPlant
					}));
				}
				if (sMaterial) {
					aFilters.push(new sap.ui.model.Filter({
						path: "Matnr",
						operator: "EQ",
						value1: sMaterial
					}));
				}
				if (sMatType) {
					aFilters.push(new sap.ui.model.Filter({
						path: "MatType",
						operator: "EQ",
						value1: sMatType
					}));
				}
				if (sMatGroup) {
					aFilters.push(new sap.ui.model.Filter({
						path: "MatGroup",
						operator: "EQ",
						value1: sMatGroup
					}));
				}
				if (sDescription) {
					aFilters.push(new sap.ui.model.Filter({
						path: "Description",
						operator: "EQ",
						value1: sDescription
					}));
				}

				this._oODataModel.read("/ZmatlwSet", {
					filters: aFilters,
					urlParameters: {
						"$skip": 0,
						"$top": 200
					},
					success: (oData) => {
						sap.ui.core.BusyIndicator.hide();
						if (oData.results.length > 0) {
							this._oAppView.setProperty("/MatnrVH", oData.results);
						} else {
							this._oAppView.setProperty("/MatnrVH", []);
						}
					},
					error: (oError) => {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error(JSON.stringify(oError));
					}
				});
			},
			//SOC by Bhavesh, Incresol, 04/07/2024//
			_getCustomers: function() {
				sap.ui.core.BusyIndicator.show(0);
				this._oODataModel.read("/ZdebiaSet", {
					urlParameters: {
						"$skip": 0
					},
					success: (oData) => {
						sap.ui.core.BusyIndicator.hide();
						if (oData.results.length > 0) {
							this._oAppView.setProperty("/CustomerVH", oData.results);
							console.log("Customer data loaded successfully:", oData.results);
							console.log("Complete oData object:", oData);
						} else {
							this._oAppView.setProperty("/CustomerVH", []);
							console.log("No customers found.");
						}
					},
					error: (oError) => {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error(JSON.stringify(oError));
					}
				});
			},
			//EOC by Bhavesh, Incresol, 04/07/2024//
			//EOC by Bhavesh, Incresol, 02/07/2024//
			// _getCustomers: function() {
			// 	sap.ui.core.BusyIndicator.show(0);
			// 	this._oODataModel.read("/DebiaSet", {
			// 		urlParameters: {
			// 			"$skip": 0,
			// 			"$top": 2000
			// 		},
			// 		success: (oData) => {
			// 			sap.ui.core.BusyIndicator.hide();
			// 			if (oData.results.length > 0) {
			// 				this._oAppView.setProperty("/CustomerVH", oData.results);
			// 			} else {
			// 				this._oAppView.setProperty("/CustomerVH", []);
			// 			}
			// 		},
			// 		error: (oError) => {
			// 			sap.ui.core.BusyIndicator.hide();
			// 			MessageBox.error(JSON.stringify(oError));
			// 		}
			// 	});
			// },

			_getCustomerGroup: function() {
				sap.ui.core.BusyIndicator.show(0);
				this._oODataModel.read("/HT151Set", {
					urlParameters: {
						"$skip": 0,
						"$top": 2000
					},
					success: (oData) => {
						sap.ui.core.BusyIndicator.hide();
						if (oData.results.length > 0) {
							this._oAppView.setProperty("/CustomerGroupVH", oData.results);
						} else {
							this._oAppView.setProperty("/CustomerGroupVH", []);
						}
					},
					error: (oError) => {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error(JSON.stringify(oError));
					}
				});
			},

			_getDistChannel: function() {
				sap.ui.core.BusyIndicator.show(0);
				this._oODataModel.read("/HTvtwSet", {
					urlParameters: {
						"$skip": 0,
						"$top": 2000
					},
					success: (oData) => {
						sap.ui.core.BusyIndicator.hide();
						if (oData.results.length > 0) {
							this._oAppView.setProperty("/DistChannelVH", oData.results);
						} else {
							this._oAppView.setProperty("/DistChannelVH", []);
						}
					},
					error: (oError) => {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error(JSON.stringify(oError));
					}
				});
			},

			onSelectMaterial: function(oEvent) {
				let oContext = oEvent.getParameter("listItem").getBindingContext("AppView");
				let oSelectedMatnr = oContext.getModel().getProperty(oContext.getPath());
				this._oInputVH.setValue(oSelectedMatnr.Matnr);
				let oTContext = this._oInputVH.getParent().getBindingContext("AppView")
				oTContext.getModel().setProperty(oTContext.getPath() + "/MaterialDescription", oSelectedMatnr.Maktg);
				this._oVHs[this._sPath].close();
			},

			_getSalesOrg: function() {
				sap.ui.core.BusyIndicator.show(0);
				this._oODataModel.read("/HTvkoSet", {
					urlParameters: {
						"$skip": 0,
						"$top": 2000
					},
					success: (oData) => {
						sap.ui.core.BusyIndicator.hide();
						if (oData.results.length > 0) {
							this._oAppView.setProperty("/SalesOrgVH", oData.results);
						} else {
							this._oAppView.setProperty("/SalesOrgVH", []);
						}
					},
					error: (oError) => {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error(JSON.stringify(oError));
					}
				});
			},

			_setDefaults: function() {
				this._oAppView.setProperty("/", {
					vh: [{
						text: "mobile",
						key: "01"
					}, {
						text: "desktop",
						key: "02"
					}, {
						text: "tablet",
						key: "03"
					}],
					gclist: [{}],
					cclist: [{}],
					materials: [{}],
					Codetype: "GC",
					gc: {
						Currency: "INR",
						PricingUnit: "1000",
						CustomerStatus: "N"
					},
					cc: {
						Currency: "INR",
						PricingUnit: "1000",
						CustomerStatus: "N"
					}
				});
				this._getLoggedInUser();
			},
			onSubmitBottleWeight: function(oEvent) {
				var oModel = this.getView().getModel("AppView").getData();
				var oContext = oEvent.getSource().getBindingContext("AppView");
				let oData = oContext.getModel().getProperty(oContext.getPath());

				if (oData.ExistingPrice) {
					oContext.getModel().setProperty(oContext.getPath() + "/ExistingPrice", (parseFloat(oData.ExistingPrice).toFixed(3) + ""));
				}

				if (oData.Amount) {
					oContext.getModel().setProperty(oContext.getPath() + "/Amount", (parseFloat(oData.Amount).toFixed(3) + ""));
				}
				if (oData.Weight) {
					oContext.getModel().setProperty(oContext.getPath() + "/Weight", (parseFloat(oData.Weight).toFixed(3) + ""));
				}

				let sExistingRelz, sNewRelz;
				if (oData.ExistingPrice && oData.Weight) {
					sExistingRelz = parseInt(oData.ExistingPrice) / parseInt(oData.Weight);
					sExistingRelz = sExistingRelz * 1000;
					oContext.getModel().setProperty(oContext.getPath() + "/ExistingRezl", (sExistingRelz.toFixed(3) + ""));
				}
				if (oData.Amount && oData.Weight) {
					sNewRelz = parseInt(oData.Amount) / parseInt(oData.Weight);
					sNewRelz = sNewRelz * 1000;
					oContext.getModel().setProperty(oContext.getPath() + "/NewRezl", (sNewRelz.toFixed(3) + ""));
				}

				if (sExistingRelz && sNewRelz) {
					let sChangeRelz = sNewRelz - sExistingRelz;
					oContext.getModel().setProperty(oContext.getPath() + "/ChangeRezl", (sChangeRelz.toFixed(3) + ""));
				}
			},

			onMaterialInputSubmit: function(oEvent) {
				var oModel = this.getView().getModel("AppView").getData();
				var oContext = oEvent.getSource().getBindingContext("AppView");
				let oData = oContext.getModel().getProperty(oContext.getPath());
				this._getMatnrDesc(oData.Material, oContext);
			},

			_getMatnrDesc: function(sMaterial, oContext = undefined) {
				let aFilter = [
					new sap.ui.model.Filter({
						path: "Matnr",
						operator: "EQ",
						value1: sMaterial
					})
				];
				sap.ui.core.BusyIndicator.show(0);
				this._oODataModel.read("/Mat0mSet", {
					filters: sMaterial ? aFilter : [],
					success: (oData) => {
						sap.ui.core.BusyIndicator.hide();
						if (oData.results.length > 0) {
							oContext.getModel().setProperty(oContext.getPath() + "/MaterialDescription", oData.results[0].Maktg);
						} else {
							oContext.getModel().setProperty(oContext.getPath() + "/MaterialDescription", "");
						}
					},
					error: (oError) => {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error(JSON.stringify(oError));
					}
				});
			},

			onAddButtonGCPress: function() {
				let aData = this._oAppView.getProperty("/gclist");
				aData = aData.length > 0 ? Array.from(aData) : [];

				aData.push({});
				this._oAppView.setProperty("/gclist", aData);
			},
			onAddButtonCCPress: function() {
				let aData = this._oAppView.getProperty("/cclist");
				aData = aData.length > 0 ? Array.from(aData) : [];

				aData.push({

				});
				this._oAppView.setProperty("/cclist", aData);
			},
			onAddButtonMatnrPress: function() {
				let aData = this._oAppView.getProperty("/materials");
				aData = aData.length > 0 ? Array.from(aData) : [];
				aData.push({});
				this._oAppView.setProperty("/materials", aData);
			},
			onCloseButtonPressMatnr: function() {

			},

			onSaveButtonPressMatnr: function() {
				this._oDialog.close();
			},

			onAddCustomCode: function() {
				if (!this._oDialog) {
					Fragment.load({
						name: "com.agi.customapproval.view.fragments.CustomerGroup",
						controller: this
					}).then((oDialog) => {
						this._oDialog = oDialog;
						this.getView().addDependent(oDialog);
						this._oDialog.open();
					});
				} else {
					this._oDialog.open();
				}
			},
			onIconDeleteRowPress: function(oEvent) {
				var oModel = this.getView().getModel("AppView").getData();
				var oContext = oEvent.getSource().getBindingContext("AppView");
				let aData = oContext.getModel().getProperty("/materials");
				var iIndex = oContext.getPath() && oContext.getPath().split("/")[2];
				aData.splice(iIndex, 1);
				oContext.getModel().setProperty("/materials", aData);
				oContext.getModel().refresh(true);
			},

			onSaveButtonPress: function() {
				let aMaterials = this._oAppView.getProperty("/materials"),
					sCodetype = this._oAppView.getProperty("/Codetype"),
					oPayload, oDateRange;

				if (sCodetype === "GC") {
					// GC
					oPayload = this._oAppView.getProperty("/gc");
					oPayload.Codetype = "G";
					oDateRange = this.getView().byId("idDateRangeG");
					if (!oDateRange.getDateValue() || !oPayload.CustomerGroup) {
						MessageBox.error("Fill mandatory fields!")
						return;
					}
				} else {
					// CC
					oPayload = this._oAppView.getProperty("/cc");
					oPayload.Codetype = "C";
					oDateRange = this.getView().byId("idDateRangeC");

					if (!oDateRange.getDateValue() || !oPayload.SalesOrg || !oPayload.DistrChannel || !oPayload.Customer) {
						MessageBox.error("Fill mandatory fields!")
						return;
					}
				}

				oPayload.FormNo = "000000001";
				oPayload.Requester = this._oAppView.getProperty("/loggedInUser");
				aMaterials = Array.from(aMaterials);
				let aFilledMatnrs = aMaterials.filter((oMatnr) => oMatnr.Material);
				if (aFilledMatnrs.length === 0) {
					MessageBox.error("Fill at least one material");
					return;
				}
				// Add ItemNo, FormNo
				aFilledMatnrs.forEach((data, index) => {
					if (data.Material) {

					}
					data.ItemNo = "" + (index + 1);
					data.ValidFrom = oDateRange.getDateValue();
					data.ValidTo = oDateRange.getSecondDateValue();
					data.Currency = "INR";
				});

				oPayload.NavCustomerToMat = aFilledMatnrs;
				sap.ui.core.BusyIndicator.show(0);
				this._oODataModel.create("/" + this._sCustomerPriceSet, oPayload, {
					success: () => {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.success("Created successfully", {
							onClose: () => {
								this._setDefaults();
							}
						});
					},
					error: (oError) => {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error(JSON.stringify(oError));
					}
				});
			},

			_getLoggedInUser: function() {
				this.getOwnerComponent().getService("ShellUIService").then((oService) => {
					let sUser = sap.ushell.Container.getService("UserInfo").getId();
					this._oAppView.setProperty("/loggedInUser", sUser);
				});
			},

			onResetButtonPress: function() {
				this._setDefaults();
			},

			onCancelButtonPress: function() {
				this._oDialog.close();
			},

			_deleteRow: function() {

			},

			_addRow: function() {

			},

			onIconTabBarPress: function(oEvent) {

			},

			onIconTabBarPress: function(oEvent) {

			}

		});
	});