sap.ui.define([
	"comagi/customapproval/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
