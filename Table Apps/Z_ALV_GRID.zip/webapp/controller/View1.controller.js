sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment"
], function(Controller, JSONModel, MessageToast, Fragment) {
	"use strict";

	return Controller.extend("com.zpocZPOC_Hetero.controller.View1", {
		onInit: function() {
			var data = {
				GoodsIssues: [{
					OBDNumber: "12345",
					MaterialName: "Widget A",
					QuantityUOM: "100 EA",
					ActualGIDate: "2025-03-20"
				}, {
					OBDNumber: "67890",
					MaterialName: "Gadget B",
					QuantityUOM: "50 PC",
					ActualGIDate: "2025-03-19"
				}, {
					OBDNumber: "11121",
					MaterialName: "Device X",
					QuantityUOM: "30 KG",
					ActualGIDate: "2025-03-18"
				}]
			};
			var oModel = new JSONModel(data);
			this.getView().setModel(oModel, "goods");
		},

		onOpenFieldSelection: function() {
			var oView = this.getView();
			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment(oView.getId(), "com.zpocZPOC_Hetero.Fragments.Dialog", this);
				oView.addDependent(this._oDialog);
			}
			// Open Dialog
			this._oDialog.open();
		},
		onDropField: function(oEvent) {
			var oDragged = oEvent.getParameter("draggedControl");
			var oDropped = oEvent.getParameter("droppedControl");
			var sDropPosition = oEvent.getParameter("dropPosition");
			var oList = this.byId("fieldList");

			var iDraggedIndex = oList.indexOfItem(oDragged);
			var iDroppedIndex = oList.indexOfItem(oDropped);

			oList.removeItem(oDragged);

			if (sDropPosition === "Before") {
				oList.insertItem(oDragged, iDroppedIndex);
			} else {
				oList.insertItem(oDragged, iDroppedIndex + 1);
			}
		},

			onApplyFieldSelection: function() {
			var oList = this.byId("fieldList");
			var aSelectedItems = oList.getSelectedItems();
			var aSelectedFields = aSelectedItems.map(function(item) {
				return item.getTitle();
			});

			MessageToast.show("Selected Fields: " + aSelectedFields.join(", "));
			this.byId("fieldSelectionDialog").close();
		},

		onSaveLayout: function() {
			var oTable = this.byId("alvGridTable");
			var aColumns = oTable.getColumns().map(function(col) {
				return {
					label: col.getLabel().getText()
				};
			});

			localStorage.setItem("alvLayout", JSON.stringify(aColumns));
			MessageToast.show("Layout saved!");
		},

		onLoadLayout: function() {
			var oTable = this.byId("alvGridTable");
			var sLayout = localStorage.getItem("alvLayout");
			if (sLayout) {
				var aColumns = JSON.parse(sLayout);
				oTable.removeAllColumns();
				aColumns.forEach(function(col) {
					oTable.addColumn(new sap.ui.table.Column({
						label: new sap.m.Label({
							text: col.label
						}),
						template: new sap.m.Text({
							text: "{" + col.label.replace(" ", "") + "}"
						})
					}));
				});
				MessageToast.show("Layout loaded!");
			} else {
				MessageToast.show("No saved layout found!");
			}
		}
	});
});