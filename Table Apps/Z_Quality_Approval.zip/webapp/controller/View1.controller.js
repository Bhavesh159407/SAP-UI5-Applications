sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/core/Fragment",
	"sap/ui/model/json/JSONModel"
], function(Controller, ODataModel, Fragment, JSONModel) {
	"use strict";

	return Controller.extend("com.qaZ_Quality_Approval.controller.View1", {
		onInit: function() {
			var serviceUrl = "/sap/opu/odata/sap/ZQC_PROCESS_SRV/";
			var oDataModel = new ODataModel(serviceUrl, {
				useBatch: false
			});
			this.getView().setModel(oDataModel, "odataModel");

			// Load OData into JSONModel for filtering
			var that = this;
			oDataModel.read("/QcDetailsSet", {
				success: function(oData) {
					var oJsonModel = new JSONModel({
						originalData: oData.results,
						filteredData: oData.results
					});
					that.getView().setModel(oJsonModel, "jsonModel");
				},
				error: function(err) {
					console.error("Error loading QcDetailsSet", err);
				}
			});
		},

		onLiveSearch: function(oEvent) {
			var sQuery = oEvent.getParameter("newValue").toLowerCase();
			var oModel = this.getView().getModel("jsonModel");
			var aData = oModel.getProperty("/originalData");

			// Log original data before filtering
			console.log("Original Data (before filtering):", aData);
			console.log("Search Query:", sQuery);

			var aFiltered = aData.filter(function(item) {
				return Object.values(item).some(function(value) {
					return value && value.toString().toLowerCase().includes(sQuery);
				});
			});

			// Log filtered data
			console.log("Filtered Data (after filtering):", aFiltered);

			oModel.setProperty("/filteredData", aFiltered);
		},

		onSelectAll: function() {
			var oTable = this.getView().byId("requestTable");
			oTable.setMode("MultiSelect"); // Enable multi-select mode
			oTable.getItems().forEach(function(oItem) {
				oTable.setSelectedItem(oItem, true); // Select each item
			});
		},
		// #######Actual Deviation##########
		onActualPress: function() {
			var oView = this.getView();
			if (!this._oFragment) {
				this._oFragment = sap.ui.xmlfragment(oView.getId(), "com.qaZ_Quality_Approval.Fragments.ActualDeviation", this);
				oView.addDependent(this._oFragment);

				this._oFragment.open();
			} else {
				this._oFragment.open();
			}
		},
		onReject: function() {

			this._oFragment.close();
		},
		// #######Actual Deviation##########
		
		
		
		// #######Edit Deviation##########
		onDeviationCreditPress: function() {
			var oView = this.getView();
			if (!this._oFragment) {
				this._oFragment = sap.ui.xmlfragment(oView.getId(), "com.qaZ_Quality_Approval.Fragments.DeviationCredit", this);
				oView.addDependent(this._oFragment);

				this._oFragment.open();
			} else {
				this._oFragment.open();
			}
		},
		onDialogClose: function() {
			this.byId("inputPercentage").setValue("").setEnabled(false);
			this.byId("inputRatePerKg").setValue("").setEnabled(false);
			this.byId("inputBulkAmount").setValue("").setEnabled(false);

			// Access the dialog and check if it is open
			var oDialog = this.byId("deviationCreditDialog");
			if (oDialog && oDialog.isOpen()) {
				// Deselect all radio buttons by their IDs
				this.byId("radioButtonPercentage").setSelected(false);
				this.byId("radioButtonRatePerKg").setSelected(false);
				this.byId("radioButtonBulkAmount").setSelected(false);
				// this.byId("radioButtonActualAmount").setSelected(false);
			}

			this._oFragment.close();
		},
		// #######Edit Deviation##########
		onUnselectAll: function() {
			var oTable = this.getView().byId("requestTable");
			oTable.removeSelections(true); // Clear all selections
			oTable.setMode("SingleSelectMaster"); // Restore original mode
		}
	});
});