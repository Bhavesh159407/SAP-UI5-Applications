sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"ZTIC_REQ_MAN/model/models",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"sap/m/MessageBox"
], function(UIComponent, Device, models, JSONModel, Filter, FilterOperator, Sorter, MessageBox) {
	"use strict";

	return UIComponent.extend("ZTIC_REQ_MAN.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			var localModel = new JSONModel();
			this.setModel(localModel, "LocalModel");
			var locationFrom = new JSONModel();
			this.setModel(locationFrom, "FromModel");
			var locationTo = new JSONModel();
			this.setModel(locationTo, "ToModel");
			var noDuplicateFrom = new JSONModel();
			this.setModel(noDuplicateFrom, "NoDuplicateFrom");
			var noDuplicateTo = new JSONModel();
			this.setModel(noDuplicateTo, "NoDuplicateTo");
			this.oModel = this.getModel();
			var filters = [];
			filters.push(new Filter({
				path: "Status",
				value1: "Request",
				operator: FilterOperator.EQ
			}));
			var sorter = [];
			sorter.push(new Sorter({
				path: "DateBeg",
				descending: true
			}));
			this.oModel.read("/ZTRAVELREQ", {
				/*filters: filters,*/
				/*sorter:sorter,*/
				success: function(oData) {
					var data = oData.results;
					//this.getModel("LocalModel").setProperty("/RealItems", data);
					/*for (var i = 0; i < data.length; i++) {
						data[i].Reinr = this.removeLeadingZero(data[i].Reinr);
						data[i].Reqnum = this.removeLeadingZero(data[i].Reqnum);
						data[i].MobileNum = this.removeLeadingZero(data[i].MobileNum);
						data[i].Deptcostcode = this.removeLeadingZero(data[i].Deptcostcode);
					}*/
					this.getModel("LocalModel").setProperty("/Items", data);
				}.bind(this),
				error: function(oError) {
					sap.m.MessageBox.error("Error in getting Travel data");
				}.bind(this)

			});
			this.oModel.read("/VehSpl", {
				success: function(oData) {
					var data = oData.results;
					var fromValues = [];
					var toValues = [];
					for (var j = 0; j < data.length; j++) {
						fromValues.push({
							"From": data[j].ZlocFrom,
							"Key": data[j].ZlocFrom
						});
						toValues.push({
							"To": data[j].ZlocTo,
							"Key": data[j].ZlocTo
						});
					}
					this.getModel("FromModel").setProperty("/fromValues", fromValues);
					this.getModel("ToModel").setProperty("/toValues", toValues);

					var itemsFrom = this.getModel("FromModel").getProperty("/fromValues");
					var itemsTo = this.getModel("ToModel").getProperty("/toValues");
					/*To remove duplicates from From and To Locations*/
					var fromArray = [];
					var toArray = [];
					if (itemsFrom.length > 0) {
						fromArray.push(itemsFrom[0]);
					}
					if (itemsTo.length > 0) {
						toArray.push(itemsTo[0]);
					}
					for (var f = 1; f < itemsFrom.length; f++) {
						var fromCount = 0;
						for (var ff = 0; ff < fromArray.length; ff++) {
							var firstItemArray = fromArray[ff].From.toString().toLowerCase();
							var firstFromArray = itemsFrom[f].From.toString().toLowerCase();
							if (firstItemArray === firstFromArray) {
								//	fromArray.push(itemsFrom[f]);
								fromCount++;
							}
						}
						if (fromCount === 0) {
							fromArray.push(itemsFrom[f]);
						}
					}
					this.getModel("NoDuplicateFrom").setProperty("/Items", fromArray);

					for (var t = 1; t < itemsTo.length; t++) {
						var toCount = 0;
						for (var tt = 0; tt < toArray.length; tt++) {
							var toItemArray = toArray[tt].To.toString().toLowerCase();
							var firstToArray = itemsTo[t].To.toString().toLowerCase();
							if (toItemArray === firstToArray) {
								//toArray.push(itemsTo[t]);	
								toCount++;
							}
						}
						if (toCount === 0) {
							toArray.push(itemsTo[t]);
						}
					}
					this.getModel("NoDuplicateTo").setProperty("/Items", toArray);

				}.bind(this),
				error: function(oError) {
					sap.m.MessageToast.show("Error in getting Special Locations data");
				}.bind(this)

			});
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			this.getRouter().initialize();
		},
		removeLeadingZero: function(input) {
			return input.replace(/^0+/, '');
		}
	});
});