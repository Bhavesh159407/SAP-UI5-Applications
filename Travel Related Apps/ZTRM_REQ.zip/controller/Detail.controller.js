sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"ZTIC_REQ_MAN/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter",
	"sap/m/MessageBox",
	"sap/m/PDFViewer"
], function(Controller, JSONModel, formatter, Filter, FilterOperator, Sorter, MessageBox, PDFViewer) {
	"use strict";
	var locBeginIndex, locEndIndex, dateBeginIndex, timeBeginIndex, dateEndIndex, mobNumberIndex, purposeIndex, requisitionIndex;
	var locBeginNonEmpIndex, locEndNonEmpIndex, dateBeginNinEmpIndex, timeBeginNonEmpIndex, dateEndNonEmpIndex, mobNumNonEmpIndex,
		purposeNonEmpIndex, personNameNonEmpIndex, requisitionNonEmpIndex, oFile, base64File, nonEmpModel, name, size, mimeType, oCheckBox,
		checkBox;

	return Controller.extend("ZTIC_REQ_MAN.controller.Detail", {
		f: formatter,
		onInit: function() {
			  //var oModel = new JSONModel();
     //       this.getView().setModel(oModel);

			this.getView().addStyleClass("sapUiSizeCompact");
			var view2Model = new JSONModel();
			this.getView().setModel(view2Model, "DetailModel");

			var enableModel = new JSONModel();
			this.getView().setModel(enableModel, "EnableModel");
			var createModel = new JSONModel();
			this.getView().setModel(createModel, "CreateModel");
			var retrievedEmpName = new JSONModel();
			this.getView().setModel(retrievedEmpName, "EmpNameModel");

			nonEmpModel = new JSONModel();
			nonEmpModel.setData({
				Items: []
			});
			this.getView().setModel(nonEmpModel, "NonEmpModel");

			this.getView().getModel("CreateModel").setData({
				aRequisition: [{
					Reqnum: "",
					DateBeg: "",
					DateEnd: "",
					LocationBegin: "",
					LocationEnd: "",
					Action: ""
				}]
			});
			var reqModel = new JSONModel();
			this.getView().setModel(reqModel, "RequisitionModel");

			this.getView().getModel("EnableModel").setProperty(
				"/EnablePanel", "No");
			this.getView().getModel("EnableModel").setProperty("/EnableMessagePage", "YES");
			this.getView().getModel(
				"EnableModel").setProperty("/EnableTableFeilds", "NO");
			this.getView().getModel("EnableModel").setProperty("/EnableFormTable",
				"NO");
			this.getView().getModel("EnableModel").setProperty("/EnableCheckBox", "NO");
			this.getView().getModel("EnableModel").setProperty(
				"/EnableEmpTable", "NO");
			this.getView().getModel("EnableModel").setProperty("/EnableEmpSplTable", "NO");
			this.getView().getModel(
				"EnableModel").setProperty("/EnableNonEmpTable", "NO");
			this.getView().getModel("EnableModel").setProperty(
				"/EnableNonEmpSplTable", "NO");
			this.getView().getModel("EnableModel").setProperty("/EnableSelect", "YES");
			this.getView().getModel(
				"EnableModel").setProperty("/EnableInput", "NO");
			//	this.getView().getModel("EnableModel").setProperty("/EnableOtherfields", "NO");
			this.getOwnerComponent().getRouter().getRoute("object").attachPatternMatched(this.onPatternMatched, this);
			var dropDown = new JSONModel({
				"values": [{
					"role": "Employee",
					"key": "E"
				}, {
					"role": "Contractual Employee",
					"key": "CE"
				}, {
					"role": "Customer",
					"key": "C"
				}, {
					"role": "Supplier",
					"key": "S"
				}, {
					"role": "Government Official",
					"key": "GOVT"
				}, {
					"role": "Press/Media",
					"key": "P"
				}, {
					"role": "Foreigner",
					"key": "F"
				}, {
					"role": "Company Guest",
					"key": "CG"
				}]
			});
			this.getView().setModel(dropDown, "DropDownModel");
			var dropDown = new JSONModel({
				"values": [{
					"role": "Entitle",
					"key": "EN"
				}, {
					"role": "Non-Entitle",
					"key": "NE"
				}]
			});
			this.getView().setModel(dropDown, "EntitleDropdownModel");
			var timeModel = new JSONModel();
			timeModel.setData({
				"timePickers": {
					"TP1": {
						"format": "HH:mm:ss",
						"placeholder": "Enter meeting start time"
					}
				}
			});
			this.getView().setModel(timeModel, "TimeModel");

		},
		onPatternMatched: function(oEvent) {
			var tripNumber = oEvent.getParameter("arguments").key;
			this.tripNum = oEvent.getParameter("arguments").key;
			//	this.tripNumber =oEvent.getParameter("arguments").key;
			if (!isNaN(tripNumber)) {

				var finalItems = this.getOwnerComponent().getModel("LocalModel").getProperty("/Items");
				var i;

				for (i = 0; i < finalItems.length; i++) {
					if (finalItems[i].Reinr.replace(/^0+/, "") === tripNumber) {
						this.required = finalItems[i].Reinr;
						this.mobileEmpNumber = finalItems[i].Mobile;
						this.getView().getModel("DetailModel").setData(finalItems[i]);
						this.getView().getModel("DetailModel").getData();

						var empNameID = finalItems[i].CategoryName + "(" + finalItems[i].Pernr + ")";
						this.getView().getModel("DetailModel").setProperty("/EmpNameID", empNameID);
						this.getView().getModel("EnableModel").setProperty("/EnablePanel", "NO");
						this.getView().getModel("EnableModel").setProperty("/EnableFormTable", "YES");
						this.getView().getModel("EnableModel").setProperty("/EnableCheckBox", "YES");
						this.getView().getModel("EnableModel").setProperty("/EnableMessagePage", "NO");
						this.getView().getModel("EnableModel").setProperty("/EnableEmpTable", "YES");
						this.getView().getModel("EnableModel").setProperty("/EnableEmpSplTable", "NO");
						this.getView().getModel("EnableModel").setProperty("/EnableNonEmpTable", "NO");
						this.getView().getModel("EnableModel").setProperty("/EnableNonEmpSplTable", "NO");
						//	this.byId("idFirstTable").removeSelections(true);
						this.getView().byId("idCancelButton").setEnabled(false);
						this.getView().byId("idAddNewButton").setEnabled(true);
						this.getView().byId("scrollContainerTable").scrollToElement(this.getView().byId("idFirstTable").getColumns()[0]);
						if (finalItems[i].LocEdit === "X") {
							this.getView().getModel("EnableModel").setProperty("/EnableSelect", "NO");
							this.getView().getModel("EnableModel").setProperty("/EnableInput", "YES");
						}
						this.getView().byId("empId").setEnabled(true);
						this.getView().byId("empId").setValue("");
						this.getView().byId("idNonEmpTable").setVisible(false);
						this.getView().byId("idCheckBox").setSelected(false);
						this.getView().getModel("NonEmpModel").setProperty("/Items", []);
						var status = this.getView().getModel("DetailModel").getData().Status;
						var companyGuest = this.getView().getModel("DetailModel").getData().TravelCategory;

						this.getView().byId('previewcolumn').setVisible(false);
						if (companyGuest == 'Company Guest') {
							this.getView().byId('previewcolumn').setVisible(true);

						}

						var finalStatusString;
						if (status === "CLOSED") {
							finalStatusString = "Trip Details" + "(" + status + ")";
						} else {
							finalStatusString = "Trip Details";
						}
						this.getView().byId("employeePanel").setHeaderText(finalStatusString);

						//	$("idNonEmpTable").remove();
						//	$("idFirstTable").add();
						break;
						//this.byId("locationBeginSelect").destroy();
						//this.byId("locationEndSelect").destroy();
					}
				}
			}
			if (tripNumber === "YES") {

				this.getView().getModel("EnableModel").setProperty("/EnableMessagePage", "NO");
				this.getView().getModel("EnableModel").setProperty("/EnablePanel", "YES");
				this.getView().getModel("EnableModel").setProperty("/EnableFormTable", "NO");
				this.getView().getModel("EnableModel").setProperty("/EnableCheckBox", "YES");
				this.getView().getModel("EnableModel").setProperty("/EnableEmpTable", "NO");
				this.getView().getModel("EnableModel").setProperty("/EnableEmpSplTable", "NO");
				this.getView().getModel("EnableModel").setProperty("/EnableNonEmpTable", "YES");
				this.getView().getModel("EnableModel").setProperty("/EnableNonEmpSplTable", "NO");
				//	this.getView().getModel("EnableModel").setProperty("/EnableOtherfields", "NO");
				this.getView().byId("retrievedEmpLabel").setVisible(false);
				this.getView().byId("retrievedEmpName").setVisible(false);
				this.getView().byId("retrievedEmpName").setText("");
				this.getView().getModel("NonEmpModel").setProperty("/Items", []);
				this.getView().byId("idFirstTable").setVisible(false);
				this.getView().byId("idCheckBox").setSelected(false);
				this.getView().byId("scrollContainerTable").scrollToElement(this.getView().byId("idNonEmpTable").getColumns()[0]);
				//to display ename
				this.getView().getModel("EnableModel").setProperty("/eName", "");
				//	$("idFirstTable").remove();
				//	$("idNonEmpTable").add();

				var aColumns = this.getView().byId("idNonEmpTable").getColumns();

				for (var z = 0; z < aColumns.length; z++) {
					if (aColumns[z].getHeader().getText() === "Vehicle Requisition") {
						requisitionNonEmpIndex = z;
					}
					if (aColumns[z].getHeader().getText() === "Location Begin") {
						locBeginNonEmpIndex = z;
					}
					if (aColumns[z].getHeader().getText() === "Location End") {
						locEndNonEmpIndex = z;
					}
					if (aColumns[z].getHeader().getText() === "Begin Date") {
						dateBeginNinEmpIndex = z;
					}
					if (aColumns[z].getHeader().getText() === "Begin Time") {
						timeBeginNonEmpIndex = z;
					}
					if (aColumns[z].getHeader().getText() === "End Date") {
						dateEndNonEmpIndex = z;
					}
					if (aColumns[z].getHeader().getText() === "Mobile Number") {
						mobNumNonEmpIndex = z;
					}
					if (aColumns[z].getHeader().getText() === "Purpose") {
						purposeNonEmpIndex = z;
					}
					if (aColumns[z].getHeader().getText() === "Person Name") {
						personNameNonEmpIndex = z;
					}
				}
			}
			var filters = [];
			filters.push(new Filter({
				path: "Reinr",
				value1: tripNumber,
				operator: FilterOperator.EQ
			}));
			var sorter = [];
			sorter.push(new Sorter({
				path: "Reqnum",
				descending: true
			}));
			this.getOwnerComponent().getModel().read("/VehRequestSet", {
				filters: filters,
				sorter: sorter,
				success: function(oData) {
					var data = oData.results;
					this.getView().getModel("RequisitionModel").setProperty("/Items", data);
				}.bind(this),
				error: function(oError) {
					MessageBox.error("Error in getting Data");
				}.bind(this)

			});
		},
		/*onAfterRendering:function(){
			this.getView().byId("idFirstTable").getBinding("items").sort(new Sorter("Reqnum","desc"));
		},*/
		goBack: function() {
			this.getOwnerComponent().onNavBack();
		},
		removeLeadingZero: function(input) {
			return input.replace(/^0+/, "");
		},
		onSaveDetails: function(oEvent) {
			var aPayload = [];
			//	var attachment = this.getView().byId("attachment").getValue();
			//	var poNumber = this.getView().byId("PONum").getValue();

			// if (category === "Entitle" && (!poNumber || !attachment)) {
			// 	MessageBox.error("Please fill out both PO Number and Attachment fields for Entitled travel.");
			// 	this.getView().byId("saveDetailsEmp").setEnabled(true);
			// 	return;
			// }
			var aRows = this.getView().byId("idFirstTable").getItems();
			var aRowLength = aRows.length - 1;
			if (aRows[aRowLength].getCells()[requisitionIndex].getValue() === "") {
				oEvent.getSource().setEnabled(false);
			} else {
				MessageBox.error("Please press on Add new Requisition button and then save");
			}
			for (var i = 0; i < aRows.length; i++) {
				if (aRows[i].getCells()[requisitionIndex].getValue() === "") {
					var jsonObj;
					var timeBeg = aRows[i].getCells()[timeBeginIndex].getValue();
					var dateBeg = aRows[i].getCells()[dateBeginIndex].getDateValue();
					var dateEnd = aRows[i].getCells()[dateEndIndex].getDateValue();
					var locationBeg, locationEnd, locEdit = "O";
					var beginFlag = 0;
					var endFlag = 0;
					//var checkBoxflag = 0;
					var checkBoxStatus = this.getView().byId("idCheckBox").getSelected();
					/*	if (checkBoxStatus) {
							checkBoxflag = 1;
						}*/
					locationBeg = aRows[i].getCells()[locBeginIndex].getValue();
					locationEnd = aRows[i].getCells()[locEndIndex].getValue();
					var fromValues = this.getOwnerComponent().getModel("FromModel").getProperty("/fromValues");
					var toValues = this.getOwnerComponent().getModel("ToModel").getProperty("/toValues");
					for (var n = 0; n < fromValues.length; n++) {
						if (fromValues[n].From.toString().toLowerCase() === locationBeg.toString().toLowerCase()) {
							locationBeg = fromValues[n].From;
							beginFlag = 1;
							break;
						}
					}
					for (var p = 0; p < toValues.length; p++) {
						if (toValues[p].To.toString().toLowerCase() === locationEnd.toString().toLowerCase()) {
							locationEnd = toValues[p].To;
							endFlag = 1;
							break;
						}
					}
					if (beginFlag === 0 || endFlag === 0) {
						if (checkBoxStatus) {
							locEdit = "X";
						} else {
							MessageBox.error("Please select the checkbox for special locations");
							this.getView().byId("saveDetailsEmp").setEnabled(true);
							break;
						}
					}
					if (beginFlag === 1 && endFlag === 1) {
						if (checkBoxStatus) {
							MessageBox.error("Please unselect the checkbox as the given locations are not special locations");
							this.getView().byId("saveDetailsEmp").setEnabled(true);
							return;
						}
					}
					var mobileNum = aRows[i].getCells()[mobNumberIndex].getValue();
					var purpose = aRows[i].getCells()[purposeIndex].getValue();
					if (!locationBeg || !locationEnd || !dateBeg || !timeBeg || !mobileNum || !purpose) {
						MessageBox.error("Please enter Start Location,End Location,Begin Date, Begin Time and Purpose of the Requisition");
						this.getView().byId("saveDetailsEmp").setEnabled(true);
						break;
					} else {
						if (locationBeg === locationEnd) {
							MessageBox.error("Both Start and End Locations cannot be same");
							this.getView().byId("saveDetailsEmp").setEnabled(true);
							break;
						} else {
							if (mobileNum.length !== 10) {
								MessageBox.error("Mobile number should be of 10 digits");
								this.getView().byId("saveDetailsEmp").setEnabled(true);
								break;
							} else {
								/*if (!timeBeg.match(/^([1-9]|0[1-9]|1[0-2]):[0-5][0-9] ([AaPp][Mm])$/)) {
									MessageBox.error("Please enter Time in HH:MM AM/PM format");
								} else {*/
								var dateValidation = this.validateDate(dateBeg);
								if (dateValidation) {
									if (dateEnd >= dateBeg) {
										var finalDateAndTimeArray = timeBeg; // this.getDateandTimeSeperated(timeBeg);
										var fTime = finalDateAndTimeArray;
										dateBeg = this.resolveTimeDifference(dateBeg);
										dateEnd = this.resolveTimeDifference(dateEnd);
										//	fTime = fTime + ":00";
										jsonObj = {
											Reinr: this.required,
											LocationBeg: locationBeg,
											LocationEnd: locationEnd,
											DateBeg: dateBeg,
											TimeBeg: fTime,
											DateEnd: dateEnd, // aRows[i].getCells()[5].getValue(), 
											MobileNum: mobileNum,
											Purpose: purpose,
											LocEdit: locEdit
										};
										aPayload.push(jsonObj);
									} else {
										MessageBox.error("The Requisition End Date should be greaterthan or equal to Begin Date");
										this.getView().byId("saveDetailsEmp").setEnabled(true);
									}

								} else {
									MessageBox.error("The Vehicle Requisition Date should be greaterthan or equal to Today's Date");
									this.getView().byId("saveDetailsEmp").setEnabled(true);
								}
								/*								}*/
							}
						}
					}

				}
			}
			if (aPayload.length > 0) {
				var oModel = this.getOwnerComponent().getModel();
				var aDeferredGroups = oModel.getDeferredGroups();
				aDeferredGroups = aDeferredGroups.concat(["CreateGroup"]);
				oModel.setDeferredGroups(aDeferredGroups);
				for (var j = 0; j < aPayload.length; j++) {
					oModel.create("/VehReqPostSet", aPayload[j], {
						groupId: "CreateGroup"
					});
				}
				this.getView().setBusy(true);
				oModel.submitChanges({
					groupId: "CreateGroup",
					success: function(req, res) {
						var reqNum = res.data.__batchResponses[0].__changeResponses[0].data.Reqnum;
						if (reqNum !== "") {
							var mesg = "New Requisition" + " " + reqNum + " " + "has been created ";
							MessageBox.success(mesg, {
								onClose: function() {
									//this.reset();
									this.resetRequisitionsEmp();
								}.bind(this)
							});
						} else {
							MessageBox.error("Some problem has occurred in creating the Requisition");
						}
					}.bind(this),
					error: function(oError) {
						this.getView().setBusy(false);
						this.getView().byId("saveDetailsEmp").setEnabled(true);
						MessageBox.error(oError);
					}
				});
			}

			//	}
		},
		getDateandTimeSeperated: function(dateAndTime) {
			var time = dateAndTime;
			var hours = Number(time.match(/^(\d+)/)[1]);
			var minutes = Number(time.match(/:(\d+)/)[1]);
			var AMPM = time.match(/\s(.*)$/)[1];
			if (AMPM === "PM" && hours < 12) {
				hours = hours + 12;
			}
			if (AMPM === "AM" && hours === 12) {
				hours = hours - 12;
			}
			var sHours = hours.toString();
			var sMinutes = minutes.toString();
			if (hours < 10) {
				sHours = "0" + sHours;
			}
			if (minutes < 10) {
				sMinutes = "0" + sMinutes;
			}
			var finalTime = sHours + ":" + sMinutes;
			return finalTime;

			/*var time = dateAndTime.match(/(\d+):(\d+):(\d+) (\w)/);
			var hours = Number(time[1]);
			var minutes = Number(time[2]);
			var seconds = Number(time[3]);
			var meridian = time[4].toLowerCase();

			if (meridian === 'p' && hours < 12) {
				hours += 12;
			} else if (meridian === 'a' && hours === 12) {
				hours -= 12;
			}
			return [hours, minutes, seconds];*/

		},
		resolveTimeDifference: function(dateTime) {
			if (dateTime !== undefined && dateTime !== null && dateTime !== "") {
				var offSet = dateTime.getTimezoneOffset();
				var offSetVal = dateTime.getTimezoneOffset() / 60;
				var h = Math.floor(Math.abs(offSetVal));
				var m = Math.floor((Math.abs(offSetVal) * 60) % 60);
				dateTime = new Date(dateTime.setHours(h, m, 0, 0));
				return dateTime;
			}
			return null;
		},
		validateDate: function(beginDate) {
			var todayDate = new Date(new Date().setHours(0, 0, 0, 0));
			if (beginDate >= todayDate) {
				return true;
			} else {
				return false;
			}
		},
		onNewRowPress: function(oButton) {

			this.getView().getModel("RequisitionModel").getData().Items.push({
				Reinr: this.required,
				Reqnum: "",
				Reqdate: "",
				DateBeg: "",
				TimeBeg: "",
				DateEnd: "",
				LocationBeg: "",
				LocationEnd: "",
				MobileNum: this.mobileEmpNumber,
				Purpose: "",
				Status: ""
			});
			this.getView().getModel("RequisitionModel").refresh(true);
			this.getView().byId("scrollContainerTable").scrollToElement(this.getView().byId("idFirstTable").getColumns()[0]);
		},
		// onNewRowPressNonEmp: function() {
		// 	//	this.getView().getModel("RequisitionModel").getData().Items=[];
		// 	var eName = this.getView().getModel("EnableModel").getProperty("/eName");
		// 	var category = this.getView().byId("idCategory").getSelectedItem().getText();
		// 	var empId = this.getView().byId("empId").getValue();
		// 	var empIdEnable = this.getView().byId("empId").getEnabled();
		// 	this.empId = empId;
		// 	var personName = this.getView().byId("nonEmpName").getValue();
		// 	if (category === "Employee") {
		// 		if (!empIdEnable) {
		// 			this.getView().getModel("NonEmpModel").getData().Items.push({
		// 				Reqnum: "",
		// 				DateBeg: "",
		// 				TimeBeg: "",
		// 				DateEnd: "",
		// 				LocationBeg: "",
		// 				LocationEnd: "",
		// 				MobileNum: "",
		// 				Purpose: "",
		// 				EmpName: eName
		// 			});
		// 		} else {
		// 			MessageBox.error("Please enter Employee ID and Click on Search button for Employee Name");
		// 		}
		// 	} else {
		// 		if (personName) {
		// 			this.getView().byId("nonEmpName").setEnabled(false);
		// 			this.getView().getModel("NonEmpModel").getData().Items.push({
		// 				Reqnum: "",
		// 				DateBeg: "",
		// 				TimeBeg: "",
		// 				DateEnd: "",
		// 				LocationBeg: "",
		// 				LocationEnd: "",
		// 				MobileNum: "",
		// 				Purpose: "",
		// 				EmpName: this.getView().byId("nonEmpName").getValue()
		// 			});
		// 		} else {
		// 			MessageBox.error("Please Enter Name of the Person");
		// 		}

		// 	}

		// 	this.getView().getModel("NonEmpModel").refresh(true);
		// },
		// onNewRowPressNonEmp: function() {
		// 	var eName = this.getView().getModel("EnableModel").getProperty("/eName");
		// 	var category = this.getView().byId("idCategory").getSelectedItem().getText();
		// 	var empId = this.getView().byId("empId").getValue();
		// 	var empIdEnable = this.getView().byId("empId").getEnabled();
		// 	this.empId = empId;
		// 	var personName = this.getView().byId("nonEmpName").getValue();

		// 	// Prepare the new row data
		// 	var newRow = {
		// 		Reqnum: "",
		// 		DateBeg: "",
		// 		TimeBeg: "",
		// 		DateEnd: "",
		// 		LocationBeg: "",
		// 		LocationEnd: "",
		// 		MobileNum: "",
		// 		Purpose: "",
		// 		EmpName: category === "Employee" ? eName : personName
		// 	};

		// 	if (category === "Employee") {
		// 		if (empIdEnable) {
		// 			// Clone the new row data to avoid reference issues
		// 			var items = this.getView().getModel("NonEmpModel").getData().Items;
		// 			items.push(Object.assign({}, newRow)); // Create a new object for each row
		// 			this.getView().getModel("NonEmpModel").setData({
		// 				Items: items
		// 			});
		// 		} else {
		// 			MessageBox.error("Please enter Employee ID and Click on Search button for Employee Name");
		// 		}
		// 	} else {
		// 		if (personName) {
		// 		//	this.getView().byId("nonEmpName").setEnabled(false);
		// 			// Clone the new row data to avoid reference issues
		// 			var items = this.getView().getModel("NonEmpModel").getData().Items;
		// 			items.push(Object.assign({}, newRow)); // Create a new object for each row
		// 			this.getView().getModel("NonEmpModel").setData({
		// 				Items: items
		// 			});
		// 		} else {
		// 			MessageBox.error("Please Enter Name of the Person");
		// 		}
		// 	}

		// 	this.getView().getModel("NonEmpModel").refresh(true);
		// },
		onNewRowPressNonEmp: function() {
			var eName = this.getView().getModel("EnableModel").getProperty("/eName");
			var category = this.getView().byId("idCategory").getSelectedItem().getText();
			var empId = this.getView().byId("empId").getValue();
			var empIdEnable = this.getView().byId("empId").getEnabled();
			var personName = this.getView().byId("nonEmpName").getValue();

			var newRow = {
				Reqnum: "",
				DateBeg: "",
				TimeBeg: "",
				DateEnd: "",
				LocationBeg: "",
				LocationEnd: "",
				MobileNum: "",
				Purpose: "",
				EmpName: category === "Employee" ? eName : personName
			};

			var model = this.getView().getModel("NonEmpModel");
			var items = model.getProperty("/Items");

			if (category === "Employee") {
				if (empIdEnable && empId) {
					if (eName) {
						var newRowClone = JSON.parse(JSON.stringify(newRow));
						items.push(newRowClone);
						model.setProperty("/Items", items);
					} else {
						MessageBox.error("Employee Name is missing for the selected Employee");
					}
				} else {
					MessageBox.error("Please enter Employee ID and Click on Search button for Employee Name");
				}
			} else {
				if (personName) {
					var newRowClone = JSON.parse(JSON.stringify(newRow));
					items.push(newRowClone);
					model.setProperty("/Items", items);
				} else {
					MessageBox.error("Please Enter Name of the Person");
				}
			}

			var oTable = this.getView().byId("idTable");
			oTable.getBinding("items").refresh();

			model.refresh(true);
		},
		// onPressNonEmpButton: function(oEvent) {
		// 			//this.getView().byId("idNonEmpTable").removeItem(oEvent.getSource().getParent());
		// 			var index = oEvent.getSource().getParent().getBindingContextPath().split("/")[2];
		// 			this.getView().getModel("NonEmpModel").getData().Items.splice(index, 1);
		// 			this.getView().getModel("NonEmpModel").refresh(true);
		// 			this.getView().byId("nonEmpName").setValue("");
		// 			this.getView().byId("nonEmpName").setEnabled(true);
		// 		},
		onPressNonEmpButton: function(oEvent) {
			// Get the table row index from the context path of the clicked item
			var index = oEvent.getSource().getParent().getBindingContextPath().split("/")[2];

			// Ensure that the model and data are accessible before making any modifications
			var oModel = this.getView().getModel("NonEmpModel");
			var oData = oModel.getData();

			if (oData && oData.Items && oData.Items.length > index) {
				// Remove the item from the data array
				oData.Items.splice(index, 1);

				// Instead of using oModel.refresh(true), update the model directly
				// This will notify the view of the change and trigger a re-binding of the table
				oModel.setProperty("/Items", oData.Items);

				// Clear the input fields and reset their state
				var oNonEmpNameField = this.getView().byId("nonEmpName");
				if (oNonEmpNameField) {
					// If needed, you can clear the value here as well
					// oNonEmpNameField.setValue(""); 
					oNonEmpNameField.setEnabled(true);
				} else {
					console.error("Field 'nonEmpName' not found!");
				}
			} else {
				console.error("Invalid index or data structure is not available!");
			}
		},

		onNewRowEmpEditORDelete: function(oEvent) {
			if (!oEvent.getSource().getParent().getCells()[0].getValue()) {
				var index = oEvent.getSource().getParent().getBindingContextPath().split("/")[2];
				this.getView().getModel("RequisitionModel").getData().Items.splice(index, 1);
				this.getView().getModel("RequisitionModel").refresh(true);
			} else {
				//code to enable existing requisitions
				//messagebox to confirm enable
				var reqnumber = oEvent.getSource().getParent().getCells()[0].getValue();
				var items = this.getView().getModel("RequisitionModel").getProperty("/Items");
				var iLength = items.length;
				for (var i = 0; i < iLength; i++) {
					if (items[i].Reqnum === reqnumber) {

						if (items[i].Status !== "CLOSED") {
							var cellNum = oEvent.getSource().getParent().getCells().length;
							for (var j = 2; j < cellNum; j++) {
								oEvent.getSource().getParent().getCells()[j].setEnabled(true);
							}
						} else {
							MessageBox.error("This Requisition has been Closed");
						}
					}

				}
			}
		},
		resetRequisitionsEmp: function() {
			var filters = [];
			filters.push(new Filter({
				path: "Reinr",
				value1: this.required,
				operator: FilterOperator.EQ
			}));
			this.getOwnerComponent().getModel().read("/VehRequestSet", {
				filters: filters,
				success: function(oData) {
					var data = oData.results;
					this.getView().getModel("RequisitionModel").setProperty("/Items", data);
					//this.getView().byId("idMobileNumber").setEnabled(false);
					this.getView().setBusy(false);
					this.getView().byId("saveDetailsEmp").setEnabled(true);
				}.bind(this),
				error: function(oError) {
					this.getView().setBusy(false);
					sap.m.MessageToast.show("Error in getting data");
					this.getView().byId("saveDetailsEmp").setEnabled(true);
				}.bind(this)

			});
		},
		onCheckBoxChange: function(oEvent) {

			oCheckBox = oEvent.getSource();
			checkBox = oCheckBox.getSelected();

		}, //working,
		// onSaveDetailsNonEmp: function(oEvent) {

		// 	var aRows = this.getView().byId("idNonEmpTable").getItems();
		// 	var attachment = this.getView().byId("attachment").getValue();
		// 	// this.onUploadPress();
		// 	if (aRows.length > 0) {
		// 		oEvent.getSource().setEnabled(false);
		// 		var category = this.getView().byId("idCategory").getSelectedItem().getText();
		// 		var entitle = this.getView().byId("idEntitle").getSelectedItem().getText();
		// 		var nonEmpName = this.getView().byId("nonEmpName").getValue();
		// 		var oModel = this.getOwnerComponent().getModel();
		// 		var aDeferredGroups = oModel.getDeferredGroups();

		// 		var aPayload = [];
		// 		// soc by Bhavesh
		// 		var poNumber = this.getView().byId("PONum").getValue();
		// 		if (category === 'Company Guest' && entitle === "Entitle" && (!poNumber || !attachment)) {
		// 			MessageBox.error("Please fill out both PO Number and Attachment fields for Entitled travel.");
		// 			this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 			return;
		// 		}
		// 		var tripkm = checkBox;

		// 		// eoc by Bhavesh
		// 		var jsonObjEmp, jsonObj, finalDateAndTimeArrayNonEmp, fTimeNonEmp;
		// 		var locationBeg, locationEnd, locEdit = "O";
		// 		var beginFlag = 0;
		// 		var endFlag = 0;
		// 		//	var checkBoxflag = 0;
		// 		var checkBoxStatus = this.getView().byId("idCheckBox").getSelected();

		// 		locationBeg = aRows[0].getCells()[locBeginNonEmpIndex].getValue();
		// 		locationEnd = aRows[0].getCells()[locEndNonEmpIndex].getValue();
		// 		var fromValues = this.getOwnerComponent().getModel("FromModel").getProperty("/fromValues");
		// 		var toValues = this.getOwnerComponent().getModel("ToModel").getProperty("/toValues");
		// 		for (var n = 0; n < fromValues.length; n++) {
		// 			if (fromValues[n].From.toString().toLowerCase() === locationBeg.toString().toLowerCase()) {
		// 				locationBeg = fromValues[n].From;
		// 				beginFlag = 1;
		// 				break;
		// 			}
		// 		}
		// 		for (var p = 0; p < toValues.length; p++) {
		// 			if (toValues[p].To.toString().toLowerCase() === locationEnd.toString().toLowerCase()) {
		// 				locationEnd = toValues[p].To;
		// 				endFlag = 1;
		// 				break;
		// 			}
		// 		}
		// 		if (beginFlag === 0 || endFlag === 0) {
		// 			if (checkBoxStatus) {
		// 				locEdit = "X";
		// 			} else {
		// 				MessageBox.error("Please select the checkbox for special locations");
		// 				this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 				return;
		// 			}
		// 		}
		// 		if (beginFlag === 1 && endFlag === 1) {
		// 			if (checkBoxStatus) {
		// 				MessageBox.error("Please unselect the checkbox as the given locations are not special locations");
		// 				this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 				return;
		// 			}
		// 		}

		// 		if (category == "Employee") {
		// 			if (aRows.length !== 0) {

		// 				jsonObjEmp = {
		// 					TravelCategory: category,
		// 					CategoryName: this.getView().getModel("EnableModel").getProperty("/eName"),
		// 					LocationBeg: locationBeg,
		// 					LocationEnd: locationEnd,
		// 					Ebeln: poNumber,
		// 					TripKm: tripkm,

		// 					DateBeg: aRows[0].getCells()[dateBeginNinEmpIndex].getDateValue(),
		// 					TimeBeg: aRows[0].getCells()[timeBeginNonEmpIndex].getValue(),
		// 					DateEnd: aRows[0].getCells()[dateEndNonEmpIndex].getDateValue(),
		// 					MobileNum: aRows[0].getCells()[mobNumNonEmpIndex].getValue(),
		// 					Purpose: aRows[0].getCells()[purposeNonEmpIndex].getValue(),
		// 					Ename: aRows[0].getCells()[personNameNonEmpIndex].getValue(),
		// 					LocEdit: locEdit,
		// 					// PoNumber: poNumber,
		// 					NontripEmpid: this.empId
		// 				};
		// 				console.log("Payloadd",jsonObjEmp)
		// 				aPayload.push(jsonObjEmp);
		// 				if (!aPayload[0].LocationBeg || !aPayload[0].LocationEnd || !aPayload[0].DateBeg || !aPayload[0].MobileNum || !aPayload[0].TimeBeg ||
		// 					!aPayload[0].Purpose) {
		// 					MessageBox.error(
		// 						"Please enter LocationBegin, LocationEnd, Begin Date, Begin Time , Purpose and Mobile number details to create a Trip");
		// 					this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 				} else {
		// 					if (aPayload[0].MobileNum.length === 10) {
		// 						if (aPayload[0].LocationBeg !== aPayload[0].LocationEnd) {

		// 							var dateValidationNonEmp = this.validateDate(aPayload[0].DateBeg);
		// 							if (dateValidationNonEmp) {
		// 								if (aPayload[0].DateEnd >= aPayload[0].DateBeg) {
		// 									aPayload[0].DateBeg = this.resolveTimeDifference(aPayload[0].DateBeg);
		// 									aPayload[0].DateEnd = this.resolveTimeDifference(aPayload[0].DateEnd);
		// 									finalDateAndTimeArrayNonEmp = aPayload[0].TimeBeg; //this.getDateandTimeSeperated(aPayload[0].TimeBeg); 
		// 									fTimeNonEmp = finalDateAndTimeArrayNonEmp;
		// 									//		fTimeNonEmp = fTimeNonEmp + ":00";
		// 									aPayload[0].TimeBeg = fTimeNonEmp;
		// 									aDeferredGroups = aDeferredGroups.concat(["CreateNOnEmpGroup"]);
		// 									oModel.setDeferredGroups(aDeferredGroups);
		// 									for (var l = 0; l < aPayload.length; l++) {
		// 										oModel.create("/VehReqPostSet", aPayload[l], {
		// 											groupId: "CreateNOnEmpGroup"
		// 										});
		// 									}
		// 									this.getView().setBusy(true);
		// 									oModel.submitChanges({
		// 										groupId: "CreateNOnEmpGroup",
		// 										success: function(req, res) {
		// 											var value = res.data.__batchResponses[0].__changeResponses[0].data.Reinr;
		// 											if (value !== "") {
		// 												var message = "New Trip" + " " + value + " " + "has been created";
		// 												MessageBox.success(message);
		// 												this.getView().getModel("NonEmpModel").setProperty("/Items", []);
		// 												this.getView().getModel("NonEmpModel").refresh(true);
		// 												this.getOwnerComponent().getModel("LocalModel").refresh(true);
		// 												this.oModel = this.getOwnerComponent().getModel();
		// 												this.oModel.read("/ZTRAVELREQ", {
		// 													success: function(oData) {
		// 														var data = oData.results;
		// 														this.getOwnerComponent().getModel("LocalModel").setProperty("/Items", data);
		// 														this.getView().getModel("LocalModel").refresh(true);
		// 														this.getView().byId("empId").setEnabled(true);
		// 														this.getView().byId("empId").setValue("");
		// 														this.getView().setBusy(false);
		// 														this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 														this.getOwnerComponent().getRouter().navTo("object", {
		// 															key: value
		// 														});
		// 														this.getView().byId("scrollContainerTable").scrollToElement(this.getView().byId("idFirstTable").getColumns()[0]);

		// 													}.bind(this),
		// 													error: function(oError) {
		// 														this.getView().setBusy(false);
		// 														sap.m.MessageToast.show("Error in getting data");
		// 													}.bind(this)

		// 												});
		// 												this.getView().getModel("RequisitionModel").refresh(true);

		// 												// Store the requisition number here
		// 												this.reqnum = value;
		// 												this.onUploadPress();
		// 												this._clearFields();
		// 												this.getView().byId("nonEmpName").setValue("");
		// 												this.getView().byId("retrievedEmpLabel").setVisible(false);
		// 												this.getView().byId("retrievedEmpName").setVisible(false);
		// 											}
		// 										}.bind(this),
		// 										error: function(oError) {
		// 											this.getView().setBusy(false);
		// 											MessageBox.error("Error in creating Requisitions");

		// 										}
		// 									});
		// 								} else {
		// 									MessageBox.error("The Requisition End Date should be greaterthan or equal to Begin Date");
		// 									this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 								}

		// 							} else {
		// 								MessageBox.error("The Vehicle Requisition Date should be greaterthan or equal to Today's Date");
		// 								this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 							}
		// 							/*	}*/
		// 						} else {
		// 							MessageBox.error("Start and End locations cannot be same");
		// 							this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 						}
		// 					} else {
		// 						MessageBox.error("Mobile Number should be of 10 Digits");
		// 						this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 					}
		// 				}
		// 			} else {
		// 				MessageBox.error("Please enter Employee ID and add new requisition for saving details");
		// 				this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 			}
		// 		} else {
		// 			if (aRows.length !== 0) {

		// 				jsonObj = {
		// 					TravelCategory: category,
		// 					CategoryName: nonEmpName,
		// 					LocationBeg: locationBeg,
		// 					LocationEnd: locationEnd,
		// 					TripKm: tripkm,
		// 					DateBeg: aRows[0].getCells()[dateBeginNinEmpIndex].getDateValue(),
		// 					TimeBeg: aRows[0].getCells()[timeBeginNonEmpIndex].getValue(),
		// 					DateEnd: aRows[0].getCells()[dateEndNonEmpIndex].getDateValue(),
		// 					MobileNum: aRows[0].getCells()[mobNumNonEmpIndex].getValue(),
		// 					Purpose: aRows[0].getCells()[purposeNonEmpIndex].getValue(),
		// 					Ename: aRows[0].getCells()[personNameNonEmpIndex].getValue(),
		// 					LocEdit: locEdit,
		// 					Ebeln: poNumber
		// 				};
		// 				console.log("Payloadd",jsonObjEmp)
		// 				aPayload.push(jsonObj);
		// 				if (!aPayload[0].LocationBeg || !aPayload[0].LocationEnd || !aPayload[0].DateBeg || !aPayload[0].MobileNum || !aPayload[0].TimeBeg ||
		// 					!aPayload[0].Purpose) {
		// 					MessageBox.error("Please enter LocationBegin ,LocationEnd,Begin Date,Begin Time, Mobile number and Purpose of the Trip");
		// 					this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 				} else {
		// 					if (aPayload[0].MobileNum.length === 10) {
		// 						if (aPayload[0].LocationBeg !== aPayload[0].LocationEnd) {

		// 							var dateValidation = this.validateDate(aPayload[0].DateBeg);
		// 							if (dateValidation) {
		// 								if (aPayload[0].DateEnd >= aPayload[0].DateBeg) {
		// 									aPayload[0].DateBeg = this.resolveTimeDifference(aPayload[0].DateBeg);
		// 									aPayload[0].DateEnd = this.resolveTimeDifference(aPayload[0].DateEnd);
		// 									finalDateAndTimeArrayNonEmp = aPayload[0].TimeBeg; //this.getDateandTimeSeperated(aPayload[0].TimeBeg); //
		// 									fTimeNonEmp = finalDateAndTimeArrayNonEmp;
		// 									//		fTimeNonEmp = fTimeNonEmp + ":00";
		// 									aPayload[0].TimeBeg = fTimeNonEmp;
		// 									aDeferredGroups = aDeferredGroups.concat(["CreateNOnEmpGroup"]);
		// 									oModel.setDeferredGroups(aDeferredGroups);
		// 									for (var k = 0; k < aPayload.length; k++) {
		// 										oModel.create("/VehReqPostSet", aPayload[k], {
		// 											groupId: "CreateNOnEmpGroup"
		// 										});
		// 									}
		// 									this.getView().setBusy(true);
		// 									oModel.submitChanges({
		// 										groupId: "CreateNOnEmpGroup",
		// 										success: function(req, res) {
		// 											var value = res.data.__batchResponses[0].__changeResponses[0].data.Reinr;
		// 											if (value !== "") {
		// 												var message = "New Trip" + " " + value + " " + "has been created";
		// 												MessageBox.success(message);

		// 												this.getView().getModel("NonEmpModel").setProperty("/Items", []);
		// 												this.getView().getModel("NonEmpModel").refresh(true);
		// 												this.getOwnerComponent().getModel("LocalModel").refresh(true);
		// 												this.oModel = this.getOwnerComponent().getModel();
		// 												this.oModel.read("/ZTRAVELREQ", {
		// 													success: function(oData) {
		// 														var data = oData.results;

		// 														this.getOwnerComponent().getModel("LocalModel").setProperty("/Items", data);
		// 														this.getView().byId("empId").setEnabled(true);
		// 														this.getView().byId("empId").setValue("");
		// 														this.getView().setBusy(false);
		// 														this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 														this.getOwnerComponent().getRouter().navTo("object", {
		// 															key: value
		// 														});

		// 													}.bind(this),
		// 													error: function(oError) {
		// 														this.getView().setBusy(false);
		// 														sap.m.MessageToast.show("Error in getting data");
		// 													}.bind(this)

		// 												});
		// 												this.getView().getModel("RequisitionModel").refresh(true);

		// 												// Store the requisition number here
		// 												this.reqnum = value;
		// 												this.onUploadPress();
		// 												this._clearFields();
		// 												this.getView().byId("nonEmpName").setEnabled(true);
		// 												this.getView().byId("nonEmpName").setValue("");
		// 											}
		// 										}.bind(this),
		// 										error: function(oError) {
		// 											this.getView().setBusy(false);
		// 											MessageBox.error("Error in creating Requisitions");
		// 										}
		// 									});
		// 								} else {
		// 									MessageBox.error("The Requisition End Date should be greaterthan or equal to Begin Date");
		// 									this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 								}

		// 							} else {
		// 								MessageBox.error("The Vehicle Requisition Date should be greaterthan or equal to Today's Date");
		// 								this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 							}
		// 							/*	}*/
		// 						} else {
		// 							MessageBox.error("Start and End locations cannot be same");
		// 							this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 						}
		// 					} else {
		// 						MessageBox.error("Mobile Number should be of 10 Digits");
		// 						this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 					}
		// 				}
		// 			} else {
		// 				MessageBox.error("Please enter name of the person and add new requisition for saving details");
		// 				this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 			}
		// 		}

		// 	} else {
		// 		MessageBox.error("Please press on Add new Requisition button and then save");
		// 		oEvent.getSource().setEnabled(true);
		// 	}

		// },

		// ======================
		// 	onSaveDetailsNonEmp: function(oEvent) {
		//     var aRows = this.getView().byId("idNonEmpTable").getItems();
		//     var attachment = this.getView().byId("attachment").getValue();

		//     if (aRows.length > 0) {
		//         oEvent.getSource().setEnabled(false);
		//         var category = this.getView().byId("idCategory").getSelectedItem().getText();
		//         var entitle = this.getView().byId("idEntitle").getSelectedItem().getText();
		//         var nonEmpName = this.getView().byId("nonEmpName").getValue();
		//         var oModel = this.getOwnerComponent().getModel();
		//         var aDeferredGroups = oModel.getDeferredGroups();

		//         var aPayload = [];
		//         var poNumber = this.getView().byId("PONum").getValue();
		//         if (category === 'Company Guest' && entitle === "Entitle" && (!poNumber || !attachment)) {
		//             MessageBox.error("Please fill out both PO Number and Attachment fields for Entitled travel.");
		//             this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		//             return;
		//         }

		//         // Loop through all rows and process them
		//         aRows.forEach(function(oRow) {
		//             var locationBeg = oRow.getCells()[locBeginNonEmpIndex].getValue();
		//             var locationEnd = oRow.getCells()[locEndNonEmpIndex].getValue();
		//             var fromValues = this.getOwnerComponent().getModel("FromModel").getProperty("/fromValues");
		//             var toValues = this.getOwnerComponent().getModel("ToModel").getProperty("/toValues");

		//             var beginFlag = 0, endFlag = 0, locEdit = "O";
		//             var checkBoxStatus = this.getView().byId("idCheckBox").getSelected();

		//             // Check if the locations are valid
		//             for (var n = 0; n < fromValues.length; n++) {
		//                 if (fromValues[n].From.toString().toLowerCase() === locationBeg.toString().toLowerCase()) {
		//                     locationBeg = fromValues[n].From;
		//                     beginFlag = 1;
		//                     break;
		//                 }
		//             }

		//             for (var p = 0; p < toValues.length; p++) {
		//                 if (toValues[p].To.toString().toLowerCase() === locationEnd.toString().toLowerCase()) {
		//                     locationEnd = toValues[p].To;
		//                     endFlag = 1;
		//                     break;
		//                 }
		//             }

		//             if (beginFlag === 0 || endFlag === 0) {
		//                 if (checkBoxStatus) {
		//                     locEdit = "X";
		//                 } else {
		//                     MessageBox.error("Please select the checkbox for special locations");
		//                     this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		//                     return;
		//                 }
		//             }

		//             if (beginFlag === 1 && endFlag === 1) {
		//                 if (checkBoxStatus) {
		//                     MessageBox.error("Please unselect the checkbox as the given locations are not special locations");
		//                     this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		//                     return;
		//                 }
		//             }

		//             // Prepare payload for the current row
		//             var jsonObj = {
		//                 TravelCategory: category,
		//                 CategoryName: (category === "Employee") ? this.getView().getModel("EnableModel").getProperty("/eName") : nonEmpName,
		//                 LocationBeg: locationBeg,
		//                 LocationEnd: locationEnd,
		//                 TripKm: checkBoxStatus,  // Assuming you want to add the checkbox status here
		//                 DateBeg: oRow.getCells()[dateBeginNinEmpIndex].getDateValue(),
		//                 TimeBeg: oRow.getCells()[timeBeginNonEmpIndex].getValue(),
		//                 DateEnd: oRow.getCells()[dateEndNonEmpIndex].getDateValue(),
		//                 MobileNum: oRow.getCells()[mobNumNonEmpIndex].getValue(),
		//                 Purpose: oRow.getCells()[purposeNonEmpIndex].getValue(),
		//                 Ename: oRow.getCells()[personNameNonEmpIndex].getValue(),
		//                 LocEdit: locEdit,
		//                 Ebeln: poNumber
		//             };

		//             // Check if required fields are filled
		//             if (!jsonObj.LocationBeg || !jsonObj.LocationEnd || !jsonObj.DateBeg || !jsonObj.MobileNum || !jsonObj.TimeBeg || !jsonObj.Purpose) {
		//                 MessageBox.error("Please enter LocationBegin, LocationEnd, Begin Date, Begin Time , Purpose and Mobile number details to create a Trip");
		//                 this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		//                 return;
		//             }

		//             if (jsonObj.MobileNum.length === 10) {
		//                 if (jsonObj.LocationBeg !== jsonObj.LocationEnd) {
		//                     var dateValidationNonEmp = this.validateDate(jsonObj.DateBeg);
		//                     if (dateValidationNonEmp) {
		//                         if (jsonObj.DateEnd >= jsonObj.DateBeg) {
		//                             jsonObj.DateBeg = this.resolveTimeDifference(jsonObj.DateBeg);
		//                             jsonObj.DateEnd = this.resolveTimeDifference(jsonObj.DateEnd);
		//                             var finalDateAndTimeArrayNonEmp = jsonObj.TimeBeg;
		//                             var fTimeNonEmp = finalDateAndTimeArrayNonEmp;
		//                             jsonObj.TimeBeg = fTimeNonEmp;
		//                             aPayload.push(jsonObj); // Add the payload for each row
		//                         } else {
		//                             MessageBox.error("The Requisition End Date should be greater than or equal to Begin Date");
		//                             this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		//                             return;
		//                         }
		//                     } else {
		//                         MessageBox.error("The Vehicle Requisition Date should be greater than or equal to Today's Date");
		//                         this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		//                         return;
		//                     }
		//                 } else {
		//                     MessageBox.error("Start and End locations cannot be same");
		//                     this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		//                     return;
		//                 }
		//             } else {
		//                 MessageBox.error("Mobile Number should be of 10 Digits");
		//                 this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		//                 return;
		//             }
		//         }, this);  // Binding 'this' to maintain controller context

		//         // After processing all rows, submit the changes
		//         if (aPayload.length > 0) {
		//             aDeferredGroups = aDeferredGroups.concat(["CreateNonEmpGroup"]);
		//             oModel.setDeferredGroups(aDeferredGroups);
		//             aPayload.forEach(function(payload) {
		//                 oModel.create("/VehReqPostSet", payload, {
		//                     groupId: "CreateNonEmpGroup"
		//                 });
		//             });

		//             this.getView().setBusy(true);
		//             oModel.submitChanges({
		//                 groupId: "CreateNonEmpGroup",
		//                 success: function(req, res) {
		//                     var value = res.data.__batchResponses[0].__changeResponses[0].data.Reinr;
		//                     if (value !== "") {
		//                         MessageBox.success("New Trip " + value + " has been created");
		//                         this.getView().getModel("NonEmpModel").setProperty("/Items", []);
		//                         this.getView().getModel("NonEmpModel").refresh(true);
		//                         this.getOwnerComponent().getModel("LocalModel").refresh(true);
		//                         this.oModel = this.getOwnerComponent().getModel();
		//                         this.oModel.read("/ZTRAVELREQ", {
		//                             success: function(oData) {
		//                                 var data = oData.results;
		//                                 this.getOwnerComponent().getModel("LocalModel").setProperty("/Items", data);
		//                                 this.getView().byId("empId").setEnabled(true);
		//                                 this.getView().byId("empId").setValue("");
		//                                 this.getView().setBusy(false);
		//                                 this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		//                                 this.getOwnerComponent().getRouter().navTo("object", {
		//                                     key: value
		//                                 });
		//                             }.bind(this),
		//                             error: function(oError) {
		//                                 this.getView().setBusy(false);
		//                                 sap.m.MessageToast.show("Error in getting data");
		//                             }.bind(this)
		//                         });
		//                         this.getView().getModel("RequisitionModel").refresh(true);
		//                         this.reqnum = value;
		//                         this.onUploadPress();
		//                         this._clearFields();
		//                         this.getView().byId("nonEmpName").setValue("");
		//                     }
		//                 }.bind(this),  // Binding success callback to controller
		//                 error: function(oError) {
		//                     this.getView().setBusy(false);
		//                     MessageBox.error("Error in creating multiple  Requisitions create one at a time,");
		//                 }.bind(this)  // Binding error callback to controller
		//             });
		//         }
		//     } else {
		//         MessageBox.error("Please press on Add new Requisition button and then save");
		//         oEvent.getSource().setEnabled(true);
		//     }
		// }

		// ,
		//==========///////////////////
		// onSaveDetailsNonEmp: function(oEvent) {
		// 	var aRows = this.getView().byId("idNonEmpTable").getItems();
		// 	var attachment = this.getView().byId("attachment").getValue();

		// 	if (aRows.length > 0) {
		// 		oEvent.getSource().setEnabled(false);
		// 		var category = this.getView().byId("idCategory").getSelectedItem().getText();
		// 		var entitle = this.getView().byId("idEntitle").getSelectedItem().getText();
		// 		var nonEmpName = this.getView().byId("nonEmpName").getValue();
		// 		var oModel = this.getOwnerComponent().getModel();
		// 		var aDeferredGroups = oModel.getDeferredGroups();

		// 		var aPayload = [];
		// 		var poNumber = this.getView().byId("PONum").getValue();

		// 		// Validation for PO Number and Attachment for 'Entitle' category
		// 		if (category === 'Company Guest' && entitle === "Entitle" && (!poNumber || !attachment)) {
		// 			MessageBox.error("Please fill out both PO Number and Attachment fields for Entitled travel.");
		// 			this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 			return;
		// 		}

		// 		// Loop through all rows and process them
		// 		for (var i = 0; i < aRows.length; i++) {
		// 			var oRow = aRows[i];
		// 			var locationBeg = oRow.getCells()[locBeginNonEmpIndex].getValue();
		// 			var locationEnd = oRow.getCells()[locEndNonEmpIndex].getValue();
		// 			var fromValues = this.getOwnerComponent().getModel("FromModel").getProperty("/fromValues");
		// 			var toValues = this.getOwnerComponent().getModel("ToModel").getProperty("/toValues");

		// 			var beginFlag = 0,
		// 				endFlag = 0,
		// 				locEdit = "O";
		// 			var checkBoxStatus = this.getView().byId("idCheckBox").getSelected();

		// 			// Validate locationBegin
		// 			for (var n = 0; n < fromValues.length; n++) {
		// 				if (fromValues[n].From.toString().toLowerCase() === locationBeg.toString().toLowerCase()) {
		// 					locationBeg = fromValues[n].From;
		// 					beginFlag = 1;
		// 					break;
		// 				}
		// 			}

		// 			// Validate locationEnd
		// 			for (var p = 0; p < toValues.length; p++) {
		// 				if (toValues[p].To.toString().toLowerCase() === locationEnd.toString().toLowerCase()) {
		// 					locationEnd = toValues[p].To;
		// 					endFlag = 1;
		// 					break;
		// 				}
		// 			}

		// 			if (beginFlag === 0 || endFlag === 0) {
		// 				if (checkBoxStatus) {
		// 					locEdit = "X";
		// 				} else {
		// 					MessageBox.error("Please select the checkbox for special locations");
		// 					this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 					return;
		// 				}
		// 			}

		// 			if (beginFlag === 1 && endFlag === 1) {
		// 				if (checkBoxStatus) {
		// 					MessageBox.error("Please unselect the checkbox as the given locations are not special locations");
		// 					this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 					return;
		// 				}
		// 			}

		// 			// Prepare payload for the current row
		// 			var jsonObj = {
		// 				TravelCategory: category,
		// 				CategoryName: (category === "Employee") ? this.getView().getModel("EnableModel").getProperty("/eName") : nonEmpName,
		// 				LocationBeg: locationBeg,
		// 				LocationEnd: locationEnd,
		// 				TripKm: checkBoxStatus, // Assuming you want to add the checkbox status here
		// 				DateBeg: oRow.getCells()[dateBeginNinEmpIndex].getDateValue(),
		// 				TimeBeg: oRow.getCells()[timeBeginNonEmpIndex].getValue(),
		// 				DateEnd: oRow.getCells()[dateEndNonEmpIndex].getDateValue(),
		// 				MobileNum: oRow.getCells()[mobNumNonEmpIndex].getValue(),
		// 				Purpose: oRow.getCells()[purposeNonEmpIndex].getValue(),
		// 				Ename: oRow.getCells()[personNameNonEmpIndex].getValue(),
		// 				LocEdit: locEdit,
		// 				Ebeln: poNumber
		// 			};

		// 			// Check if required fields are filled
		// 			if (!jsonObj.LocationBeg || !jsonObj.LocationEnd || !jsonObj.DateBeg || !jsonObj.MobileNum || !jsonObj.TimeBeg || !jsonObj.Purpose) {
		// 				MessageBox.error(
		// 					"Please enter LocationBegin, LocationEnd, Begin Date, Begin Time , Purpose and Mobile number details to create a Trip");
		// 				this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 				return;
		// 			}

		// 			// Mobile Number validation
		// 			if (jsonObj.MobileNum.length !== 10) {
		// 				MessageBox.error("Mobile Number should be of 10 Digits");
		// 				this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 				return;
		// 			}

		// 			// Additional validations
		// 			if (jsonObj.LocationBeg !== jsonObj.LocationEnd) {
		// 				var dateValidationNonEmp = this.validateDate(jsonObj.DateBeg);
		// 				if (dateValidationNonEmp) {
		// 					if (jsonObj.DateEnd >= jsonObj.DateBeg) {
		// 						jsonObj.DateBeg = this.resolveTimeDifference(jsonObj.DateBeg);
		// 						jsonObj.DateEnd = this.resolveTimeDifference(jsonObj.DateEnd);
		// 						var finalDateAndTimeArrayNonEmp = jsonObj.TimeBeg;
		// 						var fTimeNonEmp = finalDateAndTimeArrayNonEmp;
		// 						jsonObj.TimeBeg = fTimeNonEmp;
		// 						aPayload.push(jsonObj); // Add the payload for each row
		// 					} else {
		// 						MessageBox.error("The Requisition End Date should be greater than or equal to Begin Date");
		// 						this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 						return;
		// 					}
		// 				} else {
		// 					MessageBox.error("The Vehicle Requisition Date should be greater than or equal to Today's Date");
		// 					this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 					return;
		// 				}
		// 			} else {
		// 				MessageBox.error("Start and End locations cannot be the same");
		// 				this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 				return;
		// 			}
		// 		}

		// 		// After processing all rows, submit the changes
		// 		if (aPayload.length > 0) {
		// 			aDeferredGroups = aDeferredGroups.concat(["CreateNonEmpGroup"]);
		// 			oModel.setDeferredGroups(aDeferredGroups);
		// 			aPayload.forEach(function(payload) {
		// 				oModel.create("/VehReqPostSet", payload, {
		// 					groupId: "CreateNonEmpGroup"
		// 				});
		// 			});

		// 			this.getView().setBusy(true);
		// 			oModel.submitChanges({
		// 				groupId: "CreateNonEmpGroup",
		// 				success: function(req, res) {
		// 					var value = res.data.__batchResponses && res.data.__batchResponses[0] && res.data.__batchResponses[0].__changeResponses[0].data
		// 						.Reinr;
		// 					if (value !== "") {
		// 						MessageBox.success("New Trip " + value + " has been created");
		// 						this.getView().getModel("NonEmpModel").setProperty("/Items", []);
		// 						this.getView().getModel("NonEmpModel").refresh(true);
		// 						this.getOwnerComponent().getModel("LocalModel").refresh(true);
		// 						this.oModel = this.getOwnerComponent().getModel();
		// 						this.oModel.read("/ZTRAVELREQ", {
		// 							success: function(oData) {
		// 								var data = oData.results;
		// 								this.getOwnerComponent().getModel("LocalModel").setProperty("/Items", data);
		// 								this.getView().byId("empId").setEnabled(true);
		// 								this.getView().byId("empId").setValue("");
		// 								this.getView().setBusy(false);
		// 								this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 								this.getOwnerComponent().getRouter().navTo("object", {
		// 									key: value
		// 								});
		// 							}.bind(this),
		// 							error: function(oError) {
		// 								this.getView().setBusy(false);
		// 								sap.m.MessageToast.show("Error in getting data");
		// 							}.bind(this)
		// 						});
		// 						this.getView().getModel("RequisitionModel").refresh(true);
		// 						this.reqnum = value;
		// 						this.onUploadPress();
		// 						this._clearFields();
		// 						this.getView().byId("nonEmpName").setValue("");
		// 					}
		// 				}.bind(this),
		// 				error: function(oError) {
		// 					this.getView().setBusy(false);
		// 					MessageBox.error("Error in creating multiple  Requisitions, create one at a time.");
		// 				}.bind(this)
		// 			});
		// 		}
		// 	} else {
		// 		MessageBox.error("Please press the Add new Requisition button and then save.");
		// 		oEvent.getSource().setEnabled(true);
		// 	}
		// },
		onSaveDetailsNonEmp: function(oEvent) {
			var aRows = this.getView().byId("idNonEmpTable").getItems();
			var attachment = this.getView().byId("attachment").getValue();

			if (aRows.length > 0) {
				oEvent.getSource().setEnabled(false);
				var category = this.getView().byId("idCategory").getSelectedItem().getText();
				var entitle = this.getView().byId("idEntitle").getSelectedItem().getText();
				var nonEmpName = this.getView().byId("nonEmpName").getValue();
				var oModel = this.getOwnerComponent().getModel();
				var aDeferredGroups = oModel.getDeferredGroups();

				var aPayload = [];
				var poNumber = this.getView().byId("PONum").getValue();

				// Validation for PO Number and Attachment for 'Entitle' category
				if (category === 'Company Guest' && entitle === "Entitle" && (!poNumber || !attachment)) {
					MessageBox.error("Please fill out both PO Number and Attachment fields for Entitled travel.");
					this.getView().byId("saveDetailsNonEmp").setEnabled(true);
					return;
				}

				// Loop through all rows and process them
				for (var i = 0; i < aRows.length; i++) {
					var oRow = aRows[i];
					var locationBeg = oRow.getCells()[locBeginNonEmpIndex].getValue();
					var locationEnd = oRow.getCells()[locEndNonEmpIndex].getValue();
					var fromValues = this.getOwnerComponent().getModel("FromModel").getProperty("/fromValues");
					var toValues = this.getOwnerComponent().getModel("ToModel").getProperty("/toValues");

					var beginFlag = 0,
						endFlag = 0,
						locEdit = "O";
					var checkBoxStatus = this.getView().byId("idCheckBox").getSelected();

					// Validate locationBegin
					for (var n = 0; n < fromValues.length; n++) {
						if (fromValues[n].From.toString().toLowerCase() === locationBeg.toString().toLowerCase()) {
							locationBeg = fromValues[n].From;
							beginFlag = 1;
							break;
						}
					}

					// Validate locationEnd
					for (var p = 0; p < toValues.length; p++) {
						if (toValues[p].To.toString().toLowerCase() === locationEnd.toString().toLowerCase()) {
							locationEnd = toValues[p].To;
							endFlag = 1;
							break;
						}
					}

					if (beginFlag === 0 || endFlag === 0) {
						if (checkBoxStatus) {
							locEdit = "X";
						} else {
							MessageBox.error("Please select the checkbox for special locations");
							this.getView().byId("saveDetailsNonEmp").setEnabled(true);
							return;
						}
					}

					if (beginFlag === 1 && endFlag === 1) {
						if (checkBoxStatus) {
							MessageBox.error("Please unselect the checkbox as the given locations are not special locations");
							this.getView().byId("saveDetailsNonEmp").setEnabled(true);
							return;
						}
					}

					// Prepare payload for the current row
					var jsonObj = {
						TravelCategory: category,
						CategoryName: (category === "Employee") ? this.getView().getModel("EmpNameModel").getProperty("/EmpName") // Use EmpName from EmpNameModel for Employee category
							: nonEmpName, // Fallback for non-employee category
						LocationBeg: locationBeg,
						LocationEnd: locationEnd,
						TripKm: checkBoxStatus, // Assuming you want to add the checkbox status here
						DateBeg: oRow.getCells()[dateBeginNinEmpIndex].getDateValue(),
						TimeBeg: oRow.getCells()[timeBeginNonEmpIndex].getValue(),
						DateEnd: oRow.getCells()[dateEndNonEmpIndex].getDateValue(),
						MobileNum: oRow.getCells()[mobNumNonEmpIndex].getValue(),
						Purpose: oRow.getCells()[purposeNonEmpIndex].getValue(),
						Ename: oRow.getCells()[personNameNonEmpIndex].getValue(),
						LocEdit: locEdit,
						Ebeln: poNumber
					};

					// Check if required fields are filled
					if (!jsonObj.LocationBeg || !jsonObj.LocationEnd || !jsonObj.DateBeg || !jsonObj.MobileNum || !jsonObj.TimeBeg || !jsonObj.Purpose) {
						MessageBox.error(
							"Please enter LocationBegin, LocationEnd, Begin Date, Begin Time , Purpose and Mobile number details to create a Trip");
						this.getView().byId("saveDetailsNonEmp").setEnabled(true);
						return;
					}

					// Mobile Number validation
					if (jsonObj.MobileNum.length !== 10) {
						MessageBox.error("Mobile Number should be of 10 Digits");
						this.getView().byId("saveDetailsNonEmp").setEnabled(true);
						return;
					}

					// Additional validations
					if (jsonObj.LocationBeg !== jsonObj.LocationEnd) {
						var dateValidationNonEmp = this.validateDate(jsonObj.DateBeg);
						if (dateValidationNonEmp) {
							if (jsonObj.DateEnd >= jsonObj.DateBeg) {
								jsonObj.DateBeg = this.resolveTimeDifference(jsonObj.DateBeg);
								jsonObj.DateEnd = this.resolveTimeDifference(jsonObj.DateEnd);
								var finalDateAndTimeArrayNonEmp = jsonObj.TimeBeg;
								var fTimeNonEmp = finalDateAndTimeArrayNonEmp;
								jsonObj.TimeBeg = fTimeNonEmp;
								aPayload.push(jsonObj); // Add the payload for each row
							} else {
								MessageBox.error("The Requisition End Date should be greater than or equal to Begin Date");
								this.getView().byId("saveDetailsNonEmp").setEnabled(true);
								return;
							}
						} else {
							MessageBox.error("The Vehicle Requisition Date should be greater than or equal to Today's Date");
							this.getView().byId("saveDetailsNonEmp").setEnabled(true);
							return;
						}
					} else {
						MessageBox.error("Start and End locations cannot be the same");
						this.getView().byId("saveDetailsNonEmp").setEnabled(true);
						return;
					}
				}

				// After processing all rows, submit the changes
				if (aPayload.length > 0) {
					aDeferredGroups = aDeferredGroups.concat(["CreateNonEmpGroup"]);
					oModel.setDeferredGroups(aDeferredGroups);
					aPayload.forEach(function(payload) {
						oModel.create("/VehReqPostSet", payload, {
							groupId: "CreateNonEmpGroup"
						});
					});

					this.getView().setBusy(true);
					oModel.submitChanges({
						groupId: "CreateNonEmpGroup",
						success: function(req, res) {
							var value = res.data.__batchResponses && res.data.__batchResponses[0] && res.data.__batchResponses[0].__changeResponses[0].data
								.Reinr;
							if (value !== "") {
								MessageBox.success("New Trip " + value + " has been created");
								this.getView().getModel("NonEmpModel").setProperty("/Items", []);
								this.getView().getModel("NonEmpModel").refresh(true);
								this.getOwnerComponent().getModel("LocalModel").refresh(true);
								this.oModel = this.getOwnerComponent().getModel();
								this.oModel.read("/ZTRAVELREQ", {
									success: function(oData) {
										var data = oData.results;
										this.getOwnerComponent().getModel("LocalModel").setProperty("/Items", data);
										this.getView().byId("empId").setEnabled(true);
										this.getView().byId("empId").setValue("");
										this.getView().setBusy(false);
										this.getView().byId("saveDetailsNonEmp").setEnabled(true);
										this.getOwnerComponent().getRouter().navTo("object", {
											key: value
										});
									}.bind(this),
									error: function(oError) {
										this.getView().setBusy(false);
										sap.m.MessageToast.show("Error in getting data");
									}.bind(this)
								});
								this.getView().getModel("RequisitionModel").refresh(true);
								this.reqnum = value;
								this.onUploadPress();
								this._clearFields();
								this.getView().byId("nonEmpName").setValue("");
							}
						}.bind(this),
						error: function(oError) {
							this.getView().setBusy(false);
							MessageBox.error("Error in creating multiple  Requisitions, create one at a time.");
						}.bind(this)
					});
				}
			} else {
				MessageBox.error("Please press the Add new Requisition button and then save.");
				oEvent.getSource().setEnabled(true);
			}
		},

		//=======================

		// 	onSaveDetailsNonEmp: function(oEvent) {
		//     var aRows = this.getView().byId("idNonEmpTable").getItems();
		//     var attachment = this.getView().byId("attachment").getValue();
		//     if (aRows.length > 0) {
		//         oEvent.getSource().setEnabled(false);
		//         var category = this.getView().byId("idCategory").getSelectedItem().getText();
		//         var entitle = this.getView().byId("idEntitle").getSelectedItem().getText();
		//         var nonEmpName = this.getView().byId("nonEmpName").getValue();
		//         var oModel = this.getOwnerComponent().getModel();
		//         var aDeferredGroups = oModel.getDeferredGroups();

		//         var aPayload = [];
		//         var poNumber = this.getView().byId("PONum").getValue();
		//         if (category === 'Company Guest' && entitle === "Entitle" && (!poNumber || !attachment)) {
		//             MessageBox.error("Please fill out both PO Number and Attachment fields for Entitled travel.");
		//             this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		//             return;
		//         }

		//         var jsonObj, finalDateAndTimeArrayNonEmp, fTimeNonEmp;
		//         var locationBeg, locationEnd, locEdit = "O";
		//         var beginFlag = 0;
		//         var endFlag = 0;
		//         var checkBoxStatus = this.getView().byId("idCheckBox").getSelected();

		//         // Get Location, Begin and End Date and Time
		//         locationBeg = aRows[0].getCells()[locBeginNonEmpIndex].getValue();
		//         locationEnd = aRows[0].getCells()[locEndNonEmpIndex].getValue();
		//         var dateBegin = aRows[0].getCells()[dateBeginNonEmpIndex].getDateValue();
		//         var timeBegin = aRows[0].getCells()[timeBeginNonEmpIndex].getValue();
		//         console.log("timeBegin--->",timeBegin);
		//         var dateEnd = aRows[0].getCells()[dateEndNonEmpIndex].getDateValue();

		//         // Combine Date and Time for Begin Date
		//         var beginDateTime = new Date(dateBegin);
		//         var timeParts = timeBegin.split(':');
		//         beginDateTime.setHours(timeParts[0]);
		//         beginDateTime.setMinutes(timeParts[1]);
		//         beginDateTime.setSeconds(timeParts[2] || 0);
		// 		console.log("Combined Datetime:--",beginDateTime);
		//         // Handle Begin and End Dates and Times
		//         jsonObj = {
		//             TravelCategory: category,
		//             CategoryName: nonEmpName,
		//             LocationBeg: locationBeg,
		//             LocationEnd: locationEnd,
		//             DateBeg: beginDateTime.toISOString(),
		//             TimeBeg: timeBegin,
		//             DateEnd: dateEnd.toISOString(),
		//             MobileNum: aRows[0].getCells()[mobNumNonEmpIndex].getValue(),
		//             Purpose: aRows[0].getCells()[purposeNonEmpIndex].getValue(),
		//             Ename: aRows[0].getCells()[personNameNonEmpIndex].getValue(),
		//             LocEdit: locEdit,
		//             Ebeln: poNumber
		//         };

		//         aPayload.push(jsonObj);

		//         // Log the payload
		//         console.log("Payload: ", aPayload);

		//         // Validation
		//         if (!jsonObj.LocationBeg || !jsonObj.LocationEnd || !jsonObj.DateBeg || !jsonObj.MobileNum || !jsonObj.TimeBeg ||
		//             !jsonObj.Purpose) {
		//             MessageBox.error("Please enter all required fields.");
		//             this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		//         } else {
		//             if (jsonObj.MobileNum.length === 10) {
		//                 if (jsonObj.LocationBeg !== jsonObj.LocationEnd) {

		//                     var dateValidation = this.validateDate(jsonObj.DateBeg);
		//                     if (dateValidation) {
		//                         if (jsonObj.DateEnd >= jsonObj.DateBeg) {
		//                             jsonObj.DateBeg = this.resolveTimeDifference(jsonObj.DateBeg);
		//                             jsonObj.DateEnd = this.resolveTimeDifference(jsonObj.DateEnd);
		//                             finalDateAndTimeArrayNonEmp = jsonObj.TimeBeg;
		//                             fTimeNonEmp = finalDateAndTimeArrayNonEmp;
		//                             jsonObj.TimeBeg = fTimeNonEmp;
		//                             aDeferredGroups = aDeferredGroups.concat(["CreateNOnEmpGroup"]);
		//                             oModel.setDeferredGroups(aDeferredGroups);

		//                             for (var k = 0; k < aPayload.length; k++) {
		//                                 oModel.create("/VehReqPostSet", aPayload[k], { groupId: "CreateNOnEmpGroup" });
		//                             }

		//                             this.getView().setBusy(true);
		//                             oModel.submitChanges({
		//                                 groupId: "CreateNOnEmpGroup",
		//                                 success: function(req, res) {
		//                                     var value = res.data.__batchResponses[0].__changeResponses[0].data.Reinr;
		//                                     if (value !== "") {
		//                                         MessageBox.success("New Trip " + value + " has been created");
		//                                     }
		//                                 },
		//                                 error: function(oError) {
		//                                     this.getView().setBusy(false);
		//                                     MessageBox.error("Error in creating Requisitions");
		//                                 }
		//                             });
		//                         } else {
		//                             MessageBox.error("End Date must be greater than or equal to Begin Date");
		//                             this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		//                         }
		//                     } else {
		//                         MessageBox.error("Begin Date should be greater than or equal to Today's Date");
		//                         this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		//                     }
		//                 } else {
		//                     MessageBox.error("Start and End locations cannot be the same");
		//                     this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		//                 }
		//             } else {
		//                 MessageBox.error("Mobile Number should be 10 digits");
		//                 this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		//             }
		//         }
		//     } else {
		//         MessageBox.error("Please add a new requisition first");
		//         oEvent.getSource().setEnabled(true);
		//     }
		// }
		// ,

		// onSaveDetailsNonEmp: function(oEvent) {
		// 	var aRows = this.getView().byId("idNonEmpTable").getItems();
		// 	var attachment = this.getView().byId("attachment").getValue();
		// 	// this.onUploadPress();
		// 	if (aRows.length > 0) {
		// 		oEvent.getSource().setEnabled(false);
		// 		var category = this.getView().byId("idCategory").getSelectedItem().getText();
		// 		var entitle = this.getView().byId("idEntitle").getSelectedItem().getText();
		// 		var nonEmpName = this.getView().byId("nonEmpName").getValue();
		// 		var oModel = this.getOwnerComponent().getModel();
		// 		var aDeferredGroups = oModel.getDeferredGroups();

		// 		var aPayload = [];
		// 		// soc by Bhavesh
		// 		var poNumber = this.getView().byId("PONum").getValue();
		// 		// var tripkm = this.getView().byId("Trip80KM").getValue();
		// 		if (entitle === "Entitle" && (!poNumber || !attachment)) {
		// 			MessageBox.error("Please fill out both PO Number and Attachment fields for Entitled travel.");
		// 			this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 			return;
		// 		}
		// 		// eoc by Bhavesh
		// 		var jsonObjEmp, jsonObj, finalDateAndTimeArrayNonEmp, fTimeNonEmp;
		// 		var locationBeg, locationEnd, locEdit = "O";
		// 		var beginFlag = 0;
		// 		var endFlag = 0;
		// 		//	var checkBoxflag = 0;
		// 		var checkBoxStatus = this.getView().byId("idCheckBox").getSelected();

		// 		locationBeg = aRows[0].getCells()[locBeginNonEmpIndex].getValue();
		// 		locationEnd = aRows[0].getCells()[locEndNonEmpIndex].getValue();
		// 		var fromValues = this.getOwnerComponent().getModel("FromModel").getProperty("/fromValues");
		// 		var toValues = this.getOwnerComponent().getModel("ToModel").getProperty("/toValues");

		// 		for (var n = 0; n < fromValues.length; n++) {
		// 			if (fromValues[n].From.toString().toLowerCase() === locationBeg.toString().toLowerCase()) {
		// 				locationBeg = fromValues[n].From;
		// 				beginFlag = 1;
		// 				break;
		// 			}
		// 		}
		// 		for (var p = 0; p < toValues.length; p++) {
		// 			if (toValues[p].To.toString().toLowerCase() === locationEnd.toString().toLowerCase()) {
		// 				locationEnd = toValues[p].To;
		// 				endFlag = 1;
		// 				break;
		// 			}
		// 		}
		// 		if (beginFlag === 0 || endFlag === 0) {
		// 			if (checkBoxStatus) {
		// 				locEdit = "X";
		// 			} else {
		// 				MessageBox.error("Please select the checkbox for special locations");
		// 				this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 				return;
		// 			}
		// 		}
		// 		if (beginFlag === 1 && endFlag === 1) {
		// 			if (checkBoxStatus) {
		// 				MessageBox.error("Please unselect the checkbox as the given locations are not special locations");
		// 				this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 				return;
		// 			}
		// 		}
		// 		if (category === "Employee") {
		// 			if (aRows.length !== 0) {

		// 				jsonObjEmp = {
		// 					TravelCategory: category,
		// 					CategoryName: this.getView().getModel("EnableModel").getProperty("/eName"),
		// 					LocationBeg: locationBeg,
		// 					LocationEnd: locationEnd,
		// 					Ebeln: poNumber,
		// 					// TripKmL: aRows[0].getCells()[TripKmIndex].getDateValue(),
		// 					DateBeg: aRows[0].getCells()[dateBeginNinEmpIndex].getDateValue(),
		// 					TimeBeg: aRows[0].getCells()[timeBeginNonEmpIndex].getValue(),
		// 					DateEnd: aRows[0].getCells()[dateEndNonEmpIndex].getDateValue(),
		// 					MobileNum: aRows[0].getCells()[mobNumNonEmpIndex].getValue(),
		// 					Purpose: aRows[0].getCells()[purposeNonEmpIndex].getValue(),
		// 					Ename: aRows[0].getCells()[personNameNonEmpIndex].getValue(),
		// 					LocEdit: locEdit,
		// 					// PoNumber: poNumber,
		// 					NontripEmpid: this.empId
		// 				};

		// 				aPayload.push(jsonObjEmp);
		// 				if (!aPayload[0].LocationBeg || !aPayload[0].LocationEnd || !aPayload[0].DateBeg || !aPayload[0].MobileNum || !aPayload[0].TimeBeg ||
		// 					!aPayload[0].Purpose) {
		// 					MessageBox.error(
		// 						"Please enter LocationBegin, LocationEnd, Begin Date, Begin Time , Purpose and Mobile number details to create a Trip");
		// 					this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 				} else {
		// 					if (aPayload[0].MobileNum.length === 10) {
		// 						if (aPayload[0].LocationBeg !== aPayload[0].LocationEnd) {

		// 							var dateValidationNonEmp = this.validateDate(aPayload[0].DateBeg);
		// 							if (dateValidationNonEmp) {
		// 								if (aPayload[0].DateEnd >= aPayload[0].DateBeg) {
		// 									aPayload[0].DateBeg = this.resolveTimeDifference(aPayload[0].DateBeg);
		// 									aPayload[0].DateEnd = this.resolveTimeDifference(aPayload[0].DateEnd);
		// 									finalDateAndTimeArrayNonEmp = aPayload[0].TimeBeg; //this.getDateandTimeSeperated(aPayload[0].TimeBeg); 
		// 									fTimeNonEmp = finalDateAndTimeArrayNonEmp;
		// 									//		fTimeNonEmp = fTimeNonEmp + ":00";
		// 									aPayload[0].TimeBeg = fTimeNonEmp;
		// 									aDeferredGroups = aDeferredGroups.concat(["CreateNOnEmpGroup"]);
		// 									oModel.setDeferredGroups(aDeferredGroups);
		// 									for (var l = 0; l < aPayload.length; l++) {
		// 										oModel.create("/VehReqPostSet", aPayload[l], {
		// 											groupId: "CreateNOnEmpGroup"
		// 										});
		// 									}
		// 									this.getView().setBusy(true);
		// 									oModel.submitChanges({
		// 										groupId: "CreateNOnEmpGroup",
		// 										success: function(req, res) {
		// 											var value = res.data.__batchResponses[0].__changeResponses[0].data.Reinr;
		// 											if (value !== "") {
		// 												var message = "New Trip" + " " + value + " " + "has been created";
		// 												MessageBox.success(message);
		// 												this.getView().getModel("NonEmpModel").setProperty("/Items", []);
		// 												this.getView().getModel("NonEmpModel").refresh(true);
		// 												this.getOwnerComponent().getModel("LocalModel").refresh(true);
		// 												this.oModel = this.getOwnerComponent().getModel();
		// 												this.oModel.read("/ZTRAVELREQ", {
		// 													success: function(oData) {
		// 														var data = oData.results;
		// 														this.getOwnerComponent().getModel("LocalModel").setProperty("/Items", data);
		// 														this.getView().getModel("LocalModel").refresh(true);
		// 														this.getView().byId("empId").setEnabled(true);
		// 														this.getView().byId("empId").setValue("");
		// 														this.getView().setBusy(false);
		// 														this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 														this.getOwnerComponent().getRouter().navTo("object", {
		// 															key: value
		// 														});
		// 														this.getView().byId("scrollContainerTable").scrollToElement(this.getView().byId("idFirstTable").getColumns()[0]);

		// 													}.bind(this),
		// 													error: function(oError) {
		// 														this.getView().setBusy(false);
		// 														sap.m.MessageToast.show("Error in getting data");
		// 													}.bind(this)

		// 												});
		// 												this.getView().getModel("RequisitionModel").refresh(true);

		// 												// Store the requisition number here
		// 												this.reqnum = value;
		// 												this.onUploadPress();
		// 												this.getView().byId("nonEmpName").setValue("");
		// 												this.getView().byId("retrievedEmpLabel").setVisible(false);
		// 												this.getView().byId("retrievedEmpName").setVisible(false);
		// 											}
		// 										}.bind(this),
		// 										error: function(oError) {
		// 											this.getView().setBusy(false);
		// 											MessageBox.error("Error in creating Requisitions");

		// 										}
		// 									});
		// 								} else {
		// 									MessageBox.error("The Requisition End Date should be greaterthan or equal to Begin Date");
		// 									this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 								}

		// 							} else {
		// 								MessageBox.error("The Vehicle Requisition Date should be greaterthan or equal to Today's Date");
		// 								this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 							}
		// 							/*	}*/
		// 						} else {
		// 							MessageBox.error("Start and End locations cannot be same");
		// 							this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 						}
		// 					} else {
		// 						MessageBox.error("Mobile Number should be of 10 Digits");
		// 						this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 					}
		// 				}
		// 			} else {
		// 				MessageBox.error("Please enter Employee ID and add new requisition for saving details");
		// 				this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 			}
		// 		} else {
		// 			if (aRows.length !== 0) {

		// 				jsonObj = {
		// 					TravelCategory: category,
		// 					CategoryName: nonEmpName,
		// 					LocationBeg: locationBeg,
		// 					LocationEnd: locationEnd,
		// 					// TripKm: aRows[0].getCells()[TripKmIndex].getSelected(),
		// 					DateBeg: aRows[0].getCells()[dateBeginNinEmpIndex].getDateValue(),
		// 					TimeBeg: aRows[0].getCells()[timeBeginNonEmpIndex].getValue(),
		// 					DateEnd: aRows[0].getCells()[dateEndNonEmpIndex].getDateValue(),
		// 					MobileNum: aRows[0].getCells()[mobNumNonEmpIndex].getValue(),
		// 					Purpose: aRows[0].getCells()[purposeNonEmpIndex].getValue(),
		// 					Ename: aRows[0].getCells()[personNameNonEmpIndex].getValue(),
		// 					LocEdit: locEdit,
		// 					Ebeln: poNumber
		// 				};

		// 				aPayload.push(jsonObj);
		// 				if (!aPayload[0].LocationBeg || !aPayload[0].LocationEnd || !aPayload[0].DateBeg || !aPayload[0].MobileNum || !aPayload[0].TimeBeg ||
		// 					!aPayload[0].Purpose) {
		// 					MessageBox.error("Please enter LocationBegin ,LocationEnd,Begin Date,Begin Time, Mobile number and Purpose of the Trip");
		// 					this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 				} else {
		// 					if (aPayload[0].MobileNum.length === 10) {
		// 						if (aPayload[0].LocationBeg !== aPayload[0].LocationEnd) {

		// 							var dateValidation = this.validateDate(aPayload[0].DateBeg);
		// 							if (dateValidation) {
		// 								if (aPayload[0].DateEnd >= aPayload[0].DateBeg) {
		// 									aPayload[0].DateBeg = this.resolveTimeDifference(aPayload[0].DateBeg);
		// 									aPayload[0].DateEnd = this.resolveTimeDifference(aPayload[0].DateEnd);
		// 									finalDateAndTimeArrayNonEmp = aPayload[0].TimeBeg; //this.getDateandTimeSeperated(aPayload[0].TimeBeg); //
		// 									fTimeNonEmp = finalDateAndTimeArrayNonEmp;
		// 									//		fTimeNonEmp = fTimeNonEmp + ":00";
		// 									aPayload[0].TimeBeg = fTimeNonEmp;
		// 									aDeferredGroups = aDeferredGroups.concat(["CreateNOnEmpGroup"]);
		// 									oModel.setDeferredGroups(aDeferredGroups);
		// 									for (var k = 0; k < aPayload.length; k++) {
		// 										oModel.create("/VehReqPostSet", aPayload[k], {
		// 											groupId: "CreateNOnEmpGroup"
		// 										});
		// 									}
		// 									this.getView().setBusy(true);
		// 									oModel.submitChanges({
		// 										groupId: "CreateNOnEmpGroup",
		// 										success: function(req, res) {
		// 											var value = res.data.__batchResponses[0].__changeResponses[0].data.Reinr;
		// 											if (value !== "") {
		// 												var message = "New Trip" + " " + value + " " + "has been created";
		// 												MessageBox.success(message);
		// 												this._clearFields();
		// 												this.getView().getModel("NonEmpModel").setProperty("/Items", []);
		// 												this.getView().getModel("NonEmpModel").refresh(true);
		// 												this.getOwnerComponent().getModel("LocalModel").refresh(true);
		// 												this.oModel = this.getOwnerComponent().getModel();
		// 												this.oModel.read("/ZTRAVELREQ", {
		// 													success: function(oData) {
		// 														var data = oData.results;

		// 														this.getOwnerComponent().getModel("LocalModel").setProperty("/Items", data);
		// 														this.getView().byId("empId").setEnabled(true);
		// 														this.getView().byId("empId").setValue("");
		// 														this.getView().setBusy(false);
		// 														this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 														this.getOwnerComponent().getRouter().navTo("object", {
		// 															key: value
		// 														});

		// 													}.bind(this),
		// 													error: function(oError) {
		// 														this.getView().setBusy(false);
		// 														sap.m.MessageToast.show("Error in getting data");
		// 													}.bind(this)

		// 												});
		// 												this.getView().getModel("RequisitionModel").refresh(true);

		// 												// Store the requisition number here
		// 												this.reqnum = value;
		// 												this.onUploadPress();
		// 												this.getView().byId("nonEmpName").setEnabled(true);
		// 												this.getView().byId("nonEmpName").setValue("");
		// 											}
		// 										}.bind(this),
		// 										error: function(oError) {
		// 											this.getView().setBusy(false);
		// 											MessageBox.error("Error in creating Requisitions");
		// 										}
		// 									});
		// 								} else {
		// 									MessageBox.error("The Requisition End Date should be greaterthan or equal to Begin Date");
		// 									this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 								}

		// 							} else {
		// 								MessageBox.error("The Vehicle Requisition Date should be greaterthan or equal to Today's Date");
		// 								this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 							}
		// 							/*	}*/
		// 						} else {
		// 							MessageBox.error("Start and End locations cannot be same");
		// 							this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 						}
		// 					} else {
		// 						MessageBox.error("Mobile Number should be of 10 Digits");
		// 						this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 					}
		// 				}
		// 			} else {
		// 				MessageBox.error("Please enter name of the person and add new requisition for saving details");
		// 				this.getView().byId("saveDetailsNonEmp").setEnabled(true);
		// 			}
		// 		}

		// 	} else {
		// 		MessageBox.error("Please press on Add new Requisition button and then save");
		// 		oEvent.getSource().setEnabled(true);
		// 	}

		// },

		// SOC by Bhavesh
		_clearFields: function() {
			this.getView().byId("nonEmpName").setValue("");
			this.getView().byId("PONum").setValue("");
			this.getView().byId("attachment").setValue("");
			this.getView().byId("attachment").setValue("");
		},
		handleUploadComplete: function(oEvent) {
			var oFileUploader = this.getView().byId("attachment");
			var oModel = this.getView().getModel(); // Replace with your OData model instance
			var sFileName = oFileUploader.getValue(); // Get the file name

			// Ensure a file is selected
			if (!sFileName) {
				sap.m.MessageToast.show("Please select a file to upload.");
				return;
			}

			// Validate file type based on extension
			var fileExtension = sFileName.split('.').pop().toLowerCase();
			if (fileExtension !== 'pdf') {
				sap.m.MessageToast.show("Please select a valid PDF file.");
				return;
			}

			// Add the SLUG header parameter
			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "SLUG",
				value: sFileName
			}));

			// Read file content
			var domRef = oFileUploader.getFocusDomRef();
			var file = domRef.files[0];
			var that = this;

			if (file) {
				var reader = new FileReader();
				reader.onload = function(e) {
					var sBase64Data = btoa(e.target.result); // Encode file content to Base64
					var sPath = "/pdfAttachmentSet"; // Replace with the correct entity set path

					// Create payload
					var oPayload = {
						FileName: sFileName,
						FileContent: sBase64Data
					};

					// Set headers and send the create call
					oModel.create(sPath, oPayload, {
						headers: {
							"SLUG": sFileName,
							"Content-Type": "application/pdf" // Ensure correct content-type
						},
						success: function(oData) {
							sap.m.MessageToast.show("File uploaded successfully.");
						},
						error: function(oError) {
							sap.m.MessageToast.show("File upload failed.");

						}
					});
				};

				reader.readAsBinaryString(file);
			} else {
				sap.m.MessageToast.show("No file selected.");
			}
		},

		// onFileUploaderChange: function(oEvent) {
		// 	var oFileUploader = oEvent.getSource();

		// 	// Get the selected file name or placeholder
		// 	var fileName = oFileUploader.getValue(); // Retrieves the file name or placeholder value

		// 	// Base width and length factor
		// 	var baseWidth = 275; // Initial width in pixels
		// 	var lengthFactor = 8; // Pixels per character

		// 	// Reset to base width if no file is selected
		// 	if (!fileName) {
		// 		oFileUploader.setWidth(baseWidth + "px");
		// 		return;
		// 	}

		// 	// Calculate the new width based on file name length
		// 	var newWidth = baseWidth + fileName.length * lengthFactor;

		// 	// Set a maximum width limit
		// 	if (newWidth > 1000) {
		// 		newWidth = 500;
		// 	}

		// 	// Apply the new width dynamically
		// 	oFileUploader.setWidth(newWidth + "px");
		// },

		// onShowAttachment: function(oEvent) {
		// 		var tripNumber = this.getView().byId("tripNumberInput").getText();

		// 		if (!tripNumber || tripNumber.trim() === "") {
		// 			sap.m.MessageToast.show("Please enter a valid Trip Number.");
		// 			return;
		// 		}

		// 		var oModel = this.getOwnerComponent().getModel();
		// 		var entityPath = "/pdfAttachmentSet('" + tripNumber + "')/$value";

		// 		// Use a manual AJAX call since OData v2 doesn't support binary responses well
		// 		$.ajax({
		// 			url: oModel.sServiceUrl + entityPath,
		// 			method: "GET",
		// 			xhrFields: {
		// 				responseType: "arraybuffer" // Expect binary data
		// 			},
		// 			headers: {
		// 				"Accept": "application/pdf" // Adjust MIME type if necessary
		// 			},
		// 			success: function(data, textStatus, xhr) {
		// 				// Convert ArrayBuffer to Base64
		// 				var binary = '';
		// 				var bytes = new Uint8Array(data);
		// 				var len = bytes.byteLength;
		// 				for (var i = 0; i < len; i++) {
		// 					binary += String.fromCharCode(bytes[i]);
		// 				}
		// 				var base64Data = btoa(binary);

		// 				// Determine MIME type
		// 				var contentType = xhr.getResponseHeader("Content-Type") || "application/octet-stream";

		// 				// Create data URL and open in new tab
		// 				var dataUrl = `data:${contentType};base64,${base64Data}`;

		// 			},
		// 			error: function(xhr, status, error) {
		// 				console.error("Error fetching attachment:", error);
		// 				sap.m.MessageToast.show("Failed to fetch the document. Please try again.");
		// 			}
		// 		});
		// 	},
		// onShowAttachment: function(oEvent) {
		// 	var tripNumber = this.getView().byId("tripNumberInput").getText();

		// 	if (!tripNumber || tripNumber.trim() === "") {
		// 		sap.m.MessageToast.show("Please enter a valid Trip Number.");
		// 		return;
		// 	}

		// 	var oModel = this.getOwnerComponent().getModel();
		// 	var entityPath = "/pdfAttachmentSet('" + tripNumber + "')/$value";

		// 	// Use a manual AJAX call since OData v2 doesn't support binary responses well
		// 	$.ajax({
		// 		url: oModel.sServiceUrl + entityPath,
		// 		method: "GET",
		// 		xhrFields: {
		// 			responseType: "arraybuffer" // Expect binary data
		// 		},
		// 		headers: {
		// 			"Accept": "image/*" // Accept all image types (flexible for different image formats)
		// 		},
		// 		success: function(data, textStatus, xhr) {
		// 			// Log response headers for debugging purposes
		// 			console.log("Response headers:", xhr.getAllResponseHeaders());

		// 			// Convert ArrayBuffer to Base64
		// 			var binary = '';
		// 			var bytes = new Uint8Array(data);
		// 			var len = bytes.byteLength;
		// 			for (var i = 0; i < len; i++) {
		// 				binary += String.fromCharCode(bytes[i]);
		// 			}
		// 			var base64Data = btoa(binary);

		// 			// Determine MIME type
		// 			var contentType = xhr.getResponseHeader("Content-Type") || "application/octet-stream";
		// 			console.log("Content-Type:", contentType);

		// 			// Create data URL and open in the appropriate viewer
		// 			var dataUrl;

		// 			if (contentType === "PDF") {
		// 				alert("pdf");

		// 				// Handle PDF files
		// 				dataUrl = `data:application/pdf;base64,${base64Data}`;
		// 				var fileWindow = window.open();
		// 				fileWindow.document.write('<iframe src="' + dataUrl + '" width="100%" height="100%" frameborder="0"></iframe>');
		// 			} else if (contentType.startsWith("image/")) {
		// 				alert("image");

		// 				// Handle image files
		// 				var imageData = "data:" + contentType + ";base64," + base64Data;

		// 				var newWindow = window.open();
		// 				if (newWindow) {
		// 					// Add image to the new window
		// 					newWindow.document.write('<html><head><title>Image Viewer</title></head><body>');
		// 					newWindow.document.write('<img src="' + imageData + '" alt="Image" />');
		// 					newWindow.document.write('</body></html>');
		// 				}
		// 				console.log("Image Data URL:", imageData);
		// 			} else {
		// 				// Handle unsupported file types
		// 				sap.m.MessageToast.show("Unsupported file type.");
		// 			}
		// 		},
		// 		error: function(xhr, status, error) {
		// 			// Log error details for debugging purposes
		// 			console.error("Error fetching attachment:", error);
		// 			console.error("Response status:", xhr.status);
		// 			console.error("Response text:", xhr.responseText);

		// 			// Display error message
		// 			sap.m.MessageToast.show("Failed to fetch the document. Please try again.");
		// 		}
		// 	});
		// },
		onShowAttachment: function(oEvent) {
			var tripNumber = this.getView().byId("tripNumberInput").getText();

			if (!tripNumber || tripNumber.trim() === "") {
				sap.m.MessageToast.show("Please enter a valid Trip Number.");
				return;
			}

			var oModel = this.getOwnerComponent().getModel();
			var entityPath = "/pdfAttachmentSet('" + tripNumber + "')/$value";

			// Use a manual AJAX call since OData v2 doesn't support binary responses well
			$.ajax({
				url: oModel.sServiceUrl + entityPath,
				method: "GET",
				xhrFields: {
					responseType: "arraybuffer" // Expect binary data
				},
				headers: {
					"Accept": "application/pdf" // Adjust MIME type if necessary
				},
				success: function(data, textStatus, xhr) {
					// Convert ArrayBuffer to Base64
					var binary = '';
					var bytes = new Uint8Array(data);
					var len = bytes.byteLength;
					for (var i = 0; i < len; i++) {
						binary += String.fromCharCode(bytes[i]);
					}
					var base64Data = btoa(binary);

					// Determine MIME type (assuming it's either PDF or Image)
					var contentType = xhr.getResponseHeader("Content-Type") || "application/octet-stream";

					// Create data URL and open in the appropriate viewer
					var dataUrl;

					if (contentType === "application/pdf") {
						dataUrl = `data:application/pdf;base64,${base64Data}`;
						var fileWindow = window.open();
						fileWindow.document.write('<iframe src="' + dataUrl + '" width="100%" height="100%" frameborder="0"></iframe>');
						// if (oFile.type == "application/pdf") {

						// } else if (oFile.type == "image/png" || oFile.type == "image/jpeg") {

					} else if (contentType.startsWith("image/")) {
						var imageData = "data:" + "image/jpeg" + ";base64," + base64Data;
						// Open Image in a new tab
						var newWindow = window.open();

						if (newWindow) {
							// Add image to the new window
							newWindow.document.write('<html><head><title>Image Viewer</title></head><body>');
							newWindow.document.write('<img src="' + imageData + '" alt="Image" />');
							newWindow.document.write('</body></html>');
						}

					} else if (contentType === "application/msword") {
						const byteCharacters = atob(base64Data); // Decode the base64 string
						const byteArrays = [];

						for (let offset = 0; offset < byteCharacters.length; offset += 1024) {
							const slice = byteCharacters.slice(offset, offset + 1024);
							const byteNumbers = new Array(slice.length);

							for (let i = 0; i < slice.length; i++) {
								byteNumbers[i] = slice.charCodeAt(i);
							}

							byteArrays.push(new Uint8Array(byteNumbers));
						}

						var docBlob = new Blob(byteArrays, {
							type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
						});
						const url = URL.createObjectURL(docBlob);

						// Open the file in a new tab
						window.open(url, '_blank');
					} else if (contentType === "application/vnd.ms-excel") {
						const byteCharacters = atob(base64Data); // Decode the base64 string
						const byteArrays = [];

						for (let offset = 0; offset < byteCharacters.length; offset += 1024) {
							const slice = byteCharacters.slice(offset, offset + 1024);
							const byteNumbers = new Array(slice.length);

							for (let i = 0; i < slice.length; i++) {
								byteNumbers[i] = slice.charCodeAt(i);
							}

							byteArrays.push(new Uint8Array(byteNumbers));
						}

						var excelBlob = new Blob(byteArrays, {
							type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
						});
						const url = URL.createObjectURL(excelBlob);

						// Open the file in a new tab
						window.open(url, '_blank');
					} else {
						// Handle other cases (if necessary)
						sap.m.MessageToast.show("Unsupported file type.");
					}
				},
				error: function(xhr, status, error) {

					sap.m.MessageToast.show("No Document Found.");
				}
			});
		},

		onUploadPress: function() {
			var oFileUploader = this.getView().byId("attachment");

			// Ensure that reqnum is properly assigned before proceeding
			if (this.reqnum) {
				// Construct SLUG Header with pdfAttachment properties
				/*	var slugValue =
						"Reqnum=" + this.reqnum + ";" + // Add Reqnum (Requisition Number)
						"Filename=" + this.fileName +
						// Add Header Parameters
						oFileUploader.destroyHeaderParameters();*/
				var file_name = oFileUploader.getValue();
				var slugValue = file_name + '"/"' + this.reqnum;
				oFileUploader.destroyHeaderParameters();

				oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
					name: "SLUG",
					value: slugValue
				}));
				oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
					name: "Content-Type",
					value: "application/pdf"
				}));
				this.getOwnerComponent().getModel().refreshSecurityToken();
				oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
					name: "x-csrf-token",
					value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
				}));

				// Upload the file
				oFileUploader.upload();
			} else {
				sap.m.MessageToast.show("Requisition number is undefined");
			}
		},

		onUploadComplete: function(oEvent) {
			var status = oEvent.getParameter("status");
			if (status === 201) {
				sap.m.MessageToast.show("File uploaded successfully!");
			} else {
				sap.m.MessageBox.error("File upload failed. Status: " + status);
			}
		},

		onTypeMismatch: function() {
			sap.m.MessageBox.error("Invalid file type. Please upload a valid PDF.");
		},

		onUploadProgress: function(oEvent) {
			var progress = oEvent.getParameter("loaded") / oEvent.getParameter("total") * 100;
			sap.m.MessageToast.show("Upload progress: " + Math.round(progress) + "%");
		},
		// EOC by Bhavesh

		resetNonEmployee: function() {
			this.getView().getModel("NonEmpModel").setProperty("/Items", []);
			this.getView().getModel("NonEmpModel").refresh(true);
		},
		onSelectionChange: function(oEvent) {
			this._clearFields();
			var category = this.getView().byId("idCategory").getSelectedItem().getText();

			this.getView().getModel("NonEmpModel").setProperty("/Items", []);
			this.getView().getModel("NonEmpModel").refresh(true);
			this.getView().byId("idCheckBox").setSelected(false);
			var selectedTravelCategory = oEvent.getSource().getSelectedItem().getText();
			if (category === 'Employee') {
				this.getView().byId("pname").setVisible(false);
			}
			if (selectedTravelCategory !== "Employee") {
				this.getView().getModel("EnableModel").setProperty("/EnableOtherfields", "YES");
				this.getView().byId("retrievedEmpLabel").setVisible(false);
				this.getView().byId("retrievedEmpName").setVisible(false);
			} else {
				this.getView().byId("empId").setValue("");
				this.getView().byId("empId").setEnabled(true);
				this.getView().getModel("EnableModel").setProperty("/EnableOtherfields", "NO");
			}
			//soc by Bhavesh
			if (selectedTravelCategory === "Company Guest") {
				this.getView().byId("entitle").setVisible(true);
				this.getView().byId("idEntitle").setVisible(true);
				this.getView().byId("poText").setVisible(true);
				this.getView().byId("PONum").setVisible(true);
				this.getView().byId("attach").setVisible(true);
				this.getView().byId("attachment").setVisible(true);
			} else {
				this.getView().byId("entitle").setVisible(false);
				this.getView().byId("idEntitle").setVisible(false);
				this.getView().byId("poText").setVisible(false);
				this.getView().byId("PONum").setVisible(false);
				this.getView().byId("attach").setVisible(false);
				this.getView().byId("attachment").setVisible(false);
			}
		},

		onEntitleChange: function(oEvent) {
			this.getView().byId("PONum").setValue("");
			this.getView().getModel("EntitleDropdownModel").setProperty("/Items", []);
			var selectedTravelCategory = oEvent.getSource().getSelectedItem().getText();
			if (selectedTravelCategory === "Non-Entitle") {
				this.getView().byId("poText").setVisible(false);
				this.getView().byId("PONum").setVisible(false);
			} else {
				this.getView().byId("poText").setVisible(true);
				this.getView().byId("PONum").setVisible(true);
			}
			//Eoc by Bhavesh
		},

		/*onEmpIdEnter: function(oEvent) {
			var empId = oEvent.getSource().getValue();
			var oModel = this.getOwnerComponent().getModel();
			if (empId !== "") {
				oModel.read("/ZEMP_DATASet('" + empId + "')", {
					success: function(oData) {
						this.eName = oData.Sname;
						this.getView().getModel("EnableModel").setProperty("/eName", this.eName);
						this.getView().byId("empId").setEnabled(false);
						MessageBox.success("Please add new requisition");
					}.bind(this),
					error: function(oError) {
						MessageBox.error("Please Enter Correct Employee ID");
						this.getView().byId("empId").setEnabled(true);
					}.bind(this)
				});
			} else {
				MessageBox.error("Please enter Employee ID");
			}
		},*/
		onSelectCheckBox: function(oEvent) {
			console.log(this.getView().byId("idCheckBox").getSelected())
			if (this.getView().byId("idCheckBox").getSelected()) {
				this.getView().getModel("EnableModel").setProperty("/EnableSelect", "NO");
				this.getView().getModel("EnableModel").setProperty("/EnableInput", "YES");
				//	this.getView().byId("idFromSelect").unbindItems();
			} else {
				this.getView().getModel("EnableModel").setProperty("/EnableSelect", "YES");
				this.getView().getModel("EnableModel").setProperty("/EnableInput", "NO");
			}
		},
		onShowValueHelpLocationBegin: function(oEvent) {
			if (!this.dialogBegin) {
				this.dialogBegin = sap.ui.xmlfragment(this.getView().getId(), "ZTIC_REQ_MAN.view.Fragment.LocationBeginFragment", this);
				this.getView().addDependent(this.dialogBegin);
			}
			this.dialogBegin.open();
			this.beginInputId = oEvent.getSource();
			this.getView().byId("idLocationBeginTable").removeSelections();
		},
		onShowValueHelpLocationEnd: function(oEvent) {
			if (!this.dialogEnd) {
				this.dialogEnd = sap.ui.xmlfragment(this.getView().getId(), "ZTIC_REQ_MAN.view.Fragment.LocationEndFragment", this);
				this.getView().addDependent(this.dialogEnd);
			}
			this.dialogEnd.open();
			this.endInputId = oEvent.getSource();
			this.getView().byId("idLocationEndTable").removeSelections();
		},
		onCloseDialog: function() {
			if (this.dialogBegin) {
				this.dialogBegin.close();
			}
			if (this.dialogEnd) {
				this.dialogEnd.close();
			}
		},
		onBeginHelpTableRowSelect: function(oEvent) {
			var fromValue = oEvent.getSource().getSelectedItem().getCells()[0].getText();
			/*var items = this.getView().getModel("RequisitionModel").getProperty("/Items");
			items[items.length - 1].LocationBeg = fromValue;
			this.getView().getModel("RequisitionModel").refresh(true);*/
			this.beginInputId.setValue(fromValue);

			this.dialogBegin.close();
		},
		onEndHelpTableRowSelect: function(oEvent) {
			var toValue = oEvent.getSource().getSelectedItem().getCells()[0].getText();
			/*var items = this.getView().getModel("RequisitionModel").getProperty("/Items");
			items[items.length - 1].LocationEnd = toValue;
			this.getView().getModel("RequisitionModel").refresh(true);*/
			this.endInputId.setValue(toValue);
			this.dialogEnd.close();
		},
		// onShowValueHelpNonLocationBegin: function(oEvent) {
		// 	if (!this.dialogNonBegin) {
		// 		this.dialogNonBegin = sap.ui.xmlfragment(this.getView().getId(), "ZTIC_REQ_MAN.view.Fragment.NonLocationBeginFragment", this);
		// 		this.getView().addDependent(this.dialogNonBegin);
		// 	}
		// 	this.dialogNonBegin.open();
		// 	this.beginNonInputId = oEvent.getSource();
		// 	this.getView().byId("idLocationBeginNonTable").removeSelections();
		// },
		// onShowValueHelpNonLocationEnd: function(oEvent) {
		// 	if (!this.dialogNonEnd) {
		// 		this.dialogNonEnd = sap.ui.xmlfragment(this.getView().getId(), "ZTIC_REQ_MAN.view.Fragment.NonLocationEndFragment", this);
		// 		this.getView().addDependent(this.dialogNonEnd);
		// 	}
		// 	this.dialogNonEnd.open();
		// 	this.endNonInputId = oEvent.getSource();
		// 	this.getView().byId("idLocationEndNonTable").removeSelections();
		// },
		onShowValueHelpNonLocationBegin: function(oEvent) {
			var oSource = oEvent.getSource(); // Get the source of the event
			var oBindingContext = oSource.getBindingContext("NonEmpModel"); // Get the context for the specific row

			if (!this.dialogNonBegin) {
				this.dialogNonBegin = sap.ui.xmlfragment(this.getView().getId(), "ZTIC_REQ_MAN.view.Fragment.NonLocationBeginFragment", this);
				this.getView().addDependent(this.dialogNonBegin);
			}
			this.dialogNonBegin.open();

			// Bind the dialog table to the specific row context
			this.getView().byId("idLocationBeginNonTable").setBindingContext(oBindingContext);
			this.beginNonInputId = oSource; // Remember the source input ID
			this.getView().byId("idLocationBeginNonTable").removeSelections();
		},
		onSearch: function(oEvent) {
			var oTable = this.getView().byId("idLocationBeginNonTable");
			var sQuery = oEvent.getParameter("query");

			var oBinding = oTable.getBinding("items");

			if (sQuery && sQuery.length > 0) {
				var aFilters = [
					new sap.ui.model.Filter({
						path: "From", // Ensure this matches your data model path
						operator: sap.ui.model.FilterOperator.Contains,
						value1: sQuery.toLowerCase() // Convert the query to lowercase
					})
				];
				oBinding.filter(aFilters);
			} else {
				oBinding.filter([]); // Reset filter if the search field is empty
			}
		},
		onSearch1: function(oEvent) {
			var oTable = this.getView().byId("idLocationEndNonTable");
			var sQuery = oEvent.getParameter("query");

			var oBinding = oTable.getBinding("items");

			if (sQuery && sQuery.length > 0) {
				var aFilters = [
					new sap.ui.model.Filter({
						path: "To", // Ensure this matches your data model path
						operator: sap.ui.model.FilterOperator.Contains,
						value1: sQuery.toLowerCase() // Convert the query to lowercase
					})
				];
				oBinding.filter(aFilters);
			} else {
				oBinding.filter([]); // Reset the filter if the search query is empty
			}
		},

		onShowValueHelpNonLocationEnd: function(oEvent) {
			var oSource = oEvent.getSource(); // Get the source of the event
			var oBindingContext = oSource.getBindingContext("NonEmpModel"); // Get the context for the specific row

			if (!this.dialogNonEnd) {
				this.dialogNonEnd = sap.ui.xmlfragment(this.getView().getId(), "ZTIC_REQ_MAN.view.Fragment.NonLocationEndFragment", this);
				this.getView().addDependent(this.dialogNonEnd);
			}
			this.dialogNonEnd.open();

			// Bind the dialog table to the specific row context
			this.getView().byId("idLocationEndNonTable").setBindingContext(oBindingContext);
			this.endNonInputId = oSource; // Remember the source input ID
			this.getView().byId("idLocationEndNonTable").removeSelections();
		},

		onCloseNonDialog: function() {
			if (this.dialogNonBegin) {
				this.dialogNonBegin.close();
			}
			if (this.dialogNonEnd) {
				this.dialogNonEnd.close();
			}
		},
		// onBeginHelpNonTableRowSelect: function(oEvent) {
		// 	var fromValue = oEvent.getSource().getSelectedItem().getCells()[0].getText();
		// 	var nonItems = this.getView().getModel("NonEmpModel").getProperty("/Items");
		// 	nonItems[0].LocationBeg = fromValue;
		// 	this.getView().getModel("NonEmpModel").refresh(true);
		// 	this.dialogNonBegin.close();
		// },
		// onEndHelpNonTableRowSelect: function(oEvent) {
		// 	var toValue = oEvent.getSource().getSelectedItem().getCells()[0].getText();

		// 	var nonItems = this.getView().getModel("NonEmpModel").getProperty("/Items");
		// 	nonItems[0].LocationEnd = toValue;
		// 	this.getView().getModel("NonEmpModel").refresh(true);
		// 	this.dialogNonEnd.close();
		// },
		onBeginHelpNonTableRowSelect: function(oEvent) {
			var oSelectedItem = oEvent.getParameter("listItem");
			var sLocationBegin = oSelectedItem.getCells()[0].getText(); // Get the selected value

			var oInput = this.beginNonInputId; // The specific row input that triggered the dialog
			oInput.setValue(sLocationBegin); // Set the selected value to the input field

			this.dialogNonBegin.close(); // Close the dialog
		},

		onEndHelpNonTableRowSelect: function(oEvent) {
			var oSelectedItem = oEvent.getParameter("listItem");
			var sLocationEnd = oSelectedItem.getCells()[0].getText(); // Get the selected value

			var oInput = this.endNonInputId; // The specific row input that triggered the dialog
			oInput.setValue(sLocationEnd); // Set the selected value to the input field

			this.dialogNonEnd.close(); // Close the dialog
		},

		onCancelRequisition: function(oEventCancel) {
			//call confirmation fragment
			var items = this.getView().getModel("RequisitionModel").getProperty("/Items");
			var approved = 0,
				ready = 0;
			var aRows = this.getView().byId("idFirstTable").getItems();

			var errorMessageApproved = "The Requisition" + " " + this.cancelReqnum + " " +
				"has been Approved. For Cancellation Please contact Admin1.";
			var errorMessageReady = "The Requisition" + " " + this.cancelReqnum + " " +
				"is in ready-to-move status. If you need to cancel, contact Admin1.";
			for (var i = 0; i < items.length; i++) {
				if (items[i].Reqnum === this.cancelReqnum) {
					if (items[i].Status.toString().toUpperCase() === "APPROVED") {
						approved = 1;
						break;
					}
					if (items[i].Status.toString().toUpperCase() === "READY") {
						ready = 1;
						break;
					}
				}
			}
			if (approved === 1) {
				MessageBox.error(errorMessageApproved);
				for (var m = 0; m < aRows.length; m++) {
					aRows[m].getCells()[this.cancelIndex].setSelected(false);
				}
			} else if (ready === 1) {
				MessageBox.error(errorMessageReady);
				for (var r = 0; r < aRows.length; r++) {
					aRows[r].getCells()[this.cancelIndex].setSelected(false);
				}
			} else {
				if (!this.dialogCancel) {
					this.dialogCancel = sap.ui.xmlfragment(this.getView().getId(), "ZTIC_REQ_MAN.view.Fragment.CancelConfirmation", this);
					this.getView().addDependent(this.dialogCancel);
				}
				this.dialogCancel.open();
			}

		},
		enableCancelButton: function(oEvent) {
			var reqnum = oEvent.getSource().getParent().getCells()[0].getValue();
			this.cancelReqnum = reqnum;
			this.CheckBoxRef = oEvent;
			var aRows = this.getView().byId("idFirstTable").getItems();
			var count = 0;
			for (var i = 0; i < aRows.length; i++) {
				if (aRows[i].getCells()[this.cancelIndex].getSelected() === true) {
					count++;
				}
			}
			if (count > 0) {
				if (count > 1) {
					MessageBox.error("Please select only one requisition at a time");

					this.getView().byId("idCancelButton").setEnabled(false);
					this.getView().byId("idAddNewButton").setEnabled(true);
					for (var j = 0; j < aRows.length; j++) {
						aRows[j].getCells()[this.cancelIndex].setSelected(false);
					}
				} else {

					this.getView().byId("idCancelButton").setEnabled(true);
					this.getView().byId("idAddNewButton").setEnabled(false);

				}
			} else {
				this.getView().byId("idCancelButton").setEnabled(false);
				this.getView().byId("idAddNewButton").setEnabled(true);
			}

		},
		onAcceptCancelRequisitions: function(oEvent) {
			//update status

			var aPayload = [];

			var jsonObj = {};
			jsonObj = {
				Reqnum: this.cancelReqnum,
				Status: "CANCELLED"
			};
			aPayload.push(jsonObj);

			var oModel = this.getOwnerComponent().getModel();
			oModel.create("/Header", aPayload[0], {
				success: function(res) {
					var reqNum = res.Reqnum;
					if (reqNum !== "") {
						var mesg = "Requisition" + " " + reqNum + " " + "has been cancelled ";
						MessageBox.success(mesg, {
							onClose: function() {
								this.disableRow(reqNum);
							}.bind(this)
						});
					} else {
						MessageBox.error("Some problem has occurred in cancelling the Requisition");
					}
				}.bind(this),
				error: function(oError) {
					MessageBox.error(oError);
				}
			});

			this.dialogCancel.close();

		},
		onRejectCancellation: function(oEvent) {
			this.dialogCancel.close();
		},
		disableRow: function(Reqnum) {
			/*var oEvent = this.oEventRef;
			oEvent.getSource().setEnabled(false);
			oEvent.getSource().getParent().getCells()[8].setEnabled(false);*/

			var filters = [];
			filters.push(new Filter({
				path: "Reinr",
				value1: this.tripNum,
				operator: FilterOperator.EQ
			}));
			var sorter = [];
			sorter.push(new Sorter({
				path: "Reqnum",
				descending: true
			}));
			this.getOwnerComponent().getModel().read("/VehRequestSet", {
				filters: filters,
				sorter: sorter,
				success: function(oData) {
					var data = oData.results;
					this.getView().getModel("RequisitionModel").setProperty("/Items", data);
				}.bind(this),
				error: function(oError) {
					MessageBox.error("Error in getting Data");
				}.bind(this)

			});
			this.getView().getModel("RequisitionModel").refresh(true);
			this.getView().byId("idAddNewButton").setEnabled(true);
			this.getView().byId("idCancelButton").setEnabled(false);

		},
		onLiveChange: function(oEvent) {
			var inputValue = oEvent.getParameter("value");
			var oInput = oEvent.getSource();

			// Set maximum length of input
			var maxLength = 325;

			// If input exceeds max length, prevent further input
			if (inputValue.length > maxLength) {
				oEvent.preventDefault(); // Prevent further input
			}
		},
		onUpdateFinished: function(oEvent) {

			var aRows = this.getView().byId("idFirstTable").getItems();
			var aColumns = this.getView().byId("idFirstTable").getColumns();

			for (var j = 0; j < aColumns.length; j++) {
				if (aColumns[j].getHeader().getText() === "Vehicle Requisition") {
					requisitionIndex = j;
				}

				if (aColumns[j].getHeader().getText() === "Status") {
					this.statusIndex = j;
				}
				if (aColumns[j].getHeader().getText() === "Cancel") {
					this.cancelIndex = j;
				}
				if (aColumns[j].getHeader().getText() === "Edit") {
					this.editIndex = j;
				}
				if (aColumns[j].getHeader().getText() === "Location Begin") {
					locBeginIndex = j;
				}
				if (aColumns[j].getHeader().getText() === "Location End") {
					locEndIndex = j;
				}
				if (aColumns[j].getHeader().getText() === "Begin Date") {
					dateBeginIndex = j;
				}
				if (aColumns[j].getHeader().getText() === "Begin Time") {
					timeBeginIndex = j;
				}
				if (aColumns[j].getHeader().getText() === "End Date") {
					dateEndIndex = j;
				}
				if (aColumns[j].getHeader().getText() === "Mobile Number") {
					mobNumberIndex = j;
				}
				if (aColumns[j].getHeader().getText() === "Purpose") {
					purposeIndex = j;
				}

			}
			for (var i = 0; i < aRows.length; i++) {
				aRows[i].getCells()[this.cancelIndex].setSelected(false);
				aRows[i].getCells()[this.statusIndex].setEnabled(false);
			}
		},
		onEmpIdSearch: function(oEvent) {
			var empId = this.getView().byId("empId").getValue();
			var oModel = this.getOwnerComponent().getModel();
			if (empId !== "") {
				oModel.read("/ZEMP_DATASet('" + empId + "')", {
					success: function(oData) {
						this.eName = oData.Sname;
						this.getView().getModel("EmpNameModel").setProperty("/EmpName", this.eName);
						this.getView().getModel("EnableModel").setProperty("/eName", this.eName);
						// this.getView().byId("empId").setEnabled(false);
						MessageBox.success("Employee Name found,Please add new requisition");
						this.getView().byId("retrievedEmpLabel").setVisible(true);
						this.getView().byId("retrievedEmpName").setVisible(true);
						this.getView().byId("retrievedEmpName").setText(this.eName);
					}.bind(this),
					error: function(oError) {
						MessageBox.error("Please Enter Correct Employee ID");
						this.getView().byId("empId").setEnabled(true);
					}.bind(this)
				});
			} else {
				MessageBox.error("Please enter Employee ID");
			}
		},
		handleChangeDateBeg: function(oEvent) {
			var dateBeg = oEvent.getSource().getDateValue();
			var row = oEvent.getSource().getParent();
			// MessageBox.alert("End Date has been changed");
			//row.getCells()[dateEndIndex].setDateValue(dateBeg);

		},
		handleChangeNonEmpBegin: function(oEvent) {
			var dateBeg = oEvent.getSource().getDateValue();
			var row = oEvent.getSource().getParent();
			//	MessageBox.alert("End Date has been changed");
			//	row.getCells()[dateEndNonEmpIndex].setDateValue(dateBeg);
		},
		// handleUploadComplete: function(oEvent) {
		// 	var oFileUploader = this.getView().byId("attachment");
		// 	// var oFileUploader = this.byId("fileUploader"); // Replace with the actual ID of your FileUploader
		// 	var oModel = this.getView().getModel(); // Replace with your OData model instance
		// 	var sFileName = oFileUploader.getValue(); // Get the file name

		// 	// Ensure a file is selected
		// 	if (!sFileName) {
		// 		sap.m.MessageToast.show("Please select a file to upload.");
		// 		return;
		// 	}

		// 	// Add the SLUG header parameter
		// 	oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
		// 		name: "SLUG",
		// 		value: sFileName
		// 	}));

		// 	// Read file content
		// 	var domRef = oFileUploader.getFocusDomRef();
		// 	var file = domRef.files[0];
		// 	var that = this;

		// 	if (file) {
		// 		var reader = new FileReader();
		// 		reader.onload = function(e) {
		// 			var sBase64Data = btoa(e.target.result); // Encode file content to Base64
		// 			var sPath = "/pdfAttachmentSet"; // Replace with the correct entity set path

		// 			// Create payload
		// 			var oPayload = {
		// 				FileName: sFileName,
		// 				FileContent: sBase64Data
		// 			};

		// 			// Set headers and send the create call
		// 			oModel.create(sPath, oPayload, {
		// 				headers: {
		// 					"SLUG": sFileName
		// 				},
		// 				success: function(oData) {
		// 					sap.m.MessageToast.show("File uploaded successfully.");
		// 				},
		// 				error: function(oError) {
		// 					sap.m.MessageToast.show("File upload failed.");
		// 					console.error(oError);
		// 				}
		// 			});
		// 		};

		// 		reader.readAsBinaryString(file);
		// 	} else {
		// 		sap.m.MessageToast.show("No file selected.");
		// 	}
		// },
		// onShowAttachment: function(oEvent) {
		// 	var fileWindow = window.open();
		// 	if (oFile.type == "application/pdf") {
		// 		var base64Data = "data:application/pdf;base64," + base64File;
		// 		console.log("base64Data", base64Data)

		// 		fileWindow.document.write('<iframe src="' + base64Data + '" width="100%" height="100%" frameborder="0"></iframe>');
		// 	} else if (oFile.type == "image/png" || oFile.type == "image/jpeg") {
		// 		var imageData = "data:" + "image/png" + ";base64," + base64File;
		// 		fileWindow.document.write('<iframe src="' + imageData + '" width="100%" height="100%" frameborder="0"></iframe>');
		// 	}

		// },
		onValueHelpRequest: function() {
			if (!this._poDialog) {
				this._poDialog = sap.ui.xmlfragment("ZTIC_REQ_MAN.view.Fragment.PONumberDialog", this);
				this.getView().addDependent(this._poDialog);
			}

			var oAllDataModel = new sap.ui.model.json.JSONModel();
			var oModel = new sap.ui.model.json.JSONModel();

			this.getView().setModel(oAllDataModel, "poAllDataModel");
			this.getView().setModel(oModel, "poModel");

			var oDataModel = this.getView().getModel();
			oDataModel.read("/poVHSet", {
				success: function(oResponse) {
					var poData = oResponse.results;
					console.log("poData", poData)

					// Set all data to the all data model
					oAllDataModel.setData({
						poData: poData
					});

					// Initialize pagination
					var itemsPerPage = 10;
					var totalPages = Math.ceil(poData.length / itemsPerPage);

					oModel.setData({
						poData: poData.slice(0, itemsPerPage), // Load the first page data
						currentPage: 1,
						totalPages: totalPages,
						itemsPerPage: itemsPerPage
					});

					this._poDialog.open();
				}.bind(this),
				error: function(oError) {
					console.error("Error fetching data:", oError);
				}
			});
		},

		updatePageData: function() {
			var oModel = this.getView().getModel("poModel");
			var oAllDataModel = this.getView().getModel("poAllDataModel");

			var currentPage = oModel.getProperty("/currentPage");
			var itemsPerPage = oModel.getProperty("/itemsPerPage");
			var poData = oAllDataModel.getProperty("/poData");

			var startIndex = (currentPage - 1) * itemsPerPage;
			var endIndex = startIndex + itemsPerPage;

			oModel.setProperty("/poData", poData.slice(startIndex, endIndex));
		},

		onNextPage: function() {
			var oModel = this.getView().getModel("poModel");
			var currentPage = oModel.getProperty("/currentPage");
			var totalPages = oModel.getProperty("/totalPages");

			if (currentPage < totalPages) {
				oModel.setProperty("/currentPage", currentPage + 1);
				this.updatePageData();
			}
		},

		onPreviousPage: function() {
			var oModel = this.getView().getModel("poModel");
			var currentPage = oModel.getProperty("/currentPage");

			if (currentPage > 1) {
				oModel.setProperty("/currentPage", currentPage - 1);
				this.updatePageData();
			}
		},

		// Assuming you store the full, original data in a property like 'oOriginalData'
		onSearchPO: function(oEvent) {
			var sQuery = oEvent.getSource().getValue();
			var oModel = this.getView().getModel("poModel"); // Filtered data model
			var oAllDataModel = this.getView().getModel("poAllDataModel"); // All data model

			if (!oModel || !oAllDataModel) {

				return;
			}

			// Retrieve the full data from the all data model
			var oData = oAllDataModel.getData().poData; // Assuming data is stored under 'poData'

			if (sQuery) {
				// Filter the data based on the search query
				var aFilteredData = oData.filter(function(oItem) {
					return oItem.PO.toLowerCase().includes(sQuery.toLowerCase()) ||
						oItem.Vendor.toLowerCase().includes(sQuery.toLowerCase()) ||
						oItem.Name.toLowerCase().includes(sQuery.toLowerCase());
				});

				// Update the filtered data model
				oModel.setData({
					poData: aFilteredData
				});
			} else {
				// If search query is cleared, reset the filtered model to the original data
				oModel.setData({
					poData: oData
				});
			}
		},

		onSelectPO: function(oEvent) {
			var oSelectedItem = oEvent.getParameter("listItem");
			if (oSelectedItem) {
				var sPONumber = oSelectedItem.getBindingContext("poModel").getProperty("PO");
				var oInput = this.getView().byId("PONum");
				oInput.setValue(sPONumber);
			}

			// Correctly reference the table inside the fragment using the view's byId
			var oTable = this.getView().byId("poTable"); // Use this.getView().byId, not this._poDialog.byId

			// Ensure the table reference is valid and then remove selection
			if (oTable) {
				oTable.removeSelection(); // Remove the selection
			}

			this._poDialog.close();
		},

		onCancelDialog: function() {
			if (this._poDialog) {
				this._poDialog.close();
			}
		}

	});
});