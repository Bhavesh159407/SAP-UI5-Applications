sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"ZTIC_REQ_MAN/model/formatter"
], function(Controller, Filter, FilterOperator, formatter) {
	"use strict";

	return Controller.extend("ZTIC_REQ_MAN.controller.List", {
		f: formatter,
		onInit: function() {
			this.getView().addStyleClass("sapUiSizeCompact");
			this.enableNonSapUserPanel = "NO";
			this.getView().addStyleClass("sapUiSizeCompact");

		},
		onAfterRendering: function() {

		},
		onSelectionChange: function(oEvent) {
			this.enableNonSapUserPanel = "False";
			this.showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
		},
		showDetail: function(oItem) {
			this.getOwnerComponent().getRouter().navTo("object", {
				key: oItem.getProperty("title")
			});
		},
		onNonSAPUserPress: function(oEvent) {
			
			var listId = this.getView().byId("list");
			listId.removeSelections(true);
			this.enableNonSapUserPanel = "YES";
			this.getOwnerComponent().getRouter().navTo("object", {
				key: this.enableNonSapUserPanel
			});
		},
		onFilterTickets: function(oEvent) {
			var searchString = this.getView().byId("searchField").getValue();
			var aFilters = [];
			if (searchString) {
				var oFilter = new Filter("Reinr", FilterOperator.Contains, searchString);
				aFilters.push(oFilter);
			}
			this.getView().byId("list").getBinding("items").filter(aFilters);

		}
	});
});