sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"ZTIC_REQ_MAN/model/formatter"
], function(Controller, JSONModel,  formatter) {
	"use strict";

	return Controller.extend("ZTIC_REQ_MAN.controller.Empty", {
	});
});