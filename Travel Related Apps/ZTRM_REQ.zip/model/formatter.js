sap.ui.define([], function() {
	"use strict";
	return {
		formatDate: function(Doj) {
			var oDataFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "dd/MM/yyyy"
			}, sap.ui.getCore().getConfiguration().getLocale());
			return oDataFormat.format(Doj, true);
		},
		formatDateTime: function(Doj) {
			var oDataFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				// pattern: "dd/MM/yyyy HH:MM:SS"
				pattern: "dd/MM/yyyy"
			}, sap.ui.getCore().getConfiguration().getLocale());
			return oDataFormat.format(Doj, true);
		},
		formatReinr: function(Reinr) {
			return Reinr.replace(/^0+/, '');
		},
		formatPanelVisibility: function(visibility) {
			if (visibility === "YES") {
				return true;
			} else {
				return false;
			}
		},
		formatNewFeilds: function(reqnum) {
			if (reqnum.toString() !== "") {
				return false;
			}
			if (reqnum.toString() === "") {
				return true;
			}
		},
		formatButtonType: function(reqnum) {
			if (reqnum.toString() !== "") {
				return "Emphasized";
			}
			if (reqnum.toString() === "") {
				return "Reject";
			}
		},
		formatPressFunction: function(reqnum) {
			if (reqnum.toString() !== "") {
				return "OnEditCreateButtonPress";
			}
			if (reqnum.toString() === "") {
				return "onNewRowEmpDelete";
			}
		},
		formatCategoryVisibility: function(category) {
			if (category !== "") {
				return true;
			} else {
				return false;
			}
		},
		// formatCategoryCompany: function(category) {
		// 	return category === "Company Guest";
		// },
		formatIconStatus: function(Action) {
			if (Action !== "") {
				return "sap-icon://edit";

			} else {
				return "sap-icon://delete";
			}
		},
		formatIconAStatus: function(Action) {
			if (Action !== "") {
				return "sap-icon://show";

			} else {
				return "sap-icon://show";
			}
		},
		// formatAttachmentIcon: function(action) {
		// 	if (action !== "") {
		// 		return "sap-icon://show";
		// 	} else {
		// 		return "sap-icon://hide";
		// 	}
		// },

		// formatAttachmentButtonType: function(attachmentType) {
		// 	if (attachmentType === "Important") {
		// 		return "Emphasized";
		// 	} else {
		// 		return "Default";
		// 	}
		// },

		// formatAttachmentActionButton: function(status) {
		// 	if (status === "DISABLED") {
		// 		return false;
		// 	} else {
		// 		return true;
		// 	}
		// },
		formatDetailsVisibility: function(visibility) {
			if (visibility === "YES") {
				return true;
			} else {
				return false;
			}
		},
		formatSpecialCheck: function(Enable, LocEdit) {
			if (Enable === "YES" || LocEdit === "X") {
				return true;
			} else {
				return false;
			}
		},
		formatMessagePageVisibility: function(visibility) {
			if (visibility === "YES") {
				return true;
			} else {
				return false;
			}
		},
		formatTextFeildsStatus: function(visibility) {
			if (visibility === "YES") {
				return true;
			} else {
				return false;
			}
		},
		formatInputFeildsStatus: function(visibility) {
			if (visibility === "YES") {
				return false;
			} else {
				return true;
			}
		},
		formatTablesVisibility: function(visibility) {
			if (visibility === "YES") {
				return true;
			} else {
				return false;
			}
		},
		formatReqStatus: function(status) {
			if (status === "CLOSED") {
				return false;
			} else {
				return true;
			}
		},
		timeConvert: function(time) {
			// Check correct time format and split into components
			time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];

			if (time.length > 1) { // If time format correct
				time = time.slice(1); // Remove full string match value
				time[5] = +time[0] < 12 ? "AM" : "PM"; // Set AM/PM
				time[0] = +time[0] % 12 || 12; // Adjust hours
			}
			return time.join(""); // return adjusted time or original string
		},
		formatActionButton: function(Status) {
			if (Status === "CANCELLED") {
				return false;
			} else {
				return true;
			}
		},
		formatCheckBox: function(Status) {
			if (Status === "CANCELLED" || Status === "") {
				return false;
			} else {
				return true;
			}
		},
		formatRowColor: function(Status) {
			if (Status === "CANCELLED") {
				return "Error";
			}
		},
		formatTooltip: function(Status) {
			if (Status === "CANCELLED") {
				return "This Requisition has been Cancelled";
			}
		}
	};
});