sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/Token",
	"sap/m/Dialog",
	"sap/m/DialogType",
	"sap/m/Button",
	"sap/m/ButtonType",
	"sap/m/Label",
	"sap/m/MessageToast",
	"sap/m/Text",
	"sap/m/MessageBox",
	"sap/m/TextArea",
	"sap/ui/model/json/JSONModel"
], function(Controller, Filter, FilterOperator, Token, Dialog, DialogType, Button, ButtonType, Label, MessageToast, Text, MessageBox,
	TextArea, JSONModel) {
	"use strict";

	return Controller.extend("man.veh.req.controller.Main", {
		onInit: function() {
			var localModel = new sap.ui.model.json.JSONModel();
			localModel.setData({
				"SearchString": ""
			});
			this.localModel = localModel;
			this.getView().setModel(localModel, "localModel");
			sap.ui.getCore().setModel(localModel, "localModel");
			this.action = window.location.hash.split("-")[1];
			if (this.action === "url") {
				this.action = "approve";
			}
			localModel.setProperty("/Action", this.action);
		},

		onAfterRendering: function() {
			this.oModel = this.getOwnerComponent().getModel();
			this.getRequests();
		},

		onPressApprove: function() {
			this.getView().byId("rejectButton").setEnabled(false);
			this.getView().byId("approveButton").setEnabled(false);
			var docs = this.getSelectedDocs();
			this.confirmDecision(docs, "A");
		},

		onPressReject: function() {
			this.getView().byId("approveButton").setEnabled(false);
			this.getView().byId("rejectButton").setEnabled(false);
			var docs = this.getSelectedDocs();
			this.confirmDecision(docs, "R");
		},

		postActionDocument: function(items, decision, comments) {
			var data = {
				'DECISION': decision,
				"COMMENTS": comments,
				'Items': items
			};
			this.getView().setBusy(true);
			this.oModel.create('/Header', data, {
				success: function(oData) {
					//this.getView().setBusy(true);
					var disApprovedCount = 0;
					var nonRejected = 0;

					this.getOwnerComponent().getModel("VehicleRequisition").read("/VehRequestSet", {
						success: function(response) {
							for (var i = 0; i < response.results.length; i++) {
								for (var j = 0; j < items.length; j++) {
									if (response.results[i].Reqnum === items[j].Reqnum) {
										if (response.results[i].Status.toString().toLowerCase() !== "approved") {
											disApprovedCount++;
											break;
										} else if (response.results[i].Status.toString().toLowerCase() !== "rejected") {
											nonRejected++;
											break;
										}
									}
								}
							}
							if (decision === "A") {
								if (disApprovedCount === 0) {
									if (items.length === 1) {
										MessageBox.success("Request has been approved Successfully..");

									}
									if (items.length > 1) {
										MessageBox.success("Requests have been approved Successfully..");

									}
								} else {
									var req = items[j].Reqnum;
									var reqMessage = "Requisition" + "" + req + "" + "has not been approved";
									MessageBox.success(reqMessage);
								}
								this.getView().byId("rejectButton").setEnabled(true);
								this.getView().byId("approveButton").setEnabled(true);
								this.getView().setBusy(false);
							}
							if (decision === "R") {
								if (nonRejected === 0) {
									if (items.length === 1) {
										MessageBox.success("Request has been rejected Successfully..");
									}
									if (items.length > 1) {
										MessageBox.success("Requests have been rejected Successfully..");
									}

								} else {
									var rej = items[j].Reqnum;
									var rejMessage = "Some problem has occured in rejecting Requisition" + "" + rej;
									MessageBox.error(rejMessage);
								}
								this.getView().byId("rejectButton").setEnabled(true);
								this.getView().byId("approveButton").setEnabled(true);
								this.getView().setBusy(false);
							}
						}.bind(this),
						error: function(error) {
							MessageBox.success(error);
							this.getView().byId("rejectButton").setEnabled(true);
							this.getView().byId("approveButton").setEnabled(true);
							this.getView().setBusy(false);
						}

					});
					this.getView().byId("requestTable").removeSelections();
					this.getRequests();
				}.bind(this),
				error: function(oError) {
					this.getView().setBusy(false);
					this.getView().byId("rejectButton").setEnabled(true);
					this.getView().byId("approveButton").setEnabled(true);
					MessageBox.error("Error while processing request" + oError);
				}.bind(this)
			});
		},

		confirmDecision: function(items, decision) {
			if (items.length === 0) {
				return;
			}
			var text = "";
			var decisiontext = "";
			var commentbut = "";
			var showcomments = "";
			var controlId = "";
			if (decision === "A") {
				decisiontext = "Approve";
				controlId = "rejectButton";
				commentbut = true;
				showcomments = false;
			}
			if (decision === "R") {
				decisiontext = "Reject";
				controlId = "approveButton";
				commentbut = false;
				showcomments = true;
			}
			if (items.length > 1) {
				text = "Are you sure, You want to " + decisiontext + " " + items.length + " documents ?";
			} else {
				text = "Are you sure, You want to " + decisiontext + " " + items[0].Reqnum + " document ?";
			}
			var dialog = new Dialog({
				title: 'Confirm ' + decisiontext,
				type: 'Message',
				content: [
					new Label({
						text: text,
						labelFor: 'submitDialogTextarea'
					}),
					new TextArea('submitDialogTextarea', {
						liveChange: function(oEvent) {
							var sText = oEvent.getParameter('value');
							var parent = oEvent.getSource().getParent();
							parent.getBeginButton().setEnabled(sText.length > 0);
						},
						width: '100%',
						visible: showcomments,
						placeholder: 'Comments (required)'
					})
				],
				beginButton: new Button({
					text: 'Yes',
					enabled: commentbut,
					press: function() {
						this.getView().setBusy(true);
						var reason = sap.ui.getCore().byId('submitDialogTextarea').getValue();
						this.postActionDocument(items, decision, reason);
						dialog.close();
					}.bind(this)
				}),
				endButton: new Button({
					text: 'Cancel',
					press: function() {
						dialog.close();
						this.getView().byId("approveButton").setEnabled(true);
						this.getView().byId("rejectButton").setEnabled(true);
					}.bind(this)
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});
			dialog.open();
		},

		getSelectedDocs: function() {
			var items = this.getView().byId("requestTable").getSelectedItems();
			if (items.length === 0) {
				sap.m.MessageToast.show("Please select at least 1 request.");
				this.getView().byId("rejectButton").setEnabled(true);
				this.getView().byId("approveButton").setEnabled(true);
			}
			var data = [];
			for (var i = 0; i < items.length; i++) {
				data.push({
					'Reinr': items[i].getBindingContext("localModel").getObject().Reinr,
					'Reqnum': items[i].getBindingContext("localModel").getObject().Reqnum
				});
			}
			return data;
		},

		handleSaveVehReq: function(oEvent) {
			var reqData = this.localModel.getProperty("/RequestData");
			if (this.validateMobileNumber(reqData.MobileNo) === false) {
				return;
			}
			this.oModel.create('/VehReqPostSet', reqData, {
				success: function(oData) {
					MessageBox.success("Request Processed Successfully..");
					this.localModel.setProperty("/SearchString", "");
					this.getRequests();
					this.handleCloseVehReq();
				}.bind(this),
				error: function(oError) {
					sap.m.MessageToast.show("Error while processing request");
				}.bind(this)
			});
		},

		validateMobileNumber: function(input) {
			if (input.length !== 10) {
				sap.m.MessageToast.show("Please enter 10 digit mobile number");
				return false;
			}
			if (isNaN(input) === true) {
				sap.m.MessageToast.show("Please enter 10 digit mobile number");
				return false;
			}
			return true;
		},

		onPressAction: function(oEvent) {
			var path = oEvent.getSource().getBindingContext("localModel").getPath();
			var reqData = this.localModel.getProperty(path);
			var data = {};
			data.Reinr = reqData.Reinr;
			data.Reqnum = reqData.Reqnum;
			if (reqData.MobileNo === undefined) {
				reqData.MobileNo = "";
			}
			data.MobileNo = reqData.MobileNo;
			this.localModel.setProperty("/RequestData", data);
			if (!this.requestDialog) {
				this.requestDialog = sap.ui.xmlfragment("man.veh.req.view.valueHelps.RequestCreate", this);
			}
			this.requestDialog.open();
		},

		handleCloseVehReq: function() {
			this.requestDialog.close();
		},

		getRequests: function() {
			var filters = [];
			filters.push(new Filter({
				path: "Status",
				value1: this.action,
				operator: FilterOperator.EQ
			}));
			this.oModel.read("/VehRequestSet", {
				success: function(oData) {
					var data = oData.results;
					for (var i = 0; i < data.length; i++) {
						data[i].Reinr = this.removeLeadingZero(data[i].Reinr);
						data[i].Reqnum = this.removeLeadingZero(data[i].Reqnum);
						data[i].MobileNum = this.removeLeadingZero(data[i].MobileNum);
						data[i].Deptcostcode = this.removeLeadingZero(data[i].Deptcostcode);
					}
					this.localModel.setProperty("/Items", data);
					this.localModel.setProperty("/FinalItems", data);
				}.bind(this),
				error: function(oError) {
					sap.m.MessageToast.show("Error in getting data");
				}.bind(this),
				filters: filters
			});
		},

		searchRequests: function(oEvent) {
			var final = [];
			var items = this.localModel.getProperty("/Items");
			var searchString = oEvent.getSource().getValue();
			// var searchString = this.localModel.getProperty("/SearchString");
			if (searchString.trim() === "") {
				this.localModel.setProperty("/FinalItems", items);
				return;
			}
			for (var i = 0; i < items.length; i++) {
				if (items[i].Reinr.includes(searchString) === true || items[i].Reqnum.includes(searchString) === true) {
					final.push(items[i]);
				}
			}
			this.localModel.setProperty("/FinalItems", final);
		},

		timeFormat: function(input) {
			// debugger;
			if (input.ms === 0) {
				return "00:00";
			}
			var hours = input.ms / (1000 * 60 * 60);
			hours = parseInt(hours).toString();
			if (parseInt(hours) < 10) {
				hours = "0" + hours.toString();
			}
			var mins = input.ms / (1000 * 60) % hours;
			mins = parseInt(mins).toString();
			if (parseInt(mins) < 10) {
				mins = "0" + mins.toString();
			}
			return hours + ":" + mins;
		},

		dateFormat: function(input) {
			var date = "";
			if (input === undefined || input === null) {
				return "";
			}
			if (input.length === undefined) {
				var month = parseInt(input.getMonth() + 1);
				if (month < 10) {
					month = "0" + month.toString();
				}
				var dateno = input.getDate();
				if (dateno < 10) {
					dateno = "0" + dateno.toString();
				}
				date = dateno + "." + month + "." + input.getFullYear();
			}
			return date;
		},

		removeLeadingZero: function(input) {
			return input.replace(/^0+/, '');
		}

	});
});