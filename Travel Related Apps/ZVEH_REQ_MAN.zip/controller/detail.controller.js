sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/Token",
	"sap/m/Dialog",
	"sap/m/DialogType",
	"sap/m/Button",
	"sap/m/ButtonType",
	"sap/m/Label",
	"sap/m/MessageToast",
	"sap/m/Text",
	"sap/m/MessageBox",
	"sap/m/TextArea"
], function(Controller, Filter, FilterOperator, Token, Dialog, DialogType, Button, ButtonType, Label, MessageToast, Text, MessageBox,
	TextArea) {
	"use strict";

	return Controller.extend("man.veh.req.controller.detail", {

	});

});