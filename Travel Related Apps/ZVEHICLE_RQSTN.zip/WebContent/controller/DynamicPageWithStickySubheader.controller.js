sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/Core",
    "sap/ui/model/json/JSONModel",
    "sap/ndc/BarcodeScanner",
    'sap/m/MessageToast',
    "sap/m/MessageBox",
    "sap/ui/core/library",
    "sap/ui/layout/HorizontalLayout",
    "sap/ui/layout/VerticalLayout",
    "sap/m/Dialog",
    "sap/m/Button",
    "sap/m/Label",
    "sap/m/Text",
    "sap/ui/table/Table",
    "sap/m/Input",
    "sap/ushell/services/UserInfo",
    "sap/ui/comp/valuehelpdialog/ValueHelpDialog",
    "sap/ui/ux3/ToolPopup",
    "sap/ui/core/Fragment",
    "sap/ui/model/Filter",
], function(Controller, JSONModel,UserInfo,library, ValueHelpDialog,Fragment,Table, ToolPopup,MessageToast, Core, Dialog, Button, Label, Text, Input) {
    "use strict";

    return Controller.extend("sap.f.sample.DynamicPageWithStickySubheader.controller.DynamicPageWithStickySubheader", {
        onInit: function() {
        	/*self=this;
            var oModel = new sap.ui.model.odata.ODataModel("/sap/bc/ui2/");
            oModel.read("/start_up", null, null, false, function(oData, oResponse){
            	
              var   userData= oResponse.body.split(',')[7]	
            	window.userId=userData.substring(6,userData.length-1);
            	window.client=oResponse.body.split(',')[15].substring(10,oResponse.body.split(',')[15].length-1);
    			console.log(oResponse)	
    			console.log(userId)	;
    			localStorage.setItem("userId", userId);
            });*/
        	this.getView().byId("create").setVisible(false);
        	this.getView().byId("update").setVisible(false);
        	this.getView().byId("SubmitForm").setVisible(false);
        	//this.getView().byId("UpdateForm").setVisible(false);
        	// this.getView().byId("UpdateR").setVisible(false);
        	 this.getView().byId("SimpleFormChange35402").setVisible(false);
        	 this.getView().byId("SimpleFormChange354").setVisible(false);
        	 this.getView().byId("updateForm").setVisible(false);
        } ,
        
        handleChange: function(oEvent){
        	var Trn001 = this.getView().byId("go").getValue();
        	
        	if(Trn001===""){
        		
        	}
        },
        
        onGo:function(){
       	var trn = this.getView().byId("go").getValue();
        	//alert(trn);
//        if(trn === "")
//            this.setValueState(sap.ui.core.ValueState.Error);
//        else
//            this.setValueState(sap.ui.core.ValueState.Success);
//        	
//        
        var server = window.location.origin;
        //alert(delNum);
        if (trn.length != 0) {
        	//var selectedRowdata = this.byId("idProductsTable").getSelectedContexts()[0].getObject();
        	   var odataservice = "/sap/opu/odata/sap/ZTRAVEL_MANAGEMENT_SRV/";
               var link = server + odataservice;
               var oMode21 = new sap.ui.model.odata.ODataModel(link, true);
               //var oMode21 = new sap.ui.model.odata.ODataModel("proxy/http/192.168.6.123:8000/sap/opu/odata/sap/ZPIC_SEC_SRV/", true);
               //var oMode20=new sap.ui.model.odata.ODataModel("http://192.168.6.123:8000/sap/opu/odata/sap/ZPIC_SEC_SRV/",true);

               oMode21.read("ZTRAVELREQ(Pernr='00003320',Reinr='"+trn+"')", null, null, false, function(oData, oResponse) {
                   console.log(oMode21);

                   var oOdataJSONModelDLSet1 = new sap.ui.model.json.JSONModel();
                   sap.ui.getCore().setModel(oOdataJSONModelDLSet1, "ZTRAVELREQ");
                   oOdataJSONModelDLSet1.setData({
                       DLSet: oData
                   });
               }, function(err) {

                   console.log("error");

               });

               var Data3 = sap.ui.getCore().getModel("ZTRAVELREQ").getData();
               var jsonModel3 = new sap.ui.model.json.JSONModel({
                   ProductCollection: Data3.DLSet
               });

            //alert(JSON.stringify(Data2.DLSet.results[0].Vbeln));
//            if (Data2.DLSet.results.length != 0) {
//                this.getView().byId("dno").setValue(Data2.DLSet.results[0].Vbeln);
//            } else {
//                this.getView().byId("dno").setValue('');
//            }
            this.getView().byId("idProductsTable").setModel(jsonModel3);
        }else{
        	
        	
        }

     			//this.getView().setModel(oModel);
//     			var TRNO = this.getView().byId("TRN0").setValue(Data2.DLSet.Reinr)
//     			var FromPlace= this.getView().byId("From0").setValue(Data2.DLSet.LocationBeg)
//     			var ToPlace = this.getView().byId("To0").setValue(Data2.DLSet.LocationEnd)
//     			var DateBeg = this.getView().byId("Date0").setValue(Data2.DLSet.DateBeg.toLocaleDateString())
     			
     			
//     			var screen_time = Data2.DLSet.TimeBeg.ms;
//    			//console.log(screen_time);
//    			
//    			 let seconds = (screen_time / 1000);
//    			
//    			 const hours =parseInt( seconds / 3600 );
//    			 seconds = seconds % 3600; 
//    			
//    			 const minutes = parseInt( seconds / 60 ); 
//    			 seconds = seconds % 60;
//    			 
//    			 var screen_time2 = hours+":"+minutes+":"+seconds ; 
//    		
    			//var TimeBeg = this.getView().byId("Time0").setValue(screen_time2)
    			
//    			if(Data2.DLSet.Request == 1)
//    				var status = this.getView().byId("status").setValue("In Progress")
        },
     
      /*  onValueHelpRequest: function(){
        	debugger;
        	var userId = localStorage.getItem("userId");
        	 var server = window.location.origin;
        	 var odataservice = "/sap/opu/odata/sap/ZTRAVEL_MANAGEMENT_SRV/";
    		 var link = server + odataservice;
    	     var oMode20 = new sap.ui.model.odata.ODataModel(link, true);
    
    	     
    	 	oMode20.read("ZTRAVELREQ(Pernr='userId',Reinr='0000102845')", null, null, false ,function(oData, oResponse){
    		var oOdataJSONModelDLSet = new sap.ui.model.json.JSONModel();
    		sap.ui.getCore().setModel(oOdataJSONModelDLSet , "ZTRAVELREQ");
    		oOdataJSONModelDLSet.setData({ DLSet : oData });
    		
    	       }, function(err){

    	            console.log("error");

    	               } );  
    			 var Data2 = sap.ui.getCore().getModel("ZTRAVELREQ").getData();
    			 
    			 
        	var oInput = this.getView().byId("idvaluehelp1")
        	if(!this._onValueHelpDilog){
        		//alert("Hello");
        		
        		this._onValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog("idvaluehelp",{        		
        			 title:"Transport Request Number Details",   
        			 supportMultiselect: false,
        			 key:"TRN",
        			 descriptionKey :"VRN",
        			
        			 ok: function(oEvent){
        				 debugger;
        				 var aTokens = oEvent.getParameter("tokens");
        				 oInput.setTokens(aTokens);
        				// this._onValueHelpDilog.openBy(oEvent.getSource());
        				 this.destroy();
        				 this.close();
        				
        			},
        			cancel: function(){
        				//this._onValueHelpDialog.destroy();
        				 this.destroy();
        				this.close();
        			}	
        		})
        		
        	}
        	
        	//bind the column of the model
        	//dynamically create the column structure for the 
        	var oColModel = new sap.ui.model.json.JSONModel();
        	oColModel.setData({
        		cols:[
       			{label:"Travel Requisition Number", template: "TRN"},
       			{label:"From", template: "frm" ,width:"-20%"},
        		{label:"To", template: "to"},
        		{label:"Date", template: "Date"},
        		{label:"Time ", template: "time"},
        		{label:"Vehicle Requisition Number", template: "VRN"},
        		{label:"Status", template: "status"}
        		]
        	});
        	
        	var oTable = this._onValueHelpDialog.getTable();
        	oTable.setModel(oColModel,"columns")
        	
        	//Creating row model and binding it to row aggregation of table
        	var oRowModel = new sap.ui.model.json.JSONModel("model/mock.json");
        	oTable.setModel(oRowModel);
        	oTable.bindRows("/TravelRequest");
        	this._onValueHelpDialog.open();
        	//this._onValueHelpDialog.destroy();
        },*/
        radiobuttonselect: function(evt){
        	this.getView().byId("create").setVisible(true);
        	
        	
        },
//        handleChange1:function(oEvent){
//        	
//			 alert(oDate);
//        },
        onSubmit: function(){
        	this.getView().byId("SubmitForm").setVisible(false);
        	this.getView().byId("SimpleFormChange354").setVisible(false);
        	this.getView().byId("create").setVisible(false);
        	this.getView().byId("update").setVisible(true);
        	 this.getView().byId("updateForm").setVisible(false);
        	//this.getView().byId("UpdateForm").setVisible(true);
        	
   	var sServiceUrl = "/sap/opu/odata/sap/ZTRAVEL_MANAGEMENT_SRV";
            var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, false);
        	
        	var oEntry = {};
        	var time2= this.getView().byId("ERT01").getValue()
        	var format1 = sap.ui.core.format.DateFormat.getTimeInstance({

				pattern : "PThh'H'mm'M'ss'S"

				});
        	oEntry.ExpctRlseTime = format1.format(format1.parse(time2));
        	var time1= this.getView().byId("ST01").getValue()
        	var format1 = sap.ui.core.format.DateFormat.getTimeInstance({

				pattern : "PThh'H'mm'M'ss'S'"

				});
			
			oEntry.StartTime = format1.format(format1.parse(time1));
        	//oEntry.StartTime = "PT09H00M00S";
			oEntry.ReqNum = this.getView().byId("go").getValue();
        	
        	//oEntry.ReqName = this.getView().byId("Name01").getValue();
        	oEntry.MobileNum = this.getView().byId("MobNo").getValue();
        	oEntry.JourFrom = this.getView().byId("From01").getValue();
//        	//oEntry.JourTo = this.getView().byId("To01").getValue();
        	//oEntry.DeptCostcode = this.getView().byId("dcc01").getValue();
        	oEntry.JourDate = this.getView().byId("JD01").getDateValue();
        	//oEntry.StartTime =  this.oDate;
        	//oEntry.ExpctRlseTime = this.getView().byId("ERT01").getDateValue().getTime()
        	//oEntry.Purpose = this.getView().byId("purp0").getValue();
       	 
        	oModel.create('/ZTRAVEL_MGMTSet', oEntry, null,
        	function(){          
        		alert("Data is Submitted successfully");

        	      },
        	      function(){

        	        alert("Please Enter the Data Properly");
        	        
        	      });
        	
        },
        handleChange: function(oEvent){
        	
	       
	    },
        
	    onCreate : function(){
        	this.getView().byId("create").setVisible(false);
        	 this.getView().byId("SimpleFormChange354").setVisible(true);
        		this.getView().byId("SubmitForm").setVisible(true);
        	// this.getView().byId("UpdateForm").setVisible(true);
        	 //this.getView().byId("SubmitForm").setVisible(true);
        	 	var trn = this.getView().byId("go").getValue();
        	 	 this.getView().byId("updateForm").setVisible(false);
        	 	
        	 	
        	 	
        		 var server = window.location.origin;
          		// var odataservice = "/sap/opu/odata/sap/ZEQUIP_HEALTH_SRV_02/";
          		 var odataservice = "/sap/opu/odata/sap/ZTRAVEL_MANAGEMENT_SRV/";
          		 var link = server + odataservice;
          	     var oMode20 = new sap.ui.model.odata.ODataModel(link, true);
          	     
              
          	 oMode20.read("/ZTRAVELREQ(Pernr='00003320',Reinr='"+trn+"')", null, null, false ,function(oData, oResponse){
          		var oOdataJSONModelDLSet = new sap.ui.model.json.JSONModel();
          		sap.ui.getCore().setModel(oOdataJSONModelDLSet , "ZEQUIP_HEALTH_1FM_ENTSet");
          		oOdataJSONModelDLSet.setData({ DLSet : oData });
          		
          	       }, function(err){

          	            console.log("error");

          	               } );  
          			 var Data1 = sap.ui.getCore().getModel("ZEQUIP_HEALTH_1FM_ENTSet").getData();
        		
          			 var Name = this.getView().byId("Name01").setText(Data1.DLSet.Ename)
          			 var DeptCostCode = this.getView().byId("dcc01").setText(Data1.DLSet.CostCode)
          			 var JournTo =this.getView().byId("To01").setText(Data1.DLSet.LocationEnd)
          			 var Purpose = this.getView().byId("purp0").setText(Data1.DLSet.Reason)
     //   	var oDialog = new sap.m.Dialog("Dialog1",{
       //	     title:"Transport Requisition Form",
//       	    alignContent:"Center",
//       	
//       	     class:"sapUiResponsivePadding", //Not working
//       	     
//       	     content:[
//       	    	 
//       	          new sap.m.Label({text:"Name : ", width:"30%"}),
//       	          new sap.m.Input({id: "Name0" , value:"Animesh Banerjee", width:"50%" }),
//       	          new sap.m.Label({text:"Mobile Number : " , width:"30%"}),
//       	          new sap.m.Input({maxLength: 10, id: "MobNo" ,value:"9665004167",  width :"50%"}),
//       	          new sap.m.Label({text:"Journey From : ", width:"30%"}),
//    	          new sap.m.Input({id: "JourneyF" ,width :"50%", value:"Pune" }),
//    	          new sap.m.Label({text:"Journey To : ", width:"30%"}),
//    	          new sap.m.Input({maxLength: 10, id: "JourneyT" , value:"Mumbai", width :"50%"}),
//       	          new sap.m.Label({text:"Dept.Cost Code :", width:"30%" }),
//    	          new sap.m.Input({id: "DeptCC" ,width :"51%" , value:"000096" }),
//    	         
//       	          new sap.m.Label({text:"Journey Date :",width:"30%" }),
//    	          new sap.m.DatePicker({id: "JourneyD" ,width :"50%", value:"13 July, 2022"  }),
//    	          new sap.m.Label({text:"Starting Time : ",width:"30%" }),
//    	          new sap.m.TimePicker({ id: "StartTime" , width :"50%", value:"5.00 "}),
//       	          new sap.m.Label({text:"Expected Release Time :", width :"30%"}),
//    	          new sap.m.TimePicker({id: "Exp_Release_Time" ,width :"55%"  }),
//    	          new sap.m.Label({text:"Purpose : ", width :"30%"}),
//    	          new sap.m.Input({ id: "Purpose" ,value:"Office tour", width :"35%"}),
//       	         
//    	          new sap.m.Button({id:"Submit", text:"Submit" ,width:"100px", press:"onSubmitForm"})
//       	     ]
//       });
//
//       sap.ui.getCore().byId("Dialog1").open();
       this.getView().byId("create").setVisible(false);
      
        },
        
        onUpdate : function(){
        	this.getView().byId("SimpleFormChange35402").setVisible(true);
        	//this.getView().byId("Update").setVisible(false);
        	this.getView().byId("create").setVisible(false);
        	this.getView().byId("update").setVisible(false);
        	this.getView().byId("updateForm").setVisible(true);

        }
      
      
    })
});