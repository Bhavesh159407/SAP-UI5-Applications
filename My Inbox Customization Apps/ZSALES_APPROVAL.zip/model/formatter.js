sap.ui.define([], function() {
	"use strict";
	return {
		formatDate: function(Doj) {
			if (Doj !== undefined && Doj !== null && Doj !== "") {
				var offSet = Doj.getTimezoneOffset();
				var offSetVal = Doj.getTimezoneOffset() / 60;
				var h = Math.floor(Math.abs(offSetVal));
				var m = Math.floor((Math.abs(offSetVal) * 60) % 60);
				Doj = new Date(Doj.setHours(h, m, 0, 0));
			}
			var oDataFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "dd/MM/yyyy"
			}, sap.ui.getCore().getConfiguration().getLocale());
			return oDataFormat.format(Doj, true);
		},
		formatStatus: function(status) {
			if (status >= "1") {
				return "Approved";
			} else if (status === "R") {
				return "Rejected";
			} else {
				return "Pending";
			}
		}
		// isButtonEnabled: function(Zappr) {
		// 	console.log("Zappr value in formatter:", Zappr);

		// 	// Convert the value to string for comparison, in case it is not already a string
		// 	var zapprValue = String(Zappr).trim();
		// 	// Check if it is empty or not and return the boolean accordingly
		// 	return zapprValue === "" || zapprValue === null || zapprValue === undefined;
		// }
	};
});