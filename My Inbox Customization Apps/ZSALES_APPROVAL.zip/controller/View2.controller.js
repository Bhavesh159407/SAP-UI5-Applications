sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/ui/core/routing/History",
	"comZSales_Return_Layout/model/formatter"
], function(Controller, JSONModel, Filter, FilterOperator, MessageBox, History, formatter) {
	"use strict";

	return Controller.extend("comZSales_Return_Layout.controller.View2", {
		f: formatter,
		onInit: function() {
			var serviceUrl = "/sap/opu/odata/sap/ZSD_SR_APPR_SRV";
			var oModel = new sap.ui.model.odata.v2.ODataModel(serviceUrl, {
				defaultBindingMode: sap.ui.model.BindingMode.TwoWay
			});

			// // Set the model to the view
			// this.getView().setModel(oModel, "InvoiceModel");

			// Read data from the entity set
			oModel.read("/ApprovalsSet", {
					urlParameters: {
					"$orderby": "Zapno desc" // Ordering by zdec in descending order
				},
				success: function(oData) {
					var oJSONModel = new sap.ui.model.json.JSONModel();
					oJSONModel.setData({
						items: oData.results
					});
					this.getView().setModel(oJSONModel, "InvoiceModel");

					// Set initial SingleInvoiceModel data
					var firstItem = oData.results[0];
					var invSin = new sap.ui.model.json.JSONModel(firstItem);
					this.getView().setModel(invSin, "SingleInvoiceModel");

					// Attach the property change event listener
					oJSONModel.attachPropertyChange(this.onModelChange, this);

					// Update button states based on the initial values of Zappr, Zevp, and Zmd
					this.updateButtonStates(firstItem.Zappr, firstItem.Zevp, firstItem.Zmd);

					// Initialize other properties
					this.invNum = firstItem.Zapno;
					this.getOwnerComponent().getRouter().getRoute("object1").attachPatternMatched(this.onPatternMatched, this);
					this.handleAdditionalCode(firstItem.Zapno);
					this.handlestatusCode(firstItem.Zapno);
				}.bind(this),

				error: function(error) {
					var message = "Error loading invoice data. Please try again later.";
					sap.m.MessageBox.error(message);
					console.error("Error loading data:", error);
				}.bind(this)
			});
		},

		onModelChange: function(oEvent) {
			// When the model changes, update the button states
			var oModel = oEvent.getSource();
			var Zevp = oModel.getProperty("/Zevp");
			var Zmd = oModel.getProperty("/Zmd");
			var Zappr = oModel.getProperty("/Zappr");
			this.updateButtonStates(Zappr, Zevp, Zmd);
		},

		updateButtonStates: function(Zappr, Zevp, Zmd) {
			console.log("Zappr:", Zappr, "Zevp:", Zevp, "Zmd:", Zmd);

			var oApproveButton = this.byId("idApproveButton");
			var oForwardButton = this.byId("idForwardButton");
			var oRejectButton = this.byId("idCancelTripButton");

			// Reset all buttons initially
			oApproveButton.setEnabled(false);
			oForwardButton.setEnabled(false);
			oRejectButton.setEnabled(false);

			// Handle cases based on the combinations of Zappr, Zevp, and Zmd
			if (Zappr === "" && Zevp === "" && Zmd === "") {
				console.log("Case: Zappr='', Zevp='', Zmd='', enabling Forward and Reject buttons");
				oForwardButton.setEnabled(true);
				oRejectButton.setEnabled(true);
			} else if (Zappr === "" && Zevp === "X" && Zmd === "") {
				console.log("Case: Zappr='', Zevp='X', Zmd='', enabling all buttons");
				oApproveButton.setEnabled(true);
				oForwardButton.setEnabled(true);
				oRejectButton.setEnabled(true);
			} else if (Zappr === "" && Zevp === "" && Zmd === "X") {
				console.log("Case: Zappr='', Zevp='', Zmd='X', enabling Approve and Reject buttons");
				oApproveButton.setEnabled(true);
				oRejectButton.setEnabled(true);
			} else if (Zappr === "X" && Zevp === "" && Zmd === "") {
				console.log("Case: Zappr='X', Zevp='', Zmd='', disabling all buttons");
				// All buttons remain disabled
			} else if (Zappr === "X" && Zevp === "X" && Zmd === "") {
				console.log("Case: Zappr='X', Zevp='X', Zmd='', disabling all buttons");
				// All buttons remain disabled
			} else if (Zappr === "X" && Zevp === "" && Zmd === "X") {
				console.log("Case: Zappr='X', Zevp='', Zmd='X', disabling all buttons");
				// All buttons remain disabled
			}
		},

		// Method to handle pattern matched event for object1 route
		onPatternMatched: function(oEvent) {
			var productID = oEvent.getParameter("arguments").key;
			if (productID !== undefined && productID !== "") {
				this.firstProductId = productID;
			}

			var items = this.getView().getModel("InvoiceModel").getProperty("/items");
			var singleInvoiceData = items[productID];
			this.getView().getModel("SingleInvoiceModel").setData(singleInvoiceData);

			this.invNum = singleInvoiceData.Zapno;
			this.handleAdditionalCode(singleInvoiceData.Zapno);
			this.handlestatusCode(singleInvoiceData.Zapno);
			// Update button states based on the initial value of Zappr
			this.updateButtonStates(singleInvoiceData.Zappr, singleInvoiceData.Zevp, singleInvoiceData.Zmd);
		},

		// Method to handle row press event in the list
		// onProductRowPress: function(oEvent) {
		// 	var selectedItem = oEvent.getSource().getBindingContext("InvoiceModel").getObject();
		// 	var items = this.getView().getModel("InvoiceModel").getProperty("/items");

		// 	// Find the index of the selected item
		// 	// var selectedIndex = items.indexOf(selectedItem);

		// 	// if (selectedIndex !== -1) {
		// 	// 	this.getOwnerComponent().getRouter().navTo("object2", {
		// 	// 		keyIndex: selectedIndex
		// 	// 	});
		// 	// }
		// },

		handleAdditionalCode: function(zapno) {
			var vendorModel = new sap.ui.model.json.JSONModel({});
			this.getView().setModel(vendorModel, "VendorModel");

			var serviceUrl = "/sap/opu/odata/sap/ZSD_SR_APPR_SRV";
			var oModel = new sap.ui.model.odata.v2.ODataModel(serviceUrl);

			oModel.read("/InvoicesSet", {
				success: function(data) {
					var filteredData = data.results.filter(function(item) {
						return item.Zapno === zapno;
					});

					if (filteredData.length > 0) {
						var oJSONModel = new sap.ui.model.json.JSONModel();
						oJSONModel.setData({
							Items: filteredData
						});
						this.getView().setModel(oJSONModel, "VendorModel");
						console.log("Filtered data for zapno:", zapno, filteredData);

						var selectedIndex = filteredData.findIndex(function(item) {
							return item.Zapno === zapno;
						});

					}
				}.bind(this),
				error: function(error) {
					console.error("Error fetching invoices:", error);
				}
			});
		},

		handlestatusCode: function(zapno) {
			var serviceUrl = "/sap/opu/odata/sap/ZSD_SR_APPR_SRV";
			var oModel = new sap.ui.model.odata.v2.ODataModel(serviceUrl);

			oModel.read("/StatusSet", {
				filters: [
					new sap.ui.model.Filter("Zapno", sap.ui.model.FilterOperator.EQ, zapno)
				],
				success: function(data) {
					var oJSONModel = new sap.ui.model.json.JSONModel();
					oJSONModel.setData({
						Items: data.results
					});
					this.getView().setModel(oJSONModel, "AttamentModel");
					console.log("Filtered data for zapno:", zapno, data.results);

				}.bind(this),
				error: function(error) {
					console.error("Error fetching status data:", error);
				}
			});
		},

		onApprovePOPress: function() {
			if (!this.dialogApprove) {
				this.dialogApprove = sap.ui.xmlfragment(this.getView().getId(), "comZSales_Return_Layout.view.Fragment.ApproveReason", this);
				this.getView().addDependent(this.dialogApprove);
			}
			this.dialogApprove.open();
		},
		onRecommendedPOPress: function() {
			if (!this.dialogApprove) {
				this.dialogApprove = sap.ui.xmlfragment(this.getView().getId(), "comZSales_Return_Layout.view.Fragment.RecommendedReason", this);
				this.getView().addDependent(this.dialogApprove);
			}
			this.dialogApprove.open();
		},

		onRejectPOPress: function() {
			if (!this.dialogReject) {
				this.dialogReject = sap.ui.xmlfragment(this.getView().getId(), "comZSales_Return_Layout.view.Fragment.RejectReason", this);
				this.getView().addDependent(this.dialogReject);
			}
			this.dialogReject.open();
		},

		onCloseDialog: function() {
			if (this.dialogApprove) {
				this.getView().byId("idTextAreaApprvReason").setValue("");
				this.dialogApprove.close();
			}
			if (this.dialogReject) {
				this.getView().byId("idTextAreaRejReason").setValue("");
				this.dialogReject.close();
			}
		},

		onRecommendedSubmit: function() {
			this.selectedZapno = this.getView().getModel("SingleInvoiceModel").getProperty("/Zapno");
			var response = "ACCEPT"; // Response for approval
			var notes = this.byId("idTextAreaApprvReason").getValue();

			if (!notes) {
				sap.m.MessageBox.error("Please provide a reason for approval");
				return;
			}

			this.sendDataToBackend(this.selectedZapno, response, notes);
			this.onCloseDialog();
		},

		onApproveSubmit: function() {
			this.selectedZapno = this.getView().getModel("SingleInvoiceModel").getProperty("/Zapno");
			var response = "APPROVE"; // Response for approval
			var notes = this.byId("idTextAreaApprvReason").getValue();

			if (!notes) {
				sap.m.MessageBox.error("Please provide a reason for approval");
				return;
			}

			this.sendDataToBackend(this.selectedZapno, response, notes);
			this.onCloseDialog();
		},
		onReasonSubmit: function() {
			this.selectedZapno = this.getView().getModel("SingleInvoiceModel").getProperty("/Zapno");
			var response = "REJECT"; // Response for rejection
			var notes = this.byId("idTextAreaRejReason").getValue();

			if (!notes) {
				sap.m.MessageBox.error("Please provide a reason for rejection");
				return;
			}

			this.sendDataToBackend(this.selectedZapno, response, notes);
			this.onCloseDialog();
		},
		sendDataToBackend: function(zapno, response, notes) {
			var that = this; // Save the current context as `that`

			var payload = {
				Zapno: zapno,
				Zresp: response,
				Znotes: notes
			};

			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZSD_SR_APPR_SRV/");

			oModel.create("/ResponseSet", payload, {
				method: "POST",
				success: function(data) {
					console.log("POST request successful", data);

					// Call the refresh method
					that.refreshView();

				},
				error: function(error) {
					console.error("POST request failed", error);
				}
			});
		},

		refreshView: function() {
			var that = this;
			var oModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZSD_SR_APPR_SRV/");

			// Refresh ApprovalsSet data
			oModel.read("/ApprovalsSet", {
				success: function(oData) {
					var items = oData.results;
					var updatedItem = null;

					// Traditional loop to find the updated item
					for (var i = 0; i < items.length; i++) {
						if (items[i].Zapno === that.invNum) {
							updatedItem = items[i];
							break;
						}
					}

					if (updatedItem) {
						var oJSONModel = new sap.ui.model.json.JSONModel();
						oJSONModel.setData({
							items: items
						});
						that.getView().setModel(oJSONModel, "InvoiceModel");

						var invSin = new sap.ui.model.json.JSONModel(updatedItem);
						that.getView().setModel(invSin, "SingleInvoiceModel");

						// Update button states based on the new data
						that.updateButtonStates(updatedItem.Zappr, updatedItem.Zevp, updatedItem.Zmd);
					} else {
						console.log("Item not found for Zapno:", that.invNum);
					}
				},
				error: function(error) {
					console.error("Error re-reading data:", error);
				}
			});

			// Refresh StatusSet data
			oModel.read("/StatusSet", {
				filters: [
					new sap.ui.model.Filter("Zapno", sap.ui.model.FilterOperator.EQ, that.invNum)
				],
				success: function(data) {
					var oJSONModel = new sap.ui.model.json.JSONModel();
					oJSONModel.setData({
						Items: data.results
					});
					that.getView().setModel(oJSONModel, "AttamentModel");
					console.log("Filtered data for zapno:", that.invNum, data.results);
				},
				error: function(error) {
					console.error("Error fetching status data:", error);
				}
			});

			// Refresh InvoicesSet data
			oModel.read("/InvoicesSet", {
				filters: [
					new sap.ui.model.Filter("Zapno", sap.ui.model.FilterOperator.EQ, that.invNum)
				],
				success: function(data) {
					var filteredData = data.results.filter(function(item) {
						return item.Zapno === that.invNum;
					});

					if (filteredData.length > 0) {
						var oJSONModel = new sap.ui.model.json.JSONModel();
						oJSONModel.setData({
							Items: filteredData
						});
						that.getView().setModel(oJSONModel, "VendorModel");
						console.log("Filtered data for zapno:", that.invNum, filteredData);
					}
				},
				error: function(error) {
					console.error("Error fetching invoices:", error);
				}
			});
		}

	});
});