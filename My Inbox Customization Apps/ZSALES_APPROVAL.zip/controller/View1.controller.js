sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox",
	"sap/ui/core/routing/History"
], function(Controller, Filter, FilterOperator, JSONModel, MessageBox, History) {
	"use strict";
	return Controller.extend("comZSales_Return_Layout.controller.View1", {
		onInit: function() {
			var serviceUrl = "/sap/opu/odata/sap/ZSD_SR_APPR_SRV"; // Replace with the correct service URL
			var oModel = new sap.ui.model.odata.v2.ODataModel(serviceUrl, {
				defaultBindingMode: sap.ui.model.BindingMode.TwoWay // Optionally set binding mode
			});
			// Set the model to the view
			this.getView().setModel(oModel, "InvoiceModel");

			// Read data from the entity set
			oModel.read("/ApprovalsSet", {
				urlParameters: {
					"$orderby": "Zapno desc" // Ordering by zdec in descending order
				},
				success: function(oData) {
					var oJSONModel = new JSONModel();
					oJSONModel.setData({
						items: oData.results
					});
					this.getView().setModel(oJSONModel, "InvoiceModel");
				}.bind(this), // Bind 'this' to maintain context of the controller
				error: function(error) {
						var message = "Error loading invoice data. Please try again later.";
						MessageBox.error(message);
						console("Error loading data:", error);
					}.bind(this) // Bind 'this' for the error callback as well
			});
		},
		onSelectionChange: function(oEvent) {
			var proIndex = oEvent.getSource().getSelectedItem().getBindingContext("InvoiceModel").getPath().split("/")[2];
			console.log("Selected item index:", proIndex);

			if (proIndex) {
				this.getOwnerComponent().getRouter().navTo("object1", {
					key: proIndex
				});
			}
		},

		onFilterPONumbers: function() {
			var searchString = this.getView().byId("searchField").getValue();
			var aFilters = [];
			if (searchString) {
				var oFilter = new Filter("Zapno", FilterOperator.Contains, searchString);
				aFilters.push(oFilter);
			}
			this.getView().byId("list").getBinding("items").filter(aFilters);
		}
	});
});