sap.ui.define([], function() {
	"use strict";
	return {
		formatDate: function(date) {
			if (date) {
				const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "yyyy/MM/dd"
				});
				return oDateFormat.format(new Date(date));
			}
			return "";
		},

		enableButtons: function(deviation, buttonType) {
			console.log("Deviation:", deviation, "ButtonType:", buttonType);

			// Ensure deviation is valid
			if (typeof deviation === "undefined" || deviation === null) {
				return false; // Hide buttons when Deviation is undefined or null
			}

			// Check conditions for button visibility
			if (deviation === "") {
				return buttonType === "Actual Deviation" || buttonType === "Deviation Credit" || buttonType === "No Credit";
			} else if (deviation === "X") {
				return buttonType === "Approve" || buttonType === "Reject";
			}

			// Default to hiding the button
			return false;
		}

	};
});