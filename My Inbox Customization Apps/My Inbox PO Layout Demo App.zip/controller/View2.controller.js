sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/ui/core/routing/History",
	"comZSales_Return_Layout/model/formatter"
], function(Controller, JSONModel, Filter, FilterOperator, MessageBox, History, formatter) {
	"use strict";

	return Controller.extend("comZSales_Return_Layout.controller.View2", {
	
		onInit: function() {
	
		}

	});
});