sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel",
	"ZSakshi_New_PO/model/formatter"
], function(Controller, Filter, FilterOperator, JSONModel, formatter) {
	"use strict";

	return Controller.extend("ZSakshi_New_PO.controller.View1", {
		f: formatter,
		onInit: function() {
			var inv = new JSONModel({});
			this.getView().setModel(inv, "InvoiceModel");
			this.getOwnerComponent().getModel().read("/InvoiceListSet", {
				success: function(oData) {
					this.getView().getModel("InvoiceModel").setProperty("/items", oData.results);
				}.bind(this),
				error: function(error) {
					var message = "Error loading invoice data. Please try again later.";
					// Display error message in a dialog or notification
					sap.m.MessageBox.error(message);
					var eventBus = sap.ui.getCore().getEventBus();
					eventBus.subscribe("ApproveInvoice", "InvoiceApproved", this.onInvoiceApproved, this);

				}
			});
		},
		onSelectionChange: function(oEvent) {
			var proIndex = oEvent.getSource().getSelectedItem().getBindingContextPath().split("/")[2];
			this.getOwnerComponent().getRouter().navTo("object1", {
				key: proIndex
			});
		},
		onFilterPONumbers: function() {
			var searchString = this.getView().byId("searchField").getValue();
			var aFilters = [];
			if (searchString) {
				var oFilter = new Filter("Belnr", FilterOperator.Contains, searchString);
				aFilters.push(oFilter);
			}
			this.getView().byId("list").getBinding("items").filter(aFilters);
			this.refresh("items");
		}
	});
});