sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"ZSakshi_New_PO/model/formatter"
], function(Controller, MessageBox, JSONModel, formatter) {
	"use strict";

	return Controller.extend("ZSakshi_New_PO.controller.View2", {
		f: formatter,
		onInit: function() {

			var inv = new JSONModel({});
			this.getView().setModel(inv, "InvoiceModel");
			var invSin = new JSONModel({});
			this.getView().setModel(invSin, "SingleInvoiceModel");
			this.getOwnerComponent().getModel().read("/InvoiceListSet", {
				success: function(oData) {
					this.getView().getModel("InvoiceModel").setProperty("/items", oData.results);
					this.firstProductId = "0";
					this.getOwnerComponent().getRouter().getRoute("object1").attachPatternMatched(this.onPatternMatched, this);
					this.getView().getModel("SingleInvoiceModel").setData(this.getView().getModel("InvoiceModel").getProperty("/items")[0]);
					this.invNum = this.getView().getModel("SingleInvoiceModel").getData().Belnr;
					this.invDate = new Date(this.getView().getModel("SingleInvoiceModel").getData().WfStartDt);
					this.invFiscalYear = this.getView().getModel("SingleInvoiceModel").getData().Gjahr;
					this.appStatus = this.getView().getModel("SingleInvoiceModel").getData().AppStatus;

					// Call the new function to handle additional code
					this.handleAdditionalCode();
					this.fetchFilteredVendorInvoices();
					this.fetchEKPOData();
				}.bind(this),
				error: function(error) {
					// Error handler
					console.error("Error fetching invoice data:", error);
				}
			});

		},

		onPatternMatched: function(oEvent) {
			var productID = oEvent.getParameter("arguments").key;
			if (productID !== undefined || productID !== "") {
				this.firstProductId = oEvent.getParameter("arguments").key;
			}
			var singleInvoiceData = this.getView().getModel("InvoiceModel").getProperty("/items")[productID];
			this.getView().getModel("SingleInvoiceModel").setData(singleInvoiceData);
			this.invNum = singleInvoiceData.Belnr; // Set this.invNum to the correct Belnr value
			this.invDate = new Date(singleInvoiceData.WfStartDt);
			this.invFiscalYear = singleInvoiceData.Gjahr;
			this.appStatus = singleInvoiceData.AppStatus;
			this.handleAdditionalCode(singleInvoiceData.Belnr, singleInvoiceData.Gjahr);
		},
		// Function to handle additional code
		handleAdditionalCode: function(belnr, gjahr) {
			// Create and set AttachmentModel
			var atch = new JSONModel({});
			this.getView().setModel(atch, "AttachmentModel");

			// Fetching data from AttachmentsSet based on Belnr and Gjahr
			this.getOwnerComponent().getModel().read("/GetAttachmentList", {
				urlParameters: {
					"$filter": "Belnr eq '" + this.invNum + "' and Gjahr eq '" + this.invFiscalYear + "'"
				},
				success: function(data) {
					// Success handler
					// Set the attachment data to the AttachmentModel
					this.getView().getModel("AttachmentModel").setProperty("/Items", data.results); // Adjusted to set Items property
					console.log("Attachment data fetched successfully:", data.results);
				}.bind(this),
				error: function(error) {
					// Error handler
					console.error("Error fetching attachments:", error);
				}
			});
		},

		onProductRowPress: function(oEvent) {
			this.getOwnerComponent().getRouter().navTo("object2", {
				key: this.firstProductId
			});
		},
		fetchEKPOData: function() {
			// Access singleInvoiceModel from the controller's scope
			var singleInvoiceModel = this.getView().getModel("SingleInvoiceModel");

			// Check if singleInvoiceModel is defined and not null
			if (singleInvoiceModel) {
				// Get the Ebeln from the singleInvoiceModel
				var ebeln = singleInvoiceModel.getProperty("/Ebeln");

				// Create and set EKPOModel
				var ekpoModel = new sap.ui.model.json.JSONModel({});
				this.getView().setModel(ekpoModel, "EKPOModel");

				// Fetching data from EKPOSet based on Ebeln with top 10 results
				var mParameters = {
					filters: [
						new sap.ui.model.Filter("Ebeln", sap.ui.model.FilterOperator.EQ, ebeln)
					],
					// urlParameters: {
					// 	"$top": 10
					// },
					success: function(oData) {
						// Handle success
						console.log("Top 10 vendor invoices filtered by Ebeln:", oData);
						// Set the filtered vendor invoices to the EKPOModel
						ekpoModel.setProperty("/Items", oData.results);
					},
					error: function(error) {
						// Handle error
						console.error("Error fetching top 10 vendor invoices filtered by Ebeln:", error);
					}
				};

				// Fetch data with parameters
				this.getOwnerComponent().getModel().read("/EKPOSet", mParameters);
			} else {
				console.error("SingleInvoiceModel is not defined or null.");
			}
		},
		fetchFilteredVendorInvoices: function() {
			// Access singleInvoiceModel from the controller's scope
			var singleInvoiceModel = this.getView().getModel("SingleInvoiceModel");

			// Check if singleInvoiceModel is defined and not null
			if (singleInvoiceModel) {
				// Get the Lifnr from the singleInvoiceModel
				var lifnr = singleInvoiceModel.getProperty("/Lifnr");

				// Create and set VendorModel
				var vendorModel = new JSONModel({});
				this.getView().setModel(vendorModel, "VendorModel");

				// Fetching data from VendorInvoicesSet based on Lifnr with orderby
				var mParameters = {
					urlParameters: {
						"$filter": "Lifnr eq '" + lifnr + "'",
						"$top": 6,
						"$orderby": "Cpudt desc,Cputm desc" // Sort by Cpudt and Cputm in descending order
					},
					success: function(oData) {
						// Handle success
						console.log("Top 10 vendor invoices ordered by latest date:", oData);
						// Set the filtered vendor invoices to the VendorModel
						vendorModel.setProperty("/Items", oData.results);
					},
					error: function(error) {
						// Handle error
						console.error("Error fetching top 10 ordered vendor invoices:", error);
					}
				};

				// Fetch data with parameters
				this.getOwnerComponent().getModel().read("/VendorInvoicesSet", mParameters);
			} else {
				console.error("SingleInvoiceModel is not defined or null.");
			}
		},

		onAttachmentPress: function(oEvent) {
			var AttachmentModel = this.getView().getModel("AttachmentModel");
			var selectedAttachment = AttachmentModel.getProperty("/Items/0"); // Adjust this path based on actual data structure

			if (selectedAttachment) {
				var archiveId = selectedAttachment.ArchiveId;
				var docid = selectedAttachment.Docid;
				var dmsObject = selectedAttachment.DmsObject;
				var fileName = selectedAttachment.FileName;
				var fileType = selectedAttachment.FileType;

				console.log("ArchiveId:", archiveId);
				console.log("Docid:", docid);
				console.log("DmsObject:", dmsObject);
				console.log("FileName:", fileName);
				console.log("FileType:", fileType);

				if (archiveId && docid && dmsObject && fileName && fileType) {
					var oModel = this.getOwnerComponent().getModel();
					var sEntityPath = oModel.createKey("/AttachmentSet", {
						ArchiveId: archiveId,
						Docid: docid,
						DmsObject: dmsObject,
						FileName: fileName,
						FileType: fileType
					});

					// Construct the URL to access the PDF
					var sPdfUrl = oModel.sServiceUrl + sEntityPath + "/$value";

					// Open the PDF in a new tab
					sap.m.URLHelper.redirect(sPdfUrl, true);
				} else {
					// Open a blank PDF if any details are missing
					sap.m.URLHelper.redirect("/resources/blank.pdf", true);
				}
			} else {
				// Open a blank PDF if no attachment is selected
				sap.m.URLHelper.redirect("/resources/blank.pdf", true);
			}
		},

		onApprovePOPress: function() {
			var that = this;

			var singleInvoiceModel = this.getView().getModel("SingleInvoiceModel");
			var payload = {
				"Belnr": this.invNum,
				"Bukrs": singleInvoiceModel.getProperty("/Bukrs"),
				"Gjahr": this.invFiscalYear,
				"WfStartDt": this.invDate,
				"Dept": singleInvoiceModel.getProperty("/Dept"),
				"Bldat": singleInvoiceModel.getProperty("/Bldat"),
				"Ebeln": singleInvoiceModel.getProperty("/Ebeln"),
				"Lifnr": singleInvoiceModel.getProperty("/Lifnr"),
				"Name1": singleInvoiceModel.getProperty("/Name1"),
				"InvLastAmount": singleInvoiceModel.getProperty("/InvLastAmount"),
				"InvoiceAmt": singleInvoiceModel.getProperty("/InvoiceAmt"),
				"PoBal": singleInvoiceModel.getProperty("/PoBal"),
				"AppStatus": this.appStatus || "0"
			};

			if (parseInt(payload.AppStatus) < 5) {
				payload.AppStatus = (parseInt(payload.AppStatus) + 1).toString();
			} else {
				payload.AppStatus = "C";
			}

			var updateUrl = "/InvoiceListSet";

			console.log("Update URL:", updateUrl);
			this.getOwnerComponent().getModel().create(updateUrl, payload, {
				method: "POST",
				success: function(oData) {
					sap.m.MessageBox.success("Invoice approved successfully.");
					// Update app status in UI
					singleInvoiceModel.setProperty("/AppStatus", "Approved");

					// // Reset the form or perform any other necessary actions
					// that.resetForm();

					// Refresh the UI to reflect the changes
					that.refreshUI();

				},
				error: function(oError) {
					console.error("Error updating invoice:", oError);
				}
			});
		},
		refreshUI: function() {
			// Reload the entire application
			window.location.reload();
		},
		onAfterRendering: function() {
			// Get the text from the "Invoice Approval Status" label
			var approvalStatusLabel = this.getView().byId("idApprovalStatusLabel");

			// Enable or disable buttons based on the text
			var approveButton = this.getView().byId("idApproveButton");
			var rejectButton = this.getView().byId("idCancelTripButton");

			if (approvalStatusLabel === "Pending") {
				// If the status is Pending, enable the buttons
				approveButton.setEnabled(true);
				rejectButton.setEnabled(true);
			} else if (approvalStatusLabel === "Approved") {
				// If the status is Approved, disable the buttons
				approveButton.setEnabled(false);
				rejectButton.setEnabled(false);
			}
		},

		onRejectPOPress: function() {
			if (!this.dialogBegin) {
				this.dialogBegin = sap.ui.xmlfragment(this.getView().getId(), "ZSakshi_New_PO.view.Fragment.RejectReason", this);
				this.getView().addDependent(this.dialogBegin);
			}
			this.dialogBegin.open();
		},
		onCloseDialog: function() {
			if (this.dialogBegin) {
				this.getView().byId("idTextAreaReason").setValue("");
				this.dialogBegin.close();
			}
		},
		onReasonSubmit: function() {
			var oView = this.getView();
			var oSingleInvoiceModel = oView.getModel("SingleInvoiceModel");
			var sReason = oView.byId("idTextAreaReason").getValue();

			if (sReason.length > 0) {
				var oPayload = {
					"Belnr": this.invNum,
					"Bukrs": oSingleInvoiceModel.getProperty("/Bukrs"),
					"WfStartDt": this.invDate,
					"Gjahr": this.invFiscalYear,
					"Dept": oSingleInvoiceModel.getProperty("/Dept"),
					"Bldat": oSingleInvoiceModel.getProperty("/Bldat"),
					"Ebeln": oSingleInvoiceModel.getProperty("/Ebeln"),
					"Lifnr": oSingleInvoiceModel.getProperty("/Lifnr"),
					"Name1": oSingleInvoiceModel.getProperty("/Name1"),
					"InvLastAmount": oSingleInvoiceModel.getProperty("/InvLastAmount"),
					"PoBal": oSingleInvoiceModel.getProperty("/PoBal"),
					"AppStatus": this.appStatus || "0", // Default to 0 if appStatus is null or undefined
					"RejRemarks": sReason
				};

				// Increment AppStatus if it's null or blank, up to level 5
				// Increment AppStatus up to level 5
				if (parseInt(oPayload.AppStatus) < 5) {
					oPayload.AppStatus = (parseInt(oPayload.AppStatus) + 1).toString();
				} else {
					oPayload.AppStatus = "C";
				}

				this.getOwnerComponent().getModel().create("/InvoiceListSet",
					oPayload, {
						method: "POST",
						success: function(oData) {
							// Success function remains unchanged
							// Show success message box
							// var dialogBegin = sap.ui.xmlfragment(this.getView().getId(), "ZSakshi_New_PO.view.Fragment.RejectReason", this); // Assuming the dialog has an ID
							if (this.dialogBegin) {
								this.getView().byId("idTextAreaReason").setValue("");
								this.dialogBegin.close();
							}
							sap.m.MessageBox.success("Invoice rejected successfully.");
							this.refreshUI();
						}.bind(this),
						error: function(oError) {
							// Error function remains unchanged
						}
					});
			} else {
				sap.m.MessageBox.error("Please enter reason for Rejection");
			}
		},

		resolveTimeDifference: function(dateTime) {
			if (dateTime !== undefined && dateTime !== null && dateTime !== "") {
				var offSet = dateTime.getTimezoneOffset();
				var offSetVal = dateTime.getTimezoneOffset() / 60;
				var h = Math.floor(Math.abs(offSetVal));
				var m = Math.floor((Math.abs(offSetVal) * 60) % 60);
				dateTime = new Date(dateTime.setHours(h, m, 0, 0));
				return dateTime;
			}
			return null;
		}
	});
});