sap.ui.define([], function() {
	"use strict";
	return {
		formatDate: function(Doj) {
			if (Doj) {
				// Ensure Doj is a Date object
				if (!(Doj instanceof Date)) {
					Doj = new Date(Doj);
				}
				// Check if Doj is a valid date
				if (isNaN(Doj.getTime())) {
					return ""; // Return empty string if Doj is not a valid date
				}
				// Format date as dd/MM/yyyy
				var oDataFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "dd/MM/yyyy"
				}, sap.ui.getCore().getConfiguration().getLocale());
				return oDataFormat.format(Doj);
			}
			return ""; // Return empty string if Doj is undefined, null, or invalid
		},
		formatStatus: function(status) {
			if (status >= "1") {
				return "Approved";
			} else if (status === "R") {
				return "Rejected";
			} else {
				return "Pending";
			}
		},
		isButtonEnabled: function(status) {
			// Assuming you want to disable buttons for 'Pending' and 'Rejected' statuses
			return status >= "1"; // Enable button only for "Approved"
		}
	};
});