sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/m/MessageToast",
	"sap/ui/core/Fragment",
	"sap/ui/core/UIComponent",
	"sap/m/MessageBox",
	"com/PAZPayment_Approval/model/formatter"
], function(Controller, JSONModel, Filter, FilterOperator, ODataModel, MessageToast, Fragment, UIComponent, formatter, MessageBox) {
	"use strict";

	return Controller.extend("com.PAZPayment_Approval.controller.View2", {
		f: formatter,
		onInit: function() {
			// Ensure OData model is available
			// this._bShowAll = false;
			var oODataModel = new ODataModel("/sap/opu/odata/sap/ZQA_DEVIATION_SRV/", {
				odataVersion: "2.0"
			});
			this.getView().setModel(oODataModel, "odataModel");

			var oRouter = UIComponent.getRouterFor(this);
			oRouter.getRoute("object1").attachPatternMatched(this.onPatternMatched, this);

			// Fetch data when the view is initialized
			this.onFetchData();
			this.onFetchDataresults();
			this.fetchRmDeviations();
			this._applyFilter(false);
		},

		onPatternMatched: function(oEvent) {
			var sKey = oEvent.getParameter("arguments").key; // Retrieve the key (Prueflos) from the URL
			// console.log("Pattern matched with key: ", sKey);

			// Check if sKey is valid before calling onFetchData
			if (sKey) {
				this.onFetchData(sKey);
				this.onFetchDataresults(sKey);
				this.onFetchDeviation(sKey);
				this.fetchRmDeviations(sKey);
				this._applyFilter(false);
			} else {
				// console.error("Invalid sKey received in onPatternMatched: ", sKey);
			}
		},
		onShowAllParameters: function() {
			const table = this.byId("yourTableId");
			const binding = table.getBinding("items");
			const button = this.byId("showAllButton");

			// Toggle the state
			this._bShowAll = !this._bShowAll;

			if (this._bShowAll) {
				// Show all details (Remove filters)
				binding.filter([]);
				button.setText("Hide All Details");
				button.setIcon("sap-icon://hide");
			} else {
				// Apply the "Rejected" filter
				const filters = [new Filter("Zvaluation", FilterOperator.EQ, "Rejected")];
				binding.filter(filters);
				button.setText("Show All Parameters");
				button.setIcon("sap-icon://show");
			}
		},

		_applyFilter: function(showAll) {
			const oTableModel = this.getView().getModel("TableModel");

			if (!oTableModel) {
				console.error("TableModel is not available.");
				return;
			}

			const oBinding = oTableModel.bindList("/");

			if (!oBinding) {
				console.error("TableModel binding is not available.");
				return;
			}

			if (showAll) {
				// Clear all filters to show all data
				oBinding.filter([]);
			} else {
				// Apply filter to show only "Rejected" rows
				const filters = [new Filter("Zvaluation", FilterOperator.EQ, "Rejected")];

				oBinding.filter(filters);
			}
		},

		// onPatternMatched: function(oEvent) {
		// 	var sKey = oEvent.getParameter("arguments").key; // Retrieve the key (Prueflos) from the URL
		// 	console.log("Pattern matched with key: ", sKey);

		// 	// Check if sKey is valid before calling onFetchData
		// 	if (sKey) {
		// 		this.onFetchData(sKey); // Fetch data for the provided sKey
		// 	} else {
		// 		// No sKey, fetch default data
		// 		this.onFetchData();
		// 	}
		// },

		onFetchData: function(sKey) {
			var oODataModel = this.getView().getModel("odataModel");

			if (oODataModel) {
				// Fetch data for QualityProcessSet (Header Data) based on the selected Prueflos (sKey)
				oODataModel.read("/QualityProcessSet", {
					success: function(oData) {
						console.log("Data fetched successfully from QualityProcessSet:", oData);

						if (oData && oData.results && oData.results.length > 0) {
							var aFilteredResults = oData.results.filter(function(item) {
								return sKey ? item.Prueflos === sKey : true; // Match the Prueflos value if key is passed
							});

							if (aFilteredResults.length > 0) {
								var oJSONModel = new JSONModel(aFilteredResults[0]); // Bind the first item
								this.getView().setModel(oJSONModel, "SingleInvoiceModel");
							} else {
								// console.error("No matching data found for the selected Prueflos.");
							}
						} else {
							// console.error("No data found for the selected Inspection Lot (Prueflos).");
						}
					}.bind(this),
					error: function(oError) {
						// console.error("Error fetching data from QualityProcessSet:", oError);
					}
				});

			} else {
				// console.error("OData model is not available.");
			}
		},

		onFetchDeviation: function(sKey) {
			var oODataModel = this.getView().getModel("odataModel");

			if (!oODataModel) {
				return;
			}

			// Fetch data from QcDeviationsSet
			oODataModel.read("/QcDeviationsSet", {
				urlParameters: {
					"$expand": "NP_ON_DEVIATION" // Expand NP_ON_DEVIATION navigation property
				},
				success: function(oData) {
					if (oData && oData.results && oData.results.length > 0) {
						// Filter results based on selected sKey
						var aFilteredResults = oData.results.filter(function(item) {
							return sKey ? item.Prueflos === sKey : true; // Match Prueflos with sKey
						});

						if (aFilteredResults.length > 0) {
							// Map to extract only Prueflos and DevList properties
							var aReducedResults = aFilteredResults.map(function(item) {
								return {
									Prueflos: item.Prueflos,
									DevList: item.DevList
								};
							});

							console.log("Filtered and Reduced Data:", aReducedResults);

							// Set filtered deviations to VendorModel
							var oDeviationsModel = new JSONModel(aFilteredResults); // Full filtered data for VendorModel
							this.getView().setModel(oDeviationsModel, "VendorModel");

							// Check if there's more than one filtered result
							if (aReducedResults.length > 1) {
								// Pass the entire array if there are multiple results
								this.fetchRmDeviations(aReducedResults);
							} else {
								// Pass a single object if there is only one result
								this.fetchRmDeviations(aReducedResults[0]);
							}
						} else {
							console.warn("No matching deviations found for the selected sKey:", sKey);
						}
					} else {
						console.warn("No data found in QcDeviationsSet.");
					}
				}.bind(this),
				error: function(oError) {
					console.error("Error fetching QcDeviationsSet data:", oError);
				}
			});
		},

		fetchRmDeviations: function(sKey) {
			var oODataModel = this.getView().getModel("odataModel");

			if (oODataModel) {
				// Fetch data for RmDeviationsSet based on the selected Prueflos (sKey)
				oODataModel.read("/RmDeviationsSet", {
					success: function(oData) {
						console.log("Data fetched successfully from RmDeviationsSet:", oData);

						if (oData && oData.results && oData.results.length > 0) {
							// If no sKey is provided, default to the first record's Prueflos
							var sSelectedKey = sKey || oData.results[0].Prueflos; // Use sKey if provided, else use the first record's key

							// Filter based on the selected key (Prueflos)
							var aFilteredResults = oData.results.filter(function(item) {
								return item.Prueflos === sSelectedKey; // Filter only if matching Prueflos
							});

							if (aFilteredResults.length > 0) {
								// Create a model for the filtered RM deviations and bind it to the view
								var oRmDeviationsModel = new JSONModel(aFilteredResults);
								this.getView().setModel(oRmDeviationsModel, "RmModel");
								console.log("Filtered RM Deviation Data:", aFilteredResults);
								this.calculateTotalServiceAmt();
							} else {
								// Handle case where no matching results are found
								console.log("No matching RM deviations found for the selected Prueflos.");
							}
						} else {
							// Handle case where no data is returned
							console.log("No RM deviation data found.");
						}
					}.bind(this),
					error: function(oError) {
						console.error("Error fetching RM deviation data:", oError);
					}
				});
			} else {
				console.error("OData model is not available.");
			}
		},
		calculateTotalServiceAmt: function() {
			var oModel = this.getView().getModel("RmModel");
			var aItems = oModel.getData(); // Get the data from RmModel
			var totalServiceAmt = 0;

			// Loop through the items and sum the ServiceAmt
			for (var i = 0; i < aItems.length; i++) {
				totalServiceAmt += parseFloat(aItems[i].ServiceAmt) || 0; // Adding the ServiceAmt
			}

			// Update the DebitAmt in the SingleInvoiceModel
			var oSingleInvoiceModel = this.getView().getModel("SingleInvoiceModel");
			oSingleInvoiceModel.setProperty("/DebitAmt", totalServiceAmt);

			// Optionally, refresh the view if needed
			this.getView().getModel("SingleInvoiceModel").refresh();
		},

		onFetchDataresults: function(sKey) {
			var oODataModel = this.getView().getModel("odataModel");

			if (!oODataModel) {
				// console.error("OData model is not available.");
				return;
			}

			// Fetch data for QualityProcessSet (Header Data), either based on the selected sKey or the first record if no sKey is provided
			oODataModel.read("/QualityProcessSet", {
				urlParameters: {
					"$filter": sKey ? "Prueflos eq '" + sKey + "'" : "" // If sKey is provided, filter by it; otherwise fetch all
				},
				success: function(oData) {
					// console.log("Data fetched successfully from QualityProcessSet:", oData);

					if (!oData || !oData.results || oData.results.length === 0) {
						// console.error("No data found for QualityProcessSet.");
						return;
					}

					// If no sKey is provided, default to the first record
					var firstResult = oData.results[0];
					// Use the first result's values if sKey isn't provided
					var sSelectedKey = sKey || firstResult.Prueflos; // Use sKey if provided, else use the first record's key

					// Extract necessary properties
					var sWerk = firstResult.Werk; // Use Werk from the response data, corresponds to Zplant
					var sMatnr = firstResult.Matnr; // Matnr should be directly available

					// Construct the filter string for QcResultsSet using sSelectedKey (either from sKey or the first record)
					var sFilter = "Zinsplot eq '" + sSelectedKey + "'"; // Use Prueflos if no sKey is provided

					if (sWerk) {
						sFilter += " and Zplant eq '" + sWerk + "'"; // Add filter for Zplant (Werk)
					}
					if (sMatnr) {
						sFilter += " and Zmatnr eq '" + sMatnr + "'"; // Add filter for Zmatnr
					}

					// Fetch data for QcResultsSet (Table Data) using the constructed filter
					oODataModel.read("/QcResultsSet", {
						urlParameters: {
							"$filter": sFilter // Filter for QcResultsSet using the selected or first record's Zinsplot
						},
						success: function(oTableData) {
							// console.log("Data fetched successfully from QcResultsSet:", oTableData);

							if (!oTableData || !oTableData.results || oTableData.results.length === 0) {
								// console.error("No data found for QcResultsSet.");
								return;
							}

							// Bind the results data to the model
							var oTableModel = new JSONModel(oTableData.results);
							this.getView().setModel(oTableModel, "TableModel");
						}.bind(this),
						error: function(oError) {
							// console.error("Error fetching data from QcResultsSet:", oError);
						}
					});

				}.bind(this),
				error: function(oError) {
					// console.error("Error fetching data from QualityProcessSet:", oError);
				}
			});
		},

		onDeviationCreditPress: function() {
			var oView = this.getView();
			if (!this._oFragment) {
				this._oFragment = sap.ui.xmlfragment(oView.getId(), "com.PAZPayment_Approval.Fragments.DeviationCredit", this);
				oView.addDependent(this._oFragment);

				this._oFragment.open();
			} else {
				this._oFragment.open();
			}
		},

		onRadioButtonSelect: function(oEvent) {
			this.byId("inputPercentage").setEnabled(false).setValue("");
			this.byId("inputRatePerKg").setEnabled(false).setValue("");
			this.byId("inputBulkAmount").setEnabled(false).setValue("");

			var selectedButton = oEvent.getSource();
			switch (selectedButton.getText()) {
				case "Percentage":
					this.byId("inputPercentage").setEnabled(true);
					break;
				case "Rate per Kg":
					this.byId("inputRatePerKg").setEnabled(true);
					break;
				case "Bulk Amount":
					this.byId("inputBulkAmount").setEnabled(true);
					break;
			}
		},

		onDialogClose: function() {
			this.byId("inputPercentage").setValue("").setEnabled(false);
			this.byId("inputRatePerKg").setValue("").setEnabled(false);
			this.byId("inputBulkAmount").setValue("").setEnabled(false);

			// Access the dialog and check if it is open
			var oDialog = this.byId("deviationCreditDialog");
			if (oDialog && oDialog.isOpen()) {
				// Deselect all radio buttons by their IDs
				this.byId("radioButtonPercentage").setSelected(false);
				this.byId("radioButtonRatePerKg").setSelected(false);
				this.byId("radioButtonBulkAmount").setSelected(false);
				// this.byId("radioButtonActualAmount").setSelected(false);
			}
			this.byId("DebitAmt").setText("");
			this._oFragment.close();
		},

		_updateHeaderFields: function(calculatedValue) {
			var oHeaderModel = this.getView().getModel("SingleInvoiceModel");
			if (oHeaderModel) {
				oHeaderModel.setProperty("/Dmbtr", calculatedValue.toString());
			}
		},
		/*#############Actual Deviation Block###########*/
		onActualDeviationPress: function() {
			// Get the data from the "SingleInvoiceModel"
			var oData = this.getView().getModel("SingleInvoiceModel").getData();

			// Ensure DebitAmt is retrieved
			var debitAmt = oData.DebitAmt;

			// Create the payload
			var oPayload = {
				Prueflos: oData.Prueflos,
				Vcode: oData.Vcode,
				Kurztext: oData.Kurztext,
				Mblnr: oData.Mblnr,
				InvDocNo: oData.InvDocNo,
				FiscYear: oData.FiscYear,
				Mjahr: oData.Mjahr,
				Ebeln: oData.Ebeln,
				Name1: oData.Name1,
				Xblnr: oData.Xblnr,
				Budat: oData.Budat,
				Werk: oData.Werk,
				Dmbtr: oData.Dmbtr,
				Matnr: oData.Matnr,
				Ebelp: oData.Ebelp,
				Maktx: oData.Maktx,
				DebitParkDoc: oData.DebitParkDoc,
				Remarks: oData.Remarks,
				Charg: oData.Charg,
				Bukrs: oData.Bukrs,
				InsPayIden: oData.InsPayIden,
				ApprovalStatus: "AD",
				DebitAmt: debitAmt // Include DebitAmt in the payload
			};

			// Get the OData model
			var oModel = this.getView().getModel("odataModel");
			if (!oModel) {
				sap.m.MessageToast.show("Model not available. Unable to process the request.");
				return;
			}

			sap.ui.core.BusyIndicator.show(0);

			// Perform the create operation
			oModel.create("/QualityProcessSet", oPayload, {
				success: function(data, response) {
					sap.m.MessageToast.show("Actual Deviation Successfully Processed.");
					oModel.refresh(true);
					sap.ui.core.BusyIndicator.hide();
					sap.ui.getCore().getEventBus().publish("ViewUpdate", "RefreshData");
					this.onFetchData();
				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();

					// Parse and display error details
					try {
						var errorResponse = JSON.parse(oError.responseText);
						var errorDetails = errorResponse.error.innererror.errordetails;

						if (errorDetails && errorDetails.length > 0) {
							// Collect and display all error messages
							var errorMessages = errorDetails.map(function(detail) {
								return detail.message;
							}).join("\n");

							sap.m.MessageBox.error("Error while processing approval:\n" + errorMessages);
						} else {
							sap.m.MessageToast.show("An error occurred, but no detailed information is available.");
						}
					} catch (e) {
						sap.m.MessageToast.show("Error while processing approval.");
					}
				}
			});
		},

		/*#############Actual Deviation Block###########*/

		/*############# Deviation Block###########*/
		onApplyCredit: function() {
			var oModel = this.getView().getModel("SingleInvoiceModel");
			var initialInvoiceValue = oModel.getProperty("/Dmbtr"); // Get value from the model

			if (isNaN(initialInvoiceValue) || initialInvoiceValue === null || initialInvoiceValue <= 0) {
				sap.m.MessageToast.show("Invalid invoice value.");
				return;
			}

			var inputValue = null;
			var calculatedValue = initialInvoiceValue;

			if (this.byId("inputPercentage").getEnabled()) {
				inputValue = parseFloat(this.byId("inputPercentage").getValue());
				calculatedValue = (calculatedValue * inputValue) / 100; // Percentage calculation
			} else if (this.byId("inputRatePerKg").getEnabled()) {
				inputValue = parseFloat(this.byId("inputRatePerKg").getValue());
				calculatedValue = calculatedValue / inputValue; // Rate per Kg calculation
			} else if (this.byId("inputBulkAmount").getEnabled()) {
				inputValue = parseFloat(this.byId("inputBulkAmount").getValue());
				calculatedValue = calculatedValue - inputValue; // Bulk Amount calculation
			}

			if (isNaN(inputValue) || inputValue === null || inputValue < 0) {
				sap.m.MessageToast.show("Please enter a valid value.");
				return;
			}

			oModel.setProperty("/DebitAmt", calculatedValue.toString()); // Update the model with the new calculated value

			// Access the dialog and check if it is open
			var oDialog = this.byId("deviationCreditDialog");
			// if (oDialog && oDialog.isOpen()) {
			// 	// Deselect all radio buttons by their IDs
			// 	this.byId("radioButtonPercentage").setSelected(false);
			// 	this.byId("radioButtonRatePerKg").setSelected(false);
			// 	this.byId("radioButtonBulkAmount").setSelected(false);

			// }

			// Close the dialog
			// this.onDebitAmtChange();
			// this._oFragment.close();
		},
		onApproveDeviationPress: function() {
			// Get the data from the "SingleInvoiceModel"
			var oData = this.getView().getModel("SingleInvoiceModel").getData();

			// Ensure DebitAmt is retrieved
			var debitAmt = oData.DebitAmt;

			// Create the payload
			var oPayload = {
				Prueflos: oData.Prueflos,
				Vcode: oData.Vcode,
				Kurztext: oData.Kurztext,
				Mblnr: oData.Mblnr,
				InvDocNo: oData.InvDocNo,
				FiscYear: oData.FiscYear,
				Mjahr: oData.Mjahr,
				Ebeln: oData.Ebeln,
				Name1: oData.Name1,
				Xblnr: oData.Xblnr,
				Budat: oData.Budat,
				Werk: oData.Werk,
				Dmbtr: oData.Dmbtr,
				Matnr: oData.Matnr,
				Ebelp: oData.Ebelp,
				Maktx: oData.Maktx,
				DebitParkDoc: oData.DebitParkDoc,
				Remarks: oData.Remarks,
				Charg: oData.Charg,
				Bukrs: oData.Bukrs,
				InsPayIden: oData.InsPayIden,
				ApprovalStatus: "M",
				DebitAmt: debitAmt // Include DebitAmt in the payload
			};

			// Get the OData model
			var oModel = this.getView().getModel("odataModel");
			if (!oModel) {
				sap.m.MessageToast.show("Model not available. Unable to process the request.");
				return;
			}

			sap.ui.core.BusyIndicator.show(0);

			// Perform the create operation
			oModel.create("/QualityProcessSet", oPayload, {
				success: function(data, response) {
					sap.m.MessageToast.show("Manual Deviation Successfully Processed.");
					oModel.refresh(true);
					sap.ui.core.BusyIndicator.hide();
					sap.ui.getCore().getEventBus().publish("ViewUpdate", "RefreshData");
					this.onFetchData();
					if (this._oFragment) {
						this._oFragment.close();
					}
				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();

					if (oError.responseText) {
						try {
							// Parsing the error message from the response
							var errMsg = JSON.parse(oError.responseText).error.message.value;
							// Displaying the error message using MessageBox
							sap.m.MessageBox.information(errMsg);
						} catch (e) {
							sap.m.MessageToast.show("Error while processing approval.");
						}
					} else {
						sap.m.MessageToast.show("An error occurred, but no detailed information is available.");
					}

					if (this._oFragment) {
						this._oFragment.close();
					}
				}.bind(this)
			});
		},

		/*############# Deviation Block###########*/

		/*############# No Deviation Block###########*/
		onApproveNDPress: function() {
			var oData = this.getView().getModel("SingleInvoiceModel").getData();
			var oPayload = {
				Prueflos: oData.Prueflos,
				Vcode: oData.Vcode,
				Kurztext: oData.Kurztext,
				Mblnr: oData.Mblnr,
				Mjahr: oData.Mjahr,
				FiscYear: oData.FiscYear,
				Ebeln: oData.Ebeln,
				InvDocNo: oData.InvDocNo,
				Name1: oData.Name1,
				Xblnr: oData.Xblnr,
				Budat: oData.Budat,
				Werk: oData.Werk,
				Dmbtr: oData.Dmbtr,
				Ebelp: oData.Ebelp,
				Matnr: oData.Matnr,
				Maktx: oData.Maktx,
				Bukrs: oData.Bukrs,
				DebitParkDoc: oData.DebitParkDoc,
				Remarks: oData.Remarks,
				Charg: oData.Charg,
				InsPayIden: oData.InsPayIden,
				ApprovalStatus: "ND"
			};

			var oModel = this.getView().getModel("odataModel");
			if (!oModel) {
				sap.m.MessageToast.show("Model not available. Unable to process the request.");
				return;
			}

			sap.ui.core.BusyIndicator.show(0);

			oModel.create("/QualityProcessSet", oPayload, {
				success: function(data, response) {
					sap.m.MessageToast.show("No Credit Successfully Processed.");
					oModel.refresh(true);
					sap.ui.core.BusyIndicator.hide();
					sap.ui.getCore().getEventBus().publish("ViewUpdate", "RefreshData");
					this.onFetchData();
				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();

					// Parse and display error details
					try {
						var errorResponse = JSON.parse(oError.responseText);
						var errorDetails = errorResponse.error.innererror.errordetails;

						if (errorDetails && errorDetails.length > 0) {
							// Collect and display all error messages
							var errorMessages = errorDetails.map(function(detail) {
								return detail.message;
							}).join("\n");

							sap.m.MessageBox.error(errorMessages);
						} else {
							sap.m.MessageToast.show("An error occurred, but no detailed information is available.");
						}
					} catch (e) {
						// sap.m.MessageToast.show("Error while processing approval.");
					}
				}
			});
		},

		/*############# No Deviation Block###########*/

		/*############# Approval Block for Actual Deviation###########*/
		onApprovePress: function() {
			// Get the SingleInvoiceModel
			var oModel = this.getView().getModel("SingleInvoiceModel");

			if (!oModel) {
				sap.m.MessageToast.show("Model not available. Unable to process the request.");
				return;
			}

			// Retrieve the DebitAmt value safely
			var debitAmt = oModel.getProperty("/DebitAmt");

			// Ensure DebitAmt is a valid number
			debitAmt = debitAmt ? debitAmt.toString() : "0";

			// Get all data from the model
			var oData = oModel.getData();

			// Create the payload
			var oPayload = {
				Prueflos: oData.Prueflos,
				Vcode: oData.Vcode,
				Kurztext: oData.Kurztext,
				Mblnr: oData.Mblnr,
				InvDocNo: oData.InvDocNo,
				FiscYear: oData.FiscYear,
				Mjahr: oData.Mjahr,
				Ebeln: oData.Ebeln,
				Name1: oData.Name1,
				Xblnr: oData.Xblnr,
				Budat: oData.Budat,
				Werk: oData.Werk,
				Dmbtr: oData.Dmbtr,
				Matnr: oData.Matnr,
				Ebelp: oData.Ebelp,
				Maktx: oData.Maktx,
				DebitParkDoc: oData.DebitParkDoc,
				Remarks: oData.Remarks,
				Charg: oData.Charg,
				Bukrs: oData.Bukrs,
				InsPayIden: oData.InsPayIden,
				ApprovalStatus: "A",
				DebitAmt: debitAmt // Ensure the value from UI is passed
			};

			// Get the OData model
			var oODataModel = this.getView().getModel("odataModel");

			if (!oODataModel) {
				sap.m.MessageToast.show("OData Model not available.");
				return;
			}

			sap.ui.core.BusyIndicator.show(0);

			// Perform the create operation
			oODataModel.create("/QualityProcessSet", oPayload, {
				success: function(data, response) {
					sap.m.MessageToast.show("Approval Successfully Processed.");
					oODataModel.refresh(true);
					sap.ui.core.BusyIndicator.hide();
					sap.ui.getCore().getEventBus().publish("ViewUpdate", "RefreshData");
					this.onFetchData();
				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();
					try {
						var errorResponse = JSON.parse(oError.responseText);
						var errorDetails = errorResponse.error.innererror.errordetails;

						if (errorDetails && errorDetails.length > 0) {
							var errorMessages = errorDetails.map(function(detail) {
								return detail.message;
							}).join("\n");
							sap.m.MessageBox.error("Error while processing approval:\n" + errorMessages);
						} else {
							sap.m.MessageToast.show("An error occurred, but no detailed information is available.");
						}
					} catch (e) {
						sap.m.MessageToast.show("Error while processing approval.");
					}
				}
			});
		},

		/*############# Approval Block for Actual Deviation###########*/

		/*############# Rejection Block for Actual Deviation###########*/
		onRejectPOPress: function() {
			if (!this.dialogReject) {
				this.dialogReject = sap.ui.xmlfragment(this.getView().getId(), "com.PAZPayment_Approval.Fragments.RejectReason", this);
				this.getView().addDependent(this.dialogReject);
			}
			this.dialogReject.open();
		},

		onApplyReject: function() {
			var rejectionReason = this.getView().byId("idTextAreaRejReason").getValue();
			var actualRate = this.getView().byId("idActualRate").getValue(); // Fetch input value

			if (!rejectionReason) {
				sap.m.MessageToast.show("Please provide a reason for rejection.");
				return;
			}

			if (!actualRate) {
				sap.m.MessageToast.show("Please enter the Actual Rate per KG.");
				return;
			}

			var oData = this.getView().getModel("SingleInvoiceModel").getData();
			var oPayload = {
				Prueflos: oData.Prueflos,
				Vcode: oData.Vcode,
				Kurztext: oData.Kurztext,
				Mblnr: oData.Mblnr,
				Mjahr: oData.Mjahr,
				InvDocNo: oData.InvDocNo,
				FiscYear: oData.FiscYear,
				Ebeln: oData.Ebeln,
				Name1: oData.Name1,
				Xblnr: oData.Xblnr,
				Budat: oData.Budat,
				Werk: oData.Werk,
				Dmbtr: oData.Dmbtr,
				Matnr: oData.Matnr,
				Maktx: oData.Maktx,
				Ebelp: oData.Ebelp,
				Bukrs: oData.Bukrs,
				DebitParkDoc: oData.DebitParkDoc,
				RejectionReason: rejectionReason,
				Charg: oData.Charg,
				InsPayIden: oData.InsPayIden,
				ApprovalStatus: "R",
				RatePerKg: actualRate.toString() // Convert rate to string before sending
			};

			var oModel = this.getView().getModel("odataModel");
			if (!oModel) {
				sap.m.MessageToast.show("Model not available. Unable to process the request.");
				return;
			}

			sap.ui.core.BusyIndicator.show(0);

			oModel.create("/QualityProcessSet", oPayload, {
				success: function(data, response) {
					sap.m.MessageToast.show("Rejection Successfully Processed.");
					oModel.refresh(true);
					sap.ui.core.BusyIndicator.hide();
					sap.ui.getCore().getEventBus().publish("ViewUpdate", "RefreshData");
					this.onFetchData();
				}.bind(this),
				error: function(oError) {
					sap.ui.core.BusyIndicator.hide();

					try {
						var errorResponse = JSON.parse(oError.responseText);
						var errorDetails = errorResponse.error.innererror.errordetails;

						if (errorDetails && errorDetails.length > 0) {
							var errorMessages = errorDetails.map(function(detail) {
								return detail.message;
							}).join("\n");

							sap.m.MessageBox.error("Error while processing rejection:\n" + errorMessages);
						} else {
							sap.m.MessageToast.show("An error occurred, but no detailed information is available.");
						}
					} catch (e) {
						sap.m.MessageToast.show("Error while processing rejection.");
					}
				}
			});

			this.dialogReject.close();
		},

		onRejectDialogClose: function() {
			this.dialogReject.close();
		}

	});
});