sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/UIComponent",
	"sap/m/MessageToast"
], function(Controller, ODataModel, JSONModel, UIComponent, MessageToast) {
	"use strict";

	return Controller.extend("com.PAZPayment_Approval.controller.View1", {

		onInit: function() {
			var oODataModel = new ODataModel("/sap/opu/odata/sap/ZQA_DEVIATION_SRV/");
			this.getView().setModel(oODataModel, "odataModel");
			var oEventBus = sap.ui.getCore().getEventBus();
			oEventBus.subscribe("ViewUpdate", "RefreshData", this.onRefreshData, this);
			this.onFetchData();
		},
		onRefreshData: function() {
			sap.ui.core.BusyIndicator.show(0); // Show busy indicator

			// Refresh data for the list and detail views
			var oODataModel = this.getView().getModel("odataModel");

			if (oODataModel) {
				oODataModel.read("/QualityProcessSet", {
					success: function(oData) {
						var oJSONModel = new JSONModel(oData);
						this.getView().setModel(oJSONModel, "jsonModel");

						// Update count
						var iCount = oData.results.length;
						var oCountModel = new JSONModel({
							count: iCount
						});
						this.getView().setModel(oCountModel, "countModel");

						// Select the first item in the list
						var oList = this.getView().byId("list");
						if (oList.getItems().length > 0) {
							oList.setSelectedItem(oList.getItems()[0]);
						}

						sap.ui.core.BusyIndicator.hide(); // Hide busy indicator
					}.bind(this),
					error: function(oError) {
						MessageToast.show("Error refreshing data.");
						sap.ui.core.BusyIndicator.hide(); // Hide busy indicator
					}
				});
			}
		},
		onFetchData: function() {
			var oODataModel = this.getView().getModel("odataModel");

			if (oODataModel) {
				oODataModel.read("/QualityProcessSet", {
					success: function(oData) {
						var oJSONModel = new JSONModel(oData);
						this.getView().setModel(oJSONModel, "jsonModel");
						var iCount = oData.results.length;
						var oCountModel = new JSONModel({
							count: iCount
						});
						this.getView().setModel(oCountModel, "countModel");
					}.bind(this),
					error: function(oError) {
						console.error("Error fetching data:", oError);
					}
				});
			}
		},
		onSelectAll: function() {
			var oList = this.getView().byId("list");
			oList.setMode("MultiSelect");
			oList.getItems().forEach(function(oItem) {
				oList.setSelectedItem(oItem, true);
			});
		},

		onUnselectAll: function() {
			var oList = this.getView().byId("list");
			oList.removeSelections(true);
			oList.setMode("SingleSelectMaster");
		},
		onApproveAll: function() {
			var oData = this.getView().getModel("SingleInvoiceModel").getData();
			var oPayload = {
				Prueflos: oData.Prueflos,
				Vcode: oData.Vcode,
				Kurztext: oData.Kurztext,
				Mblnr: oData.Mblnr,
				Mjahr: oData.Mjahr,
				FiscYear: oData.FiscYear,
				Ebeln: oData.Ebeln,
				InvDocNo: oData.InvDocNo,
				Name1: oData.Name1,
				Xblnr: oData.Xblnr,
				Budat: oData.Budat,
				Werk: oData.Werk,
				Dmbtr: oData.Dmbtr,
				Ebelp: oData.Ebelp,
				Matnr: oData.Matnr,
				Maktx: oData.Maktx,
				Bukrs: oData.Bukrs,
				DebitParkDoc: oData.DebitParkDoc,
				Remarks: oData.Remarks,
				Charg: oData.Charg,
				InsPayIden: oData.InsPayIden,
				ApprovalStatus: 'ND'
			};

			console.log("Payload for create call:", oPayload);

			var oModel = this.getView().getModel("odataModel");
			if (!oModel) {
				console.error("OData model is not available.");
				sap.m.MessageToast.show("Model not available. Unable to process the request.");
				return;
			}

			oModel.create("/QualityProcessSet", oPayload, {
				success: function(data, response) {
					console.log("Create call successful:", data);
					sap.m.MessageToast.show(" Approval Successfully Processed.");
					oModel.refresh(true);
					this.onRefreshData();
				}.bind(this),
				error: function(oError) {
					console.error("Error in create call:", oError);
					sap.m.MessageToast.show("Error while processing approval.");
					this.onRefreshData();
				}
			});

		},

		onSelectionChange: function(oEvent) {
			var oSelectedItem = oEvent.getParameter("listItem");
			if (oSelectedItem) {
				var oBindingContext = oSelectedItem.getBindingContext("jsonModel");
				var sKey = oBindingContext.getProperty("Prueflos");
				var oRouter = UIComponent.getRouterFor(this);
				oRouter.navTo("object1", {
					key: sKey
				});
				var oList = this.getView().byId("list");
				oList.removeSelections(true);
			}
		},

		onFilterPress: function(oEvent) {
			// Open a Filter Dialog or trigger predefined filter
			var oFilter = new sap.m.Menu({
				items: [
					new sap.m.MenuItem({
						text: "All"
					}),
					new sap.m.MenuItem({
						text: "Open"
					}),
					new sap.m.MenuItem({
						text: "Closed"
					})
				]
			});

			oFilter.openBy(oEvent.getSource());
		},

		onSortPress: function(oEvent) {
			// Open a Sort Dialog or trigger predefined sort
			var oSortMenu = new sap.m.Menu({
				items: [
					new sap.m.MenuItem({
						text: "Sort Ascending",
						press: this.onSortAscending.bind(this)
					}),
					new sap.m.MenuItem({
						text: "Sort Descending",
						press: this.onSortDescending.bind(this)
					}),
					new sap.m.MenuItem({
						text: "Sort Alphabetically",
						press: this.onSortAlphabetically.bind(this)
					})

				]
			});

			oSortMenu.openBy(oEvent.getSource());
		},

		// onSortAscending: function() {
		// 	var oList = this.getView().byId("list");
		// 	var oBinding = oList.getBinding("items");
		// 	var oSorter = new sap.ui.model.Sorter("Prueflos", false); // false for ascending
		// 	oBinding.sort(oSorter);
		// 	MessageToast.show("Sorted Ascending by Inspection Lot");
		// },

		// onSortDescending: function() {
		// 	var oList = this.getView().byId("list");
		// 	var oBinding = oList.getBinding("items");
		// 	var oSorter = new sap.ui.model.Sorter("Prueflos", true); // true for descending
		// 	oBinding.sort(oSorter);
		// 	MessageToast.show("Sorted Descending by Inspection Lot");
		// },

		// onSortAlphabetically: function() {
		// 	var oList = this.getView().byId("list");
		// 	var oBinding = oList.getBinding("items");
		// 	var oSorter = new sap.ui.model.Sorter("Name1", false); // Alphabetical sorting
		// 	oBinding.sort(oSorter);
		// 	MessageToast.show("Sorted Alphabetically by Name");
		// },

		// onSortByLatest: function() {
		// 	var oList = this.getView().byId("list");
		// 	var oBinding = oList.getBinding("items");
		// 	var oSorter = new sap.ui.model.Sorter("CreatedAt", true); // Assuming 'CreatedAt' is a field for latest
		// 	oBinding.sort(oSorter);
		// 	MessageToast.show("Sorted by Latest Date");
		// },
		onFilterPONumbers: function(oEvent) {
			var sQuery = oEvent.getParameter("newValue");
			var sSelectedKey = this.getView().byId("searchCriteria").getSelectedKey();
			var oList = this.getView().byId("list");
			var oBinding = oList.getBinding("items");

			if (oBinding) {
				var aFilters = [];
				if (sQuery) {
					// Ensure the selected key is valid and used dynamically
					var oFilter = new sap.ui.model.Filter(sSelectedKey, sap.ui.model.FilterOperator.Contains, sQuery);
					aFilters.push(oFilter);
				}
				oBinding.filter(aFilters, sap.ui.model.FilterType.Application);
			}
		}

		// onFilterPONumbers: function(oEvent) {
		// 	var sQuery = oEvent.getParameter("newValue");
		// 	var oList = this.getView().byId("list");
		// 	var oBinding = oList.getBinding("items");

		// 	if (oBinding) {
		// 		var aFilters = [];
		// 		if (sQuery) {
		// 			var aFieldFilters = [
		// 				new sap.ui.model.Filter("Prueflos", sap.ui.model.FilterOperator.Contains, sQuery),
		// 				new sap.ui.model.Filter("Ebeln", sap.ui.model.FilterOperator.Contains, sQuery),
		// 				new sap.ui.model.Filter("Name1", sap.ui.model.FilterOperator.Contains, sQuery),
		// 				new sap.ui.model.Filter("Dmbtr", sap.ui.model.FilterOperator.Contains, sQuery)
		// 			];
		// 			aFilters.push(new sap.ui.model.Filter({
		// 				filters: aFieldFilters,
		// 				and: false // OR condition
		// 			}));
		// 		}
		// 		oBinding.filter(aFilters, sap.ui.model.FilterType.Application);
		// 	}
		// }
	});
});