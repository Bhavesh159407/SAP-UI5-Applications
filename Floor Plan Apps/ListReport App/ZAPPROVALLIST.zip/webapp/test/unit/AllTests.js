sap.ui.define([
	"comagicustomer/approvallist/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
