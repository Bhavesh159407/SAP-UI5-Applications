/* global QUnit */

sap.ui.require(["com/agi/customer/approvallist/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
