sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("com.agi.customer.approvallist.controller.DetailObjectNotFound", {});
});