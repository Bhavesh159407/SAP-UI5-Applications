sap.ui.define([
	"./BaseController",
	"sap/m/MessageBox"
], function (BaseController, MessageBox) {
	"use strict";

	return BaseController.extend("com.agi.customer.approvallist.controller.Master", {

		onSelectionChange: function (oEvent) {
			var oList = oEvent.getSource(),
				bSelected = oEvent.getParameter("selected");

			if (!this.getOwnerComponent()._oList) {
				this.getOwnerComponent()._oList = oList;
			}

			// skip navigation when deselecting an item in multi selection mode
			if (!(oList.getMode() === "MultiSelect" && !bSelected)) {
				// get the list item, either from the listItem parameter or from the events source itself (will depend on the device-dependent mode).
				this._showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
			}
		},


		/**
	   * Shows the selected item on the detail page
	   * On phones a additional history entry is created
	   * @param {sap.m.ObjectListItem} oItem selected Item
	   * @private
	   */
		_showDetail: function (oItem) {

			if (!oItem) {
				this.getModel("AppView").setProperty("/layout", "OneColumn");
				this._oAppView.setProperty("/approvalData", {});
				this._oAppView.setProperty("/detail", {});
				return;
			}

			// set the layout property of FCL control to show two columns
			this.getModel("AppView").setProperty("/layout", "TwoColumnsMidExpanded");
			let oDetailData = this._oAppView.getProperty(oItem.getBindingContext("AppView").getPath());
			// Insert notes data
			oDetailData.Notes = "Approved form no,  level 1 \n Approved form no, level 2";
			let aNotes = oDetailData.Notes.split("\n"),
			aNotesData = [];
			aNotes.forEach((comment) => {
				aNotesData.push({
					note: comment
				});
			})
			oDetailData.Notes = Array.from(aNotesData);
			this._oAppView.setProperty("/approvalData", oDetailData);


			this.getRouter().navTo("object", {
				objectId: oDetailData.ApprAgent,
				FormNo: oDetailData.FormNo,
			});
		},

		onSearch: function (oEvent) {
			if (oEvent.getParameter("refreshButtonPressed")) {
				this._getApprovals().then(() => {
					this._applyFilter(oEvent);
				});
			} else {
				this._applyFilter(oEvent);
			}
		},

		_applyFilter: function (oEvent) {
			let oList = this.getView().byId("idList");
			let sValue = oEvent.getSource().getValue(),
				aFilter = new sap.ui.model.Filter({
					path: "FormNo",
					operator: "Contains",
					value1: sValue
				});
			if (!sValue) {
				oList.getBinding("items").filter([]);
			} else {
				oList.getBinding("items").filter(aFilter);
			}
		},

		_onMetadataLoaded: function () {
			this._oODataModel = this.getOwnerComponent().getModel();
			this._oAppView = this.getOwnerComponent().getModel("AppView");
			this._getLoggedInUser();
		},



		onInit: function () {
			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
		}

	});
});