sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/m/library",
	"sap/ui/core/Fragment",
	"sap/m/MessageBox"
], function (BaseController, JSONModel, mobileLibrary, Fragment, MessageBox) {
	"use strict";

	// shortcut for sap.m.URLHelper
	var URLHelper = mobileLibrary.URLHelper;

	return BaseController.extend("com.agi.customer.approvallist.controller.Detail", {

		onInit: function () {
			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);
			this._oAppView = this.getOwnerComponent().getModel("AppView");
			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));
		},


		_onMetadataLoaded: function () {
			this._oODataModel = this.getOwnerComponent().getModel();
			if (!this._oAppView.getProperty("/loggedInUser")) {
				this._getLoggedInUser();
			}
		},

		onAcceptButtonPress: function () {
			this._bIsAccept = true;
			this._oAppView.setProperty("/EnteredNotes", "");
			this._openComments();
		},


		onSaveButtonPress: function () {
			this.onSaveButtonPressComments();
		},

		_openComments: function () {
			return new Promise((fnResolve) => {
				if (!this._oComments) {
					if (Fragment.load === 1) {
						Fragment.load({
							name: "com.agi.customer.approvallist.view.Comments",
							controller: this
						}).then((oDialog) => {
							this._oComments = oDialog;
							this.getView().addDependent(oDialog);
							this._oComments.open();
							fnResolve();
						});
					} else {
						let oDialog = sap.ui.xmlfragment("com.agi.customer.approvallist.view.Comments", this);
						this.getView().addDependent(oDialog);
						this._oComments = oDialog;
						oDialog.open();
						fnResolve();
					}

				} else {
					this._oComments.open();
					fnResolve();
				}
			});
		},

		onCancelButtonPress: function () {
			this._oComments.close();
		},

		onSaveButtonPressComments: function () {
			let oApprovalData = this._oAppView.getProperty("/approvalData"),
				oPayload = {
					ApprAgent: oApprovalData.ApprAgent,
					FormNo: oApprovalData.FormNo,
					WiId: oApprovalData.WiId,
					ApprLevel: oApprovalData.ApprLevel,
					Decision: this._bIsAccept ? "0001" : "0002", // Accept=0001, Reject=0002
					Notes: this._oAppView.getProperty("/EnteredNotes")
				};
			sap.ui.core.BusyIndicator.show(0);
			this._oODataModel.create("/ApprovalListSet", oPayload, {
				success: () => {
					sap.ui.core.BusyIndicator.hide();
					if (this._oComments) {
						this._oComments.close();
					}
					this._getApprovals().then(() => {
						let oList = this.getOwnerComponent()._oList;
						// Auto select next approval form
						oList.fireSelectionChange({
							listItem: oList.getItems()[0]
						});
						oList.getItems()[0].setSelected(true);
					});
				},
				error: (oError) => {
					sap.ui.core.BusyIndicator.hide();
					MessageBox.error(JSON.stringify(oError));
				}
			});
		},

		onRejectButtonPress: function () {
			this._bIsAccept = false;
			this._oAppView.setProperty("/EnteredNotes", "");
			this._openComments();
		},


		onSendEmailPress: function () {
			var oViewModel = this.getModel("detailView");

			URLHelper.triggerEmail(
				null,
				oViewModel.getProperty("/shareSendEmailSubject"),
				oViewModel.getProperty("/shareSendEmailMessage")
			);
		},


		_getDetail: function (sFormNo) {
			return new Promise((fnResolve, fnReject) => {
				sap.ui.core.BusyIndicator.show(0);
				let sPath = this._oODataModel.createKey("/CustomerPriceSet", {
					FormNo: sFormNo
				});

				this._oODataModel.read(sPath, {
					urlParameters: {
						"$expand": "NavCustomerToMat"
					},
					success: (oData) => {
						sap.ui.core.BusyIndicator.hide();
						this._oAppView.setProperty("/detail", oData);
						fnResolve();
					},
					error: (oError) => {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error(JSON.stringify(oError));
						fnReject();
					}
				});
			});
		},

		_onObjectMatched: function (oEvent) {
			var oArguments = oEvent.getParameter("arguments");

			// Convert comments to table
			let oApprovalData = this._oAppView.getProperty("/approvalData");
			if (oApprovalData.Comments) {
				let aComments = oApprovalData.Comments.split("\r\n");
				let aNewComments = [];
				aComments.forEach((sNote) => aNewComments.push({note: sNote}));
				this._oAppView.setProperty("/approvalData/Comments", aNewComments);
			}

			this._getDetail(oArguments.FormNo);
			this._sObjectId = oArguments.objectId;
			// Dont show two columns when in full screen mode
			if (this.getModel("AppView").getProperty("/layout") !== "MidColumnFullScreen") {
				this.getModel("AppView").setProperty("/layout", "TwoColumnsMidExpanded");
			}
		},

		onCloseDetailPress: function () {
			this.getModel("AppView").setProperty("/actionButtonsInfo/midColumn/fullScreen", false);
			// No item should be selected on master after detail page is closed
			this.getOwnerComponent().oListSelector.clearMasterListSelection();
			this.getRouter().navTo("master");
		},

		/**
		 * Toggle between full and non full screen mode.
		 */
		toggleFullScreen: function () {
			var bFullScreen = this.getModel("AppView").getProperty("/actionButtonsInfo/midColumn/fullScreen");
			this.getModel("AppView").setProperty("/actionButtonsInfo/midColumn/fullScreen", !bFullScreen);
			if (!bFullScreen) {
				// store current layout and go full screen
				this.getModel("AppView").setProperty("/previousLayout", this.getModel("AppView").getProperty("/layout"));
				this.getModel("AppView").setProperty("/layout", "MidColumnFullScreen");
			} else {
				// reset to previous layout
				this.getModel("AppView").setProperty("/layout", this.getModel("AppView").getProperty("/previousLayout"));
			}

		}

	});
});