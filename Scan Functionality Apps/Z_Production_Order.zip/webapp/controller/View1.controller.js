sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/model/odata/v2/ODataModel"
], function(Controller, MessageBox, ODataModel) {
	"use strict";

	return Controller.extend("com.ZPOZ_Production_Order.controller.View1", {
		onInit: function() {
			// Initialize OData Model
			var serviceUrl = "/sap/opu/odata/sap/ZWM_PROCESS_SRV";
			var oDataModel = new ODataModel(serviceUrl, {
				useBatch: false
			});
			this.getView().setModel(oDataModel, "odataModel");
		},

		onNavigateToScan: function() {
			var oModel = this.getView().getModel("odataModel");

			// Fetch Palette_Number dynamically from backend
			oModel.read("/PaletteSet", {
				success: function(oData) {
					if (oData && oData.results && oData.results.length > 0) {
						const sPaletteNumber = oData.results[0].Palette_Number;

						// Navigate to view2 and pass Palette_Number
						this.getOwnerComponent().getRouter().navTo("view2", {
							paletteNumber: sPaletteNumber
						});
					} else {
						MessageBox.error("No Palette_Number data found.");
					}
				}.bind(this),
				error: function(oError) {
					MessageBox.error("Failed to fetch Palette_Number: " + oError.message);
				}
			});
		}
	});
});