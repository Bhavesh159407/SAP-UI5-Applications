sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ndc/BarcodeScanner",
	"sap/m/MessageToast",
], function(Controller, MessageBox, ODataModel, BarcodeScanner, MessageToast) {
	"use strict";

	return Controller.extend("com.ZPOZ_Production_Order.controller.View2", {

		onInit: function() {
			var billingInput = this.byId("billingInput");
			if (billingInput) {
				billingInput.focus();
			}
			// Initialize OData Model
			var serviceUrl = "/sap/opu/odata/sap/ZWM_PROCESS_SRV";
			var oModel = new ODataModel(serviceUrl, {
				defaultBindingMode: sap.ui.model.BindingMode.TwoWay,
				useBatch: false
			});
			this.getView().setModel(oModel);

			// Initialize JSON Model for Table Data
			var oTableModel = new sap.ui.model.json.JSONModel({
				tableData: []
			});
			this.getView().setModel(oTableModel, "tableModel");

			// Attach hardware scan listener
			this._attachHardwareScanListener();

			// Attach route match for navigation
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.getRoute("view2").attachPatternMatched(this._onRouteMatched, this);
		},
		onAfterRendering: function() {
			setTimeout(() => {
				var billingInput = this.byId("billingInput");
				if (billingInput) {
					billingInput.focus();
				}

			}, 500)
		},

		onDeletePress: function(oEvent) {
			var oTable = this.getView().byId("yourTableId"); // Set your Table ID
			var oModel = this.getView().getModel("tableModel");
			var oContext = oEvent.getSource().getBindingContext("tableModel");
			var sPath = oContext.getPath();

			var aTableData = oModel.getProperty("/tableData");
			var iIndex = parseInt(sPath.split("/").pop(), 10); // Get index from path

			if (iIndex !== -1) {
				aTableData.splice(iIndex, 1); // Remove item from array
				oModel.setProperty("/tableData", aTableData); // Update model
			}
		},

		_onRouteMatched: function(oEvent) {
			var oArgs = oEvent.getParameter("arguments");
			var sPaletteNumber = oArgs.paletteNumber;

			if (sPaletteNumber) {
				this._bindPaletteData(sPaletteNumber);
			}
		},

		_bindPaletteData: function(sPaletteNumber) {
			var oModel = this.getView().getModel();
			var sPath = `/PaletteSet('${sPaletteNumber}')`;

			oModel.read(sPath, {
				success: function(oData) {
					var oViewModel = new sap.ui.model.json.JSONModel(oData);
					this.getView().setModel(oViewModel, "paletteModel");
				}.bind(this),
				error: function(oError) {
					MessageBox.error("Failed to fetch Palette data: " + oError.message);
				}
			});
		},

		onNavigateBack: function() {
			// Clear the table data when navigating back to view2
			const oTableModel = this.getView().getModel("tableModel");
			oTableModel.setProperty("/tableData", []); // Clears the table data

			this.getOwnerComponent().getRouter().navTo("view1");
		},

		_attachHardwareScanListener: function() {
			let scanBuffer = "";
			let scanTimeout;

			document.addEventListener(
				"keydown",
				function(event) {
					if (event.target.tagName === "INPUT") {
						return; // Skip if an input field is already focused
					}

					if (event.key !== "Enter") {
						scanBuffer += event.key;
						clearTimeout(scanTimeout);

						scanTimeout = setTimeout(() => {
							scanBuffer = ""; // Reset buffer after delay
						}, 200);
					} else if (scanBuffer) {
						const scannedValue = scanBuffer.trim();
						scanBuffer = ""; // Reset buffer

						if (scannedValue) {
							console.log("Scanned Data:", scannedValue);

							this.handleScannedData({
								mParameters: {
									text: scannedValue
								}
							});
						}
					}
				}.bind(this)
			);
		},

		onScanPress: function() {
			BarcodeScanner.scan(
				function(oResult) {
					if (oResult.text) {
						console.log("Scanned QR Code Value:", oResult.text);

						this.scannedValue = oResult.text;

						this.handleScannedData({
							mParameters: {
								text: oResult.text
							}
						});

						// Just pass the scanned text without invoking the function
						// var scannedValue = oResult.text;
					} else {
						MessageBox.error("No QR code detected.");
					}
				}.bind(this),
				function(oError) {
					MessageBox.error("Scan failed: " + oError.message);
				}
			);
		},

		onInputChange: function(oEvent) {
			var sValue = oEvent.getParameter("value").trim();
			const billingInput = this.byId("billingInput");
			if (!sValue) {
				MessageBox.error("Invalid input. Please scan again.");
				return;
			}

			console.log("Manually Entered or Scanned Value:", sValue);
			// Clear the input field after handling the data
			if (billingInput) {
				billingInput.setValue("");
			}
			this.handleScannedData({
				mParameters: {
					text: sValue
				}
			});
		},
		passScannedDataToPreview: function(sScannedText) {
			if (sScannedText) {
				this.onPreviewAttachment(sScannedText);
			}
		},
		handleScannedData: function(oScanResult) {
			var qrdata=oScanResult.mParameters.text;
			console.log("typeof", typeof qrdata)
			var sSerialNumber ;
			if (typeof qrdata === "string") {

				sSerialNumber = JSON.parse(qrdata);
			} else if (typeof qrdata === "object") {

				sSerialNumber = qrdata;
			}

			if (!sSerialNumber) {
				MessageBox.error("Invalid scan data.");
				this._setFocusOnBillingInput();
				return;
			}

			// Use a regular expression to extract the serial number directly from the string
			const extractedNumber = sSerialNumber["Serial_Number"];
			if (!extractedNumber) {
				MessageBox.error("Scanned data does not contain a valid number.");
				this._setFocusOnBillingInput();
				return;
			}

			console.log("Extracted Serial Number:", extractedNumber);

			const oModel = this.getView().getModel(); // OData model
			const oTableModel = this.getView().getModel("tableModel");
			const aTableData = oTableModel.getProperty("/tableData");

			// Ensure aTableData is a valid array
			if (!Array.isArray(aTableData)) {
				console.error("aTableData is not an array or is undefined.");
				MessageBox.error("Unexpected error: Table data is not available.");
				this._setFocusOnBillingInput();
				return;
			}

			// Check if the serial number already exists in tableData
			const existingItem = aTableData.find(item => item.Serial_Number === extractedNumber);
			if (existingItem) {
				MessageBox.information("Item Already Exists in Table.", {
					onClose: () => this._setFocusOnBillingInput()
				});
				return;
			}

			// Make OData GET call to fetch Material for the scanned Serial_Number
			const sPath = `/SerialCodesSet('${extractedNumber}')`;

			oModel.read(sPath, {
				success: function(oData) {
					console.log("Backend Response Data:", oData);

					if (!oData.Material) {
						console.error("OData response does not contain 'Material':", oData);
						MessageBox.error("OData response is missing the Material field.");
						this._setFocusOnBillingInput();
						return;
					}

					const scannedMaterial = String(oData.Material).trim().toUpperCase();

					if (aTableData.length > 0) {
						const firstMaterial = String(aTableData[0].Material).trim().toUpperCase();

						if (firstMaterial !== scannedMaterial) {
							MessageBox.information(`Material which you are scanning is different. Only ${firstMaterial} is allowed.`, {
								onClose: () => this._setFocusOnBillingInput()
							});
							return;
						}
					}

					if (oData.Label_Rejected === "X") {
						MessageBox.information("The Serial Code is Rejected.", {
							onClose: () => this._setFocusOnBillingInput()
						});
						return;
					}

					if (oData.Palette_Number) {
						MessageBox.information(`This material is already assigned to pallet: ${oData.Palette_Number}`, {
							onClose: () => this._setFocusOnBillingInput()
						});
					} else {
						this.fetchDetailsFromOData(extractedNumber)
							.then(oDetail => {
								this.addLineItemToTable(oDetail);
								this._setFocusOnBillingInput();
							})
							.catch(oError => {
								console.error("Error fetching details:", oError);
								MessageBox.error("Failed to fetch details: " + oError.message, {
									onClose: () => this._setFocusOnBillingInput()
								});
							});
					}
				}.bind(this),
				error: function(oError) {
					console.error("Backend Error:", oError);
					MessageBox.information("Serial Code Does not Exist", {
						onClose: () => this._setFocusOnBillingInput()
					});
				}.bind(this)
			});
		},

		_setFocusOnBillingInput: function() {
			setTimeout(() => {
				const billingInput = this.byId("billingInput");
				if (billingInput) {
					billingInput.focus();
				} else {
					console.warn("Billing input field not found. Ensure the control ID is correct.");
				}
			}, 10); // Slightly longer delay for consistent behavior
		},
		fetchDetailsFromOData: function(sSerialNumber) {
			const oTableModel = this.getView().getModel("tableModel");
			const aTableData = oTableModel.getProperty("/tableData");

			if (aTableData.some(item => item.Serial_Number === sSerialNumber)) {
				return Promise.resolve(aTableData.find(item => item.Serial_Number === sSerialNumber));
			}

			return new Promise((resolve, reject) => {
				const oDataModel = this.getView().getModel();
				const sPath = `/SerialCodesSet('${sSerialNumber}')`;

				oDataModel.read(sPath, {
					success: resolve,
					error: reject
				});
			});
		},

		addLineItemToTable: function(oDetail) {
			const oTableModel = this.getView().getModel("tableModel");
			const aTableData = oTableModel.getProperty("/tableData");

			// Assign S.No dynamically
			oDetail.SNo = aTableData.length + 1;

			// Add the new item to the table data
			aTableData.push(oDetail);

			// Update the model with the new data
			oTableModel.setProperty("/tableData", aTableData);

			MessageBox.success("Item added successfully.");
		},

		onSubmitPress: function() {
			const oModel = this.getView().getModel();
			const oTableModel = this.getView().getModel("tableModel");
			let aScannedItems = oTableModel.getProperty("/tableData");

			if (!aScannedItems.length) {
				MessageBox.error("No items scanned. Cannot submit.");
				return;
			}

			// Remove S.No field from scanned items for the payload
			aScannedItems = aScannedItems.map(({
				SNo,
				...rest
			}) => rest);

			// Use Palette_Number currently displayed in the view
			const sPaletteNumber = this.getView().getModel("paletteModel").getProperty("/Palette_Number");

			const oPayload = {
				Palette_Number: sPaletteNumber,
				NP_ON_PALETTE: {
					results: aScannedItems
				}
			};

			oModel.create("/PaletteSet", oPayload, {
				success: function() {
					MessageBox.success("Data submitted successfully.");
					this.onNavigateBack();
				}.bind(this),
				error: function(oError) {
					MessageBox.error("Submission failed: " + oError.message);
				}
			});
		},
		onPreviewAttachment: function() {
			var sSerialNumber = this.scannedValue;

			if (!sSerialNumber) {
				MessageToast.show("Serial Number is missing.");
				return;
			}

			// Ensure that sSerialNumber is a string and attempt to parse the JSON
			let oParsedData;
			try {
				oParsedData = JSON.parse(sSerialNumber); // Attempt to parse JSON
			} catch (error) {
				MessageBox.error("Scanned data is not in valid JSON format.");
				this._setFocusOnBillingInput();
				return;
			}

			// Extract the Serial Number value
			var serialNumber = oParsedData.Serial_Number; // Access the Serial_Number from the parsed JSON

			if (!serialNumber) {
				MessageToast.show("Serial Number is missing from the parsed data.");
				return;
			}

			var oModel = this.getView().getModel(); // Get the model
			var sPath = `/PSPSet('${encodeURIComponent(serialNumber)}')/$value`; // Use the serialNumber for the OData call

			var that = this; // Store reference to "this"

			// Use AJAX to fetch data
			$.ajax({
				url: oModel.sServiceUrl + sPath,
				method: "GET",
				xhrFields: {
					responseType: "arraybuffer" // Expect binary data (for PDFs)
				},
				headers: {
					"Accept": "*/*" // Allow both JSON & PDF responses
				},
				success: function(data, textStatus, xhr) {
					console.log("API Response:", data); // Debugging: Check raw data

					var contentType = xhr.getResponseHeader("Content-Type");
					console.log("Content-Type:", contentType); // Debugging: Check file format

					if (contentType.includes("application/json")) {
						var jsonText = new TextDecoder("utf-8").decode(data);
						var jsonResponse = JSON.parse(jsonText);

						if (jsonResponse && jsonResponse.Psp_Data) {
							console.log("Extracted Base64 Data:", jsonResponse.Psp_Data);
							that.renderPDF(jsonResponse.Psp_Data.trim()); // Use "that" to call function
						} else {
							sap.m.MessageToast.show("No document data found.");
						}
					} else if (contentType.includes("application/pdf")) {
						var blob = new Blob([data], {
							type: "application/pdf"
						});
						var pdfUrl = URL.createObjectURL(blob);
						that.openPDF(pdfUrl); // Use "that" to call function
					} else {
						sap.m.MessageToast.show("Unsupported file format received.");
					}
				},
				error: function(xhr, status, error) {
					console.error("Error fetching document:", xhr, status, error);
					sap.m.MessageToast.show("Product Specification Document Doesn't Exist");
				}
			});
		},

		// Function to Decode Base64 and Open PDF
		renderPDF: function(base64Data) {
			try {
				// Convert Base64 to Binary
				var byteCharacters = atob(base64Data);
				var byteNumbers = new Array(byteCharacters.length);
				for (var i = 0; i < byteCharacters.length; i++) {
					byteNumbers[i] = byteCharacters.charCodeAt(i);
				}
				var byteArray = new Uint8Array(byteNumbers);
				var blob = new Blob([byteArray], {
					type: "application/pdf"
				});

				// Generate URL and Open PDF
				var pdfUrl = URL.createObjectURL(blob);
				this.openPDF(pdfUrl);
			} catch (error) {
				console.error("Error processing Base64 PDF:", error);
				sap.m.MessageToast.show("Failed to render document.");
			}
		},

		// Function to Open PDF (Handles Popup Blockers)
		openPDF: function(pdfUrl) {
			var newTab = window.open(pdfUrl, "_blank");

			if (!newTab) {
				// If popup is blocked, show PDF in an iframe
				var iframe = document.createElement("iframe");
				iframe.style.width = "100%";
				iframe.style.height = "600px";
				iframe.src = pdfUrl;
				document.body.appendChild(iframe);
				sap.m.MessageToast.show("Popup blocked! Displaying PDF below.");
			}
		}

	});
});