sap.ui.define(
	[
		"sap/ui/core/mvc/Controller",
		"sap/m/MessageToast",
		"sap/ui/model/json/JSONModel",
		"sap/ndc/BarcodeScanner",
		"sap/ui/model/odata/v2/ODataModel",
		"sap/m/MessageBox"
	],
	function(Controller, MessageToast, JSONModel, BarcodeScanner, ODataModel, MessageBox) {
		"use strict";
		var oDataModel, oIssueModel, oConfirmModel, issueSlNo = 0,
			confirmSlNo = 0;
		return Controller.extend("com.ziccz_issue_chemical_container.controller.View1", {
			onInit: function() {
				//creating models for table
				oIssueModel = new JSONModel({
					issues: []
				});
				oConfirmModel = new JSONModel({
					confirms: []
				});
				var oTable1 = this.byId("issueTableId");
				oTable1.setModel(oIssueModel, "issueModel");
				var oTable2 = this.byId("confirmTableId");
				oTable2.setModel(oConfirmModel, "confirmModel");
				// Attach hardware scan listener
				this._attachHardwareScanListener();

				// Initialize OData Model
				var serviceUrl = "/sap/opu/odata/sap/ZWM_PROCESS_SRV";
				oDataModel = new ODataModel(serviceUrl, {
					useBatch: false
				});
				this.getView().setModel(oDataModel, "odataModel");
				this._setFocusOnInput();

			},
			onAfterRendering: function() {
				setTimeout(() => {
					this.byId("inputField").focus();
				}, 100);
			},
			_setFocusOnInput: function() {
				setTimeout(() => {
					var oInput = this.byId("inputField");
					if (oInput) {
						oInput.focus();
					}
				}, 10);
			},
			onInputChange: function(oEvent) {
				var sValue = oEvent.getParameter("value").trim();
				const oInput = this.byId("inputField");
				// console.log("sval", sValue);
				if (!sValue) {
					MessageBox.error("Invalid input. Please scan again.");
					return;
				}

				// console.log("Manually Entered or Scanned Value:", sValue);
				// Clear the input field after handling the data
				if (oInput) {
					oInput.setValue("");
				}
				this.handleScannedData(sValue);
				//setting focus again on inputfield
				this._setFocusOnInput();
			},
			_attachHardwareScanListener: function() {
				let scanBuffer = "";
				let scanTimeout;

				document.addEventListener(
					"keydown",
					function(event) {
						if (event.target.tagName === "INPUT") {
							return; // Skip if an input field is already focused
						}

						if (event.key !== "Enter") {
							scanBuffer += event.key;
							clearTimeout(scanTimeout);

							scanTimeout = setTimeout(() => {
								scanBuffer = ""; // Reset buffer after delay
							}, 200);
						} else if (scanBuffer) {
							const scannedValue = scanBuffer.trim();
							scanBuffer = ""; // Reset buffer

							if (scannedValue) {
								console.log("Scanned Data:", scannedValue);

								this.handleScannedData(scannedValue);
							}
						}
					}.bind(this)
				);
			},

			onIssueSelect: function() {
				this.byId("issueTable").setVisible(true);
				this.byId("confirmTable").setVisible(false);
				// this.byId("confirmbtn").setEnabled(false);
			},

			onConfirmSelect: function() {
				this.byId("issueTable").setVisible(false);
				this.byId("confirmTable").setVisible(true);
				// this.byId("issuebtn").setEnabled(false);
			},

			onScan: function() {
				// Implement barcode scanner logic here
				BarcodeScanner.scan(
					function(oResult) {
						if (oResult.text) {
							var qrCode = oResult.text;
							this.handleScannedData(qrCode);
							this._setFocusOnInput();

						} else {
							MessageToast.show("No QR code detected.");
							oInput.focus();
						}
					}.bind(this),
					function(oError) {
						MessageToast.show("Scan failed: " + oError.message);
						oInput.focus();
					}
				);

			},
			handleScannedData: function(qrCode) {
				var oInput = this.byId("inputField");
				var issueBtn = this.byId("issuebtn").getSelected();
				var confirmBtn = this.byId("confirmbtn").getSelected();
				// console.log("QR code", qrCode);
				oDataModel.read("/HeaderSet('" + qrCode + "')", {
					success: function(oData) {

						if (issueBtn) {
							//Status validation
							if (oData.CurrentStatus !== "RW" && oData.CurrentStatus !== "RC") {
								MessageToast.show("Status validation failed");
								return;
							}
							if (oData) {
								var newIssue = {
									serial: issueSlNo + 1,
									qrCode: oData.BarCode,
									materialDesc: oData.MaterialDescription,
									grossWeight: oData.GrossWeight,
									netWeight: oData.NetWeight,
									ContainerWeight: oData.ContainerWeight,
									Material: oData.Material,
									CurrentStatus: oData.CurrentStatus,
									CurrentLocation: oData.CurrentLocation,
									CurrentGrossWeight: oData.CurrentGrossWeight,
									ContainerBarCode: oData.ContainerBarCode,
									CurrentNetWeight: oData.CurrentNetWeight,
									RegisteredBy: oData.RegisteredBy,
									RegisteredDate: oData.RegisteredDate,
									RegisteredTime: oData.RegisteredTime,
									LastChangedBy: oData.LastChangedBy,
									LastChangedDate: oData.LastChangedDate,
									LastChangedTime: oData.LastChangedTime
								};

								var issues = oIssueModel.getProperty("/issues");

								//validation for duplicate lineitem
								for (var issue of issues) {
									if (issue.qrCode == qrCode) {
										MessageToast.show("Data already available in table");
										return;
									}
								}

								issues.push(newIssue);
								oIssueModel.setProperty("/issues", issues);

								issueSlNo++;
								// console.log("newIssue", oIssueModel);
							}
							oInput.focus();
						} else if (confirmBtn) {
							// console.log("odata confirm", oData);
							//Status validation
							if (oData.CurrentStatus != "IL") {
								MessageToast.show("Status validation failed");
								return;
							}
							//location validation
							if (oData.CurrentLocation !== this.byId("locationSelect").getSelectedItem().getKey()) {
								MessageToast.show("Select valid location: issue and confirm Location mismatched");
								return;
							}
							if (oData) {
								var newConfirm = {
									serial: confirmSlNo + 1,
									qrCode: oData.BarCode,
									materialDesc: oData.MaterialDescription,
									grossWeight: oData.GrossWeight,
									netWeight: oData.NetWeight,
									ContainerWeight: oData.ContainerWeight,
									Material: oData.Material,
									CurrentStatus: oData.CurrentStatus,
									CurrentLocation: oData.CurrentLocation,
									CurrentGrossWeight: oData.CurrentGrossWeight,
									ContainerBarCode: oData.ContainerBarCode,
									CurrentNetWeight: oData.CurrentNetWeight,
									RegisteredBy: oData.RegisteredBy,
									RegisteredDate: oData.RegisteredDate,
									RegisteredTime: oData.RegisteredTime,
									LastChangedBy: oData.LastChangedBy,
									LastChangedDate: oData.LastChangedDate,
									LastChangedTime: oData.LastChangedTime
								};

								var confirms = oConfirmModel.getProperty("/confirms");

								//validation for duplicate lineitem
								for (var confirm of confirms) {
									if (confirm.qrCode == qrCode) {
										MessageToast.show("Data already available in table");
										return;
									}
								}
								confirms.push(newConfirm);
								oConfirmModel.setProperty("/confirms", confirms);

								confirmSlNo++;
								// console.log("newConfirm", oConfirmModel);
							}
							oInput.focus();

						}

					}.bind(this),
					error: function(oError) {
						oInput.focus();
						MessageToast.show("No data available for scanned QR code.");
					}
				});

			},

			onSubmit: function() {

				var issueBtn = this.byId("issuebtn").getSelected();
				var confirmBtn = this.byId("confirmbtn").getSelected();

				if (issueBtn) {
					//reset slno
					issueSlNo = 0;
					var issuesData = oIssueModel.getProperty("/issues");
					if (issuesData.length == 0) {
						MessageToast.show("No lineitem in the table. Can not submit");
						return;
					}
					console.log("Collected Issues Data: ", issuesData);
					if (this.byId("locationSelect").getSelectedItem().getKey() === "Select") {
						MessageToast.show("Please select a valid location");
						return;
					}
					MessageToast.show("Issues data collected: " + issuesData.length + " items.");
					for (var issue of issuesData) {

						var oPayload = {
							BarCode: issue.qrCode,
							MaterialDescription: issue.materialDesc,
							NetWeight: issue.netWeight,
							GrossWeight: issue.grossWeight,
							ContainerWeight: issue.ContainerWeight,
							Material: issue.Material,
							CurrentGrossWeight: issue.CurrentGrossWeight,
							ContainerBarCode: issue.ContainerBarCode,
							CurrentNetWeight: issue.CurrentNetWeight,
							RegisteredBy: issue.RegisteredBy,
							RegisteredDate: issue.RegisteredDate,
							RegisteredTime: issue.RegisteredTime,
							LastChangedBy: issue.LastChangedBy,
							LastChangedDate: issue.LastChangedDate,
							LastChangedTime: issue.LastChangedTime,
							CurrentStatus: "IL",
							CurrentLocation: this.byId("locationSelect").getSelectedItem().getKey(),

						};
						// console.log("Payload---", oPayload)

						oDataModel.update("/HeaderSet('" + issue.qrCode + "')", oPayload, {
							method: "PUT",
							success: function() {
								MessageToast.show("Data for chemical issue updated successfully.");
							},
							error: function(oError) {
								MessageToast.show("Update failed for issue: " + oError.message);
							}
						});
					}

				} else if (confirmBtn) {
					//reset slno
					confirmSlNo = 0;
					var confirmData = oConfirmModel.getProperty("/confirms");
					if (confirmData.length == 0) {
						MessageToast.show("No lineitem in the table. Can not submit");
						return;
					}
					console.log("Collected Confirm Data: ", confirmData);
					if (this.byId("locationSelect").getSelectedItem().getKey() === "Select") {
						MessageToast.show("Please select a valid location");
						return;
					}
					MessageToast.show("Confirm data collected: " + confirmData.length + " items.");
					for (var confirm of confirmData) {

						var oPayload = {
							BarCode: confirm.qrCode,
							MaterialDescription: confirm.materialDesc,
							NetWeight: confirm.netWeight,
							GrossWeight: confirm.grossWeight,
							ContainerWeight: confirm.ContainerWeight,
							Material: confirm.Material,
							CurrentGrossWeight: confirm.CurrentGrossWeight,
							ContainerBarCode: confirm.ContainerBarCode,
							CurrentNetWeight: confirm.CurrentNetWeight,
							RegisteredBy: confirm.RegisteredBy,
							RegisteredDate: confirm.RegisteredDate,
							RegisteredTime: confirm.RegisteredTime,
							LastChangedBy: confirm.LastChangedBy,
							LastChangedDate: confirm.LastChangedDate,
							LastChangedTime: confirm.LastChangedTime,
							CurrentStatus: "DL",
							CurrentLocation: this.byId("locationSelect").getSelectedItem().getKey(),
						};
						// console.log("Payload confirm---", oPayload)

						oDataModel.update("/HeaderSet('" + confirm.qrCode + "')", oPayload, {
							method: "PUT",
							success: function() {
								MessageToast.show("Data for chemical confirm updated successfully.");
							},
							error: function(oError) {
								MessageToast.show("Update failed for issue: " + oError.message);
							}
						});
					}
				} else {
					MessageBox.error("No action selected. Please choose Issue or Confirm.");
				}
				this.clearPageData();
			},
			clearPageData: function() {
				this.byId("inputField").setValue("");
				this.byId("locationSelect").setSelectedKey("Select");
				this.byId("issuebtn").setSelected(true);
				this.byId("confirmbtn").setSelected(false);

				const issueModel = this.byId("issueTableId").getModel("issueModel");
				const confirmModel = this.byId("confirmTableId").getModel("confirmModel");

				if (issueModel) {
					issueModel.setData({
						issues: []
					});
				}

				if (confirmModel) {
					confirmModel.setData({
						confirms: []
					});
				}

				this.byId("confirmTable").setVisible(false);
				this.byId("issueTable").setVisible(true);

			}

		});
	}
);