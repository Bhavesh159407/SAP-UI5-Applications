sap.ui.define([
  "sap/ui/core/UIComponent",
  "sap/ui/Device",
  "somanyimpresa/billingbilling/model/models"
], function(UIComponent, Device, models) {
  "use strict";

  return UIComponent.extend("somanyimpresa.billingbilling.Component", {

    metadata: {
      manifest: "json"
    },

    /**
     * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
     * @public
     * @override
     */
    init: function() {
      // call the base component's init function
      UIComponent.prototype.init.apply(this, arguments);

      this.getRouter().initialize();

      // set the device model
      this.setModel(models.createDeviceModel(), "device");
      var oODataModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/SAP/ZSD_ADVANCE_BILLING_SRV/");
      this.setModel(oODataModel);
    }
  });
});