sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/greenbyte/zmmobd/model/formatter",
	"sap/m/MessageToast"
], function(Controller, Formatter, MessageToast) {
	"use strict";

	return Controller.extend("com.greenbyte.zmmobd.controller.Main", {
		formatter: Formatter,
		_QRcodes: {},

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.greenbyte.zmmobd.view.Main
		 */
		onInit: function() {
			var oRsrcModel = new sap.ui.model.resource.ResourceModel({
				bundleName: "com.greenbyte.zmmobd.i18n.i18n"
			});
			this.getView().setModel(oRsrcModel, "i18n");

			this._oODataModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/SAP/ZSD_OUTBOUND_DELIVERY_PGI_SRV/");
			this.getOwnerComponent().setModel(this._oODataModel);

			var oMainModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oMainModel, "MainModel");
			this._oMainModel = this.getView().getModel("MainModel");
			this._setInitialData();
		},

		_setInitialData: function() {
			this._oCurrTable = this.getView().byId("deliveryItems");

			if (this._oCurrTable) {
				this._oCurrTable.removeSelections(true);
			}

			this._oMainModel.setProperty("/deliveryItems", []);
			this.aSelectedPath = [];
			this._oMainModel.setProperty("/QRCodes", []);
			this._oMainModel.setProperty("/itemsCnt", "0");

			this._oMainModel.setProperty("/header", {
				Bldat: new Date(),
				Vbeln: ""
			});

		},

		onTableSelect: function(oEvent) {
			this.aSelectedPath = oEvent.getSource()._aSelectedPaths;
		},

		onChangeDeliveryHdr: function() {
			var sEntrdDlvryNo = this._oMainModel.getProperty("/header/Vbeln");

			this._oODataModel.read("/DeliveryHeaderSet('" + sEntrdDlvryNo + "')", {
				urlParameters: {
					"$expand": "NAVITEM/NAVQR"
				},
				success: function(oData) {
					if (oData.NAVITEM.results.length > 0) {
						this._oMainModel.setProperty("/deliveryItems", oData.NAVITEM.results);
						this._oMainModel.setProperty("/itemsCnt", oData.NAVITEM.results.length + "");

						// Set NAV QR item length
						//for (var i = 0; i < oData.NAVITEM.results.length; i++) {
						//  oData.NAVITEM.results[i].ScanQty = oData.NAVITEM.results[i].NAVQR.results.length + "";
						//}

						if (oData.NAVITEM.results) {
							// this._oMainModel.setProperty("/ScanQty", oData.NAVITEM.results);
						}
					} else {
						this._oMainModel.setProperty("/deliveryItems", []);
					}

					this._oMainModel.refresh(true);
				}.bind(this),
				error: function(oError) {
					this._showResponseErrMsg(oError);
				}
			});
		},

		onScan: function() {
			try {
				cordova.plugins.barcodeScanner.scan(
					function(oResult) {
						if (oResult.text) {
							var sString = new String('' + oResult.text + '');
							var sValue = sString.split("|")[6] || sString.split("|")[3];

							if (sValue) {
								this._validateQRCode(sValue);
							} else {
								MessageToast.show("Scanned QR code format is not valid", {
									duration: 700
								});
							}
						} else {
							MessageToast.show("Scanned value is empty", {
								duration: 700
							});
						}
					}.bind(this),
					function(error) {
						this._showDialog("Error", JSON.parse(error));
					}
				);

			} catch (e) {
				MessageToast.show("Not supported! \n Run the app inside Fiori Client and try again.");
			}

		},

		_validateQRCode: function(sScannedQR) {
			var aQRList = this._oMainModel.getProperty("/QRCodes");

			for (var a = 0; a < aQRList.length; a++) {
				// Validation already existed QR code
				if (aQRList[a].Qrserial === sScannedQR) {

					MessageToast.show("Serial number is already used", {
						durtion: 1000
					});
					return;

				}
			}

			var onQRMatnr = this._oCurrSelectedItem['Matnr'];
			var aFilter = [];
			if ((onQRMatnr !== " ") || (onQRMatnr !== null)) {
				aFilter.push(
					new sap.ui.model.Filter({
						path: "Material",
						operator: "EQ",
						value1: onQRMatnr
					})
				);
			}

			/* aFilter.push(
			   new sap.ui.model.Filter({
			     path: "Delivery",
			     operator: "EQ",
			     value1: this._oCurrSelectedItem['Vbeln']
			   })
			 );*/

			this._oODataModel.read("/CheckScannedQrSet('" + sScannedQR + "')", {
				filters: aFilter,
				success: function(oData) {
					if (oData.IsExist === "true") {
						if (oData.IsConsumed === "true") {
							MessageToast.show("Scanned QR code is already consumed!", {
								duration: 900
							});
						} else {
							this._appendQRtoItem(sScannedQR);
						}
					} else {
						MessageToast.show("Scanned QR code is not available!", {
							duration: 900
						});
					}

				}.bind(this),
				error: function(oError) {
					this._showResponseErrMsg(oError);
				}.bind(this)
			});
		},

		onSearch: function(evt) {
			this._QRcodes = {};
			this._oMainModel.setProperty("/deliveryItems", []);
			this._oMainModel.setProperty("/itemsCnt", "");
			this._oMainModel.setProperty("/header/Vbeln", evt.getParameter("selectionSet")[0].getValue());
			this.onChangeDeliveryHdr();
		},

		onSave: function() {
			var oHeader = this._oMainModel.getProperty("/header");

			var oItem = [];
			if (this.aSelectedPath.length > 0) {
				for (var p = 0; p < this.aSelectedPath.length; p++) {
					oItem.push(this._oMainModel.getProperty(this.aSelectedPath[p]));
				}
			} else {
				MessageToast.show("Please select at least one line item", {
					durtion: 1000
				});
				return;
			}

			var oDataToSend = Object.assign({}, oHeader);

			var oDocDate = new Date(oDataToSend.Bldat);

			oDataToSend.Bldat = oDocDate.getDate() + ".0" + (oDocDate.getMonth() + 1) + "." + oDocDate.getFullYear();
			if (oDocDate.getMonth() < 9) {
				oDataToSend.Bldat = oDocDate.getDate() + ".0" + (oDocDate.getMonth() + 1) + "." + oDocDate.getFullYear();
			} else {
				oDataToSend.Bldat = oDocDate.getDate() + "." + (oDocDate.getMonth() + 1) + "." + oDocDate.getFullYear();
			}

			oDataToSend.NAVITEM = Array.from(oItem);

			for (var i = 0; i < oDataToSend.NAVITEM.length; i++) {

				if (oDataToSend.NAVITEM[i].NAVQR.results)
					oDataToSend.NAVITEM[i].NAVQR = Array.from(oDataToSend.NAVITEM[i].NAVQR.results);
				else
					oDataToSend.NAVITEM[i].NAVQR = Array.from(oDataToSend.NAVITEM[i].NAVQR);

				// Validation messge: Actual Qty and Scanned Qty are not equal
				if (parseInt(oDataToSend.NAVITEM[i].Pikmg, 10) < parseInt(oDataToSend.NAVITEM[i].ScanQty, 10)) {

					MessageToast.show("Scanned Qty is more than the Pick Qty", {
						durtion: 1000
					});
					return;

				}
				for (var a = 0; a < oDataToSend.NAVITEM[i].NAVQR.length; a++) {
					delete oDataToSend.NAVITEM[i].NAVQR[a].Matnr;
				}

			}

			this._postCall(oDataToSend);

		},

		_postCall: function(oDataToSend) {
			this._oODataModel.create("/DeliveryHeaderSet", oDataToSend, {
				success: function(data) {
					if (data.ReturnMessage.Message) {
						this._setInitialData();
						this._oMainModel.refresh(true);
						this._showDialog("Success", data.ReturnMessage.Message);
					} else {
						this._showDialog("Success", "No message found");
					}
				}.bind(this),
				error: function(oError) {
					this._showResponseErrMsg(oError);
				}.bind(this)
			});
		},

		_showDialog: function(sTitle, sText) {
			var oDialog = new sap.m.Dialog({
				title: sTitle,
				type: "Message",
				state: sTitle,
				content: new sap.m.Text({
					text: sText
				}),
				beginButton: new sap.m.Button({
					text: "OK",
					press: function() {
						oDialog.close();
					}
				}),
				afterClose: function() {
					oDialog.destroy();
				}
			});

			oDialog.open();
		},

		_showResponseErrMsg: function(oError) {
			if (Formatter.isJSON(oError.responseText)) {
				this._showDialog("Error", JSON.parse(oError.responseText).error.message.value);
			} else {
				try {
					var oDOMParser = new DOMParser();
					var oXMLError = oDOMParser.parseFromString(oError.responseText, "application/xml");
					this._showDialog("Error", oXMLError.all[2].innerHTML);
				} catch (e) {
					this._showDialog("Error", e);
				}
			}
		},

		OnQRCode: function(oEvent) {

			var oTable = oEvent.getSource().getParent();
			var oContext = oTable.getBindingContext("MainModel");
			this._sCurrentPath = oContext.getPath();
			var aQRData = oContext.getModel().getProperty(oContext.getPath() + "/NAVQR/results");

			this._oCurrSelectedItem = oContext.getModel().getProperty(oContext.getPath());

			this._sId = oContext.getPath().split("/")[2];

			this._QRcodes[this._sId] = this._QRcodes[this._sId] && this._QRcodes[this._sId].length > 0 ? this._QRcodes[this._sId] : aQRData;

			this._oMainModel.setProperty("/QRCodes", this._QRcodes[this._sId] ? this._QRcodes[this._sId] : []);
			this._oMainModel.refresh(true);

			if (!this._oQRDialog) {
				this._oQRDialog = sap.ui.xmlfragment(this.getView().getId(), "com.greenbyte.zmmobd.view.fragments.QRCode", this);
				this.getView().addDependent(this._oQRDialog);
			}
			this._oQRDialog.open();

		},

		_appendQRtoItem: function(sValue) {
			var oQRCode = this._oMainModel.getProperty("/QRCodes");
			oQRCode = oQRCode.length > 0 ? oQRCode : [];

			if (parseInt(this._oCurrSelectedItem.Pikmg, 10) === oQRCode.length || parseInt(this._oCurrSelectedItem.Pikmg, 10) < oQRCode.length) {
				MessageToast.show("Exceeded maximum no. of scanned quantity!", {
					duration: 900
				});
				return;
			}

			oQRCode.push({
				Qrserial: sValue,
				Matnr: this._oMainModel.getProperty(this._sCurrentPath).Matnr
			});
			this._oMainModel.setProperty("/QRCodes", oQRCode);
			// this._oMainModel.setProperty(this._sCurrentPath + "/ScanQty", oQRCode.length + "");

			this._oMainModel.refresh(true);
		},

		onChangeManualScan: function(oEvent) {
			this._validateQRCode(oEvent.getParameter("value"));
			oEvent.getSource().setValue("");
		},

		onCloseQRCode: function() {
			var aData = this._oMainModel.getProperty("/QRCodes");

			this._QRcodes[this._sId] = this._oMainModel.getProperty("/QRCodes");
			this._oMainModel.setProperty(this._sCurrentPath + "/NAVQR", this._QRcodes[this._sId]);
			// this._oMainModel.setProperty(this._sCurrentPath + "/ScanQty", aData.length + "");

			this._sId = null;

			this._oQRDialog.close();
		},

		onDeleteQRCodes: function(oEvent) {
			var oModel = oEvent.getSource().getParent().getBindingContext("MainModel"),
				sPath = oModel.getPath(),
				aData = oModel.getModel().getProperty("/QRCodes");
			sPath = sPath.split("/")[2];

			aData.splice(parseInt(sPath, 10), 1);
			this._oMainModel.setProperty("/QRCodes", aData);

			this._oMainModel.refresh(true);
		},

		onLiveQRChange: function(oEvent) {
			var sVal = oEvent.getSource().getValue();
			if (sVal.trim() && sVal.split("|").length > 3) {
				sVal = sVal.split("|")[3].length === 14 ? sVal.split("|")[3] : sVal.split("|")[6];
				oEvent.getSource().setValue(sVal);
				this._validateQRCode(sVal);
				oEvent.getSource().setValue("");
			}
			//if(sVal.split("|").length=== 5) {
			//oEvent.getSource().setValue(sVal.split("|")[3]);
			//this._validateQRCode(sVal.split("|")[3]);
			//this._appendQRtoItem(sVal.split("|")[3]);
			//oEvent.getSource().setValue("");
			//}
			//if(sVal.split("|").length=== 8) {
			//oEvent.getSource().setValue(sVal.split("|")[6]);
			//this._validateQRCode(sVal.split("|")[6]);
			// this._appendQRtoItem(sVal.split("|")[6]);
			//oEvent.getSource().setValue("");
			//}
		},

onConfirm: function(oEvent) {
    var aData = this._oMainModel.getProperty("/QRCodes");

    // Store scanned QR codes in a temporary object
    this._QRcodes[this._sId] = this._oMainModel.getProperty("/QRCodes");
    this._oMainModel.setProperty(this._sCurrentPath + "/NAVQR", this._QRcodes[this._sId]);

    // Reset the current ID
    this._sId = null;

    // Create filters for the scanned QR codes
    var filters = [];
    for (var a = 0; a < aData.length; a++) {
        filters.push(new sap.ui.model.Filter("Qrserial", sap.ui.model.FilterOperator.EQ, aData[a].Qrserial, aData[a].Matnr));
    }

    // Close the QR Dialog
    this._oQRDialog.close();

    // Fetch scanned quantities from OData service
    this._oODataModel.read("/GetScannedQtySet", {
        filters: filters,
        success: function(oData) {
            this._oMainModel.setProperty(this._sCurrentPath + "/ScanQty", oData.results[0].Qty);
        }.bind(this),
        error: function(oError) {
            this._showResponseErrMsg(oError);
        }.bind(this)
    });

    // Clear the QR code data from the model
    this._oMainModel.setProperty("/QRCodes", []);
}




		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.greenbyte.zmmobd.view.Main
		 */
		//  onBeforeRendering: function() {
		//
		//  },

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.greenbyte.zmmobd.view.Main
		 */
		//  onAfterRendering: function() {
		//
		//  },

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.greenbyte.zmmobd.view.Main
		 */
		//  onExit: function() {
		//
		//  }

	});

});