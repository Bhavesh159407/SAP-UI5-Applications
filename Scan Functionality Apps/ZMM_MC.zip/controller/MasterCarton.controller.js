sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"com/greenbyte/zmm_mc_box/model/formatter",
	"sap/m/Button",
	"sap/ui/core/Fragment"
], function(Controller, MessageToast, Formatter, Button, Fragment) {
	"use strict";

	return Controller.extend("com.greenbyte.zmm_mc_box.controller.MasterCarton", {
		formatter: Formatter,
		onInit: function() {

			this._oODataModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/SAP/ZSD_MASTER_CARTON_SRV/");
			var oDefaultModel = new sap.ui.model.json.JSONModel();
			this.getView().setModel(oDefaultModel, "oDefaultModel");
			this.oDefaultModel = this.getView().getModel("oDefaultModel");
			this.initializeMcData();

		},

		onMasterCartonSearch: function(oEvent) {
			var sValue = oEvent.getParameter("value");
			var sCatCode = "";
			if (!sValue.trim()) {
				MessageToast.show("Invalid Qr Serial");
				this.oDefaultModel.setProperty("/SearchQuery", "");
				return;
			} else {
				if (sValue.split("|").length > 3) {
					sCatCode = sValue.split("|")[2];
					sValue = sValue.split("|")[3];
				}
			}
			this.oDefaultModel.setProperty("/SearchQuery", sValue);
			this.oDefaultModel.setProperty("/CatCode", sCatCode);

			var isMcScanned = this.oDefaultModel.getProperty("/IsMcScanned");
			if (sValue && (sValue.charAt(0) !== "M" && !isMcScanned) || (isMcScanned && sValue.charAt(0) === "M")) {
				MessageToast.show("Invalid Qr Serial");
				this.oDefaultModel.setProperty("/SearchQuery", "");
				return;
			} else if (!isMcScanned && sValue.charAt(0) === "M") {
				this.getMasterCartonData(sValue);
			} else {
				this.checkScannedItemData(sValue);
				// this.AppendQrToMc(sValue);
			}
		},

		getMasterCartonData: function(sValue) {
			var aFilter = [];
			aFilter.push(new sap.ui.model.Filter({
				path: "McQrserial",
				operator: "EQ",
				value1: sValue
			}));
			this._oODataModel.read("/QRHeaderSet('" + sValue + "')", {
				success: function(oData) {
					if (oData) {
						var sMaterial = oData.Material.replace(/^0+/, '');
						this.oDefaultModel.setProperty("/Material", sMaterial);
						this.oDefaultModel.setProperty("/McQrSerial", oData.McQrserial);
						this.oDefaultModel.setProperty("/BaseQuantity", oData ? parseInt(oData.BaseQuantity, 10) : 0);
					}
				}.bind(this),
				error: function(oError) {
					this._showResponseErrMsg(oError);
				}
			});
			this._oODataModel.read("/QRHeaderSet", {
				filters: aFilter,
				success: function(oData) {
					this.oDefaultModel.setProperty("/SearchQuery", "");
					var aResults = oData.results;
					if (aResults.length) {
						var iTotalItemQty = 0;
						aResults.filter(function(item) {
							item.DeleteFlag = "";
							item.SaveFlag = false;
							var iBaseQty = parseInt(item.BaseQuantity, 10);
							iTotalItemQty = iTotalItemQty + iBaseQty;
						});
						this.oDefaultModel.setProperty("/TotalItemQty", iTotalItemQty);
						this.oDefaultModel.setProperty("/MasterCartonItems", aResults);
						this.oDefaultModel.setProperty("/ItemCount", aResults.length);
					}
					this.oDefaultModel.setProperty("/IsMcScanned", true);
					this.oDefaultModel.refresh(true);
				}.bind(this),
				error: function(oError) {
					this._showResponseErrMsg(oError);
				}
			});
		},

		AppendQrToMc: function(sValue) {
			// setTimeout(function() {
			var that = this;
			var aMcData = this.oDefaultModel.getProperty("/MasterCartonItems");
			var sMcQrSerial = this.oDefaultModel.getProperty("/McQrSerial");
			var sKey = this.oDefaultModel.getProperty("/AttachDetachKey");
			var index = aMcData.findIndex(function(item) {
				return item.Qrserial === sValue;
			});
			var oQrData = this.oDefaultModel.getProperty("/QrSerial");
			var sIsConsumed = oQrData.IsConsumed;
			if (oQrData.IsExist === "true") {
				if (sIsConsumed === "true" && (sMcQrSerial !== oQrData.McQrserial)) { //consumed in other mc
					this.oDefaultModel.setProperty("/SearchQuery", "");
					MessageToast.show("Scanned QR code is already consumed!", {
						duration: 900
					});
				} else if (sIsConsumed === "true" && (sMcQrSerial === oQrData.McQrserial)) { //detach case
					if (sKey === "01") {
						this.oCnfrmDialog = new sap.m.Dialog({
							type: "Message",
							title: "Confirmation",
							content: new sap.m.Text({
								text: "Qr Serial already exists, Do you want to Detach ?"
							}),
							beginButton: new Button({
								type: "Emphasized",
								text: "Submit",
								press: function() {
									this.onDetachQrSerial(index);
									this.oCnfrmDialog.close();
								}.bind(this)
							}),
							endButton: new Button({
								text: "Cancel",
								press: function() {
									this.oDefaultModel.setProperty("/SearchQuery", "");
									this.oCnfrmDialog.close();
								}.bind(this)
							})
						});
						this.oCnfrmDialog.open();
					} else {
						this.onDetachQrSerial(index);
					}

				} else if (sIsConsumed === "false" && (index !== -1 || sKey === "02")) { //Already in queue
					if (sKey === "01") {
						MessageToast.show("Qr serial is already scanned and in queue to save", {
							duration: 900
						});
					} else {
						MessageToast.show("Invalid Qr Serial", {
							duration: 900
						});
					}
					this.oDefaultModel.setProperty("/SearchQuery", "");
				} else {
					// this.getScannedItemData(oQrData.Qrserial);
					var getPromise = function getPromise(sQrserial) {
						var promise = new Promise(function(resolve, reject) {
							var filters = [];
							filters.push(new sap.ui.model.Filter("Qrserial", sap.ui.model.FilterOperator.EQ, sQrserial));
							that._oODataModel.read("/GetScannedQtySet", {
								filters: filters,
								success: function(oData) {
									resolve(oData);
								},
								error: function(oError) {
									reject(oError);
								}
							});
						});
						return promise;
					};
					var promise = getPromise(oQrData.Qrserial);
					promise.then(function(oData) {
						var aResults = oData.results;
						if (aResults.length) {
							var oQrItem = aResults[0];
							var iCurrentQrSerialQty = aResults.length ? parseInt(oQrItem.QrQty, 10) : 0;
							var sQrMaterial = oQrItem.Material.replace(/^0+/, '');
							// var sQrMaterial = parseInt(oQrItem.Material, 10).toString();
							that.oDefaultModel.setProperty("/CurrentQrSerialMaterial", sQrMaterial);
							that.oDefaultModel.setProperty("/CurrentQrSerialQty", iCurrentQrSerialQty);
							that.oDefaultModel.setProperty("/SearchQuery", "");
							var sMcMaterial = that.oDefaultModel.getProperty("/Material");
							if (sMcMaterial !== sQrMaterial) {
								MessageToast.show("Invalid qr serial");
								return;
							}
							var iBaseQty = that.oDefaultModel.getProperty("/BaseQuantity");
							var iTotalItemQty = that.oDefaultModel.getProperty("/TotalItemQty");
							if (iTotalItemQty >= iBaseQty) {
								MessageToast.show("Exceeded maximum no. of scanned quantity!");
								return;
							}
							var oQrSerial = {
								BaseQuantity: iCurrentQrSerialQty,
								Material: that.oDefaultModel.getProperty("/Material"),
								McQrserial: that.oDefaultModel.getProperty("/McQrSerial"),
								Qrserial: oQrData.Qrserial,
								DeleteFlag: "",
								SaveFlag: true
							};
							aMcData.push(oQrSerial);
							that.calculateItemQty(true, oQrSerial.BaseQuantity);
							that.oDefaultModel.refresh(true);
						}
					});
				}
			} else {
				this.oDefaultModel.setProperty("/SearchQuery", "");
				MessageToast.show("Scanned QR code is not available!", {
					duration: 900
				});
			}
			// }.bind(this), 500);
		},

		calculateItemQty: function(isAttach, baseQty) {
			// var aMcData = this.oDefaultModel.getProperty("/MasterCartonItems");
			var iTotalItemQty = this.oDefaultModel.getProperty("/TotalItemQty");
			var count = isAttach ? iTotalItemQty + parseInt(baseQty, 10) : iTotalItemQty - parseInt(baseQty, 10);
			this.oDefaultModel.setProperty("/TotalItemQty", count);
			if (!isAttach) {
				var detachCount = this.oDefaultModel.getProperty("/DetachCount");
				detachCount += parseInt(baseQty, 10);
				this.oDefaultModel.setProperty("/DetachCount", detachCount);
			}
		},

		onDetachQrSerial: function(index) {
			var oMcItem = this.oDefaultModel.getProperty("/MasterCartonItems/" + index);
			var sDeleteFlag = oMcItem.DeleteFlag;
			this.oDefaultModel.setProperty("/SearchQuery", "");
			if (sDeleteFlag === "X") {
				MessageToast.show("Qr serial is already scanned and in queue to detach");
				return;
			}
			var baseQty = oMcItem.BaseQuantity;
			this.oDefaultModel.setProperty("/MasterCartonItems/" + index + "/" + "DeleteFlag", "X");
			this.oDefaultModel.setProperty("/MasterCartonItems/" + index + "/" + "SaveFlag", true);
			this.filterMcList(this.oDefaultModel.getProperty("/AttachDetachKey"));
			this.calculateItemQty(false, baseQty);
			this.oDefaultModel.refresh(true);
		},

		onScan: function() {
			MessageToast.show("Scanning success(onScan)");
			try {
				cordova.plugins.barcodeScanner.scan(
					function(oResult) {
						if (oResult.text) {
							MessageToast.show("Scanning success" + oResult.text);
						}
					}.bind(this),
					function(error) {
						MessageToast.show("Scanning Failed" + error.text);
					}
				);

			} catch (e) {
				MessageToast.show("Not supported! \n Run the app inside Fiori Client and try again.");
			}
		},

		onSaveMc: function() {
			var aMcData = this.oDefaultModel.getProperty("/MasterCartonItems");
			var aNavQrHeadtoQrItem = [];
			aMcData.filter(function(item) {
				if (item.SaveFlag) {
					var oNewQr = {
						Qrserial: item.Qrserial,
						DeleteFlag: item.DeleteFlag
					};
					aNavQrHeadtoQrItem.push(oNewQr);
				}
			});
			var oMcPayload = {
				McQrserial: this.oDefaultModel.getProperty("/McQrSerial"),
				NavQrHeadtoQrItem: aNavQrHeadtoQrItem
			};
			if (aNavQrHeadtoQrItem.length === 0) {
				MessageToast.show("No changes done");
				return;
			}
			this._oODataModel.create("/QRHeaderSet", oMcPayload, {
				success: function(data) {
					this._showDialog("Success", data.ReturnMessage.Message);
				}.bind(this),
				error: function(oError) {
					this._showResponseErrMsg(oError);
				}.bind(this)
			});
		},

		getScannedItemData: function(sQrserial) {
			var that = this;
			var filters = [];
			filters.push(new sap.ui.model.Filter("Qrserial", sap.ui.model.FilterOperator.EQ, sQrserial));
			this._oODataModel.read("/GetScannedQtySet", {
				filters: filters,
				success: function(oData) {
					var aResults = oData.results;
					if (aResults.length) {
						var oItem = aResults[0];
						var iQrQty = aResults.length ? parseInt(oItem.QrQty, 10) : 0;
						var sQrMaterial = parseInt(oItem.Material, 10).toString();
						that.oDefaultModel.setProperty("/CurrentQrSerialMaterial", sQrMaterial);
						that.oDefaultModel.setProperty("/CurrentQrSerialQty", iQrQty);
						that.oDefaultModel.refresh(true);
					}
				}.bind(this),
				error: function(oError) {
					this._showResponseErrMsg(oError);
				}.bind(this)
			});
		},

		checkScannedItemData: function(sValue) {
			var that = this;
			this._oODataModel.read("/CheckScannedQrSet('" + sValue + "')", {
				success: function(oData) {
					that.oDefaultModel.setProperty("/QrSerial", oData);
					that.AppendQrToMc(sValue);
				}.bind(this),
				error: function(oError) {
					this._showResponseErrMsg(oError);
				}.bind(this)
			});
		},

		onCancelMc: function(oEvent) {
			var oButton = oEvent.getSource(),
				oView = this.getView();
			if (!this.cancelPopover) {
				this.cancelPopover = sap.ui.xmlfragment(oView.getId(), "com.greenbyte.zmm_mc_box.fragments.McCancelPopover", this);
				oView.addDependent(this.cancelPopover);
			}
			this.cancelPopover.openBy(oButton);
		},

		onDiscardChanges: function() {
			this.cancelPopover.close();
			this.initializeMcData();
		},

		onAttachDetachChange: function(oEvent) {
			var sSelectedKey = oEvent.getSource().getSelectedKey();
			var sText = sSelectedKey === "01" ? 'Pack' : 'Unpack';
			this.oAttachCnfrmDialog = new sap.m.Dialog({
				type: "Message",
				title: "Confirmation",
				content: new sap.m.Text({
					text: "Do you want to switch to " + sText + "?"
				}),
				beginButton: new Button({
					type: "Emphasized",
					text: "Submit",
					press: function() {
						this.oAttachCnfrmDialog.close();
						this.filterMcList(sSelectedKey);
					}.bind(this)
				}),
				endButton: new Button({
					text: "Cancel",
					press: function() {
						this.oDefaultModel.setProperty("/AttachDetachKey", sSelectedKey === "01" ? "02" : "01");
						this.oAttachCnfrmDialog.close();
					}.bind(this)
				})
			});
			this.oAttachCnfrmDialog.open();
		},

		filterMcList: function(sSelectedKey) {
			var oList = this.byId("idMcList");
			var aFilters = [];
			aFilters.push(new sap.ui.model.Filter({
				path: "DeleteFlag",
				operator: "EQ",
				value1: sSelectedKey === "01" ? "" : "X"
			}));
			oList.getBinding("items").filter(aFilters);
		},

		initializeMcData: function() {
			this.oDefaultModel.setProperty("/MasterCartonItems", []);
			this.oDefaultModel.setProperty("/IsMcScanned", false);
			this.oDefaultModel.setProperty("/SearchQuery", "");
			this.oDefaultModel.setProperty("/AttachDetachKey", "01");
			this.oDefaultModel.setProperty("/DetachCount", 0);
			this.oDefaultModel.setProperty("/TotalItemQty", 0);
			this.oDefaultModel.setProperty("/BaseQuantity", 0);
			this.oDefaultModel.setProperty("/CatCode", "");
			this.oDefaultModel.setProperty("/isSaveEnabled", "");
			this.filterMcList("01");
		},

		_showDialog: function(sTitle, sText) {
			var that = this;
			var oDialog = new sap.m.Dialog({
				title: sTitle,
				type: "Message",
				state: sTitle,
				content: new sap.m.Text({
					text: sText
				}),
				beginButton: new sap.m.Button({
					text: "OK",
					press: function() {
						oDialog.close();
						if (sTitle === "Success") {
							that.initializeMcData();
						}
					}
				}),
				afterClose: function() {
					oDialog.destroy();
				}
			});

			oDialog.open();
		},

		_showResponseErrMsg: function(oError) {
			if (Formatter.isJSON(oError.responseText)) {
				this._showDialog("Error", JSON.parse(oError.responseText).error.message.value);
			} else {
				try {
					var oDOMParser = new DOMParser();
					var oXMLError = oDOMParser.parseFromString(oError.responseText, "application/xml");
					this._showDialog("Error", oXMLError.all[2].innerHTML);
				} catch (e) {
					this._showDialog("Error", e);
				}
			}
		},

	});
});