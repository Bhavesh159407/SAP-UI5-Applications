sap.ui.define([

], function() {
	"use strict";

	return {

		isJSON: function(sReponseTxt) {
			try {
				return (JSON.parse(sReponseTxt) && !!sReponseTxt);
			} catch (e) {
				return false;
			}
		},

		setMaterialTxt: function(sMaterial) {
			if (sMaterial) {
				sMaterial = sMaterial.replace(/^0+/, '');
				// sMaterial = parseInt(sMaterial, 10).toString();
				return sMaterial;
			}

		},

		setNoDataTxt: function(isScanned, sMaterial, sCatCode) {
			if (isScanned && sMaterial) {
				if (sCatCode) {
					return "Material: " + sMaterial + ", CatCode: " + sCatCode;
				} else {
					return "Material: " + sMaterial;
				}
			} else {
				return "No data";
			}

		},

		setPercentValue: function(itemCount, totalCount) {
			var percentage = itemCount / totalCount * 100;
			return percentage;
		}
	};
});