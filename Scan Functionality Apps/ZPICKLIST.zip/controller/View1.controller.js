sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/model/json/JSONModel",
	"sap/ndc/BarcodeScanner",
	"sap/ui/core/format/DateFormat"
], function(Controller, ODataModel, JSONModel, BarcodeScanner, DateFormat) {
	"use strict";
	var oDataModel, materialList, aObdItems, savedNpOnDelivery;

	return Controller.extend("com.ZPLZPicklist.controller.View1", {
		onInit: function() {
			var serviceUrl = "/sap/opu/odata/sap/ZWM_PROCESS_SRV";
			oDataModel = new ODataModel(serviceUrl, {
				useBatch: false
			});
			this.getView().setModel(oDataModel, "odataModel");
			this.inputDataModel = new JSONModel({
				currentPageData: [],
				currentPage: 1,
				hasPreviousPage: false,
				hasNextPage: true
			});
			this.getView().setModel(this.inputDataModel, "inputDataModel");

			var oViewModel = new sap.ui.model.json.JSONModel({
				SelectedObdItems: [] // Empty array initially
			});

			this.getView().setModel(oViewModel, "viewModel");

			var tableDataModel = new JSONModel({
				tableData: [] // Start with an empty table data array
			});
			this.getView().setModel(tableDataModel, "tableDataModel");

			// this._loadedRecords = 0; // Track number of records loaded

			this.loadOBDData(1);

		},
		onCloseDialog1: function() {
			if (this._oDialog) {
				this._oDialog.close();
			}
		},

		onOpenObdDetails: function() {
			var oView = this.getView();
			var oViewModel = oView.getModel("viewModel");

			if (!oViewModel) {
				sap.m.MessageToast.show("No OBD details available.");
				return;
			}

			// Load Fragment if not already loaded
			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment(oView.getId(), "com.ZPLZPicklist.Fragments.ObdDetailsFragment", this);
				oView.addDependent(this._oDialog);
			}

			// Open Dialog
			this._oDialog.open();
		},

		onInputChange: function(oEvent) {
			const billingInput = this.byId("billingInput");
			var sValue = oEvent.getParameter("value").trim();
			// console.log("code", code );
			if (sValue) {
				try {
					var qrData = JSON.parse(sValue);
					// Clear the input field after handling the data
					if (billingInput) {
						billingInput.setValue("");
					}
					this.processScannedData(sValue);

				} catch (e) {
					// console.log(e);
				}
			}

		},
		formatDate: function(sDate) {
			if (!sDate) return "";
			var oDateFormat = DateFormat.getDateInstance({
				pattern: "dd/MM/yyyy" // Adjust format if needed
			});
			return oDateFormat.format(new Date(sDate));
		},

		formatTime: function(oTime) {
			if (!oTime || typeof oTime !== "object" || !oTime.ms) {
				return ""; // Handle null, undefined, or unexpected format
			}

			// Convert milliseconds to time (SAP stores time as milliseconds from 00:00:00)
			var oDate = new Date(oTime.ms);

			var hours = String(oDate.getUTCHours()).padStart(2, "0"); // Get hours
			var minutes = String(oDate.getUTCMinutes()).padStart(2, "0"); // Get minutes
			var seconds = String(oDate.getUTCSeconds()).padStart(2, "0"); // Get seconds

			return hours + ":" + minutes + ":" + seconds; // Format as HH:MM:SS
		},
		onClearSearch: function() {
			alert("input cleared")
		},

		//SOC NIGAM
		onLiveSearch: function(oEvent) {
			// var sQuery = oEvent.getParameter("newValue").toLowerCase();
			var sQuery = oEvent.getSource().getValue();

			//if sQuery=== undefined or null
			if (!sQuery) {
				var curr_page = this.getView().getModel("inputDataModel").getProperty("/currentPage");
				this.loadOBDData(curr_page);

			}
			//if sQuery exist
			else {
				//Creating filter for get call
				var oFilter = new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.EQ, sQuery);
				oDataModel.read("/ZshLikpSet", {
					filters: [oFilter],
					success: function(oData, response) {
						// Update the model with filtered data
						this.getView().getModel("inputDataModel").setProperty("/currentPageData", oData.results);
						this.getView().getModel("inputDataModel").refresh();
					}.bind(this),
					error: function(oError) {
						console.error("filter-Error:", oError);
					}
				});
			}

		},
		//EOC NIGAM

		onItemSelect: function(oEvent) {
			var oSelectedItem = oEvent.getParameter("listItem");
			var oList = this.getView().byId("deliveryItemList");

			if (!oSelectedItem) {
				return;
			}

			var oContext = oSelectedItem.getBindingContext("inputDataModel");

			if (oContext) {
				var oData = oContext.getObject();

				var sObdNumber = oData.Vbeln; // Selected OBD Number

				// Set OBD Number in the Input Field
				this.getView().byId("ObdField").setValue(sObdNumber);

				// get the Named OData Model
				var oModel = this.getView().getModel("odataModel");
				var that = this;

				if (!oModel) {
					sap.m.MessageToast.show("OData Model is not available!");
					return;
				}

				// fetch Data from OData Entity Set (Filtered by Vbeln)
				oModel.read("/obdItemSet", {
					filters: [new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.EQ, sObdNumber)],
					success: function(oData) {
						aObdItems = oData.results;

						//storing copy of aObdItems
						var fTotalQty = aObdItems.reduce((sum, item) => sum + parseFloat(item.Lfimg || 0), 0);

						that.getView().byId("TotalQtyField").setText(fTotalQty.toFixed(3));
						that.getView().byId("totalMat").setText(aObdItems.length);

						that.getView().getModel("viewModel").setProperty("/SelectedObdItems", aObdItems);
					},
					error: function(oError) {
						sap.m.MessageToast.show("Failed to fetch OBD details.");
					}
				});

				//SOC NIGAM
				//Fetching saved lineItem for the selected OBD(if any)
				var sPath = "/PickListOrderSet(Vbeln='" + sObdNumber + "')?$expand=NP_ON_DELIVERY";

				oModel.read(sPath, {
					urlParameters: {
						"$expand": "NP_ON_DELIVERY"
					},
					success: function(oData, response) {
						console.log("Expanded NP_ON_DELIVERY against selected OBD:", oData.NP_ON_DELIVERY.results);
						savedNpOnDelivery = oData.NP_ON_DELIVERY.results;
						//adding already saved data to view
						var totalSavedQty = 0;
						if (savedNpOnDelivery) {
							// Adding SNo
							savedNpOnDelivery.forEach((item, index) => {
								item.SNo = index + 1;
								item.isSaved = 'Y';
								totalSavedQty += item.Quantity;
							});
							var oTable = this.getView().byId("TableId");
							var oTableModel = oTable.getModel("tableDataModel");
							if (oTableModel) {
								oTableModel.setProperty("/tableData", savedNpOnDelivery);
								oTableModel.refresh();
							}

							setTimeout(cb => {
								// /Soc changes by Bhavesh
								var tableData = this.getView().getModel("tableDataModel").getData().tableData || [];
								var cumulativeSum = tableData.reduce(function(acc, curr) {
									var material = curr.Material;
									if (!acc[material]) {
										acc[material] = 0;
									}
									acc[material] += curr.Quantity;
									return acc;
								}, {});

								var X = true;

								for (const obd of aObdItems) {
									var mat = obd.Matnr;
									if (cumulativeSum[mat] && cumulativeSum[mat] == obd.Nsolm) {
										X = true;
									} else {
										X = false;
										break;
									}
								}

								console.log("nigamFetch", X);
								console.log("123", cumulativeSum);

								if (X) {
									this.getView().byId("idSubmitButton").setVisible(true);
								} else {
									this.getView().byId("idSubmitButton").setVisible(false);
								}
								//Eoc changes by Bhavesh
							}, 500);

						}
						//Enabling save button if table is not empty or saved data retrived against OBD.
						if (savedNpOnDelivery.length >= 1) {
							that.getView().byId("idSaveButton").setEnabled(true);
						}

						//updating aObdItems and materialList and updating binding in view
						// savedNpOnDelivery.forEach(savedItem => {
						// 	const matchingItem = aObdItems.find(obdItem => obdItem.Matnr === savedItem.Material);

						// 	if (matchingItem) {
						// 		matchingItem.Lfimg -= savedItem.Quantity; //subtracting saved quantity;
						// 	}
						// });

						// materialList = JSON.parse(JSON.stringify(aObdItems));
						// var fTotalQty = aObdItems.reduce((sum, item) => sum + parseFloat(item.Lfimg || 0), 0);

						// this.getView().byId("TotalQtyField").setText(fTotalQty.toFixed(3));

						// this.getView().getModel("viewModel").setProperty("/SelectedObdItems", aObdItems);

					}.bind(this),
					error: function(oError) {
						console.error("Error fetching saved NP_ON_DELIVERY :", oError);
					}
				});
				//EOC NIGAM

				// Enable Fields
				this.getView().byId("ObdField").setEnabled(true);
				this.getView().byId("scanQrButton").setEnabled(true);
				this.getView().byId("billingInput").setEnabled(true);

				// Focus Billing Input after delay
				setTimeout(() => {
					this.getView().byId("billingInput").focus();
				}, 500);
			}

			// Deselect item
			oList.removeSelections(true);
			// var oTable = this.getView().byId("TableId");
			// var oTableModel = oTable.getModel("tableDataModel");
			// if (oTableModel) {
			// 	oTableModel.setProperty("/tableData", []);
			// 	oTableModel.refresh();
			// }

			// Close the dialog after selection
			this.onCloseDialog();
		},
		loadOBDData: function(iPage) {
			var oDataModel = this.getView().getModel("odataModel");

			if (!oDataModel) {
				console.error("Error: OData Model is not initialized!");
				return;
			}

			var inputDataModel = this.getView().getModel("inputDataModel");
			var iPageSize = 100; // Number of items per page
			var iSkip = (iPage - 1) * iPageSize; // Skip records for pagination

			console.log("Fetching data for page:", iPage, "Skip:", iSkip);

			oDataModel.read("/ZshLikpSet", {
				urlParameters: {
					"$top": iPageSize,
					"$skip": iSkip
				},
				success: function(oData) {
					var newData = oData.results || [];

					inputDataModel.setProperty("/currentPageData", newData);
					inputDataModel.setProperty("/currentPage", iPage);
					inputDataModel.setProperty("/hasPreviousPage", iPage > 1);
					inputDataModel.setProperty("/hasNextPage", newData.length === iPageSize); // If less than page size, no more pages
					inputDataModel.refresh(true);

					console.log("Data loaded successfully for page", iPage);
				}.bind(this),
				error: function(oError) {
					console.error("Error fetching data:", oError);
				}
			});
		},

		onNextPage: function() {
			var currentPage = this.getView().getModel("inputDataModel").getProperty("/currentPage");
			this.loadOBDData(currentPage + 1);
		},

		onPreviousPage: function() {
			var currentPage = this.getView().getModel("inputDataModel").getProperty("/currentPage");
			if (currentPage > 1) {
				this.loadOBDData(currentPage - 1);
			}
		},
		onOBDHelp: function() {
			if (!this.dialogBegin) {
				this.dialogBegin = sap.ui.xmlfragment(this.getView().getId(), "com.ZPLZPicklist.Fragments.OBDNumber", this);
				this.getView().addDependent(this.dialogBegin);
			}
			this.dialogBegin.open();
		},

		onCloseDialog: function() {
			if (this.dialogBegin) {
				this.dialogBegin.close();
			}
		},

		processScannedData: function(QRdata) {
			var that = this;
			var oDataModel = that.getView().getModel("odataModel");
			var obdQtyText = that.getView().byId("TotalQtyField").getText();
			var obdNum = that.getView().byId("ObdField").getValue();
			var obdQty = parseInt(obdQtyText.split(" / ")[0], 10);
			// var selectedObdMaterial = this.getView().byId("field1").getValue();
			var totalQty = 0;
			var tableData = that.getView().getModel("tableDataModel").getData().tableData || [];

			if (!QRdata) {
				console.error("Serial code is missing.");
				return;
			}
			var sSerialNumber;
			if (typeof QRdata === "string") {
				try {
					sSerialNumber = JSON.parse(QRdata);
				} catch (e) {
					console.log("error in parsing", e);
					sap.m.MessageToast.show("Invalid JSON format in scanned data.");
					that.getView().byId("billingInput").setValue("");
					setTimeout(() => {
						that.getView().byId("billingInput").focus();
					}, 100);
					return;
				}
			}
			//extracting qr code from json.
			var code = sSerialNumber.Serial_Number;

			//fetching data from oData using retrived qr.
			oDataModel.read("/SerialCodesSet('" + code + "')", {
				success: function(oData) {
					var foundItem = aObdItems.find(e => e.Matnr === oData.Material);

					//if material not found in OBD material list.
					if (!foundItem) {
						sap.m.MessageBox.information("Material not found in OBD material list.", {
							onClose: function() {
								that.getView().byId("billingInput").setValue("");
								setTimeout(() => {
									that.getView().byId("billingInput").focus();
								}, 500);
							}
						});
						return;
					}

					// Check if serial label is rejected
					if (oData.Label_Rejected === "X") {

						sap.m.MessageBox.information("Label Is Rejected.", {
							onClose: function() {
								that.getView().byId("billingInput").setValue("");
								setTimeout(() => {
									that.getView().byId("billingInput").focus();
								}, 500);
							}
						});
						return;
					}

					if (oData.Palette_Number === '') {
						sap.m.MessageBox.information("Not Assigned To Any Palette", {
							onClose: function() {
								that.getView().byId("billingInput").setValue("");
								setTimeout(() => {
									that.getView().byId("billingInput").focus();
								}, 500);
							}
						});
						return;
					}

					if (oData.Vbeln !== '') {
						sap.m.MessageBox.information(`Already Assigned To OutBound Delivery: ${oData.Vbeln} `, {
							onClose: function() {
								that.getView().byId("billingInput").setValue("");
								setTimeout(() => {
									that.getView().byId("billingInput").focus();
								}, 500);
							}
						});
						return;
					}

					if (oData.Zmblnr === '') {
						sap.m.MessageBox.information("Does not contain any GRN", {
							onClose: function() {
								that.getView().byId("billingInput").setValue("");
								setTimeout(() => {
									that.getView().byId("billingInput").focus();
								}, 500);
							}
						});
						return;
					}

					// Check if the serial number is already scanned
					var isDuplicate = tableData.some(function(item) {
						return item.Serial_Number === oData.Serial_Number;
					});

					if (isDuplicate) {
						sap.m.MessageBox.information("Material Is Already Scanned.", {
							onClose: function() {
								setTimeout(() => {
									that.getView().byId("billingInput").focus();
								}, 500);
							}
						});
						that.getView().byId("billingInput").setValue("");
						return;
					}

					//Allowed case
					// if (foundItem) {
					// 	var flag = 0;
					// 	//checking and updating quantity in materialList's lfimg 
					// 	materialList.forEach(mat => {
					// 		if ((mat.Matnr === oData.Material) && (mat.Lfimg - oData.Quantity >= 0)) {
					// 			mat.Lfimg = mat.Lfimg - oData.Quantity;
					// 		} else if ((mat.Matnr === oData.Material) && (mat.Lfimg - oData.Quantity < 0)) {
					// 			flag = 1;
					// 			sap.m.MessageBox.information("Scanned Quantity Exceeds Available Material Quantity.", {
					// 				onClose: function() {
					// 					that.getView().byId("billingInput").setValue("");
					// 					setTimeout(() => {
					// 						that.getView().byId("billingInput").focus();
					// 					}, 500);

					// 				}
					// 			});
					// 			return;
					// 		}

					// 	});

					// 	var foundItem2 = materialList.find(e => e.Matnr === oData.Material);
					// 	console.log("foundItem updated after add", foundItem2)
					// 	if (flag === 1) {
					// 		flag = 0;
					// 		return;
					// 	}

					// }
					console.log("yytt", foundItem);
					//Allowed case- New
					if (foundItem) {
						// Grouping by material and calculate the cumulative quantity sum
						var cumulativeSum = tableData.reduce(function(acc, curr) {
							var material = curr.Material;
							if (!acc[material]) {
								acc[material] = 0;
							}
							acc[material] += curr.Quantity;
							return acc;
						}, {});
						var incoming_material = oData.Material;
						var newQuantity = cumulativeSum[incoming_material] + oData.Quantity;
						console.log("Cumulative sum", cumulativeSum);
						console.log("incoming material", oData.Material, " sum--", cumulativeSum[incoming_material] + oData.Quantity)
							//if newQuantity of material<=saleorderQuantity of that material then allow or block
						var flag = 0;
						//checking and updating quantity in aObdItems's Kwmeng
						aObdItems.forEach(item => {
							if ((item.Matnr === incoming_material) && (newQuantity <= item.Nsolm)) {

							} else if ((item.Matnr === incoming_material) && (newQuantity > item.Nsolm)) {
								flag = 1;
								sap.m.MessageBox.information("Scanned Quantity Exceeds Picked Quantity.", {
									onClose: function() {
										that.getView().byId("billingInput").setValue("");
										setTimeout(() => {
											that.getView().byId("billingInput").focus();
										}, 500);

									}
								});
								return;
							}

						});
						if (flag === 1) {
							flag = 0;
							return;
						}
					}

					//updating totalQty
					tableData.forEach(e => {
							totalQty = totalQty + parseInt(e.Quantity);
						})
						//Soc changes by Bhavesh
						// var X = true;
						// for (const obd of aObdItems) {
						// 	var mat = obd.Matnr;
						// 	if (!cumulativeSum[mat] || cumulativeSum[mat] + oData.Quantity < obd.Lfimg) {
						// 		X = false; // If even one material is below required qty, keep disabled
						// 		break;
						// 	}
						// }

					//Eoc changes by bhavesh

					// if (totalQty + oData.Quantity >= obdQty) {
					// 	that.getView().byId("idSubmitButton").setVisible(true);
					// } else {
					// 	that.getView().byId("idSubmitButton").setVisible(false);
					// }

					// Add scanned material to the table
					tableData.push({
						SNo: tableData.length + 1,
						Client_Code: oData.Client_Code,
						Label_Rejected: oData.Label_Rejected,
						Machine_Code: oData.Machine_Code,
						Manufacturing_Date: oData.Manufacturing_Date,
						Material: oData.Material,
						Material_Description: oData.Material_Description,
						PSP_Name: oData.PSP_Name,
						PSP_Number: oData.PSP_Number,
						Palette_Number: oData.Palette_Number,
						Plant: oData.Plant,
						Plant_Code: oData.Plant_Code,
						Posnr: oData.Posnr,
						Quantity: oData.Quantity,
						Serial_Number: oData.Serial_Number,
						Shift_Code: oData.Shift_Code,
						Ship_To_Party: oData.Ship_To_Party,
						Vbeln: oData.Vbeln,
						Zmblnr: oData.Zmblnr,
						Zmjahr: oData.Zmjahr
					});

					// Update table model
					that.getView().getModel("tableDataModel").setData({
						tableData
					});
					that.getView().byId('idSaveButton').setEnabled(true);
					that.getView().byId('billingInput').setValue("");
					setTimeout(() => {
						that.getView().byId("billingInput").focus();
					}, 500);

					var serialcodeDataModel = new JSONModel(oData);
					that.getView().setModel(serialcodeDataModel, "serialcodeDataModel");

					//Adjusting Visibility of Submit Button SOC BY Bhavesh
					var tableData2 = that.getView().getModel("tableDataModel").getData().tableData || [];
					var cumulativeSum2 = tableData2.reduce(function(acc, curr) {
						var material = curr.Material;
						if (!acc[material]) {
							acc[material] = 0;
						}
						acc[material] += curr.Quantity;
						return acc;
					}, {});
					var X = true;
					for (const obd of aObdItems) {
						var mat = obd.Matnr;
						debugger;
						if (cumulativeSum2[mat] && cumulativeSum2[mat] == obd.Nsolm) {
							X = true;
						} else {
							X = false;
							break;
						}
					}
					console.log("newnigam", cumulativeSum2);
					console.log("nigam", X);
					if (X) {
						that.getView().byId("idSubmitButton").setVisible(true);
					} else {
						that.getView().byId("idSubmitButton").setVisible(false);
					}
					//Adjusting Visibility of Submit Button EOC BY Bhavesh
				},
				error: function(oError) {
					sap.m.MessageBox.error("Error fetching data.");
				}
			});
		},

		onScanPress: function() {
			var that = this;
			sap.ndc.BarcodeScanner.scan(
				function(oResult) {
					var qrCode = oResult.text;
					var qcode = JSON.parse(qrCode);
					var code = qcode.Serial_Number;

					if (!code) {
						sap.m.MessageToast.show("No QR Code detected.");
						return;
					}

					// that.byId("billingInput").setValue(code);
					that.processScannedData(qrCode);
				},
				function(oError) {
					sap.m.MessageToast.show("Scan failed: " + oError, {
						duration: 1000
					});
					that.byId("billingInput").setValue("");
				}
			);
		},

		onDeleteRow: async function(oEvent) {
			// var oTable = this.getView().byId("itemTable");
			var oItem = oEvent.getSource().getParent();
			var obdNumber = this.getView().byId("ObdField").getValue();
			var oBindingContext = oItem.getBindingContext("tableDataModel");
			var bindedLineData = oBindingContext.getObject();

			// If no binding context is found, exit the function
			if (!oBindingContext) {
				console.error("No binding context found");
				return;
			}

			//Removing data from TabledataModel
			var sPath = oBindingContext.getPath();
			var aTableData = this.getView().getModel("tableDataModel").getProperty("/tableData");

			var index = aTableData.findIndex(function(item, idx) {
				return sPath === "/tableData/" + idx;
			});

			if (index !== -1) {
				aTableData.splice(index, 1);
			}

			this.getView().getModel("tableDataModel").setData({
				tableData: aTableData
			});

			var oTable = this.getView().byId("TableId");
			// this.onOBDQtyChange();

			oTable.getModel("tableDataModel").refresh();

			//SOC NIGAM
			var lineItemData = [{
				Serial_Number: bindedLineData.Serial_Number
			}]
			var payload = {
				Vbeln: obdNumber,
				ZfuncCode: "01",
				NP_ON_DELIVERY: lineItemData
			};

			// Perform OData Create (POST) Call for delete
			await oDataModel.create("/PickListOrderSet", payload, {
				success: function(oData) {
					sap.m.MessageBox.information("Item Deleted Successfully!", {

					});
				},
				error: function(oError) {
					console.error("Error in delete OData call:", oError);
					sap.m.MessageToast.show("Failed to delete item.");
				}
			});

			//get cumulative 

			//adjusting submit button visibility
			var totalQty = 0;
			var tableData = this.getView().getModel("tableDataModel").getData().tableData || [];
			var obdQtyText = this.getView().byId("TotalQtyField").getText();
			var obdQty = parseInt(obdQtyText.split(" / ")[0], 10);
			tableData.forEach(e => {
				totalQty = totalQty + parseInt(e.Quantity);
			})

			//Soc changes by Bhavesh

			var cumulativeSum = tableData.reduce(function(acc, curr) {
				var material = curr.Material;
				if (!acc[material]) {
					acc[material] = 0;
				}
				acc[material] += curr.Quantity;
				return acc;
			}, {});
			var X = true;
			for (const obd of aObdItems) {
				var mat = obd.Matnr;
				if (!cumulativeSum[mat] || cumulativeSum[mat] !== obd.Nsolm) {
					X = false; // If even one material is below required qty, keep disabled
					break;
				}
			}
			console.log("nigamdelete", X);
			if (X) {
				this.getView().byId("idSubmitButton").setVisible(true);
			} else {
				this.getView().byId("idSubmitButton").setVisible(false);
			}
			//Eoc changes by bhavesh
			// if (totalQty >= obdQty) {
			// 	this.getView().byId("idSubmitButton").setVisible(true);
			// } else {
			// 	this.getView().byId("idSubmitButton").setVisible(false);
			// }
			//EOC NIGAM
			setTimeout(() => {
				this.getView().byId("billingInput").focus();
			}, 500);

		},
		onOBDQtyChange: function() {
			var oTable = this.getView().byId("TableId");
			var aItems = oTable.getItems();
			var totalQuantity = 0;

			// Loop through table items to calculate total quantity
			aItems.forEach(function(oItem) {
				var oContext = oItem.getBindingContext("tableDataModel");
				var quantity = oContext.getProperty("Quantity");
				totalQuantity += parseFloat(quantity) || 0;
			});

			// Get the OBD Quantity
			var obdQuantity = parseFloat(this.getView().byId("TotalQtyField").getText()) || 0;

			// Check if both are equal
			var submitButton = this.getView().byId("idSubmitButton");
			if (totalQuantity === obdQuantity) {
				submitButton.setVisible(true);
			} else {
				submitButton.setVisible(false);
			}
		},

		onAddRow: function() {
			// Your existing logic for adding a row
			this.onQuantityCheck(); // Call the check function
		},

		// onDeleteRow: function(oEvent) {
		// 	// Your existing logic for deleting a row
		// 	this.onQuantityCheck(); // Call the check function
		// },

		// onOBDQtyChange: function(oEvent) {
		// 	this.onQuantityCheck(); // Call when OBD-Qty is updated
		// },

		onSavePress: function() {
			var that = this;
			var obdNumber = this.getView().byId("ObdField").getValue();

			var oTable = this.getView().byId("TableId");

			//...
			var tableLineItems = oTable.getModel("tableDataModel").getProperty("/tableData") || [];

			if (tableLineItems.length === 0) {
				sap.m.MessageToast.show("No items in the table to save.");
				return; // Stop execution
			}

			var aLineItems = tableLineItems
				.map(({
					Label_Rejected,
					Zmblnr,
					Palette_Number,
					Zmjahr,
					PSP_Number,
					Vbeln,
					Posnr,
					PSP_Name,
					Serial_Number,
					Shift_Code,
					Machine_Code
				}) => ({
					Label_Rejected,
					Zmblnr,
					Palette_Number,
					Zmjahr,
					PSP_Number,
					Vbeln,
					Posnr,
					PSP_Name,
					Serial_Number,
					Shift_Code,
					Machine_Code
				}));

			var payload = {
				Vbeln: obdNumber,
				ZfuncCode: "02",
				NP_ON_DELIVERY: aLineItems
			};

			oDataModel.create("/PickListOrderSet", payload, {
				success: function(oData) {
					if (oData.Zmessage && oData.Zmessage.trim() !== "") {
						// If Zmessage contains a message, show it in a MessageBox
						sap.m.MessageBox.information(oData.Zmessage, {
							onClose: function() {}
						});

					} else {
						// If no Zmessage, proceed as usual
						sap.m.MessageToast.show("OBD saved successfully!");

						// fetch updated obdItemSet Data from OData Entity Set (Filtered by Vbeln)
						var sObdNumber = this.getView().byId("ObdField").getValue();
						setTimeout(() => {
							oDataModel.read("/obdItemSet", {
								filters: [new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.EQ, sObdNumber)],
								success: function(oData) {
									aObdItems = oData.results;
									var fTotalQty = aObdItems.reduce((sum, item) => sum + parseFloat(item.Lfimg || 0), 0);
									this.getView().byId("TotalQtyField").setText(fTotalQty.toFixed(3));
									this.getView().byId("totalMat").setText(aObdItems.length);
									this.getView().getModel("viewModel").setProperty("/SelectedObdItems", aObdItems);
									this.getView().getModel("viewModel").refresh();
									//Soc changes by Bhavesh
									var tableData = this.getView().getModel("tableDataModel").getData().tableData || [];
									var cumulativeSum = tableData.reduce(function(acc, curr) {
										var material = curr.Material;
										if (!acc[material]) {
											acc[material] = 0;
										}
										acc[material] += curr.Quantity;
										return acc;
									}, {});
									var X = true;
									for (const obd of aObdItems) {
										var mat = obd.Matnr;
										if (cumulativeSum[mat] && cumulativeSum[mat] == obd.Nsolm) {
											X = true;
										} else {
											X = false;
											break;
										}
									}
									console.log("nigamsave", X);
									if (X) {
										this.getView().byId("idSubmitButton").setVisible(true);
									} else {
										this.getView().byId("idSubmitButton").setVisible(false);
									}
									//Eoc changes by bhavesh
								}.bind(this),
								error: function(oError) {
									sap.m.MessageToast.show("Failed to fetch updated OBD details.");
								}
							});
						}, 1000);

						//alternate approach...
						//get cumulative sum of materials present in view (table)
						//replace Lfimg of aObdItems with cumulative sum and bind it to view
						//updating aObdItems and updating binding in view

					}
				}.bind(this),
				error: function(oError) {
					console.error("Error in OData call:", oError);
					sap.m.MessageToast.show("Failed to save OBD.");
				}
			});
		},

		onSubmitPress: function() {
			var that = this;
			var obdNumber = this.getView().byId("ObdField").getValue();

			var oTable = this.getView().byId("TableId");
			var tableLineItems = oTable.getModel("tableDataModel").getProperty("/tableData") || [];

			if (tableLineItems.length === 0) {
				sap.m.MessageToast.show("No items in the table to Submit.");
				return; // Stop execution
			}

			var aLineItems = tableLineItems.map(({
				Label_Rejected,
				Zmblnr,
				Palette_Number,
				Zmjahr,
				PSP_Number,
				Vbeln,
				Posnr,
				PSP_Name,
				Serial_Number,
				Shift_Code,
				Machine_Code
			}) => ({
				Label_Rejected,
				Zmblnr,
				Palette_Number,
				Zmjahr,
				PSP_Number,
				Vbeln,
				Posnr,
				PSP_Name,
				Serial_Number,
				Shift_Code,
				Machine_Code
			}));

			var oPayload = {
				"Vbeln": obdNumber,
				"ZfuncCode": "03",
				"NP_ON_DELIVERY": aLineItems
			};

			oDataModel.create("/PickListOrderSet", oPayload, {
				method: "POST",
				success: function(oData, response) {
					if (oData.Zmessage) {
						sap.m.MessageBox.information(oData.Zmessage, {
							onClose: function() {
								// that._clearFormFields();
								// that.getView().byId("TotalQtyField").setText("0.000");
								// that.getView().getModel("viewModel").setProperty("/SelectedObdItems", []);
							}
						});
					} else {
						sap.m.MessageBox.information("OBD Submitted Successfully!!", {
							onClose: function() {
								that._clearFormFields();
								that.getView().byId("TotalQtyField").setText("0.000");
								that.getView().getModel("viewModel").setProperty("/SelectedObdItems", []);

							}
						});
					}

				},
				error: function(oError) {
					sap.m.MessageToast.show("Failed to save OBD.", {
						onClose: function() {
							that._clearFormFields();
						}
					});
					console.error("Error:", oError);
				}
			});
		},

		_clearFormFields: function() {
			var oView = this.getView();
			var fieldIds = ["ObdField", "field1", "field2", "field4", "billingInput"];

			fieldIds.forEach(id => {
				var field = oView.byId(id);
				if (field) {
					field.setValue("");
				}
			});
			// Refresh table data
			var oTable = this.getView().byId("TableId");
			var oTableModel = oTable.getModel("tableDataModel");
			if (oTableModel) {
				oTableModel.setProperty("/tableData", []);
				oTableModel.refresh();
			}
			var billingInput = oView.byId("billingInput");
			var scanQrButton = oView.byId("scanQrButton");
			var obdField = oView.byId("ObdField");
			var submitButton = oView.byId("idSubmitButton");

			if (billingInput) billingInput.setEnabled(false);
			if (scanQrButton) scanQrButton.setEnabled(false);
			if (obdField) obdField.setEnabled(true);
			if (submitButton) submitButton.setVisible(false);
			this.getView().byId("totalMat").setText("0");
		}

	});
});