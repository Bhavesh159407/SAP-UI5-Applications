sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ndc/BarcodeScanner"
], function(Controller, MessageBox, ODataModel, BarcodeScanner) {
	"use strict";

	return Controller.extend("com.zeqsZEQS.controller.View1", {
		onInit: function() {
			var billingInput = this.byId("billingInput");
			if (billingInput) {
				billingInput.focus();
			}
			// Initialize OData Model
			var serviceUrl = "/sap/opu/odata/sap/ZWM_PROCESS_SRV";
			var oModel = new ODataModel(serviceUrl, {
				defaultBindingMode: sap.ui.model.BindingMode.TwoWay,
				useBatch: false
			});
			this.getView().setModel(oModel);

			// Initialize JSON Model for Table Data
			var oTableModel = new sap.ui.model.json.JSONModel({
				tableData: []
			});
			this.getView().setModel(oTableModel, "tableModel");

			// Attach hardware scan listener
			this._attachHardwareScanListener();

			// Attach route match for navigation
			// var oRouter = this.getOwnerComponent().getRouter();
			// oRouter.getRoute("view2").attachPatternMatched(this._onRouteMatched, this);
		},

		_onRouteMatched: function(oEvent) {
			var oArgs = oEvent.getParameter("arguments");
			var sPaletteNumber = oArgs.paletteNumber;

			if (sPaletteNumber) {
				this._bindPaletteData(sPaletteNumber);
			}
		},

		_bindPaletteData: function(sPaletteNumber) {
			var oModel = this.getView().getModel();
			var sPath = `/PaletteSet('${sPaletteNumber}')`;

			oModel.read(sPath, {
				success: function(oData) {
					var oViewModel = new sap.ui.model.json.JSONModel(oData);
					this.getView().setModel(oViewModel, "paletteModel");
				}.bind(this),
				error: function(oError) {
					MessageBox.error("Failed to fetch Palette data: " + oError.message);
				}
			});
		},

		onNavigateBack: function() {
			// Clear the table data when navigating back to view2
			const oTableModel = this.getView().getModel("tableModel");
			oTableModel.setProperty("/tableData", []); // Clears the table data

			this.getOwnerComponent().getRouter().navTo("view1");
		},

		_attachHardwareScanListener: function() {
			let scanBuffer = "";
			let scanTimeout;

			document.addEventListener(
				"keydown",
				function(event) {
					if (event.target.tagName === "INPUT") {
						return; // Skip if an input field is already focused
					}

					if (event.key !== "Enter") {
						scanBuffer += event.key;
						clearTimeout(scanTimeout);

						scanTimeout = setTimeout(() => {
							scanBuffer = ""; // Reset buffer after delay
						}, 200);
					} else if (scanBuffer) {
						const scannedValue = scanBuffer.trim();
						scanBuffer = ""; // Reset buffer

						if (scannedValue) {
							console.log("Scanned Data:", scannedValue);

							this.handleScannedData({
								mParameters: {
									text: scannedValue
								}
							});
						}
					}
				}.bind(this)
			);
		},

		onScanPress: function() {
			BarcodeScanner.scan(
				function(oResult) {
					if (oResult.text) {
						console.log("Scanned QR Code Value:", oResult.text);
						this.handleScannedData({
							mParameters: {
								text: oResult.text
							}
						});
					} else {
						MessageBox.error("No QR code detected.");
					}
				}.bind(this),
				function(oError) {
					MessageBox.error("Scan failed: " + oError.message);
				}
			);
		},

		onInputChange: function(oEvent) {
			var sValue = oEvent.getParameter("value").trim();
			const billingInput = this.byId("billingInput");
			if (!sValue) {
				MessageBox.error("Invalid input. Please scan again.");
				return;
			}

			console.log("Manually Entered or Scanned Value:", sValue);
			// Clear the input field after handling the data
			if (billingInput) {
				billingInput.setValue("");
			}
			this.handleScannedData({
				mParameters: {
					text: sValue
				}
			});
		},

		handleScannedData: function(oScanResult) {
			const sSerialNumber = oScanResult.mParameters.text;
			if (!sSerialNumber) {
				MessageBox.error("Invalid scan data.");
				this._setFocusOnBillingInput();
				return;
			}

			let oParsedData;
			try {
				oParsedData = JSON.parse(sSerialNumber); // Attempt to parse JSON
			} catch (error) {
				MessageBox.error("Scanned data is not in valid JSON format.");
				this._setFocusOnBillingInput();
				return;
			}

			const oModel = this.getView().getModel(); // OData model
			const oTableModel = this.getView().getModel("tableModel");
			const aTableData = oTableModel.getProperty("/tableData");

			// Check if the serial number is already in the local table data
			const existingItem = aTableData.find(item => item.Serial_Number === oParsedData.Serial_Number);
			if (existingItem) {
				MessageBox.information(`This material is already assigned to pallet: ${existingItem.Palette_Number}`, {
					onClose: () => this._setFocusOnBillingInput()
				});
				return;
			}

			// Check in the backend if the serial number already has an assigned pallet
			const sPath = `/SerialCodesSet('${oParsedData.Serial_Number}')`;

			oModel.read(sPath, {
				success: function(oData) {
					if (oData.Palette_Number) {
						MessageBox.information(`This material is already assigned to pallet: ${oData.Palette_Number}`, {
							onClose: () => this._setFocusOnBillingInput()
						});
					} else {
						// Fetch details and add a new line item if no pallet is assigned
						this.fetchDetailsFromOData(oParsedData.Serial_Number)
							.then(oDetail => {
								this.addLineItemToTable(oDetail);
								this._setFocusOnBillingInput();
							})
							.catch(oError => {
								MessageBox.error("Failed to fetch details: " + oError.message, {
									onClose: () => this._setFocusOnBillingInput()
								});
							});
					}
				}.bind(this),
				error: function(oError) {
					MessageBox.error("Error checking pallet assignment: " + oError.message, {
						onClose: () => this._setFocusOnBillingInput()
					});
				}.bind(this)
			});
		},

		_setFocusOnBillingInput: function() {
			setTimeout(() => {
				const billingInput = this.byId("billingInput");
				if (billingInput) {
					billingInput.focus();
				} else {
					console.warn("Billing input field not found. Ensure the control ID is correct.");
				}
			}, 10); // Slightly longer delay for consistent behavior
		},
		fetchDetailsFromOData: function(sSerialNumber) {
			const oTableModel = this.getView().getModel("tableModel");
			const aTableData = oTableModel.getProperty("/tableData");

			if (aTableData.some(item => item.Serial_Number === sSerialNumber)) {
				return Promise.resolve(aTableData.find(item => item.Serial_Number === sSerialNumber));
			}

			return new Promise((resolve, reject) => {
				const oDataModel = this.getView().getModel();
				const sPath = `/SerialCodesSet('${sSerialNumber}')`;

				oDataModel.read(sPath, {
					success: resolve,
					error: reject
				});
			});
		},

		addLineItemToTable: function(oDetail) {
			const oTableModel = this.getView().getModel("tableModel");
			const aTableData = oTableModel.getProperty("/tableData");
			aTableData.push(oDetail);
			oTableModel.setProperty("/tableData", aTableData);
			MessageBox.success("Item added successfully.");
		},

		onSubmitPress: function() {
			const oModel = this.getView().getModel();
			const oTableModel = this.getView().getModel("tableModel");
			const aScannedItems = oTableModel.getProperty("/tableData");

			if (!aScannedItems.length) {
				MessageBox.error("No items scanned. Cannot submit.");
				return;
			}

			// Use Palette_Number currently displayed in the view
			const sPaletteNumber = this.getView().getModel("paletteModel").getProperty("/Palette_Number");

			const oPayload = {
				Palette_Number: sPaletteNumber,
				NP_ON_PALETTE: {
					results: aScannedItems
				}
			};

			oModel.create("/PaletteSet", oPayload, {
				success: function() {
					MessageBox.success("Data submitted successfully.");
					this.onNavigateBack();
				}.bind(this),
				error: function(oError) {
					MessageBox.error("Submission failed: " + oError.message);
				}
			});
		}
	});
});