sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/m/MessageBox",
	"sap/ui/model/json/JSONModel",
	"sap/ndc/BarcodeScanner"
], function(Controller, ODataModel, MessageBox, JSONModel, BarcodeScanner) {
	"use strict";

	return Controller.extend("com.mrpqrcodeZ_MRPQRCode.controller.View1", {
		onInit: function() {
			var serviceUrl = "/sap/opu/odata/sap/ZSD_RFID_SRV";
			var oDataModel = new ODataModel(serviceUrl, {
				useBatch: false
			});
			this.getView().setModel(oDataModel, "odataModel");

			const oModel = new JSONModel({
				items: []
			});
			this.getView().setModel(oModel);
		},
		onAfterRendering: function() {
			setTimeout(() => {
				var initialScanInput = this.byId("initialScanInput");
				if (initialScanInput) {
					initialScanInput.focus();
				}

			}, 500)
		},

		onScanQRCode: function() {
			BarcodeScanner.scan(
				function(oResult) {
					if (!oResult.cancelled) {
						this._addScannedItem(oResult.text);
						this._clearInputField(); // Clear input after scan
					}
				}.bind(this),
				function(oError) {
					MessageBox.information("Scan failed: " + oError, {
						onClose: function() {
							this.byId("initialScanInput").focus();
						}.bind(this)
					});
				}
			);
		},

		onInitialScan: function(oEvent) {
			const sValue = oEvent.getParameter("value");
			if (sValue.length > 0) {
				this._addScannedItem(sValue);
				this._clearInputField(); // Clear input after manual entry
			}
		},

		_clearInputField: function() {
			const oInput = this.byId("initialScanInput");
			if (oInput) {
				oInput.setValue(""); // Clear input field
				setTimeout(() => {
					oInput.focus(); // Ensure input is focused again for next scan
				}, 100);
			}
		},

		_addScannedItem: function(sScannedCode) {
			const sParsedCode = sScannedCode.split("|")[0];
			const oModel = this.getView().getModel();
			const aItems = oModel.getProperty("/items");

			// Check for duplicate QR code
			const bDuplicateQR = aItems.some(item => item.PALD === sParsedCode);
			if (bDuplicateQR) {
				MessageBox.information("Pallet ID is already scanned", {
					onClose: function() {
						this.byId("initialScanInput").focus();
					}.bind(this)
				});
				return;
			}

			const iSerialNo = aItems.length + 1;
			const oNewItem = {
				SerialNo: iSerialNo,
				PALD: sParsedCode,
				RFID_NO: ""
			};

			aItems.push(oNewItem);
			oModel.setProperty("/items", aItems);

			setTimeout(() => {
				this._focusRFIDInput();
			}, 1000);
		},

		_focusRFIDInput: function() {
			const aItems = this.byId("itemsTable").getItems();
			if (aItems.length > 0) {
				const oLastItem = aItems[aItems.length - 1];
				const oRFIDInput = oLastItem.getCells()[2];
				if (oRFIDInput) {
					oRFIDInput.focus();
				}
			}
		},

		onItemScan: function(oEvent) {
			const sValue = oEvent.getParameter("value").substring(0, 24); // Restrict to 24 characters
			const oInput = oEvent.getSource();
			const oBindingContext = oInput.getBindingContext();

			if (sValue.length > 0) {
				const oModel = this.getView().getModel();
				const aItems = oModel.getProperty("/items");

				// Debug: Log the scanned value and existing items for comparison
				console.log("Scanned RFID:", sValue);
				console.log("Existing RFIDs:", aItems.filter(item => item.RFID_NO === sValue));

				// Check for duplicate RFID
				const bDuplicateRFID = aItems.filter(item => item.RFID_NO.trim() === sValue.trim());
				if (bDuplicateRFID.length > 1) {
					MessageBox.information("RFID is already scanned", {

						onClose: function() {
							oInput.setValue("")
							oInput.focus();
						}
					});
					return;
				}

				// Set the trimmed value (in case it exceeds 24 characters)
				oModel.setProperty(oBindingContext.getPath() + "/RFID_NO", sValue);

				MessageBox.information("RFID added: " + sValue, {
					onClose: function() {
						// Auto-focus on the QR code field
						this.byId("initialScanInput").focus();
					}.bind(this)
				});
			}
		},

		onSavePress: function() {
			const oModel = this.getView().getModel();
			const aItems = oModel.getProperty("/items");

			// Validation 1: Check if no items have been scanned
			if (aItems.length === 0) {
				MessageBox.information("Please Scan the Details", {
					onClose: function() {
						this.byId("initialScanInput").focus();
					}.bind(this)
				});
				return;
			}

			// Validation 2: Check if any RFID is empty
			const bEmptyRFID = aItems.some(item => !item.RFID_NO || item.RFID_NO.trim() === "");
			if (bEmptyRFID) {
				MessageBox.information("Please Scan RFID", {
					onClose: function() {
						this._focusRFIDInput();
					}.bind(this)
				});
				return;
			}

			const oODataModel = this.getView().getModel("odataModel");

			// Serialize all items into a single JSON string
			const aSerializedData = aItems.map(item => ({
				PALD: item.PALD.split("|")[0],
				RFID_NO: item.RFID_NO
			}));

			// Create a single payload with the serialized JSON string
			const oPayload = {
				rfid: JSON.stringify(aSerializedData)
			};

			// Store the context
			const that = this;

			// Make the create call to the backend
			oODataModel.create("/rf_idsSet", oPayload, {
				success: function() {
					MessageBox.information("All data saved successfully!", {
						onClose: function() {
							oModel.setProperty("/items", []);
							that.byId("initialScanInput").focus();
						}
					});
				},
				error: function(oError) {
					const sErrorMessage = JSON.parse(oError.responseText).error.message.value;
					MessageBox.information("Error during save: " + sErrorMessage, {
						onClose: function() {
							that.byId("initialScanInput").focus();
						}
					});
				}
			});
		},

		onDeleteRow: function(oEvent) {
			var oTable = this.getView().byId("itemsTable");
			var oItem = oEvent.getSource().getParent(); // Get the clicked row
			var oBinding = oTable.getBinding("items");
			var oModel = oBinding.getModel();
			var aItems = oModel.getProperty("/items");

			var iIndex = oTable.indexOfItem(oItem); // Get the row index
			if (iIndex !== -1) {
				aItems.splice(iIndex, 1); // Remove the item from the array
				oModel.setProperty("/items", aItems); // Update model
			}
		}

	});
});