sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ndc/BarcodeScanner",
	"sap/m/MessageToast",
	"sap/ui/core/format/DateFormat" // Import the DateFormat module
], function(Controller, JSONModel, ODataModel, BarcodeScanner, MessageToast, DateFormat) {
	"use strict";

	return Controller.extend("Zchemicalcontainerhistory.controller.View1", {
		onInit: function() {
			var oModel = new ODataModel("/sap/opu/odata/sap/ZWM_PROCESS_SRV/");
			this.getView().setModel(oModel);

			// Create a JSON model to store QR data
			var qrModel = new JSONModel({
				qrData: ""
			});
			this.getView().setModel(qrModel, "qrModel");
		},

		onScanPress: function() {

			this.getView().byId('historyTable').setVisible(false);
			if (BarcodeScanner) {
				BarcodeScanner.scan(
					function(oResult) {
						var qrData = oResult.text;
						this.handleQRCodeScan(qrData); // Call the helper function with scanned data
					}.bind(this),
					function(oError) {
						MessageToast.show("Scan failed: " + oError);
					}
				);
			} else {
				console.error("BarcodeScanner is not available");
			}
		},

		handleQRCodeScan: function(qrData) {
			this.byId("qrCode").setValue(qrData); // Set scanned value to the QR code input field

			var oDataModel = this.getView().getModel();
			oDataModel.read("/HeaderSet('" + qrData + "')", {
				success: function(oData) {
					this.processQRCodeData(oData, qrData); 
					// this.onPress();// Pass the data to process and handle UI updates
				}.bind(this),
				error: function(oError) {
					MessageToast.show("No data Found.");
				}
			});
		},

		processQRCodeData: function(oData, qrData) {
			// Format dates and times
			oData.RegisteredDate = this.formatDate(oData.RegisteredDate);
			oData.LastChangedDate = this.formatDate(oData.LastChangedDate);
			oData.RegisteredTime = this.formatTime(oData.RegisteredTime);
			oData.LastChangedTime = this.formatTime(oData.LastChangedTime);

			// Log the formatted data for debugging
			console.log("Retrieved Data:", oData);
			console.log("Registered Time:", oData.RegisteredTime);

			// Update the model with formatted data
			var oJsonModel = new JSONModel(oData);
			this.getView().setModel(oJsonModel, "qrModel");

			// Store QR data in the model
			this.getView().getModel("qrModel").setProperty("/qrData", qrData);

			// Update the UI fields with formatted values
			this.byId("RegisteredTime").setText(oJsonModel.getProperty("/RegisteredTime"));
			this.byId("LastChangedTime").setText(oJsonModel.getProperty("/LastChangedTime"));
		},

		onInputChange: function(oEvent) {
			this.getView().byId('historyTable').setVisible(false);
			var sValue = oEvent.getParameter("value").trim();
			const billingInput = this.byId("qrCode");

			// Check if the input is empty or invalid
			if (!sValue) {
				sap.m.MessageBox.error("Invalid input. Please scan again.");
				return;
			}

			console.log("Manually Entered or Scanned Value:", sValue);

			// Clear the billing input field after handling the data
			if (billingInput) {
				billingInput.setValue("");
			}

			// Process the input (either manual or scanned)
			this.handleQRCodeScan(sValue); // Call the helper function to handle the manual value
		},
		onPress: function() {
			var qrData = this.getView().byId("qrCode").getValue(); // Get QR data from input field

			if (!qrData) {
				MessageToast.show("Please scan a QR Code first.");
				return;
			}

			this.getView().byId("historyTable").setVisible(true);
			var oDataModel = this.getView().getModel();

			oDataModel.read(`/HistorySet?$filter=BarCode eq '${qrData}'`, {
				success: function(myoData) {

					// Filter the results based on the QR code
					var filteredData = myoData.results.filter(function(item) {
						return item.BarCode === qrData;
					});

					// Apply date and time formatting to each record
					filteredData.forEach(function(item) {
						// Apply the date formatter
						item.RegisteredDate = this.formatDate(item.RegisteredDate);
						item.LastChangedDate = this.formatDate(item.LastChangedDate);

						// Apply the time formatter
						item.RegisteredTime = this.formatTime(item.RegisteredTime);
						item.LastChangedTime = this.formatTime(item.LastChangedTime);
					}.bind(this));

					// Set the filtered data to the JSON model
					var oJsonModel = new JSONModel({
						results: filteredData
					});
					this.getView().setModel(oJsonModel, "filterqrModel");

					// Force UI Refresh
					this.getView().byId("historyTable").getModel("filterqrModel").refresh(true);
				}.bind(this),
				error: function(oError) {
					MessageToast.show("Error fetching history data.");
					console.error("OData Read Error:", oError);
				}
			});
		},

		// Formatter function to format Date separately
		formatDate: function(sDate) {
			if (!sDate) return "";
			var oDate = new Date(sDate); // Convert string to date object
			var oFormatter = DateFormat.getInstance({
				pattern: "dd MMM yyyy" // Only Date format (no time)
			});
			return oFormatter.format(oDate);
		},

		// Formatter function to format Time separately (milliseconds)
		formatTime: function(oTime) {
			if (!oTime || !oTime.ms) return "";

			// Convert the milliseconds into hours, minutes, and seconds
			var hours = Math.floor(oTime.ms / 3600000);
			var minutes = Math.floor((oTime.ms % 3600000) / 60000);
			var seconds = Math.floor((oTime.ms % 60000) / 1000);

			return (hours < 10 ? "0" + hours : hours) + ":" +
				(minutes < 10 ? "0" + minutes : minutes) + ":" +
				(seconds < 10 ? "0" + seconds : seconds);
		}
	});
});