sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/model/json/JSONModel",
	"sap/ndc/BarcodeScanner",
	"sap/ui/core/format/DateFormat",
	"sap/m/MessageBox",
	"sap/m/MessageToast"

], function(Controller, ODataModel, JSONModel, BarcodeScanner, DateFormat, MessageBox, MessageToast) {
	"use strict";
	var oDataModel, aObdItems, RfidFlag, PalletData, savedNpOnDelivery;
	return Controller.extend("ZDispatchOrder.controller.View1", {
		formatDate: function(sDate) {
			if (!sDate) return "";
			var oDateFormat = DateFormat.getDateInstance({
				pattern: "dd/MM/yyyy" // Adjust format if needed
			});
			return oDateFormat.format(new Date(sDate));
		},

		formatTime: function(oTime) {
			if (!oTime || typeof oTime !== "object" || !oTime.ms) {
				return ""; // Handle null, undefined, or unexpected format
			}

			// Convert milliseconds to time (SAP stores time as milliseconds from 00:00:00)
			var oDate = new Date(oTime.ms);

			var hours = String(oDate.getUTCHours()).padStart(2, "0"); // Get hours
			var minutes = String(oDate.getUTCMinutes()).padStart(2, "0"); // Get minutes
			var seconds = String(oDate.getUTCSeconds()).padStart(2, "0"); // Get seconds

			return hours + ":" + minutes + ":" + seconds; // Format as HH:MM:SS
		},
		onSearch2: function() {
			alert("changed");
		},
		onInit: function() {
			var serviceUrl = "/sap/opu/odata/sap/ZOBD_UPDATE_SRV";
			oDataModel = new ODataModel(serviceUrl, {
				useBatch: false
			});
			this.getView().setModel(oDataModel, "odataModel");
			this.inputDataModel = new JSONModel({
				currentPageData: [],
				currentPage: 1,
				hasPreviousPage: false,
				hasNextPage: true
			});
			this.getView().setModel(this.inputDataModel, "inputDataModel");

			var oViewModel = new sap.ui.model.json.JSONModel({
				SelectedObdItems: [] // Empty array initially
			});

			this.getView().setModel(oViewModel, "viewModel");

			var tableDataModel = new JSONModel({
				tableData: [] // Start with an empty table data array
			});
			this.getView().setModel(tableDataModel, "tableDataModel");

			// this._loadedRecords = 0; // Track number of records loaded
			if (!this.dialogBegin) {
				this.dialogBegin = sap.ui.xmlfragment(this.getView().getId(), "ZDispatchOrder.Fragments.OBDNumber", this);
				this.getView().addDependent(this.dialogBegin);
			}
			this.loadOBDData(1);
		},

		onOBDHelp: function() {
			if (!this.dialogBegin) {
				this.dialogBegin = sap.ui.xmlfragment(this.getView().getId(), "ZDispatchOrder.Fragments.OBDNumber", this);
				this.getView().addDependent(this.dialogBegin);
			}
			this.dialogBegin.open();
		},
		onCloseDialog: function() {
			if (this.dialogBegin) {
				this.dialogBegin.close();
			}
		},
		loadOBDData: function(iPage) {
			if (!oDataModel) {
				console.error("Error: OData Model is not initialized!");
				return;
			}

			var inputDataModel = this.getView().getModel("inputDataModel");
			var iPageSize = 100; // Number of items per page
			var iSkip = (iPage - 1) * iPageSize; // Skip records for pagination

			console.log("Fetching data for page:", iPage, "Skip:", iSkip);

			oDataModel.read("/ZshLikpSet", {
				urlParameters: {
					"$top": iPageSize,
					"$skip": iSkip
				},
				success: function(oData) {
					var newData = oData.results || [];

					inputDataModel.setProperty("/currentPageData", newData);
					inputDataModel.setProperty("/currentPage", iPage);
					inputDataModel.setProperty("/hasPreviousPage", iPage > 1);
					inputDataModel.setProperty("/hasNextPage", newData.length === iPageSize); // If less than page size, no more pages
					inputDataModel.refresh(true);

					console.log("Data loaded successfully for page", iPage);
				}.bind(this),
				error: function(oError) {
					console.error("Error fetching data:", oError);
				}
			});
		},
		onNextPage: function() {
			var currentPage = this.getView().getModel("inputDataModel").getProperty("/currentPage");
			this.loadOBDData(currentPage + 1);
		},

		onPreviousPage: function() {
			var currentPage = this.getView().getModel("inputDataModel").getProperty("/currentPage");
			if (currentPage > 1) {
				this.loadOBDData(currentPage - 1);
			}
		},
		onItemSelect: function(oEvent) {
			var oSelectedItem = oEvent.getParameter("listItem");
			var oList = this.getView().byId("deliveryItemList");
			if (!oSelectedItem) {
				return;
			}
			var oContext = oSelectedItem.getBindingContext("inputDataModel");
			if (oContext) {
				var oData = oContext.getObject();
				// get Selected OBD Number
				var sObdNumber = oData.Vbeln;
				// Set OBD Number in the Input Field
				this.getView().byId("ObdField").setValue(sObdNumber);

				if (!oDataModel) {
					sap.m.MessageToast.show("OData Model is not available!");
					return;
				}

				// fetch Data from OData Entity Set (Filtered by Vbeln)
				oDataModel.read("/ZOBD_ITEM_SETSSet", {
					filters: [new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.EQ, sObdNumber)],
					success: function(oData) {
						aObdItems = oData.results;
						var fTotalQty = aObdItems.reduce((sum, item) => sum + parseFloat(item.Lfimg || 0), 0);
						this.getView().byId("TotalQtyField").setText(fTotalQty.toFixed(3));
						this.getView().byId("totalMat").setText(aObdItems.length);
						this.getView().byId("RfidReq").setText(aObdItems[0].FlagYes || "-");
						this.getView().getModel("viewModel").setProperty("/SelectedObdItems", aObdItems);
						//if rfid Mandatory= Yes then show the rfid scan button.
						RfidFlag = aObdItems[0].FlagYes;
						if (RfidFlag === "Yes") {
							this.getView().byId("rfidHbox").setVisible(true);
						} else {
							this.getView().byId("rfidHbox").setVisible(false);
						}
					}.bind(this),
					error: function(oError) {
						sap.m.MessageToast.show("Failed to fetch OBD details.");
					}
				});

				//Fetching saved lineItem for the selected OBD(if any)
				var sPath = "/ZHEADER_PALLET_RFIDSet('" + sObdNumber + "')";

				oDataModel.read(sPath, {
					urlParameters: {
						"$expand": "NP_ON_DELIVERY"
					},
					success: function(oData, response) {
						console.log("Expanded NP_ON_DELIVERY against selected OBD:", oData.NP_ON_DELIVERY.results);
						savedNpOnDelivery = oData.NP_ON_DELIVERY.results;
						if (savedNpOnDelivery) {
							// Adding SNo
							savedNpOnDelivery.forEach((item, index) => {
								item.SNo = index + 1;
								item.isSaved = 'Y';

							});
							var oTable = this.getView().byId("TableId");
							var oTableModel = oTable.getModel("tableDataModel");
							if (oTableModel) {
								oTableModel.setProperty("/tableData", savedNpOnDelivery);
								oTableModel.refresh();
							}
							setTimeout(() => {
								this.addDataToTable();
							}, 500)
						}

					}.bind(this),
					error: function(oError) {
						console.error("Error fetching saved NP_ON_DELIVERY :", oError);
					}
				});

				//Enable Fields
				this.getView().byId("ObdField").setEnabled(true);
				this.getView().byId("scanQrButton").setEnabled(true);
				this.getView().byId("billingInput").setEnabled(true);

				// Focus Billing Input after delay
				setTimeout(() => {
					this.getView().byId("billingInput").focus();
				}, 500);
			}

			// Deselect item
			oList.removeSelections(true);
			this.onCloseDialog();
		},
		onSearch: function(oEvent) {
			// var sQuery = oEvent.getParameter("newValue").toLowerCase();
			var sQuery = oEvent.getSource().getValue();

			//if sQuery=== undefined or null
			if (!sQuery) {
				var curr_page = this.getView().getModel("inputDataModel").getProperty("/currentPage");
				this.loadOBDData(curr_page);

			}
			//if sQuery exist
			else {
				//Creating filter for get call
				var oFilter = new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.EQ, sQuery);
				oDataModel.read("/ZshLikpSet", {
					filters: [oFilter],
					success: function(oData, response) {
						// Update the model with filtered data
						this.getView().getModel("inputDataModel").setProperty("/currentPageData", oData.results);
						this.getView().getModel("inputDataModel").refresh();
					}.bind(this),
					error: function(oError) {
						console.error("filter-Error:", oError);
					}
				});
			}

		},
		onOpenObdDetails: function() {
			var oView = this.getView();
			var oViewModel = oView.getModel("viewModel");
			if (!oViewModel) {
				sap.m.MessageToast.show("No OBD details available.");
				return;
			}
			// Load Fragment if not already loaded
			if (!this._oDialog) {
				this._oDialog = sap.ui.xmlfragment(oView.getId(), "ZDispatchOrder.Fragments.ObdDetailsFragment", this);
				oView.addDependent(this._oDialog);
			}
			// Open Dialog
			this._oDialog.open();
		},
		onCloseDialog1: function() {
			if (this._oDialog) {
				this._oDialog.close();
			}
		},
		onScanPress: function() {
			var that = this;
			sap.ndc.BarcodeScanner.scan(
				function(oResult) {
					var qrCode = oResult.text;
					// var qcode = JSON.parse(qrCode);
					// var code = qcode.Serial_Number;
					var code=qrCode.split("|")[0];
					if (!code) {
						sap.m.MessageToast.show("No QR Code detected.");
						return;
					}

					that.byId("billingInput").setValue(code);
					that.processScannedData(code);
				},
				function(oError) {
					sap.m.MessageToast.show("Scan failed: " + oError, {
						duration: 1000
					});
					that.byId("qrCode").setValue("");
				}
			);
		},
		onInputChange: function(oEvent) {
			var that = this;
			var qr_code = oEvent.getParameter("value").trim();
			var code=qr_code.split("|")[0];
			
			console.log("length code", code.length);
			//validation for 24 Characters Rfid
			if (code.length > 10) {
				MessageToast.show("Invalid Length for Scanned Pallet Code!", {
					duration: 3000
				});

				setTimeout(() => {
					that.getView().byId("billingInput").setValue("");
					that.getView().byId("billingInput").focus();
				}, 500);
				return;
			}
			this.processScannedData(code);
		},
		addDataToTable: function() {
			var that = this;
			var tableData = this.getView().getModel("tableDataModel").getData().tableData || [];
			var totalPallet = this.getView().byId("totalMat").getText("");

			//IF DATA ADDED THROUGH SCAN
			if (PalletData) {
				if ((tableData.length + 1) > totalPallet) {

					MessageToast.show("Limit Reached! Can't Scan More!", {
						duration: 3000
					});

					setTimeout(() => {
						that.getView().byId("billingInput").setValue("");
						that.getView().byId("billingInput").focus();
					}, 500);
					return;
				}
				// Check if the pallet number is already scanned
				var isDuplicate = tableData.some(function(item) {
					return item.Pald === PalletData.Pald;
				});

				if (isDuplicate) {
					MessageToast.show("Pallet Is Already Scanned.", {
						duration: 3000
					});

					setTimeout(() => {
						that.getView().byId("billingInput").setValue("");
						that.getView().byId("billingInput").focus();
					}, 500);
				}
				// Add scanned material to the table
				tableData.push({
					SNo: tableData.length + 1,
					Pald: PalletData.Pald,
					RfidNo: PalletData.RfidNo
				});

				PalletData = null;
				// Update table model
				this.getView().getModel("tableDataModel").setData({
					tableData
				});
				sap.m.MessageToast.show("Data added successfully to the table!");
			}
			//IF DATA RETRIEVED THROUGH OBD ITEM SELECT(SAVED DATA FROM DB)
			if (savedNpOnDelivery) {
				savedNpOnDelivery = null;
			}
			//enabling submit button if the total pallet=no. of lineitem in table
			if (tableData.length == totalPallet) {
				this.getView().byId('idSubmitButton').setVisible(true);
			}

			this.getView().byId('idSaveButton').setEnabled(true);
			this.getView().byId('billingInput').setValue("");
			this.getView().byId('RfidScan').setValue("");
			setTimeout(() => {
				this.getView().byId("billingInput").focus();
			}, 500);

		},
		processScannedData: function(code) {
			var that = this;
			var obdQtyText = this.getView().byId("TotalQtyField").getText();
			var obdNum = this.getView().byId("ObdField").getValue();
			var obdQty = parseInt(obdQtyText.split(" / ")[0], 10);
			// var selectedObdMaterial = this.getView().byId("field1").getValue();
			var totalQty = 0;
			var tableData = this.getView().getModel("tableDataModel").getData().tableData || [];

			if (!code) {
				console.error("Pallet Serial Code is Missing.");
				return;
			}

			PalletData = null; //resetting pallet data
			oDataModel.read("/ZLIST_PALLET_RFIDSet('" + code + "')", {
				success: function(oData) {
					//storing palletData for qr code globally.
					PalletData = oData;
					//checking for duplicates
					// Check if the pallet number is already scanned
					var isDuplicate = tableData.some(function(item) {
						return item.Pald === PalletData.Pald;
					});

					if (isDuplicate) {
						MessageToast.show("Pallet Is Already Scanned.", {
							duration: 3000
						});

						setTimeout(() => {
							that.getView().byId("billingInput").setValue("");
							that.getView().byId("billingInput").focus();
						}, 500);
						return;
					}

					//if "YES" .Proceed for RFID scan
					if (RfidFlag === "Yes") {
						sap.m.MessageToast.show("Scan the Rfid tag.");
						this.getView().byId("RfidScan").setEnabled(true);
						setTimeout(() => {
							this.getView().byId("RfidScan").focus();
						}, 500);
					}

					//if "NO". directly add data to table
					else {
						this.addDataToTable();
					}

				}.bind(this),
				error: function(oError) {
					MessageToast.show("Invalid Length for Scanned RFID!", {
						duration: 3000
					});

				}
			});
		},
		onRfidScan: function(oEvent) {
			var that = this;
			var entered_Rfid = oEvent.getParameter("value");

			//validation for 24 Characters Rfid
			if (entered_Rfid.length > 24) {
				MessageToast.show("Invalid Length for Scanned RFID!", {
					duration: 3000
				});

				that.getView().byId("RfidScan").setValue("");
				setTimeout(() => {
					that.getView().byId("RfidScan").focus();
				}, 500);
				return;
			}

			//validation
			if (entered_Rfid == PalletData.RfidNo) {
				//allow to add in table
				this.addDataToTable();
				this.getView().byId("RfidScan").setValue("");
				this.getView().byId("RfidScan").setEnabled(false);
			} else {
				//Dont allow to add in table
				MessageToast.show("Rfid Mis-matched!", {
					duration: 3000
				});

				that.getView().byId("RfidScan").setValue("");
				setTimeout(() => {
					that.getView().byId("RfidScan").focus();
				}, 200);
				return;
			}
		},

		onDeleteRow: async function(oEvent) {
			var oItem = oEvent.getSource().getParent();
			var obdNumber = this.getView().byId("ObdField").getValue();
			var oBindingContext = oItem.getBindingContext("tableDataModel");
			var bindedLineData = oBindingContext.getObject();
			var totalPallet = this.getView().byId("totalMat").getText("");

			// If no binding context is found, exit the function
			if (!oBindingContext) {
				console.error("No binding context found");
				return;
			}
			//Removing data from TabledataModel
			var sPath = oBindingContext.getPath();
			var aTableData = this.getView().getModel("tableDataModel").getProperty("/tableData");

			var index = aTableData.findIndex(function(item, idx) {
				return sPath === "/tableData/" + idx;
			});

			if (index !== -1) {
				aTableData.splice(index, 1);
			}
			//reassigning SNo
			aTableData.forEach((item, index) => {
				item.SNo = index + 1;
			});
			this.getView().getModel("tableDataModel").setData({
				tableData: aTableData
			});
			this.getView().getModel("tableDataModel").refresh();

			//adjusting visibility of submit button
			if (totalPallet == aTableData.length) {
				this.getView().byId('idSubmitButton').setVisible(true);
			} else {
				this.getView().byId('idSubmitButton').setVisible(false);
			}
			//Api call for Delete
			var lineItemData = [{
				Pald: bindedLineData.Pald,
				Vbeln: bindedLineData.Vbeln,
				RfidNo: bindedLineData.RfidNo
			}]
			var payload = {
				Vbeln: obdNumber,
				SaveSubmit: "03",
				MsgTexts: "",
				NP_ON_DELIVERY: lineItemData
			};

			// Perform OData Create (POST) Call for delete
			await oDataModel.create("/ZHEADER_PALLET_RFIDSet", payload, {
				success: function(oData) {
					sap.m.MessageToast.show("Item Deleted Successfully!");
					setTimeout(() => {
						this.getView().byId("billingInput").setValue("");
						this.getView().byId("billingInput").focus();
					}, 200);
				}.bind(this),
				error: function(oError) {
					console.error("Error in delete OData call:", oError);
					sap.m.MessageToast.show("Failed to delete item.");
				}
			});

		},
		onSavePress: function() {
			var that = this;
			var obdNumber = this.getView().byId("ObdField").getValue();

			var oTable = this.getView().byId("TableId");

			var tableLineItems = oTable.getModel("tableDataModel").getProperty("/tableData") || [];

			if (tableLineItems.length === 0) {
				sap.m.MessageToast.show("No items in the table to save.");
				return; // Stop execution
			}

			var aLineItems = tableLineItems
				.map(({
					Pald,
					Vbeln,
					RfidNo
				}) => ({
					Pald,
					Vbeln,
					RfidNo
				}));

			var payload = {
				Vbeln: obdNumber,
				SaveSubmit: "01",
				MsgTexts: "",
				NP_ON_DELIVERY: aLineItems
			};
			oDataModel.create("/ZHEADER_PALLET_RFIDSet", payload, {
				success: function(oData) {
					sap.m.MessageToast.show("Data Saved Successfully!");
				},
				error: function(error) {
					sap.m.MessageToast.show("Failed to Save Data.");
				}
			});
		},
		onSubmitPress: function() {
			var that = this;
			var obdNumber = this.getView().byId("ObdField").getValue();

			var oTable = this.getView().byId("TableId");

			var tableLineItems = oTable.getModel("tableDataModel").getProperty("/tableData") || [];

			if (tableLineItems.length === 0) {
				sap.m.MessageToast.show("No items in the table to save.");
				return; // Stop execution
			}

			var aLineItems = tableLineItems
				.map(({
					Pald,
					Vbeln,
					RfidNo
				}) => ({
					Pald,
					Vbeln,
					RfidNo
				}));

			var payload = {
				Vbeln: obdNumber,
				SaveSubmit: "02",
				MsgTexts: "",
				NP_ON_DELIVERY: aLineItems
			};
			oDataModel.create("/ZHEADER_PALLET_RFIDSet", payload, {
				success: function(oData) {
					sap.m.MessageToast.show("Data Submitted Successfully!");
				},
				error: function(error) {
					sap.m.MessageToast.show("Failed to Submit Data!");
				}
			});
		},
		clearPageData: function() {
			this.getView().byId("billingInput").setValue("");
			this.getView().byId("ObdField").setValue("");
			this.getView().byId("TotalQtyField").setText("");
			this.getView().byId("totalMat").setText("");
			this.getView().byId("RfidReq").setText("");
			this.getView().byId("RfidScan").setValue("");
			this.getView().getModel("tableDataModel").setProperty("/tableData", []);
			this.getView().getModel("tableDataModel").refresh();
			this.getView().getModel("viewModel").setProperty("/SelectedObdItems", []);
			this.getView().getModel("viewModel").refresh();
			this.getView().byId("billingInput").setEnabled(false);

		}

	});

});