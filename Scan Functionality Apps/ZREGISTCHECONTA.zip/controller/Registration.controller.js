sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/odata/v2/ODataModel",
	"sap/ui/core/Fragment",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function(Controller, MessageToast, ODataModel, Fragment, Filter, FilterOperator) {
	"use strict";
	var oDataModel;

	return Controller.extend("Zchemicalcontainer.controller.Registration", {

		onInit: function() {
			var serviceUrl = "/sap/opu/odata/sap/ZWM_PROCESS_SRV";
			oDataModel = new ODataModel(serviceUrl, {
				useBatch: false
			});
			this.getView().setModel(oDataModel, "odataModel");

			this._setFocusOnBillingInput();
		},
		_setFocusOnBillingInput: function() {
			setTimeout(() => {
				const billingInput = this.byId("billingInput");
				if (billingInput) {
					billingInput.focus();
				} else {
					console.warn("Billing input field not found. Ensure the control ID is correct.");
				}
			}, 10); // Slightly longer delay for consistent behavior
		},
		// onAfterRendering: function() {
		// 	// Auto-focus on the input field after the view has been rendered
		// 	this.byId("billingInput").focus();
		// },
		onInputChange: function(oEvent) {
			var sValue = oEvent.getParameter("value").trim();
			const billingInput = this.byId("billingInput");

			// Check if the input is empty or invalid
			if (!sValue) {
				sap.m.MessageBox.error("Invalid input. Please scan again.");
				return;
			}

			console.log("Manually Entered or Scanned Value:", sValue);

			// Clear the billing input field after handling the data
			if (billingInput) {
				billingInput.setValue("");
			}

			// Process the input (either manual or scanned)
			this.processScannedData(sValue); // This function now handles both QR scan and manual input
			this.byId("qrCode").setValue(sValue); // Set the value in the QR code input field
		},

		onScanPress: function() {
			var that = this;

			// Use the barcode scanner API to trigger a scan
			sap.ndc.BarcodeScanner.scan(
				function(oResult) {
					var qrCode = oResult.text; // The scanned text data

					if (!qrCode) {
						sap.m.MessageToast.show("No QR Code detected.");
						return;
					}

					// console.log("Scanned QR Code: " + qrCode);
					that.byId("qrCode").setValue(qrCode); // Set the scanned value in the input field

					// Pass the scanned QR code to the processing function
					that.processScannedData(qrCode);
				}.bind(this),
				function(oError) {
					// Handle scan error
					sap.m.MessageToast.show("Scan failed: " + oError, {
						duration: 1000
					});
					that.byId("qrCode").setValue(""); // Clear the field on scan failure
				}
			);
		},

		processScannedData: function(qrCode) {
			var that = this;

			// Retrieve the OData model correctly
			var oModel = that.getView().getModel("odataModel");
			if (!oModel) {
				sap.m.MessageToast.show("OData model is not available.");
				that.byId("qrCode").setValue(""); // Clear field if model is missing
				return;
			}

			// Call SAP OData service to check if the QR Code is already registered
			oModel.read("/HeaderSet('" + qrCode + "')", {
				success: function(oData) {
					if (oData && oData.BarCode) { // Ensure the correct field is checked
						sap.m.MessageBox.information("This QR Code is already registered.");
						that.byId("qrCode").setValue(""); // Clear the field if already registered
					} else {
						sap.m.MessageToast.show("QR Code is valid. Proceed with data entry.");
					}
				},
				error: function(oError) {
					// If QR code is not found, assume it's valid for registration
					if (oError.statusCode === 404) {
						sap.m.MessageToast.show("QR Code is valid. Proceed with data entry.");
					} else {
						sap.m.MessageToast.show("Error fetching QR data. Please try again.");
						that.byId("qrCode").setValue(""); // Clear field on error
					}
				}
			});
		},

		onScanError: function(oEvent) {
			MessageToast.show("Scan failed: " + oEvent, {
				duration: 1000
			});
		},
		onScanSuccess1: function(oEvent) {
			// Get the scanned result from the event (if oEvent is passed, otherwise we will use the input from the TextArea)
			var sScannedValue = oEvent ? oEvent.getParameter("text") : '';

			// Bind the scanned result to the TextArea if it is passed from the event
			if (sScannedValue) {
				var oTextArea = this.byId("inputField1");
				oTextArea.setValue(sScannedValue);

				// Optionally show a message toast with the scanned value
				// MessageToast.show("Scanned Value: " + sScannedValue);
			}
		},

		// Event handler for the TextArea input change
		onInputTextArea: function(oEvent) {
			// Get the new value entered into the TextArea
			var sInputValue = oEvent.getParameter("newValue");

			// Call onScanSuccess1 to handle the change and bind the value (similar to scan behavior)
			this.onScanSuccess1({
				getParameter: function() {
					return sInputValue;
				}
			});

			// Optionally show a message toast with the updated value
			// MessageToast.show("Input Changed: " + sInputValue);
		},
		onScanLiveupdate: function(oEvent) {
			// User can implement the validation about inputting value
		},

		onValueHelpRequest: function(oEvent) {
			var oInput = oEvent.getSource();

			// Check if the value help dialog is already created
			if (!this._valueHelpDialog) {
				// Log for debugging purposes
				console.log("Creating and opening the value help dialog...");

				// Use sap.ui.xmlfragment to load the fragment
				this._valueHelpDialog = sap.ui.xmlfragment(
					"Zchemicalcontainer.view.Fragment.MaterialCodeValueHelp", // Fragment path
					this // Bind the controller to the fragment
				);

				// Add dialog as a dependent to the view
				this.getView().addDependent(this._valueHelpDialog);
			}

			// Open the dialog
			this._valueHelpDialog.open();
		},
		// onSearchLiveChange: function(oEvent) {
		// 	var sQuery = oEvent.getParameter("newValue"); // Get the new search query

		// 	// Create a filter to filter by Material Code (Matnr)
		// 	var oFilter = new sap.ui.model.Filter({
		// 		path: "Matnr", // The field to filter by
		// 		operator: sap.ui.model.FilterOperator.Contains, // Use 'Contains' operator for partial matching
		// 		value1: sQuery // The search query entered by the user
		// 	});

		// 	// Get the list and apply the filter to its binding
		// 	var oList = this.byId("materialList");
		// 	var oBinding = oList.getBinding("items");

		// 	// Apply the filter to the list binding
		// 	oBinding.filter([oFilter]);
		// },

		// onValueHelpItemSelect: function(oEvent) {
		// 	// Handle item selection from the value help dialog
		// 	var oSelectedItem = oEvent.getSource();
		// 	var sMaterialCode = oSelectedItem.getTitle(); // Assuming materialCode is in the title
		// 	this.getView().byId("materialCode").setValue(sMaterialCode);
		// 	this.onDialogClose.close();
		// },

		// onDialogClose: function() {
		// 	if (this._valueHelpDialog) {
		// 		this._valueHelpDialog.close();
		// 	}
		// },

		onNetWeightChange: function() {
			var oView = this.getView();
			var grossWeight = parseFloat(oView.byId("grossWeight").getValue()) || 0;
			var netWeight = parseFloat(oView.byId("netWeight").getValue()) || 0;

			if (grossWeight < netWeight) {
				MessageToast.show("Gross weight cannot be less than net weight");
				oView.byId("grossWeight").setValue("");
				return;
			}

			var containerWeight = grossWeight - netWeight;
			oView.byId("containerWeight").setValue(containerWeight);
		},

		onValueHelpItemSelect: function(oEvent) {
			// Get the selected item from the List
			var oSelectedItem = oEvent.getSource();
			// console.log(oSelectedItem);

			// Retrieve the material code (Matnr) from the selected item
			var sMaterialCode = oSelectedItem.getBindingContext("odataModel").getProperty("Material");

			// Get the Input field where you want to display the material code
			var oMaterialCodeInput = this.byId("materialCode");

			// Set the value of the Input field to the selected material code
			oMaterialCodeInput.setValue(sMaterialCode);

			// Close the dialog after selection
			this._valueHelpDialog.close();
		},

		onDialogClose: function() {
			// Check if the dialog is defined, then close it
			if (this._valueHelpDialog) {
				this._valueHelpDialog.close();
			}
		},

		onPress: function() {
			var oView = this.getView();

			// Retrieve input values
			var qrCode = oView.byId("qrCode").getValue().trim();
			var ContainerWeight = oView.byId("containerWeight").getValue().trim();
			var ManufacturerQRCode = oView.byId("inputField1").getValue().trim();
			var materialCode = oView.byId("materialCode").getValue().trim();
			var grossWeight = oView.byId("grossWeight").getValue().trim();
			var netWeight = oView.byId("netWeight").getValue().trim();

			// Validation: Check if any field is empty
			if (!qrCode || !ContainerWeight || !materialCode || !grossWeight || !netWeight) {
				MessageToast.show("All fields must be filled before submission.");
				return;
			}

			var oDataModel = this.getView().getModel("odataModel");
			var that = this; // Preserve 'this' for callback

			// Use GET request to check if QR code already exists
			oDataModel.read("/HeaderSet('" + qrCode + "')", {
				success: function(oData) {
					MessageToast.show("This QR code has already been submitted.");
				},
				error: function(oError) {
					// If not found (error), proceed with submission
					if (oError.statusCode === 404) {
						that._submitData(qrCode, ContainerWeight, ManufacturerQRCode, materialCode, grossWeight, netWeight);
					} else {
						MessageToast.show("Error checking for duplicate QR code.");
					}
				}
			});
		},

		_submitData: function(qrCode, ContainerWeight, ManufacturerQRCode, materialCode, grossWeight, netWeight) {
			var oView = this.getView();
			var that = this; // Define 'that' to preserve 'this' context

			var formatDecimal = function(value) {
				return parseFloat(value).toFixed(3);
			};

			var oDataPayload = {
				BarCode: qrCode,
				// ContainerBarCode: containerQrCode,
				ContainerBarCode: ManufacturerQRCode, // Added Manufacturer QR Code
				MaterialDescription: "",
				Material: materialCode,
				GrossWeight: formatDecimal(grossWeight),
				NetWeight: formatDecimal(netWeight),
				ContainerWeight: formatDecimal(oView.byId("containerWeight").getValue()) || "0.000",
				CurrentStatus: "RW",
				CurrentLocation: "WH"
			};

			var oDataModel = this.getView().getModel("odataModel");

			oDataModel.create("/HeaderSet", oDataPayload, {
				success: function() {
					MessageToast.show("Container registered successfully!");
					that._clearFields(); // Use 'that' to call the function
				},
				error: function() {
					MessageToast.show("Error registering container. Check logs.");
				}
			});
		},

		_clearFields: function() {
			var oView = this.getView();

			oView.byId("billingInput").setValue("");
			oView.byId("qrCode").setValue("");
			oView.byId("inputField1").setValue(""); // Clear ManufacturerQRCode field
			oView.byId("materialCode").setValue("");
			oView.byId("grossWeight").setValue("");
			oView.byId("netWeight").setValue("");
			oView.byId("containerWeight").setValue("");
		}

	});
});