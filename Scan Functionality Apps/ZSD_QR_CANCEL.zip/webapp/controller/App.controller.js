sap.ui.define([
"sap/ui/core/mvc/Controller",
"sap/m/MessageToast"
], function(Controller, MessageToast) {
"use strict";
return Controller.extend("somanyimpresacancellation.controller.App", {
onInit: function() {
var oRsrcModel = new sap.ui.model.resource.ResourceModel({
bundleName: "somanyimpresacancellation.i18n.i18n"
});
this.getView().setModel(oRsrcModel, "i18n");
this._oODataModel = new sap.ui.model.odata.v2.ODataModel("/sap/opu/odata/sap/ZMM_QRCODE_CANCEL_SRV/");
var oMainModel = new sap.ui.model.json.JSONModel();
this.getView().setModel(oMainModel, "MainModel");
oMainModel.setProperty("/QRCodes", []);
this._oMainModel = this.getView().getModel("MainModel");
},
onLiveQRChange: function(oEvent) {
var sVal = oEvent.getSource().getValue();
if (sVal.split("|").length === 5) {
oEvent.getSource().setValue(sVal.split("|")[3]);
this._validateQRCode(sVal.split("|")[3]);
//this._appendQRtoItem(sVal.split("|")[3]);
oEvent.getSource().setValue("");
}
if (sVal.split("|").length === 8) {
oEvent.getSource().setValue(sVal.split("|")[6]);
this._validateQRCode(sVal.split("|")[6]);
//this._appendQRtoItem(sVal.split("|")[6]);
oEvent.getSource().setValue("");
}
},
_validateQRCode: function(sScannedQR) {
var aQRList = this._oMainModel.getProperty("/QRCodes");
var fExist = false;
if (aQRList.length > 0) {
for (var a = 0; a < aQRList.length; a++) {
// Validation already existed QR code
if (aQRList[a].Qrserial === sScannedQR) {
fExist = true;
break;
}
}
if (fExist) {
MessageToast.show("Serial number is already used", {
durtion: 1000
});
return;
}
/*else {
aQRList.push({"Qrserial":sScannedQR});
this._oMainModel.setProperty("/QRCodes",aQRList);
this._oMainModel.refresh(true);
}*/
} else {
aQRList = [];
/* aQRList.push({"Qrserial":sScannedQR});
this._oMainModel.setProperty("/QRCodes",aQRList);
this._oMainModel.refresh(true);*/
}
this._oODataModel.read("/CheckScannedQrSet('" + sScannedQR + "')", {
/*filters: aFilter,*/
success: function(oData) {
if (oData.IsExist === "true") {
if (oData.IsConsumed === "true") {
MessageToast.show("Scanned QR code is already consumed!", {
duration: 900
});
} else {
aQRList.push({"Qrserial":sScannedQR});
this._oMainModel.setProperty("/QRCodes", aQRList);
this._oMainModel.refresh(true);
}
} else {
MessageToast.show("Scanned QR code is not available!", {
duration: 900
});
}
}.bind(this),
error: function(oError) {
this._showResponseErrMsg(oError);
}.bind(this)
});
},
onDeleteQRCodes: function(oEvent) {
var oModel = oEvent.getSource().getParent().getBindingContext("MainModel"),
sPath = oModel.getPath(),
aData = oModel.getModel().getProperty("/QRCodes");
sPath = sPath.split("/")[2];
aData.splice(parseInt(sPath, 10), 1);
this._oMainModel.setProperty("/QRCodes", aData);
this._oMainModel.refresh(true);
},
onCancel: function(oEvent) {
var aQRList = this._oMainModel.getProperty("/QRCodes");
var aFilter = [];
for (var a = 0; a < aQRList.length; a++) {
aFilter.push(
new sap.ui.model.Filter({
path: "GroupQrserial",
operator: "EQ",
value1: aQRList[a].Qrserial
})
);
}
var that = this;
sap.ui.core.BusyIndicator.show();
this._oODataModel.read("/ET_QRCODESet", {
filters: aFilter,
success: function(oData) {
sap.ui.core.BusyIndicator.hide();
var aItems = oData.results;
var sflag = false;
var GroupQrserial = "";
for (var x = 0; x < aItems.length; x++) {
if (aItems[x].ReturnMessage.Message !== "QR code serial no. cancelled successfully") {
GroupQrserial = aItems[x].GroupQrserial;
sflag = true;
break;
}
}
if (!sflag) {
MessageToast.show("Cancelled successfully!", {
duration: 900
});
that.getView().getModel("MainModel").setProperty("/QRCodes", []);
} else {
MessageToast.show(GroupQrserial + " Not Cancelled!", {
duration: 900
});
}
}.bind(this),
error: function(oError) {
sap.ui.core.BusyIndicator.hide();
this._showResponseErrMsg(oError);
}.bind(this)
});
}
});
});