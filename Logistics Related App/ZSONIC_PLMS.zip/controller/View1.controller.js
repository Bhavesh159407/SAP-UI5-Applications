sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"ZSonic_PLMS/model/formatter",
	"sap/ui/core/Fragment"
], function(Controller, JSONModel, Filter, FilterOperator, MessageBox, formatter, Fragment) {
	"use strict";

	return Controller.extend("ZSonic_PLMS.controller.View1", {
		f: formatter,
		onInit: function() {
			this.getView().byId("idDateFromSelect").setDateValue(new Date());
			this.getView().byId("idDateToSelect").setDateValue(new Date());
			this.getView().addStyleClass("sapUiSizeCompact");
			var obdNo = new JSONModel();
			this.getView().setModel(obdNo, "OBDModel");
			var truckNo = new JSONModel();
			this.getView().setModel(truckNo, "TruckNoModel");
			var custName = new JSONModel();
			this.getView().setModel(custName, "CustNameModel");
			var status = new JSONModel();
			this.getView().setModel(status, "StatusModel");
			/*var trip = new JSONModel();
			this.getView().setModel(trip, "TripModel");*/
			var plant = new JSONModel();
			this.getView().setModel(plant, "PlantModel");
			var pop = new JSONModel();
			this.getView().setModel(pop, "PopoverModel");
			var text = new JSONModel();
			text.setData({
				Text: ""
			});
			this.getView().setModel(text, "DeliveryTextModel");
			this.getView().setBusy(true);
			this.getOwnerComponent().getModel().read("/ZplmsObdNoShpSet", {
				success: function(oData) {
					var data = oData.results;
					this.getView().getModel("OBDModel").setProperty("/obdValues", data);
					this.getView().setBusy(false);
				}.bind(this),
				error: function(oError) {
					sap.m.MessageToast.show("Error in getting OBD numbers data");
					this.getView().setBusy(false);
				}.bind(this)
			});
			this.getView().setBusy(true);
			this.getOwnerComponent().getModel().read("/ZplmsShpTruckNoSet", {
				success: function(oData) {
					var data = oData.results;
					this.getView().getModel("TruckNoModel").setProperty("/truckValues", data);
					this.getView().setBusy(false);
				}.bind(this),
				error: function(oError) {
					sap.m.MessageToast.show("Error in getting Truck numbers data");
					this.getView().setBusy(false);
				}.bind(this)
			});
			this.getView().setBusy(true);
			this.getOwnerComponent().getModel().read("/ZplmsShpCustSet", {
				success: function(oData) {
					var data = oData.results;
					this.getView().getModel("CustNameModel").setProperty("/custValues", data);
					this.getView().setBusy(false);
				}.bind(this),
				error: function(oError) {
					sap.m.MessageToast.show("Error in getting Customer Names data");
					this.getView().setBusy(false);
				}.bind(this)
			});
			this.getView().setBusy(true);
			this.getOwnerComponent().getModel().read("/PLMS_STAT_SHPSet", {
				success: function(oData) {
					var data = oData.results;
					this.getView().getModel("StatusModel").setProperty("/statusValues", data);
					this.getView().setBusy(false);
				}.bind(this),
				error: function(oError) {
					sap.m.MessageToast.show("Error in getting Customer Names data");
					this.getView().setBusy(false);
				}.bind(this)
			});
			this.getView().setBusy(true);
			setTimeout(function() {
				this.byId("pullToRefresh").hide();
				this.onSearch();
			}.bind(this), 1000000);
		},
		onOBDValueHelpPress: function(oEvent) {
			if (!this.dialogOBDBegin) {
				this.dialogOBDBegin = sap.ui.xmlfragment(this.getView().getId(), "ZSonic_PLMS.view.Fragment.OBDValueHelpFragment", this);
				this.getView().addDependent(this.dialogOBDBegin);
			}
			this.dialogOBDBegin.open();
		},
		onCloseOBDDialog: function(oEvent) {
			if (this.dialogOBDBegin) {
				this.dialogOBDBegin.close();
			}
		},
		onTruckNoValueHelpPress: function(oEvent) {
			if (!this.dialogTruckBegin) {
				this.dialogTruckBegin = sap.ui.xmlfragment(this.getView().getId(), "ZSonic_PLMS.view.Fragment.TruckValueHelpFragment", this);
				this.getView().addDependent(this.dialogTruckBegin);
			}
			this.dialogTruckBegin.open();
		},
		onCloseTruckDialog: function(oEvent) {
			if (this.dialogTruckBegin) {
				this.dialogTruckBegin.close();
			}
		},
		onCustNameValueHelpPress: function(oEvent) {
			if (!this.dialogCustNoBegin) {
				this.dialogCustNoBegin = sap.ui.xmlfragment(this.getView().getId(), "ZSonic_PLMS.view.Fragment.CustomerNameHelpFragment", this);
				this.getView().addDependent(this.dialogCustNoBegin);
			}
			this.dialogCustNoBegin.open();
		},
		onCloseCustNoDialog: function(oEvent) {
			if (this.dialogCustNoBegin) {
				this.dialogCustNoBegin.close();
			}
		},
		onStatusValueHelpPress: function(oEvent) {
			if (!this.dialogStatusBegin) {
				this.dialogStatusBegin = sap.ui.xmlfragment(this.getView().getId(), "ZSonic_PLMS.view.Fragment.StatusHelpFragment", this);
				this.getView().addDependent(this.dialogStatusBegin);
			}
			this.dialogStatusBegin.open();
		},
		onCloseStatusDialog: function(oEvent) {
			if (this.dialogStatusBegin) {
				this.dialogStatusBegin.close();
			}
		},
		onPlantValueHelpPress: function(oEvent) {
			if (!this.dialogPlantBegin) {
				this.dialogPlantBegin = sap.ui.xmlfragment(this.getView().getId(), "ZSonic_PLMS.view.Fragment.PlantHelpFragment", this);
				this.getView().addDependent(this.dialogPlantBegin);
			}
			this.dialogPlantBegin.open();
		},
		onClosePlantDialog: function(oEvent) {
			if (this.dialogPlantBegin) {
				this.dialogPlantBegin.close();
			}
		},
		onSearch: function(oEvent) {
			//	this.getView().getModel("TripModel").setProperty("/Items", []);
			this.getOwnerComponent().getModel("TripDisplayModel").setProperty("/Items", []);
			var obd = this.getView().byId("idOBDNumber").getValue();
			var truckNo = this.getView().byId("idTruckNumber").getValue();
			var custName = this.getView().byId("idCustName").getValue();
			var obdStatus = this.getView().byId("idStatus").getValue().toUpperCase();
			var plant = this.getView().byId("idPlantName").getValue();
			if (plant !== "") {
				this.getOwnerComponent().getModel("PlantModel").setProperty("/selectedPlant", plant);
			}
			var dateRangeFirst = this.getView().byId("idDateFromSelect").getDateValue();
			var dateRangeSecond = this.getView().byId("idDateToSelect").getDateValue();
			var plantValues = this.getOwnerComponent().getModel("PlantsModel").getProperty("/plantValues");
			var aFilters = [],
				aOrFilters = [],
				aStatusFilter = [];
			if (obd || truckNo || custName || obdStatus || plant || dateRangeFirst || dateRangeSecond) {
				if (obd) {
					if (obd.length !== 10) {
						var remainingZeroes = 10 - obd.length;
						for (var i = 0; i < remainingZeroes; i++) {
							obd = "0" + obd;
						}
					}
					aFilters.push(new Filter({
						path: "ObdNumber",
						value1: obd,
						operator: FilterOperator.EQ
					}));
				}
				if (truckNo) {
					aFilters.push(new Filter({
						path: "TruckNumber",
						value1: truckNo,
						operator: FilterOperator.EQ
					}));
				}
				if (custName) {
					aFilters.push(new Filter({
						path: "Kunnr",
						value1: custName,
						operator: FilterOperator.EQ
					}));
				}
				if (obdStatus) {
					aFilters.push(new Filter({
						path: "TripStatus",
						value1: obdStatus,
						operator: FilterOperator.EQ
					}));
				}
				if (dateRangeFirst && dateRangeSecond) {
					aFilters.push(new Filter({
						path: "ObdDate",
						value1: this.resolveTimeDifference(dateRangeFirst),
						operator: FilterOperator.GE
					}));
					aFilters.push(new Filter({
						path: "ObdDate",
						value1: this.resolveTimeDifference(dateRangeSecond),
						operator: FilterOperator.LE
					}));
				}
				if (plant) {
					aFilters.push(new Filter({
						path: "Plant",
						value1: plant,
						operator: FilterOperator.EQ
					}));
				} else {
					var plantsLength = plantValues.length;
					if (plantsLength > 0) {
						for (var f = 0; f < plantsLength; f++) {
							aOrFilters.push(new Filter({
								path: "Plant",
								value1: plantValues[f].PlantCode,
								operator: FilterOperator.EQ
							}));
						}
						var oOrFilter = new Filter(aOrFilters, false);
						aFilters.push(oOrFilter);
					} else {
						MessageBox.error("You are not Authorized to access this Application");
					}
				}
				var oFilter = new Filter(aFilters, true);
				aStatusFilter.push(oFilter);
				this.getView().setBusy(true);
				this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
					filters: aStatusFilter,
					urlParameters: {
						"$expand": "ZHDR_HDR"
					},
					success: function(oData) {
						var data = oData.results;
						if (data.length === 0) {
							MessageBox.error("No Data vailable for selected Filters for the Authorized plants");
						}
						this.getOwnerComponent().getModel("TripDisplayModel").setProperty("/Items", data);
						this.getView().setBusy(false);
					}.bind(this),
					error: function(error) {
						MessageBox.error("No data is available for selected filters.Please select valid Filters");
						this.getView().setBusy(false);
					}.bind(this)
				});
			} else {
				MessageBox.error("Please give atleast one Filter");
			}
		},
		onOBDNoSelect: function(oEvent) {
			var obdNo = oEvent.getSource().getSelectedItem().getCells()[0].getText();
			this.getView().byId("idOBDNumber").setValue(obdNo);
			this.dialogOBDBegin.close();
			this.getView().byId("idOBDTable").removeSelections();
		},
		onTruckNoSelect: function(oEvent) {
			var truckNo = oEvent.getSource().getSelectedItem().getCells()[0].getText();
			this.getView().byId("idTruckNumber").setValue(truckNo);
			this.dialogTruckBegin.close();
			this.getView().byId("idTruckNumTable").removeSelections();
		},
		onCustNameSelect: function(oEvent) {
			var custName = oEvent.getSource().getSelectedItem().getCells()[1].getText();
			this.getView().byId("idCustName").setValue(custName);
			this.dialogCustNoBegin.close();
			this.getView().byId("idCustNameTable").removeSelections();

		},
		onStatusSelect: function(oEvent) {
			var statusCode = oEvent.getSource().getSelectedItem().getCells()[1].getText();
			this.getView().byId("idStatus").setValue(statusCode);
			this.dialogStatusBegin.close();
			this.getView().byId("idStatusTable").removeSelections();
		},
		onPlantSelect: function(oEvent) {
			var plantCode = oEvent.getSource().getSelectedItem().getCells()[1].getText();
			this.getView().byId("idPlantName").setValue(plantCode);
			this.dialogPlantBegin.close();
			this.getView().byId("idPlantNameTable").removeSelections();
		},
		onTripRowPress: function(oEvent) {
			//	var key1 = oEvent.getSource().getCells()[2].getText();
			var key1 = oEvent.getSource().getCells()[0].getText();
			var key2 = oEvent.getSource().getCells()[1].getText();
			var key3 = "";
			var key4 = oEvent.getSource().getCells()[6].getText();

			if (key2.includes("+")) {
				key3 = key2.split("+");
				this.getOwnerComponent().getRouter().navTo("view2", {
					key1: key1,
					key2: key3[0],
					key3: key4
				});
			} else {
				this.getOwnerComponent().getRouter().navTo("view2", {
					key1: key1,
					key2: key2,
					key3: key4
				});
			}
		},
		onFilterTickets: function(oEvent) {
			var searchString = this.getView().byId("searchField").getValue();
			var aFilters = [];
			if (searchString) {
				var oFilter = new Filter("TruckNumber", FilterOperator.Contains, searchString);
				aFilters.push(oFilter);
			}
			this.getView().byId("idMainTable").getBinding("items").filter(aFilters);
		},
		onOBDFilterTickets: function(oEvent) {
			var searchString = this.getView().byId("obdSearchField").getValue();
			var aFilters = [];
			if (searchString) {
				var oFilter = new Filter("Vbeln", FilterOperator.Contains, searchString);
				aFilters.push(oFilter);
			}
			this.getView().byId("idOBDTable").getBinding("items").filter(aFilters);
		},
		onCustNameFilterTickets: function(oEvent) {
			var searchString = this.getView().byId("custNameSearchField").getValue();
			var aFilters = [];
			if (searchString) {
				var oFilter = new Filter("Name1", FilterOperator.Contains, searchString);
				aFilters.push(oFilter);
			}
			this.getView().byId("idCustNameTable").getBinding("items").filter(aFilters);
		},
		onPlantFilterTickets: function(oEvent) {
			var searchString = this.getView().byId("plantSearchField").getValue();
			var aFilters = [];
			if (searchString) {
				var oFilter = new Filter("Name1", FilterOperator.Contains, searchString);
				aFilters.push(oFilter);
			}
			this.getView().byId("idPlantNameTable").getBinding("items").filter(aFilters);
		},
		onStatusFilterTickets: function(oEvent) {
			var searchString = this.getView().byId("statusSearchField").getValue();
			var aFilters = [];
			if (searchString) {
				var oFilter = new Filter("DomainValue", FilterOperator.Contains, searchString);
				aFilters.push(oFilter);
			}
			this.getView().byId("idStatusTable").getBinding("items").filter(aFilters);
		},
		onTruckNoFilterTickets: function(oEvent) {
			var searchString = this.getView().byId("truckSearchField").getValue();
			var aFilters = [];
			if (searchString) {
				var oFilter = new Filter("Traid", FilterOperator.Contains, searchString);
				aFilters.push(oFilter);
			}
			this.getView().byId("idTruckNumTable").getBinding("items").filter(aFilters);
		},
		changeColor: function(oEvent) {
			if (oEvent.getSource().getItems()) {
				for (var i = 0; i < oEvent.getSource().getItems().length; i++) {
					if (oEvent.getSource().getItems()[i].getCells()[4].getText() === "Reported") {
						oEvent.getSource().getItems()[i].addStyleClass("statusReported");
					}
					if (oEvent.getSource().getItems()[i].getCells()[4].getText() === "Arrived") {
						oEvent.getSource().getItems()[i].addStyleClass("statusArrived");
					}
					if (oEvent.getSource().getItems()[i].getCells()[4].getText() === "Planned") {
						oEvent.getSource().getItems()[i].addStyleClass("statusPlanned");
					}
					if (oEvent.getSource().getItems()[i].getCells()[4].getText() === "Inspection in Progress") {
						oEvent.getSource().getItems()[i].addStyleClass("statusIP");
					}
					if (oEvent.getSource().getItems()[i].getCells()[4].getText() === "Inspection Completed") {
						oEvent.getSource().getItems()[i].addStyleClass("statusIC");
					}
					if (oEvent.getSource().getItems()[i].getCells()[4].getText() === "") {
						oEvent.getSource().getItems()[i].addStyleClass("statusPlanned");
					}
					if (oEvent.getSource().getItems()[i].getCells()[4].getText() === "Gate-In") {
						oEvent.getSource().getItems()[i].addStyleClass("statusGI");
					}
					if (oEvent.getSource().getItems()[i].getCells()[4].getText() === "Gate-Out") {
						oEvent.getSource().getItems()[i].addStyleClass("statusGO");
					}
					if (oEvent.getSource().getItems()[i].getCells()[4].getText() === "Weighment Completed") {
						oEvent.getSource().getItems()[i].addStyleClass("statusWC");
					}
					if (oEvent.getSource().getItems()[i].getCells()[4].getText() === "Loading Completed") {
						oEvent.getSource().getItems()[i].addStyleClass("statusLC");
					}
					if (oEvent.getSource().getItems()[i].getCells()[4].getText() === "Cancelled") {
						oEvent.getSource().getItems()[i].addStyleClass("statusCL");
					}
				}
			}
		},
		onOBDNumberLinkPress: function(oEvent) {
			var oLink = oEvent.getSource();
			var oBinding = oEvent.getSource().getParent().getBindingContextPath().split("/")[2];
			var bindingVariable = "";
			var truckNum = oEvent.getSource().getParent().getCells()[0].getText();
			var aPropFilters = [];
			var oPopFilter = new Filter({
				path: "TruckNumber",
				value1: truckNum,
				operator: FilterOperator.EQ
			});
			aPropFilters.push(oPopFilter);
			this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
				filters: aPropFilters,
				success: function(oData) {
					var data = oData.results;
					this.getView().getModel("PopoverModel").setProperty("/Items", data);
					if (this.getView().getModel("PopoverModel").getProperty("/Items").length > 1) {
						if (!this._pPopover) {
							this._pPopover = Fragment.load({
								id: this.getView().getId(),
								name: "ZSonic_PLMS.view.Fragment.Popover",
								controller: this
							}).then(function(oPopover) {
								this.getView().addDependent(oPopover);
								//	bindingVariable = "TripModel>/Items/"+oBinding+"/ZHDR_HDR/results" + oBinding;
								//	oPopover.bindElement(bindingVariable);
								return oPopover;
							}.bind(this));
						}
						this._pPopover.then(function(oPopover) {
							oPopover.openBy(oLink);
						});
					}
				}.bind(this),
				error: function(error) {
					MessageBox.error("No data is available for selected filters.Please select valid Filters");
				}.bind(this)
			});
		},
		resolveTimeDifference: function(dateTime) {
			if (dateTime !== undefined && dateTime !== null && dateTime !== "") {
				var offSet = dateTime.getTimezoneOffset();
				var offSetVal = dateTime.getTimezoneOffset() / 60;
				var h = Math.floor(Math.abs(offSetVal));
				var m = Math.floor((Math.abs(offSetVal) * 60) % 60);
				dateTime = new Date(dateTime.setHours(h, m, 0, 0));
				return dateTime;
			}
			return null;
		},
		onDeliveryTextLinkPress: function(oEvent) {
			var text = oEvent.getSource().getText();
			var oLink = oEvent.getSource();
			//	this.getView().getModel("DeliveryTextModel").getData()[0]=null;
			this.getView().getModel("DeliveryTextModel").setProperty("/Text", text);
			this.getView().getModel("DeliveryTextModel").refresh(true);
			if (!this.dialogDeliveryText) {
				this.dialogDeliveryText = sap.ui.xmlfragment(this.getView().getId(), "ZSonic_PLMS.view.Fragment.DeliveryText", this);
				this.getView().addDependent(this.dialogDeliveryText);
			}
			this.dialogDeliveryText.open();
		},
		/*,
				handlePullToRefresh:function(oEvent){
					setTimeout(function () {
						this.byId("pullToRefresh").hide();
						this.onSearch();
					}.bind(this), 1000);
				}*/
		onCloseDeliveryTextDialog: function() {
			if (this.dialogDeliveryText) {
				this.dialogDeliveryText.close();
			}
		},
		onUnlistedVehicleRegister: function() {
			//get plant code.
			var plantCode=this.byId("idPlantName").getValue();
			if(!plantCode){
				plantCode="NA"
			}
			// Perform the navigation
			this.getOwnerComponent().getRouter().navTo("view3", {plantCode:plantCode});

			// Prepare the filters for reading the Unlisted Vehicles data
			var aUnListedFilters = [],
				aUnListedStatusFilter = [];
			aUnListedFilters.push(new Filter({
				path: "DelInd",
				value1: "false",
				operator: FilterOperator.EQ
			}));
			var oUnListedFilter = new Filter(aUnListedFilters, true);
			aUnListedStatusFilter.push(oUnListedFilter);

		},
		onRegisterUnlistedVehicle: function() {
			var type = this.getView().byId("idTypeofVehicle");
			var truckNo = this.getView().byId("idUnlistedTruckNumber");
			var transporterName = this.getView().byId("idTransporterName");
			var payload = {
				"Type": type,
				"TruckNo": truckNo,
				"TransporterName": transporterName
			};
			this.getOwnerComponent().getModel().create("/Entityset", payload, {
				success: function(oData) {
					MessageBox.success("Vehicle has been registered Successfully");
				},
				error: function(oError) {
					MessageBox.success("Error occured while registering the vehicle");
				}
			});
		},
		/*onCloseRegisterButton: function() {
			if (this.dialogUnlisted) {
				this.dialogUnlisted.close();
			}
		},*/
		onRefreshScreen: function() {
			var aFilters = [],
				aOrFilters = [],
				aStatusFilter = [];
			aFilters.push(new Filter({
				path: "ObdDate",
				value1: new Date("01/01/2019"),
				operator: FilterOperator.GT
			}));
			aFilters.push(new Filter({
				path: "ObdDate",
				value1: new Date(),
				operator: FilterOperator.LT
			}));
			var plantValues1 = this.getOwnerComponent().getModel("PlantsModel").getProperty("/plantValues");
			var plantsLength = this.getOwnerComponent().getModel("PlantsModel").getProperty("/plantValues").length;
			if (plantsLength > 0) {
				for (var f = 0; f < plantsLength; f++) {
					aOrFilters.push(new Filter({
						path: "Plant",
						value1: plantValues1[f].PlantCode,
						operator: FilterOperator.EQ
					}));
				}
			} else {
				MessageBox.error("You are not Authorized to access this Application");
			}
			var oOrFilter = new Filter(aOrFilters, false);
			aFilters.push(oOrFilter);
			var oFilter = new Filter(aFilters, true);
			aStatusFilter.push(oFilter);
			this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
				filters: aStatusFilter,
				urlParameters: {
					"$expand": "ZHDR_HDR"
				},
				success: function(oDataHDR) {
					var dataHDR = oDataHDR.results;
					this.getOwnerComponent().getModel("TripDisplayModel").setProperty("/Items", dataHDR);
				}.bind(this),
				error: function(error) {
					MessageBox.error("No data is available for selected filters.Please select valid Filters");
				}.bind(this)
			});
		}
	});
});