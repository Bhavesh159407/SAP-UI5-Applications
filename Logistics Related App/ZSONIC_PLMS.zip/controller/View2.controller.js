sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/Fragment",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"ZSonic_PLMS/model/formatter"
], function(Controller, JSONModel, Fragment, History, Filter, FilterOperator, MessageBox, formatter) {
	"use strict";
	var lineItemsBuffer = [];
	return Controller.extend("ZSonic_PLMS.controller.View2", {
		f: formatter,
		onInit: function() {
			this.getOwnerComponent().getRouter().getRoute("view2").attachPatternMatched(this.onPatternMatched, this);
			this.getView().addStyleClass("sapUiSizeCompact");
			var mobdNo = new JSONModel();
			this.getView().setModel(mobdNo, "MultiOBDModel");
			var pgi = new JSONModel();
			this.getView().setModel(pgi, "PGIModel");
			var img = new JSONModel();
			this.getView().setModel(img, "ImageModel");
			var contNo = new JSONModel();
			this.getView().setModel(contNo, "ContainerNoModel");
			var rej = new JSONModel();
			this.getView().setModel(rej, "RejectReasonModel");
			var canvas = new JSONModel({
				"values": [{
					"value": "01"
				}, {
					"value": "02"
				}, {
					"value": "03"
				}]
			});
			this.getView().setModel(canvas, "CanvasModel");
			var attach = new JSONModel();
			this.getView().setModel(attach, "AttachmentModel");
			var timeLine = new JSONModel();
			this.getView().setModel(timeLine, "TimeLineSetModel");
			var tgiude = new JSONModel();
			this.getView().setModel(tgiude, "TimeGuideModel");
			var newObdNo = new JSONModel();
			this.getView().setModel(newObdNo, "NewOBDDisplayModel");
			var enabledisable = new JSONModel();
			this.getView().setModel(enabledisable, "EnableDisableModel");
			var setEnableDisable = this.getView().getModel("EnableDisableModel");
			setEnableDisable.setProperty("/InspectionFormElements", true);
			setEnableDisable.setProperty("/InspectionEditSaveButtons", true);
			setEnableDisable.setProperty("/InspectionSubmitButton", true);
			setEnableDisable.setProperty("/GateInEditSaveandSubmitButtons", true);
			setEnableDisable.setProperty("/LoadingEditSaveandSubmitButtons", true);
			setEnableDisable.setProperty("/WeighmentSlip", true);
			setEnableDisable.setProperty("/Select", false);
			var batch = new JSONModel();
			batch.setData({
				Items: []
			});
			this.loadingCompleted = false;
			this.getView().setModel(batch, "BatchModel");
			var timeline = new JSONModel({
				/*"Items": [{
					"ID": 1,
					"Name": "Reporting",
					"JobTitle": "3:35 PM",
					"Finished": "3:35 PM",
					"Status": "Success",
					"Delay": "0 min",
					"Icon": "sap-icon://survey",
					"status": "Success"
				}, {
					"ID": 2,
					"Name": "Inspection",
					"JobTitle": "4:00 PM",
					"Finished": "4:10 PM",
					"Status": "Success",
					"Delay": "10 min",
					"Icon": "sap-icon://activity-2"
				}, {
					"ID": 3,
					"Name": "Gate-In",
					"JobTitle": "4:15 PM",
					"Finished": "4:30 PM",
					"Status": "Success",
					"Delay": "15 min",
					"Icon": "sap-icon://inventory"
				}, {
					"ID": 4,
					"Name": "Weighment",
					"JobTitle": "5:00 PM",
					"Finished": "5:30 PM",
					"Status": "Error",
					"Delay": "30 min",
					"Icon": "sap-icon://measurement-document"
				}, {
					"ID": 5,
					"Name": "Loading/Unloading",
					"JobTitle": "5:30 PM",
					"Finished": "6:00 PM",
					"Status": "Error",
					"Delay": "30 min",
					"Icon": "sap-icon://measurement-document"
				}, {
					"ID": 6,
					"Name": "Gate-out",
					"JobTitle": "6:00 PM",
					"Finished": "6:30 PM",
					"Status": "Error",
					"Delay": "30 min",
					"Icon": "sap-icon://measurement-document"
				}]*/
			});
			this.getView().setModel(timeline, "TimeLineModel");
			var dropDown = new JSONModel({
				"values": [{
					"type": "Container",
					"key": "Container"
				}, {
					"type": "Truck",
					"key": "Truck"
				}, {
					"type": "Container + Truck",
					"key": "Container + Truck"
				}, {
					"type": "Tank",
					"key": "Tank"
				}]
			});
			this.getView().setModel(dropDown, "DropDownModel");
			var addWeighment = new JSONModel();
			this.getView().setModel(addWeighment, "RemarksModel");
			var manual = new JSONModel({
				"Items": []
			});
			this.getView().setModel(manual, "ManualReasonModel");
			var addWeighment1 = new JSONModel();
			this.getView().setModel(addWeighment1, "WeighmentModel");
			var loading = new JSONModel();
			this.getView().setModel(loading, "LoadingMaterialsModel");
			var loadingItems = new JSONModel();
			this.getView().setModel(loadingItems, "LoadingItemsBatchModel");
			var vehT = new JSONModel();
			this.getView().setModel(vehT, "VehTypeModel");
			var enable = new JSONModel();
			this.getView().setModel(enable, "EnableModel");
			var gateDetails = new JSONModel({
				"values": []
			});
			this.getView().setModel(gateDetails, "GateModel");
			var aShipFilters = [],
				aShipStatusFilter = [];
			aShipFilters.push(new Filter({
				path: "Activity",
				value1: "GO",
				operator: FilterOperator.EQ
			}));
			var oShipFilter = new Filter(aShipFilters, true);
			aShipStatusFilter.push(oShipFilter);
			this.getOwnerComponent().getModel().read("/RemarksSet", {
				filters: aShipStatusFilter,
				success: function(oContData) {
					/*var remarksDropDown=[];
					for(var ii=1;ii<oContData.results.length;ii++){
						remarksDropDown.push(oContData.results[ii]);
					}*/
					this.getView().getModel("RemarksModel").setProperty("/Items", oContData.results);
				}.bind(this)
			});
		},
		onPatternMatched: function(oEvent) {
			this.truckNumber = oEvent.getParameters().arguments.key1;
			this.obdNumber = oEvent.getParameters().arguments.key2;
			if ((this.obdNumber).length !== 10) {
				var remainingZeroes = 10 - (this.obdNumber).length;
				for (var i = 0; i < remainingZeroes; i++) {
					this.obdNumber = "0" + (this.obdNumber);
				}
			}
			var vehType;
			var trip = new JSONModel();
			this.getView().setModel(trip, "TripModel");
			var notes = new JSONModel();
			this.getView().setModel(notes, "NotesModel");
			var load = new JSONModel();
			this.getView().setModel(load, "LoadingItemsModel");
			var tOBD = new JSONModel();
			this.getView().setModel(tOBD, "TripOBDModel");
			var inspection = new JSONModel();
			this.getView().setModel(inspection, "InspectionModel");
			var aFilters = [],
				aStatusFilter = [];
			// if (this.tripNumber && this.tripNumber !== "0000000000") {
			// Add filters for existing TripNumber
			aFilters.push(new sap.ui.model.Filter({
				path: "TruckNumber",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: this.truckNumber
			}));
			// SoC by Abul
			var tripNum = oEvent.getParameters().arguments.key3 || "0000000000";
			this.tripNumber = tripNum;
			// Eoc by Abul 
			aFilters.push(new sap.ui.model.Filter({
				path: "TripNumber",
				operator: sap.ui.model.FilterOperator.EQ,
				value1: this.tripNumber
			}));

			// else {
			// 	// Add alternate filter logic if TripNumber doesn't exist
			// 	aFilters.push(new sap.ui.model.Filter({
			// 		path: "TruckNumber",
			// 		operator: sap.ui.model.FilterOperator.EQ,
			// 		value1: this.truckNumber
			// 	}));
			// }
			var oFilter = new Filter(aFilters, true);
			aStatusFilter.push(oFilter);
			this.aStatusFilter = aStatusFilter;
			this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
				filters: aStatusFilter,
				urlParameters: {
					"$expand": "ZHDR_HDR"
				},
				success: function(oExtData) {
					this.getView().getModel("EnableModel").setData(oExtData.results[0]);
				}.bind(this),
				error: function(oExterror) {
					MessageBox.error("No data is available for selected filters.Please select valid Filters");
				}.bind(this)
			});
			this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
				filters: aStatusFilter,
				success: function(oData) {
					var dataHeader = oData.results[0];
					var plantCode = oData.results[0].Plant;
					this.plant = oData.results[0].Plant;
					//	this.loadingUnloadingPointReadCall(plantCode);
					this.getView().getModel("TripModel").setData(dataHeader);
					this.getView().getModel("TripOBDModel").setProperty("/Items", oData.results);
					this.tripNumber = this.getView().getModel("TripModel").getProperty("/TripNumber");
					this.tripStatus = this.getView().getModel("TripModel").getProperty("/TripStatus");
					/*aFilters.push(new Filter({
						path: "TripNumber",
						value1: this.tripNumber,
						operator: FilterOperator.EQ
					}));*/
					if (this.tripStatus !== "" || this.tripStatus !== undefined) {
						this.attachmentsSection();
						this.callNotes();
					}
					this.callEnableDisableFunction();
					if (oData.results[0].ImageFileName) {
						this.setImageSource("idImageGateOut", oData.results[0].ImageFileName);
					}
					if (oData.results[0].DriverPhoto) {
						this.setImageSource("idDriverPhotoImage", oData.results[0].DriverPhoto);
					}
					if (oData.results[0].LoadPicPhase1) {
						this.setImageSource("idLoadingPhase1Image", oData.results[0].LoadPicPhase1);
					}
					if (oData.results[0].LoadPicPhase2) {
						this.setImageSource("idLoadingPhase2Image", oData.results[0].LoadPicPhase2);
					}
					if (oData.results[0].LoadPicPhase3) {
						this.setImageSource("idLoadingPhase3Image", oData.results[0].LoadPicPhase3);
					}
					if (oData.results[0].LoadPicPhase4) {
						this.setImageSource("idLoadingPhase4Image", oData.results[0].LoadPicPhase4);
					}
					if (oData.results[0].LoadPicPhase5) {
						this.setImageSource("idLoadingPhase5Image", oData.results[0].LoadPicPhase5);
					}
					if (oData.results[0].LoadPicPhase6) {
						this.setImageSource("idLoadingPhase6Image", oData.results[0].LoadPicPhase6);
					}
					this.vehicleType = this.getView().getModel("TripModel").getProperty("/VehicleType");
					this.vehicle = this.getView().getModel("TripModel").getProperty("/VehTypeDesc");
					if (this.vehicleType === "YB16") {
						this.getView().getModel("EnableDisableModel").setProperty("/Select", true);
						this.getView().getModel("EnableDisableModel").setProperty("/SelectWidth", "8rem");
					} else {
						this.getView().getModel("EnableDisableModel").setProperty("/Select", false);
						this.getView().getModel("EnableDisableModel").setProperty("/SelectWidth", "0rem");
					}
					var ship = this.getView().getModel("TripModel").getProperty("/ShipmentNo");
					var shipLength = ship.length;
					for (var c = 0; c < 10 - shipLength; c++) {
						ship = "0" + ship;
					}
					/*var contListHdr = dataHeader.ContainerList.split(",");
					for (var contLoop = 0; contLoop < contItems.length; contLoop++) {
						for (var inspItems = 0; inspItems < contListHdr.length; inspItems++) {
							if (contListHdr[inspItems].ContainerNo === contItems[contLoop].getCells()[0].getText()) {
								contItems[contLoop].getCells()[2].setSelected(true);
							}
						}
					}*/

					this.getOwnerComponent().getModel().read("/PLMS_Vehicle_InspectionSet", {
						filters: aStatusFilter,
						success: function(oInspData) {
							var data = oInspData.results;
							if (data.length > 0) {
								vehType = data[0].VehicleTypeDesc;
								if (this.vehicleType === "YB16") {
									this.getView().getModel("InspectionModel").setProperty("/Items", data);
									this.NoofContainers = this.getView().getModel("InspectionModel").getProperty("/Items").length;
									if (this.tripNumber !== "0000000000" && this.tripNumber !== undefined) {
										this.getView().byId("idOverAllCheckPoints").destroyContent();
										var contData1 = this.getView().getModel("InspectionModel").getProperty("/Items");
										if (contData1.length > 0) {
											for (var g = 0; g < contData1.length; g++) {
												this.createContainerCheckListPanel(contData1[g].ContainerBoxNo, contData1[g].ContainerNo, g);
											}
										}
									}
								} else {
									this.getView().getModel("InspectionModel").setData(data[0]);
								}
								if (vehType === "Truck") {
									if (oInspData.results[0].ContCleanImgFileName) {
										this.setImageSource("idTruckCanvasCheckImage", oInspData.results[0].ContCleanImgFileName);
									}
									if (oInspData.results[0].RubberLeakFileName) {
										this.setImageSource("idRopeImage", oInspData.results[0].RubberLeakFileName);
									}
									if (oInspData.results[0].ContImageFile) {
										this.setImageSource("idFWImage", oInspData.results[0].ContImageFile);
									}
									if (oInspData.results[0].VehImageFileName) {
										this.setImageSource("idVehicleImage", oInspData.results[0].VehImageFileName);
									}
									if (oInspData.results[0].FumigationImgFileName) {
										this.setImageSource("idBodyImage", oInspData.results[0].FumigationImgFileName);
									}
									if (oInspData.results[0].ContLoadedImgFileName) {
										this.setImageSource("idVehicleCleanImage", oInspData.results[0].ContLoadedImgFileName);
									}
								}
								if (vehType === "Tank lorry") {
									if (oInspData.results[0].VehImageFileName) {
										this.setImageSource("idTankerCleanImage", oInspData.results[0].VehImageFileName);
									}
									if (oInspData.results[0].RubberLeakFileName) {
										this.setImageSource("idBottomSealImage", oInspData.results[0].RubberLeakFileName);
									}
									if (oInspData.results[0].ContImageFile) {
										this.setImageSource("idForeignImage", oInspData.results[0].ContImageFile);
									}
									if (oInspData.results[0].FumigationImgFileName) {
										this.setImageSource("idCSCImage", oInspData.results[0].FumigationImgFileName);
									}
									if (oInspData.results[0].ContWeightImgFileName) {
										this.setImageSource("idTankerRSImage", oInspData.results[0].ContWeightImgFileName);
									}
									if (oInspData.results[0].ContReadyImgFileName) {
										this.setImageSource("idTankWBImage", oInspData.results[0].ContReadyImgFileName);
									}
									if (oInspData.results[0].FumigationDoneImgFileName) {
										this.setImageSource("idTankStuffingImage", oInspData.results[0].FumigationDoneImgFileName);
									}
								}
								if (this.vehicleType === "YB16") {
									var checkPointPanel = this.getView().byId("idOverAllCheckPoints");
									var noofContainers = checkPointPanel.getContent().length;
									var oItems = this.getView().getModel("InspectionModel").getProperty("/Items");
									for (var o = 0; o < noofContainers; o++) {
										var headerTxt = checkPointPanel.getContent()[o].getHeaderText().split(":")[1].toString();
										if (headerTxt.includes(oItems[o].ContainerNo)) {
											this.setImageSourceContainer(checkPointPanel.getContent()[o], oItems[o]);
										}
									}
									/*	var contItems = this.getView().byId("idContainerNumber").getItems();
										for (var contLoop = 0; contLoop < contItems.length; contLoop++) {
											for (var inspItems = 0; inspItems < data.length; inspItems++) {
												if (data[inspItems].ContainerNo === contItems[contLoop].getCells()[0].getText()) {
													contItems[contLoop].getCells()[2].setSelected(true);
												}
											}
										}*/
								}
							}
							this.getView().setBusy(false);
						}.bind(this),
						error: function(error) {
							MessageBox.error("Inspection Pending");
						}.bind(this)
					});
					if (this.vehicleType === "YB16") {
						var aShipFilters = [],
							aShipStatusFilter = [];
						aShipFilters.push(new Filter({
							path: "Tknum",
							value1: ship,
							operator: FilterOperator.EQ
						}));
						var oShipFilter = new Filter(aShipFilters, true);
						aShipStatusFilter.push(oShipFilter);
						var contItems = this.getView().byId("idContainerNumber").getItems();
						var selLength = contItems.length;
						for (var self = 0; self < selLength; self++) {
							contItems[self].getCells()[2].setSelected(false);
						}
						this.getOwnerComponent().getModel().read("/GetContainersListSet", {
							filters: aShipStatusFilter,
							success: function(oContData) {
								var contData = oContData.results;
								this.NoofContainers = oContData.results.length;
								this.getView().getModel("ContainerNoModel").setProperty("/Items", oContData.results);
								if (this.tripStatus === "") {
									if (this.NoofContainers > 0) {
										for (var kk = 0; kk < this.NoofContainers; kk++) {
											this.createContainerCheckListPanel(contData[kk].SerialNo, contData[kk].ContainerNo, 0);
										}
									} else {
										MessageBox.error("No Containers are available");
									}
								}
								var contItems = this.getView().byId("idContainerNumber").getItems();
								var contListHdr = dataHeader.ContainerList.split(",");
								for (var contLoop = 0; contLoop < contData.length; contLoop++) {
									for (var inspItems = 0; inspItems < contListHdr.length; inspItems++) {
										if (contListHdr[inspItems] === contData[contLoop].ContainerNo) {
											contItems[contLoop].getCells()[2].setSelected(true);
										}
									}
								}
							}.bind(this)
						});
					}
					this.getView().setBusy(false);
					this.contNo = this.getView().getModel("TripModel").getProperty("/ContainerNo");
					if (!this.tripNumber) {
						this.tripNumber = "0000000000";
					}
					this.getView().byId("idLoadingMaterialsTab").destroyContent();
					this.getView().byId("idLoadingUnloading").destroyContent();
					this.getView().byId("idGateInMainPanel").destroyContent();
					for (var mm = 0; mm < oData.results.length; mm++) {
						this.createLoadingMaterialsTabContent(mm);
						this.createGateInTabContent(mm);
						this.createLoadingUnloadingMaterialsTabContent(mm);
					}
					var aTimeGuideFilters = [],
						aTimeGuideStatusFilter = [];
					aTimeGuideFilters.push(new Filter({
						path: "Werks",
						value1: plantCode,
						operator: FilterOperator.EQ
					}));
					var oTimeGuideFilter = new Filter(aTimeGuideFilters, true);
					aTimeGuideStatusFilter.push(oTimeGuideFilter);
					this.getOwnerComponent().getModel().read("/TimeGuideLineSet", {
						filters: aTimeGuideStatusFilter,
						success: function(oGuideData) {
							this.getView().getModel("TimeGuideModel").setProperty("/Items", oGuideData.results);
							this.onAnalysisTabPress();
							//	this.timeLineUpdate();
						}.bind(this),
						error: function(oGuideError) {
							MessageBox.error("Error in getting Time Guide Data");
						}
					});
				}.bind(this),
				error: function(error) {
					MessageBox.error("No found for this OBDNumber");
					this.getView().setBusy(false);
				}.bind(this)
			});
			/*setTimeout(function() {
				this.getOwnerComponent().getModel().read("/PLMS_Obd_ItemSet", {
					filters: aStatusFilter,
					success: function(oLoadingBatchData) {
						this.getView().getModel("LoadingItemsBatchModel").setProperty("/Items", oLoadingBatchData.results);
					}.bind(this)
				});
			}.bind(this), 3000);*/
			this.getView().byId("idIconTabBar").setSelectedKey("01");
			if (this.tripNumber !== "0000000000" && this.tripNumber) {
				var aItemFilters = [],
					aItemsAllFilters = [];
				aItemFilters.push(new Filter({
					path: "TruckNumber",
					value1: this.truckNumber,
					operator: FilterOperator.EQ
				}));
				aItemFilters.push(new Filter({
					path: "TripNumber",
					value1: this.tripNumber,
					operator: FilterOperator.EQ
				}));
				var oItemFilter = new Filter(aItemFilters, true);
				aItemsAllFilters.push(oItemFilter);
				this.getOwnerComponent().getModel().read("/PLMS_Obd_ItemSet", {
					filters: aItemsAllFilters,
					success: function(oItemsData) {
						this.getView().getModel("LoadingItemsBatchModel").setProperty("/Items", oItemsData.results);
						aItemFilters.push(new Filter({
							path: "BatchAdded",
							value1: "000",
							operator: FilterOperator.EQ
						}));
						this.getOwnerComponent().getModel().read("/PLMS_Obd_ItemSet", {
							filters: aItemsAllFilters,
							success: function(oBatchData) {
								this.getView().getModel("LoadingItemsModel").setProperty("/Items", oBatchData.results);
							}.bind(this)
						});
					}.bind(this)
				});
			}
		},
		goToMain: function() {
			var data = this.getView().getModel("InspectionModel").getProperty("/Items");
			var aTripFilters = [],
				aTripStatusFilter = [];
			aTripFilters.push(new Filter({
				path: "ObdDate",
				value1: new Date("01/01/2019"),
				operator: FilterOperator.GT
			}));
			aTripFilters.push(new Filter({
				path: "ObdDate",
				value1: new Date(),
				operator: FilterOperator.LT
			}));
			var plantValues = this.getOwnerComponent().getModel("PlantModel").getProperty("/plantValues");
			var selectedPlant = this.getOwnerComponent().getModel("PlantModel").getProperty("/selectedPlant");
			if (selectedPlant) {
				aTripFilters.push(new Filter({
					path: "Plant",
					value1: selectedPlant,
					operator: FilterOperator.EQ
				}));
			} else {

				//soc by Bhavesh
				// aTripFilters.push(new Filter({
				// 	path: "Plant",
				// 	value1: plantValues[].PlantCode,
				// 	operator: FilterOperator.EQ
				// }));
				var plantFilters = [];
				// Iterate over plantValues and create filters
				plantValues.forEach(function(plant) {
					plantFilters.push(new Filter({
						path: "Plant",
						value1: plant.PlantCode,
						operator: FilterOperator.EQ
					}));
				});
				// Combine all filters with an OR condition
				var combinedFilter = new Filter({
					filters: plantFilters,
					and: false // 'false' means OR condition
				});
				// Push the combined filter to aTripFilters
				aTripFilters.push(combinedFilter);
			}
			var oTripFilter = new Filter(aTripFilters, true);
			aTripStatusFilter.push(oTripFilter);
			// var selectedFilter = this.getOwnerComponent().getModel("TripDisplayModel").getProperty("obdNo");
			// if (aTripStatusFilter) {
			// 	aTripFilters.push(new Filter({
			// 		path: "ObdNumber",
			// 		value1: aTripStatusFilter,
			// 		operator: FilterOperator.EQ
			// 	}));
			// }
			// // selectedFilter = this.getOwnerComponent().getModel("TripDisplayModel").getProperty("vehNum");
			// if (aTripStatusFilter) {
			// 	aTripFilters.push(new Filter({
			// 		path: "TruckNumber",
			// 		value1: aTripStatusFilter,
			// 		operator: FilterOperator.EQ
			// 	}));
			// }
			// // selectedFilter = this.getOwnerComponent().getModel("TripDisplayModel").getProperty("status");
			// if (aTripStatusFilter) {
			// 	aTripFilters.push(new Filter({
			// 		path: "TripStatus",
			// 		value1: aTripStatusFilter,
			// 		operator: FilterOperator.EQ
			// 	}));
			// }
			//Eoc of Bhavesh  
			if (data) {
				this.getView().byId("idOverAllCheckPoints").destroyContent();
			}
			this.getView().byId("idReportDetailsPanel").setExpanded(false);
			this.getView().byId("idTruckInspectionPanel").setExpanded(false);
			this.getView().byId("idTankerInspectionPanel").setExpanded(false);
			this.getView().byId("idContainerInspectionPanel").setExpanded(false);
			this.getView().byId("idLoadingMaterialsTab").destroyContent();
			this.getView().byId("idLoadingUnloading").destroyContent();
			this.getView().byId("idGateInMainPanel").destroyContent();
			this.getView().byId("idReportingAttachmentsPanel").destroyContent();
			this.getView().byId("idInspectionAttachmentsPanel").destroyContent();
			this.getView().byId("idGateOutAttachmentsPanel").destroyContent();
			this.getView().byId("idLoadingAttachmentsPanel").destroyContent();
			this.getView().byId("idTruckCanvasCheckImage").setSrc("");
			this.getView().byId("idRopeImage").setSrc("");
			this.getView().byId("idFWImage").setSrc("");
			this.getView().byId("idVehicleImage").setSrc("");
			this.getView().byId("idBodyImage").setSrc("");
			this.getView().byId("idVehicleCleanImage").setSrc("");
			this.getView().byId("idTankerCleanImage").setSrc("");
			this.getView().byId("idBottomSealImage").setSrc("");
			this.getView().byId("idForeignImage").setSrc("");
			this.getView().byId("idCSCImage").setSrc("");
			this.getView().byId("idTankerRSImage").setSrc("");
			/*	this.getView().byId("idTankStuffingImage").setSrc("");*/
			this.getView().byId("idLoadingPhase1Image").setSrc("");
			this.getView().byId("idLoadingPhase2Image").setSrc("");
			this.getView().byId("idLoadingPhase3Image").setSrc("");
			this.getView().byId("idLoadingPhase4Image").setSrc("");
			this.getView().byId("idDriverPhotoImage").setSrc("");
			this.getView().byId("idDriverPhotoFileUpload").setValue("");
			this.getView().byId("idImageGateOut").setSrc("");
			// if (this.tripStatus === "CL") {
			// 	var contItems = this.getView().byId("idContainerNumber").getItems();
			// 	var contRows = contItems.length;
			// 	for (var kk = 0; kk < contRows; kk++) {
			// 		contItems[kk].getCells[2].setEnabled(true);
			// 		contItems[kk].getCells[2].setSelected(false);
			// 	}
			// }
			var oRouter = this.getOwnerComponent().getRouter();
			this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
				filters: aTripStatusFilter,
				urlParameters: {
					"$expand": "ZHDR_HDR"
				},
				success: function(oData) {
					var results = oData.results;
					this.getOwnerComponent().getModel("TripDisplayModel").setProperty("/Items", results);
					this.getOwnerComponent().getModel("TripDisplayModel").refresh(true);
					oRouter.navTo("view1", {}, true);
				}.bind(this),
				error: function(error) {
					MessageBox.error("No data is available for selected filters.Please select valid Filters");
					oRouter.navTo("view1", {}, true);
				}.bind(this)
			});
			/*var oRouter = this.getOwnerComponent().getRouter();
			oRouter.navTo("view1", {}, true);*/
		},
		onPressAllowGateIn: function(oEvent) {
			if (this.tripStatus === "IC") {
				var rem = this.getView().byId("idGateInRemarks").getSelectedKey();
				var aLoadingGatePayload = [];
				var oPanel = this.getView().byId("idLoadingMaterialsTab");
				var oContent = oPanel.getContent();
				for (var i = 0; i < oContent.length; i++) {
					var oInnerContent = oContent[i].getContent()[0].getItems();
					for (var k = 0; k < oInnerContent.length; k++) {
						var loadingGate = oInnerContent[k].getCells()[6].getSelectedKey();
						var obdNo = oInnerContent[k].getCells()[1].getText();
						var obdLeng = obdNo.length;
						if (obdLeng !== 10) {
							for (var g = 0; g < 10 - obdLeng; g++) {
								obdNo = "0" + obdNo;
							}
						}
						var lGort = oInnerContent[k].getCells()[8].getText();
						var obdItem = oInnerContent[k].getCells()[7].getText();
						var jsonObj = {
							Lstel: loadingGate,
							ObdNumber: obdNo,
							ObdItem: obdItem,
							Lgort: lGort,
							TripNumber: this.tripNumber,
							TruckNumber: this.truckNumber
						};
						aLoadingGatePayload.push(jsonObj);
					}
				}
				if (aLoadingGatePayload.length > 0) {
					var oModel = this.getOwnerComponent().getModel();
					oModel.setUseBatch(true);
					var aDeferredGroups = oModel.getDeferredGroups();
					aDeferredGroups = aDeferredGroups.concat(["UpdateGateGroup"]);
					oModel.setDeferredGroups(aDeferredGroups);
					for (var j = 0; j < aLoadingGatePayload.length; j++) {
						oModel.update("/PLMS_Obd_ItemSet(TruckNumber='" + this.truckNumber + "',ObdNumber='" + aLoadingGatePayload[j].ObdNumber +
							"',TripNumber='" + this.tripNumber + "',BatchAdded='" + "000" + "',ObdItem='" + aLoadingGatePayload[j].ObdItem +
							"',Lgort='" +
							aLoadingGatePayload[j].Lgort + "')", aLoadingGatePayload[j], {
								groupId: "UpdateGateGroup"
							});
					}
					oModel.submitChanges({
						groupId: "UpdateGateGroup",
						success: function(req, res) {
							oModel.setUseBatch(false);
							if (rem !== "") {
								var payload = {
									"Gatein": "X",
									"GateinRemarks": rem,
									"TripStatus": "GI"
								};
								this.getOwnerComponent().getModel().update("/PLMS_outbound_HdrSet(TruckNumber='" + this.truckNumber + "',ObdNumber='" +
									this
									.obdNumber +
									"',TripNumber='" + this.tripNumber + "')", payload, {
										method: "PUT",
										success: function(response) {
											MessageBox.success("Gate-In have been updated successfully", {
												onClose: function() {
													this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
														filters: this.aStatusFilter,
														success: function(oData) {
															this.getView().getModel("TripModel").setData(oData.results[0]);
															this.getView().getModel("TripModel").refresh(true);
															this.tripStatus = this.getView().getModel("TripModel").getData().TripStatus;
															this.timeLineUpdate();
															this.getView().byId("idLoadingMaterialsTab").destroyContent();
															this.getView().byId("idLoadingUnloading").destroyContent();
															var oItems = this.getView().getModel("TripOBDModel").getProperty("/Items");
															for (var ee = 0; ee < oItems.length; ee++) {
																this.createLoadingMaterialsTabContent(ee);
																this.createLoadingUnloadingMaterialsTabContent(ee);
															}
														}.bind(this),
														error: function() {
															MessageBox.warning("Error occurred while reading Header data");
														}
													});
												}.bind(this)
											});
										}.bind(this),
										error: function(error) {
											MessageBox.warning("Error occurred while updating the data");
										}.bind(this)
									});
							} else {
								MessageBox.error("Remarks are mandatory");
							}
						}.bind(this),
						error: function(oGateinError) {
							MessageBox.error("Error");
						}
					});
				}
			} else if (this.tripStatus === "WP" || this.tripStatus === "WC" || this.tripStatus === "LP" || this.tripStatus === "LC" || this
				.tripStatus ===
				"GO") {
				MessageBox.error("Gate -In is already Completed");
			} else {
				MessageBox.error("Gate -In is allowed only after Inspection is Completed");
			}
		},
		handleOverallImageChange: function(oEvent) {
			this.overAllFileName = oEvent.getParameter("files")[0].name;
			this.overAllFileType = oEvent.getParameter("files")[0].type;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idOverallImage").setSrc(path);
			}
		},
		resolveTimeDifference: function(dateTime) {
			if (dateTime !== undefined && dateTime !== null && dateTime !== "") {
				var offSet = dateTime.getTimezoneOffset();
				var offSetVal = dateTime.getTimezoneOffset() / 60;
				var h = Math.floor(Math.abs(offSetVal));
				var m = Math.floor((Math.abs(offSetVal) * 60) % 60);
				dateTime = new Date(dateTime.setHours(h, m, 0, 0));
				return dateTime;
			}
			return null;
		},
		createLoadingUnloadingMaterialsTabContent: function(i) {
			if (this.tripNumber !== "0000000000" && this.tripNumber) {
				var obdNo = this.getView().getModel("TripOBDModel").getData().Items[i].ObdNumber;
				var count = obdNo.length;
				var setEnableDisable = this.getView().getModel("EnableDisableModel");
				if (count !== 10) {
					for (var h = 0; h < 10 - count; h++) {
						obdNo = "0" + obdNo;
					}
				}
				var cutName = this.getView().getModel("TripOBDModel").getData().Items[i].Name1;
				var aItemFilters = [],
					aItemsAllFilters = [];
				aItemFilters.push(new Filter({
					path: "TruckNumber",
					value1: this.truckNumber,
					operator: FilterOperator.EQ
				}));
				aItemFilters.push(new Filter({
					path: "TripNumber",
					value1: this.tripNumber,
					operator: FilterOperator.EQ
				}));
				aItemFilters.push(new Filter({
					path: "ObdNumber",
					value1: obdNo,
					operator: FilterOperator.EQ
				}));
				/*	aItemFilters.push(new Filter({
						path: "CombinedFlag",
						value1: "false",
						operator: FilterOperator.EQ
					}));*/
				var oItemFilter = new Filter(aItemFilters, true);
				aItemsAllFilters.push(oItemFilter);
				this.getOwnerComponent().getModel().read("/PLMS_Obd_ItemSet", {
					filters: aItemsAllFilters,
					success: function(oData) {
						this.plantCode = oData.results[0].Werks;
						this.NoofLineItems = oData.results.length;
						var panelHeader = "OBD Number :" + obdNo + "(" + cutName + ")";
						var tableLULid = "id" + obdNo + "LULTable";
						var panelLULId = "id" + obdNo + "LULPanel";
						var oLULTable = new sap.m.Table(tableLULid, {
							columns: [
								new sap.m.Column({
									header: new sap.m.Text({
										text: "Material Description"
									}),
									width: "8rem"
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "ObdItem"
									}),
									width: "5rem"
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "Storage Location"
									}),
									width: "5rem"
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "Qty to Deliver"
									}),
									width: "5rem"
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "UOM"
									}),
									width: "3rem"
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "Container No"
									}),
									visible: setEnableDisable.getProperty("/Select"),
									width: setEnableDisable.getProperty("/SelectWidth")
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "Batch"
									}),
									width: "9rem"
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "Type"
									}),
									width: "4rem"
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "Qty"
									}),
									width: "4rem"
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "Check Weight"
									}),
									width: "6rem"
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "Cumulative Weight"
									}),
									width: "6rem"
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "Cumulative Qty"
									}),
									width: "6rem"
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "Edit"
									}),
									width: "3rem"
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "Save"
									}),
									width: "3rem"
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "Add Item"
									}),
									width: "3rem"
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "Weighment Status"
									}),
									width: "7rem"
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "BatchAdded"
									}),
									visible: false
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "SaveIndex"
									}),
									visible: false
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "Matnr"
									}),
									visible: false
								})
							]
						});
						for (var u = 0; u < oData.results.length; u++) {
							var aColListLUL = this.createLULTableRows(u, oData.results, obdNo);
							oLULTable.addItem(aColListLUL);
						}
						this.oLULTable = oLULTable;
						var oLULPanel = new sap.m.Panel({
							id: panelLULId,
							headerText: panelHeader,
							expanded: true,
							expandable: true,
							content: [oLULTable /*oFlex*/ ]
						});
						this.getView().byId("idLoadingUnloading").addContent(oLULPanel);
					}.bind(this),
					error: function(error) {

					}
				});
			}
		},
		createGateInTabContent: function(i) {
			if (this.tripNumber !== "0000000000" && this.tripNumber) {
				var obdNo = this.getView().getModel("TripOBDModel").getData().Items[i].ObdNumber;
				var count = obdNo.length;
				var setEnableDisable = this.getView().getModel("EnableDisableModel");
				if (count !== 10) {
					for (var h = 0; h < 10 - count; h++) {
						obdNo = "0" + obdNo;
					}
				}
				var cutName = this.getView().getModel("TripOBDModel").getData().Items[i].Name1;
				var aItemFilters = [],
					aItemsAllFilters = [];
				aItemFilters.push(new Filter({
					path: "TruckNumber",
					value1: this.truckNumber,
					operator: FilterOperator.EQ
				}));
				aItemFilters.push(new Filter({
					path: "TripNumber",
					value1: this.tripNumber,
					operator: FilterOperator.EQ
				}));
				aItemFilters.push(new Filter({
					path: "ObdNumber",
					value1: obdNo,
					operator: FilterOperator.EQ
				}));
				aItemFilters.push(new Filter({
					path: "BatchAdded",
					value1: "000",
					operator: FilterOperator.EQ
				}));
				aItemFilters.push(new Filter({
					path: "CombinedFlag",
					value1: false,
					operator: FilterOperator.EQ
				}));
				var oItemFilter = new Filter(aItemFilters, true);
				aItemsAllFilters.push(oItemFilter);
				var combinedWeight = false;
				var combinedRecordIndex;
				this.getOwnerComponent().getModel().read("/PLMS_Obd_ItemSet", {
					filters: aItemsAllFilters,
					success: function(oData1) {
						for (var f = 0; f < oData1.results.length; f++) {
							if (oData1.results[f].CombinedFlag) {
								combinedWeight = true;
								combinedRecordIndex = f;
								break;
							}
						}
						this.getView().getModel("LoadingItemsModel").setProperty("/CombinedWeight", combinedWeight);
						if (combinedRecordIndex !== undefined) {
							this.getView().getModel("LoadingItemsModel").setProperty("/GrossWeight", oData1.results[combinedRecordIndex].VehGrossWeight);
							this.getView().getModel("LoadingItemsModel").setProperty("/TareWeight", oData1.results[combinedRecordIndex].VehTareWeight);
							this.getView().getModel("LoadingItemsModel").setProperty("/NetWeight", oData1.results[combinedRecordIndex].VehNetWeight);
						}
						/*	aItemFilters.push(new Filter({
								path: "CombinedFlag",
								value1: false,
								operator: FilterOperator.EQ
							}));*/
						this.getOwnerComponent().getModel().read("/PLMS_Obd_ItemSet", {
							filters: aItemsAllFilters,
							success: function(oData) {
								this.itemOdata = oData;
								this.plantCode = oData.results[0].Werks;
								var panelHeader = "OBD Number :" + obdNo + "(" + cutName + ")";
								var tableGateInId = "id" + obdNo + "GateInTable1";
								var panelGateInId = "id" + obdNo + "GateInPanel";
								var gateInSubmit = "id" + obdNo + "Submit";
								var oGateInTable = new sap.m.Table(tableGateInId, {
									columns: [
										new sap.m.Column({
											header: new sap.m.Text({
												text: "Line-Item"
											}),
											width: "4rem"
										}), new sap.m.Column({
											header: new sap.m.Text({
												text: "Material Description"
											}),
											width: "7rem"
										}),
										new sap.m.Column({
											header: new sap.m.Text({
												text: "Gross Weight(KG)"
											}),
											width: "7rem"
										}),
										new sap.m.Column({
											header: new sap.m.Text({
												text: "Tare Weight(KG)"
											}),
											width: "7rem"
										}),
										new sap.m.Column({
											header: new sap.m.Text({
												text: "Net Weight(KG)"
											}),
											width: "7rem"
										}),
										new sap.m.Column({
											header: new sap.m.Text({
												text: "Accept"
											}),
											width: "7rem"
										}),
										new sap.m.Column({
											header: new sap.m.Text({
												text: "Reject"
											}),
											width: "7rem"
										}),
										new sap.m.Column({
											header: new sap.m.Text({
												text: "Remarks Reasons"
											}),
											width: "8rem"
										}),
										new sap.m.Column({
											header: new sap.m.Text({
												text: "Storage loaction"
											}),
											visible: false
										}),
										new sap.m.Column({
											header: new sap.m.Text({
												text: "Dispatch Quantity"
											}),
											visible: false
										}),
										new sap.m.Column({
											header: new sap.m.Text({
												text: "UOM"
											}),
											visible: false
										}),
										new sap.m.Column({
											header: new sap.m.Text({
												text: "OBD NO"
											}),
											visible: false
										})
									]
								});
								for (var v = 0; v < oData.results.length; v++) {
									var aColListGateIn = this.createGateInTableRows(v, oData.results, obdNo);
									oGateInTable.addItem(aColListGateIn);
								}
								var srccW = "";
								var tripOBDItems = this.getView().getModel("TripOBDModel").getProperty("/Items");
								var tripOBDLength = tripOBDItems.length;
								for (var q = 0; q < tripOBDLength; q++) {
									if ("00" + tripOBDItems[q].ObdNumber === obdNo) {
										srccW = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + obdNo + "'" + "," + "FileName=" +
											"'" +
											tripOBDItems[q].WtFileName + "'" + ")/$value";
									}
								}
								var oGateInPanel = new sap.m.Panel({
									id: panelGateInId,
									headerText: panelHeader,
									expanded: true,
									expandable: true,
									content: [oGateInTable /*, oGateInFlex*/ ]
								});
								this.getView().byId("idGateInMainPanel").addContent(oGateInPanel);
							}.bind(this),
							error: function(error) {

							}
						});
					}.bind(this),
					error: function(error) {

					}
				});
			}
		},
		createTableRows: function(i, results) {
			var oCell = [];
			oCell[0] = new sap.m.Text({
				text: results[i].SalesOrder
			});
			oCell[1] = new sap.m.Text({
				text: results[i].ObdNumber
			});
			oCell[2] = new sap.m.Text({
				text: results[i].Matnr
			});
			oCell[3] = new sap.m.Text({
				text: results[i].Maktx
			});
			oCell[4] = new sap.m.Text({
				text: results[i].Quantity
			});
			oCell[5] = new sap.m.Text({
				text: results[i].Meins
			});
			oCell[6] = new sap.m.Select({
				selectedKey: results[i].Lstel,
				enabled: this.enableLoadingGate(),
				width: "13rem"
			});
			oCell[7] = new sap.m.Text({
				text: results[i].ObdItem,
				visible: false
			});
			oCell[8] = new sap.m.Text({
				text: results[i].Lgort,
				visible: false
			});
			this.loadingUnloadingPointReadCall(oCell[6]);
			var aColList = new sap.m.ColumnListItem({
				cells: oCell
			});
			return aColList;
		},
		createLULTableRows: function(i, results, obdNo) {
			var setEnableDisable = this.getView().getModel("EnableDisableModel");
			var oCell = [];
			oCell[0] = new sap.m.Text({
				text: results[i].Maktx
			});
			oCell[1] = new sap.m.Text({
				text: results[i].ObdItem
			});
			oCell[2] = new sap.m.Text({
				text: results[i].Lgort
			});
			oCell[3] = new sap.m.Text({
				text: results[i].Quantity
			});
			oCell[4] = new sap.m.Text({
				text: results[i].SalesUnit
			});
			oCell[5] = new sap.m.Select({
				visible: setEnableDisable.getProperty("/Select"),
				width: setEnableDisable.getProperty("/SelectWidth"),
				selectedKey: results[i].ContainerNo,
				enabled: this.checkLoadingUnloadingLineItems(results[i].WeighStatus)
			});
			this.addContainersToSelect(oCell[5]);
			oCell[6] = new sap.m.Input({
				value: results[i].Batch,
				width: "9rem",
				valueHelpRequest: function(oEvent) {
					var material = results[i].Matnr;
					var plant = results[i].Werks;
					var stLoc = results[i].Lgort;
					this.batchInput = oEvent.getSource();
					if (results[i].BatchEnabled) {
						this.readBatchF4Values(material, plant, stLoc);
						if (!this.dialogBatchNo) {
							this.dialogBatchNo = sap.ui.xmlfragment(this.getView().getId(), "ZSonic_PLMS.view.Fragment.BatchcNoFragment", this);
							this.getView().addDependent(this.dialogBatchNo);
						}
						this.dialogBatchNo.open();
					}
				}.bind(this),
				enabled: this.checkLoadingUnloadingLineItemsBatchEnabled(results[i].BatchEnabled, results[i].WeighStatus), //setEnableDisable.getProperty("/LoadingEditSaveandSubmitButtons"),
				showValueHelp: true
			});
			oCell[7] = new sap.m.Input({
				value: results[i].BagType,
				enabled: this.checkLoadingUnloadingLineItems(results[i].WeighStatus), //setEnableDisable.getProperty("/LoadingEditSaveandSubmitButtons"),
				maxLength: 20
			});
			oCell[8] = new sap.m.Input({
				value: results[i].BagQuantity,
				maxLength: 10,
				enabled: this.checkLoadingUnloadingLineItems(results[i].WeighStatus)
					/*,
									change: function(oEvent) {
											var bags = oEvent.getSource().getValue();
											var chkW = oEvent.getSource().getParent().getCells()[9].getValue();
											var multi = bags * chkW;
											oEvent.getSource().getParent().getCells()[10].setText((multi.toString()));
										} setEnableDisable.getProperty("/LoadingEditSaveandSubmitButtons")*/
			});
			oCell[9] = new sap.m.Input({
				enabled: this.checkLoadingUnloadingLineItems(results[i].WeighStatus), //setEnableDisable.getProperty("/LoadingEditSaveandSubmitButtons"),
				value: results[i].BagsChkWeight
					/*,
									change: function(oEvent) {
										var bags = oEvent.getSource().getParent().getCells()[8].getValue();
										var chkW = oEvent.getSource().getValue();
										var multi = bags * chkW;
										oEvent.getSource().getParent().getCells()[10].setText((multi.toString()));
									}*/
			});
			oCell[10] = new sap.m.Text({
				width: "7rem",
				text: results[i].SumChkWt
			});
			oCell[11] = new sap.m.Text({
				width: "7rem",
				text: this.removeLeadingZero(results[i].SumQty)
			});
			oCell[12] = new sap.m.Button({
				icon: "sap-icon://edit",
				type: "Emphasized",
				enabled: this.checkLoadingUnloadingLineItems(results[i].WeighStatus), //setEnableDisable.getProperty("/LoadingEditSaveandSubmitButtons"),
				press: function(oEvent1) {
					var oItems = oEvent1.getSource().getParent().getCells();
					if (results[i].BatchEnabled) {
						for (var t = 6; t < 10; t++) {
							oItems[t].setEnabled(true);
						}
					} else {
						for (var tt = 7; tt < 10; tt++) {
							oItems[tt].setEnabled(true);
						}
					}
				}.bind(this)
			});
			oCell[13] = new sap.m.Button({
				icon: "sap-icon://save",
				type: "Accept",
				enabled: this.checkLoadingUnloadingLineItems(results[i].WeighStatus), //setEnableDisable.getProperty("/LoadingEditSaveandSubmitButtons"),
				press: function(oEvent) {
					var oParent = oEvent.getSource().getParent();
					var combinedStatus = this.getView().getModel("TripModel").getData().CombinedWeightValue;
					if (combinedStatus === 0 || combinedStatus === undefined) {
						MessageBox.error("Please Save Combined Weight status");
					} else if (combinedStatus === 1) {
						this.saveLineItems(results, i, oParent, combinedStatus);
					} else {
						var aItemFilters = [],
							aItemsAllFilters = [];
						aItemFilters.push(new Filter({
							path: "TruckNumber",
							value1: this.truckNumber,
							operator: FilterOperator.EQ
						}));
						aItemFilters.push(new Filter({
							path: "TripNumber",
							value1: this.tripNumber,
							operator: FilterOperator.EQ
						}));
						var oItemFilter = new Filter(aItemFilters, true);
						aItemsAllFilters.push(oItemFilter);
						this.getOwnerComponent().getModel().read("/PLMS_Obd_ItemSet", {
							filters: aItemsAllFilters,
							success: function(oData) {
								var totalLineItems = oData.results;
								var anyOneLoaded = false;
								for (var qqq = 0; qqq < totalLineItems.length; qqq++) {
									if (totalLineItems[qqq].LineItemLoaded) {
										if (totalLineItems[qqq].WeighStatus === "" || totalLineItems[qqq].WeighStatus === undefined) {
											anyOneLoaded = true;
											break;
										}
									}
								}
								if (!anyOneLoaded) {
									//first line item loading
									this.saveLineItems(results, i, oParent, combinedStatus);
								} else {
									//if current lineitem is one among the already loaded line items
									var contains = false;
									for (var kkk = 0; kkk < totalLineItems.length; kkk++) {
										if (totalLineItems[kkk].LineItemLoaded) {
											if (totalLineItems[kkk].ObdItem === oParent.getCells()[1].getText()) {
												contains = true;
											}
										}
									}
									if (contains) {
										this.saveLineItems(results, i, oParent, combinedStatus);
									} else {
										var weighmentNotFinished = false;
										for (var hhh = 0; hhh < totalLineItems.length; hhh++) {
											if (totalLineItems[hhh].LineItemLoaded) {
												if (totalLineItems[hhh].WeighStatus === "" || totalLineItems[hhh].WeighStatus === undefined /*|| totalLineItems[hhh].WeighStatus === "REJECTED"*/ ) {
													weighmentNotFinished = true;
													break;
												}
											}
											if (totalLineItems[hhh].WeighStatus === "REJECTED") {
												weighmentNotFinished = true;
												break;
											}
										}
										if (weighmentNotFinished) {
											MessageBox.error("One of the Line Items is yet to be weighed.Please check again");
										} else {
											if (this.getView().getModel("TripModel").getData().TripStatus === "WR") {
												if (results[i].WeighStatus === "REJECTED") {
													this.saveLineItems(results, i, oParent, combinedStatus);
												} else {
													MessageBox.error("Please load the Rejected Line Item");
												}
											} else {
												this.saveLineItems(results, i, oParent, combinedStatus);

											}
										}
									}
								}
							}.bind(this),
							error: function(oError) {

							}
						});
					}
				}.bind(this)
			});
			oCell[14] = new sap.m.Button({
				icon: "sap-icon://add",
				enabled: this.enablePlus(results[i], results[i].WeighStatus),
				press: function(oEvent) {
					var oParent = oEvent.getSource().getParent();
					var lineItem = oParent.getCells()[1].getText();
					var NoofItems = 0;
					for (var d = 0; d < results.length; d++) {
						if (results[d].ObdItem === lineItem) {
							NoofItems = NoofItems + 1;
						}
					}
					var batchadded;
					if (NoofItems.toString().length === 1) {
						batchadded = "00" + NoofItems;
					}
					if (NoofItems.toString().length === 2) {
						batchadded = "0" + NoofItems;
					}
					if (NoofItems.toString().length === 3) {
						batchadded = "" + NoofItems;
					}
					var oNewItem = {
						"Maktx": oParent.getCells()[0].getText(),
						"ObdItem": oParent.getCells()[1].getText(),
						"Lgort": oParent.getCells()[2].getText(),
						"Quantity": oParent.getCells()[3].getText(),
						"SalesUnit": oParent.getCells()[4].getText(),
						"obdNo": obdNo,
						"Plant": results[i].Werks,
						"BatchAdded": batchadded,
						"Matnr": results[i].Matnr,
						"BatchEnabled": results[i].BatchEnabled,
						"WeighStatus": results[i].WeighStatus
					};
					oParent.getCells()[16].setText(batchadded);
					//	results.push(oNewItem);
					var oRow = this.createLULNewRow(oNewItem);
					//oEvent.getSource().getParent().getParent().addItem(oRow);
					var tableObject = oEvent.getSource().getParent().getParent();
					var items = tableObject.getItems();
					for (var kk = 0; kk < items.length; kk++) {
						tableObject.removeItem(items[kk]);
					}
					var finalItems = [],
						v, k, u = 0;
					for (v = 0; v < items.length; v++) {
						var obdItem = items[v].getCells()[1].getText();
						var newText = oRow.getCells()[1].getText();
						if (obdItem === newText) {
							finalItems.push(items[v]);
							finalItems.push(oRow);
							break;
						} else {
							finalItems.push(items[v]);
						}
						u = u + 1;
					}
					/*	var remLength = (items.length - v) - 1;
						for (k = v + 1; k <= remLength; k++) {
							finalItems.push(items[k]);
						}*/
					var remLength = (items.length - u) - 1;
					var newFinalLength = finalItems.length;
					for (k = 0; k < remLength; k++) {
						finalItems.push(items[newFinalLength + k - 1]);
					}
					for (var l = 0; l < finalItems.length; l++) {
						tableObject.addItem(finalItems[l]);
					}
				}.bind(this)
			});
			oCell[15] = new sap.m.Text({
				text: results[i].WeighStatus,
				width: "5rem"
			});
			oCell[16] = new sap.m.Text({
				text: results[i].BatchAdded,
				width: "5rem"
			});
			oCell[17] = new sap.m.Text({
				text: results[i].SaveIndex,
				width: "5rem"
			});
			oCell[18] = new sap.m.Text({
				text: results[i].Matnr,
				width: "5rem"
			});
			var aColList = new sap.m.ColumnListItem({
				cells: oCell
			});
			return aColList;
		},
		createGateInTableRows: function(i, results, obd) {
			var oCell = [];
			oCell[0] = new sap.m.Text({
				text: results[i].ObdItem,
				width: "4rem"
			});
			oCell[1] = new sap.m.Text({
				text: results[i].Maktx,
				width: "7rem"
			});
			oCell[2] = new sap.m.Input({
				value: results[i].VehGrossWeight,
				enabled: false, //this.checkEnableGrossWeight(results[i].ObdNumber, results[i].ObdItem),
				width: "7rem"
			});
			oCell[3] = new sap.m.Input({
				value: results[i].VehTareWeight,
				enabled: false, //this.checkEnableTareWeight(results[i].ObdNumber, results[i].ObdItem),
				width: "7rem"
			});
			oCell[4] = new sap.m.Input({
				enabled: false,
				value: results[i].VehNetWeight,
				width: "7rem"
			});
			oCell[5] = new sap.m.Button({
				type: "Accept",
				text: "Accept",
				press: function(oEvent) {
					var oParent = oEvent.getSource().getParent();
					var grossW = oParent.getCells()[2].getValue();
					var tareW = oParent.getCells()[3].getValue();
					var netW = oParent.getCells()[4].getValue();
					if (grossW !== "0.000" && tareW !== "0.000" && netW !== "0.000") {
						var payload = {
							"ObdItem": results[i].ObdItem,
							"WeighStatus": "ACCEPTED",
							"LineItemLoaded": false
						};
						this.getOwnerComponent().getModel().update("/PLMS_Obd_ItemSet(TruckNumber='" + this.truckNumber + "',ObdNumber='" + "00" +
							results[i].ObdNumber +
							"',TripNumber='" + this.tripNumber + "',BatchAdded='" + "000" + "',ObdItem='" + results[i].ObdItem +
							"',Lgort='" +
							results[i].Lgort + "')", payload, {
								success: function(oData2) {
									MessageBox.success("Weighment Accepted");
									var tripPayload;
									/*	if (this.loadingCompleted) {
											tripPayload = {
												"TripStatus": "LC"
											};
										} else {
											tripPayload = {
												"TripStatus": "LP"
											};
										}
										this.getOwnerComponent().getModel().update("/PLMS_outbound_HdrSet(TruckNumber='" + this.truckNumber +
											"',ObdNumber='" +
											this.obdNumber +
											"',TripNumber='" + this.tripNumber + "')", tripPayload, {
												success: function(oData1) {*/
									this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
										filters: this.aStatusFilter,
										success: function(oData) {
											this.getView().getModel("TripModel").setData(oData.results[0]);
											this.getView().getModel("TripOBDModel").setProperty("/Items", oData.results);
											this.tripStatus = this.getView().getModel("TripModel").getData().TripStatus;
											this.tripNumber = this.getView().getModel("TripModel").getData().TripNumber;
											this.timeLineUpdate();
											if (this.tripStatus !== "" && this.tripStatus !== undefined) {
												this.attachmentsSection();
											}
											this.getView().getModel("TripModel").refresh(true);
											this.callEnableDisableFunction();
											this.getView().byId("idLoadingUnloading").destroyContent();
											this.getView().byId("idGateInMainPanel").destroyContent();
											var oItems = this.getView().getModel("TripOBDModel").getProperty("/Items");
											for (var ee = 0; ee < oItems.length; ee++) {
												this.createGateInTabContent(ee);
												this.createLoadingUnloadingMaterialsTabContent(ee);
											}
										}.bind(this),
										error: function(oError) {
											MessageBox.warning("Error occurred while reading Header data");
										}
									});
									/*	}.bind(this),
										error: function(error) {
											MessageBox.error("error while updating the trip status");
										}
									});*/
								}.bind(this),
								error: function(oerror) {
									MessageBox.error("error while updating the weighment status");
								}
							});
					} else {
						MessageBox.error("Weights are Empty");
					}
				}.bind(this),
				enabled: this.checkWeightAcceptEnabled(results, i)
			});
			oCell[6] = new sap.m.Button({
				type: "Reject",
				text: "Reject",
				press: function(oEvent) {
					var oParent = oEvent.getSource().getParent();
					var grossW = oParent.getCells()[2].getValue();
					var tareW = oParent.getCells()[3].getValue();
					var netW = oParent.getCells()[4].getValue();
					this.resultOBDNo = results[i].ObdNumber;
					this.resultsObdItem = results[i].ObdItem;
					this.resultLgort = results[i].Lgort;
					if (grossW !== "0.000" && tareW !== "0.000" && netW !== "0.000") {
						if (!this.dialogUnlistedText) {
							this.dialogUnlistedText = sap.ui.xmlfragment(this.getView().getId(), "ZSonic_PLMS.view.Fragment.RejectionText", this);
							this.getView().addDependent(this.dialogUnlistedText);
						}
						this.dialogUnlistedText.open();
					} else {
						MessageBox.error("Weights are Empty");
					}
				}.bind(this),
				enabled: this.checkWeightRejectEnabled(results, i)
			});
			oCell[7] = new sap.m.Button({
				type: "Emphasized",
				text: "Reject Reasons List",
				press: function(oEvent) {
					var aItemFilters = [],
						aItemsAllFilters = [];
					aItemFilters.push(new Filter({
						path: "Traid",
						value1: this.truckNumber,
						operator: FilterOperator.EQ
					}));
					aItemFilters.push(new Filter({
						path: "TripNumber",
						value1: this.tripNumber,
						operator: FilterOperator.EQ
					}));
					aItemFilters.push(new Filter({
						path: "Vbeln",
						value1: /* this.obdNumber,*/ oEvent.getSource().getParent().getCells()[11].getText(),
						operator: FilterOperator.EQ
					}));
					aItemFilters.push(new Filter({
						path: "Posnr",
						value1: results[i].ObdItem,
						operator: FilterOperator.EQ
					}));
					var oItemFilter = new Filter(aItemFilters, true);
					aItemsAllFilters.push(oItemFilter);
					this.getOwnerComponent().getModel().read("/WeightCancelSet", {
						filters: aItemsAllFilters,
						success: function(oData) {
							var totalLineItems = oData.results;
							this.getView().getModel("RejectReasonModel").setProperty("/Items", totalLineItems);
							this.getView().getModel("RejectReasonModel").refresh(true);
						}.bind(this),
						error: function(oError) {
							MessageBox.error("Error in getting Reject Reasons");
						}
					});
					if (!this.dialogUnlisted) {
						this.dialogUnlisted = sap.ui.xmlfragment(this.getView().getId(), "ZSonic_PLMS.view.Fragment.RejectReasons", this);
						this.getView().addDependent(this.dialogUnlisted);
					}
					this.dialogUnlisted.open();
				}.bind(this),
				enabled: this.checkWeightRejectReasonsEnabled(results, i)
			});
			/*	oCell[5] = new sap.m.Select({
					enabled: this.checkGateinButtons(), //setEnableDisable.getProperty("/GateInEditSaveandSubmitButtons"),
					selectedKey: results[i].GrossWtCmt,
					width: "10rem"
				});
				this.addRemarksGateInDropDown(oCell[5]);
				oCell[6] = new sap.m.Button({
					icon: "sap-icon://edit",
					enabled: this.checkGateinButtons(), // setEnableDisable.getProperty("/GateInEditSaveandSubmitButtons"),
					press: function(oEvent) {
						var oItems = oEvent.getSource().getParent().getCells();
						var grsWt = oItems[2].getValue();
						var trWt = oItems[3].getValue();
						if (grsWt === "0.000" && trWt === "0.000") {
							MessageBox.error("Loading details are not found for the selected LineItem,Please check.");
							return;
						}
						if ((grsWt !== "0.000" && trWt === "0.000") || (grsWt === "0.000" && trWt !== "0.000")) {
							/*if (!this.dialogReason) {*/
			/*	this.dialogReason = sap.ui.xmlfragment(this.getView().getId(), "ZSonic_PLMS.view.Fragment.GateInManualEntry", this);
						this.getView().addDependent(this.dialogReason);
						this.dialogReason.open();
						this.manualEntryObject = oEvent.getSource();
					}
					if (grsWt !== "0.000" && trWt !== "0.000") {
						MessageBox.error("Sorry,You cannot edit");
					}
				}.bind(this)
			});
			oCell[7] = new sap.m.Button({
				icon: "sap-icon://save",
				enabled: this.checkGateinButtons(), //this.checkManualWeightEntry(i, results),
				type: "Accept",
				press: function(oEvent) {
					var oItems = oEvent.getSource().getParent().getCells();
					var grsWt = parseFloat(oItems[2].getValue()).toFixed(3);
					var trWt = parseFloat(oItems[3].getValue()).toFixed(3);
					var ntWt = parseFloat(oItems[4].getValue()).toFixed(3);
					var lineItem = oItems[0].getText();
					var rmrks = oItems[5].getSelectedKey();
					var llgort = oItems[9].getText();
					if (grsWt !== "0.000") {
						if (trWt !== "0.000") {
							if (ntWt >= 0) {
								var payload1 = {
									"VehGrossWeight": grsWt,
									"VehTareWeight": trWt,
									"VehNetWeight": ntWt,
									"WeightRemarks": rmrks
								};
								this.getOwnerComponent().getModel().update("/PLMS_Obd_ItemSet(TruckNumber='" + this.truckNumber +
									"',ObdNumber='" + obd + "',TripNumber='" + this.tripNumber + "',ObdItem='" + lineItem +
									"',BatchAdded='" + "000" + "',Lgort='" +
									llgort + "')", payload1, {
										success: function(oData1) {
											for (var f = 2; f < 6; f++) {
												oItems[f].setEnabled(false);
											}
											MessageBox.success("Line Item Weights have been saved successfully");
										}.bind(this),
										error: function(error) {
											MessageBox.error("Error in saving " + lineItem + " data");
										}
									});
							} else {
								MessageBox.error("Gross weight should be more than Tare weight");
							}
						} else {
							MessageBox.error("Please enter tear weight");
						}
					} else {
						MessageBox.error("Please enter Gross weight");
					}*/
			/*} else {
								MessageBox.error("Net Weight doesnot match with Dispatch Quantity");
							}
						}.bind(this)
					});*/
			/*var batchQuamtity = parseFloat(oItems[9].getText()).toFixed(3);
			var batchQuantity;
			var uot = results[i].Meins;
			if (uot === "MT") {
				batchQuantity = ((batchQuamtity).toFixed(3)) * 1000;
			}
			if (uot === "KG") {
				batchQuantity = batchQuamtity;
			}
			var ntWtMT = ntWt;
			if (ntWtMT >= 0) {
				var rmrks = oItems[5].getValue();
				var lineItem = oItems[0].getText();
				var llgort = oItems[8].getText();
				if (ntWtMT < batchQuantity || ntWtMT === batchQuantity) {
					var payload = {
						"VehGrossWeight": grsWt,
						"VehTareWeight": trWt,
						"VehNetWeight": ntWt,
						"WeightRemarks": rmrks
					};
					if (ntWtMT === batchQuantity) {
						this.getOwnerComponent().getModel().update("/PLMS_Obd_ItemSet(TruckNumber='" + this.truckNumber +
							"',ObdNumber='" + obd + "',TripNumber='" + this.tripNumber + "',ObdItem='" + lineItem +
							"',BatchAdded='" + "000" + "',Lgort='" +
							llgort + "')", payload, {
								success: function(oData) {
									for (var f = 2; f < 6; f++) {
										oItems[f].setEnabled(false);
									}
									MessageBox.success("Line Item Weights have been saved successfully");
								}.bind(this),
								error: function(error) {
									MessageBox.error("Error in saving " + lineItem + " data");
								}
							});
					}
					if (ntWtMT < batchQuantity) {
						MessageBox.confirm("Net Weight is lessthan Dispatch Quantity", {
							title: "Confirm",
							onClose: function(oPressEvent) {
								var pressedValue = oPressEvent;
								if (pressedValue === "OK") {
									this.getOwnerComponent().getModel().update("/PLMS_Obd_ItemSet(TruckNumber='" + this.truckNumber +
										"',ObdNumber='" + obd + "',TripNumber='" + this.tripNumber + "',ObdItem='" + lineItem +
										"',Lgort='" +
										llgort + "')", payload, {
											success: function(oData) {
												for (var f = 2; f < 6; f++) {
													oItems[f].setEnabled(false);
												}
												MessageBox.success("Line Item Weights have been saved successfully");
											}.bind(this),
											error: function(error) {
												MessageBox.error("Error in saving " + lineItem + " data");
											}
										});
								}
								if (pressedValue === "CANCEL") {
									return;
								}
							}.bind(this),
							styleClass: "",
							actions: [sap.m.MessageBox.Action.OK,
								sap.m.MessageBox.Action.CANCEL
							],
							emphasizedAction: sap.m.MessageBox.Action.OK
						});
					}
				} else {
					MessageBox.error("Net Weight doesnot match with Dispatch Quantity");
				}
			} else {
				MessageBox.error("Tare Weight cannot be greaterthan Gross Weight");
			}*/
			/*} else {
					MessageBox.error("Please enter Tare weight");
				}
			} else {
				MessageBox.error("Please enter Gross weight");
			}*/
			/*	}.bind(this)
			});
			oCell[8] = new sap.m.Button({
				text: "Approve",
				width: "5rem",
				type: "Emphasized",
				press: function(oEvent) {
					var oItems = oEvent.getSource().getParent().getCells();
					var manualPayload = {
						ManualAppr: 1
					};
					this.getOwnerComponent().getModel().update("/PLMS_Obd_ItemSet(TruckNumber='" + this.truckNumber + "',ObdNumber='" + "00" +
						results[i].ObdNumber +
						"',TripNumber='" + this.tripNumber + "',BatchAdded='" + "000" + "',ObdItem='" + results[i].ObdItem +
						"',Lgort='" +
						results[i].Lgort + "')", manualPayload, {
							success: function(oData) {
								this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
									filters: this.aStatusFilter,
									success: function(oData1) {
										this.getView().getModel("TripModel").setData(oData1.results[0]);
										this.getView().getModel("TripOBDModel").setProperty("/Items", oData1.results);
										this.tripStatus = this.getView().getModel("TripModel").getData().TripStatus;
										this.timeLineUpdate();
										if (this.tripStatus === "IP" || this.tripStatus === "GI" || this.tripStatus === "GO") {
											this.attachmentsSection();
										}
										this.getView().getModel("TripModel").refresh(true);
										this.callEnableDisableFunction();
										this.getView().byId("idGateInMainPanel").destroyContent();
										var oItems1 = this.getView().getModel("TripOBDModel").getProperty("/Items");
										for (var ee = 0; ee < oItems1.length; ee++) {
											this.createGateInTabContent(ee);
										}
									}.bind(this),
									error: function(oError) {
										MessageBox.warning("Error occurred while reading Header data");
									}
								});
							}.bind(this),
							error: function(error) {
								MessageBox.error("Error in Approving Maual Entry");
							}
						});
				}.bind(this),
				enabled: this.enableManualApprovalButton(results[i].ObdNumber, results[i].ObdItem)
			});*/
			oCell[9] = new sap.m.Text({
				text: results[i].Lgort,
				width: "5rem",
				visible: false
			});
			oCell[10] = new sap.m.Text({
				text: results[i].Quantity,
				width: "5rem",
				visible: false
			});
			oCell[11] = new sap.m.Text({
				text: results[i].SalesUnit,
				visible: false
			});
			oCell[12] = new sap.m.Text({
				text: results[i].ObdNumber,
				visible: false
			});
			var aColList = new sap.m.ColumnListItem({
				cells: oCell
			});
			return aColList;
		},
		createContainerCheckListPanel: function(contBoxNo, contNo, bindingIndex) {
			if (this.tripNumber !== "0000000000" && this.tripNumber !== undefined) {
				var oEmptyContainer = this.createContainerInnerCheckListCC(contBoxNo, contNo, "Empty Container Check", "CC",
					"Are there any Holes/Bungs/LeakageHoles/Deposition?", bindingIndex);
				var oRubber = this.createContainerInnerCheckListRS(contBoxNo, contNo, "Rubber Sealing Check", "RS",
					"Is Rubber sealing proper?",
					bindingIndex);
				var oSide = this.createContainerInnerCheckListSH(contBoxNo, contNo, "Side Holes Check", "SH", "Are there any Side holes?",
					bindingIndex);
				var oFumi = this.createContainerInnerCheckListFC(contBoxNo, contNo, "Fumigation Check", "FC",
					"Is Fumigation done by PRI operator?",
					bindingIndex);
				var oCleanCont = this.createContainerInnerCheckListCleanCont(contBoxNo, contNo, "Cleaning Container", "CLC",
					"Are innersides and outersides of Container,door plywood cleaned and unwanted material wiped out?",
					bindingIndex);
				var oJumbo = this.createContainerInnerCheckListJumbo(contBoxNo, contNo, "Jumbo Bag strips removal", "JB",
					"Has the Jumbo bags strips removed from outer hooks and container door closed?",
					bindingIndex);
				var oCSC = this.createContainerInnerCheckListCSC(contBoxNo, contNo, "Availability of CSC safety plate", "CSC",
					"Is CSC plate available?",
					bindingIndex);
				var containersData = this.getView().getModel("InspectionModel").getProperty("/Items");
				var lastContainerIndex = containersData.length - 1; //this.NoofContainers - 1;
				var vis = false;
				if (containersData[lastContainerIndex].ContainerBoxNo === contBoxNo) {
					vis = true;
				}
				var oFlex = new sap.m.FlexBox({
					justifyContent: sap.m.FlexAlignItems.End,
					alignContent: sap.m.FlexAlignItems.End,
					items: [
						new sap.m.Button({
							text: "Submit",
							visible: vis,
							type: "Accept",
							press: function(oEvent) {
								var tr = this.getView().getModel("TripModel").getProperty("/TripStatus");
								var errMessage = "no";
								if (tr === "IP") {
									this.getOwnerComponent().getModel().read("/PLMS_Vehicle_InspectionSet", {
										filters: this.aStatusFilter,
										success: function(oData) {
											var data = oData.results;
											this.getView().getModel("InspectionModel").setProperty("/Items", data);
											var items = this.getView().getModel("InspectionModel").getProperty("/Items");
											for (var f = 0; f < items.length; f++) {
												if (items[f].VehicleCheck && items[f].RubberSealChk && items[f].ContainerChk && items[f].FumigationChk &&
													items[
														f]
													.ContLoadCleanChk &&
													items[f].BagsStripChk && items[f].CscSafetyChk) {
													errMessage = "no";
												} else {
													errMessage = "yes";
													break;
												}
											}
											if (errMessage === "no") {
												var payload = {
													"InspectionStatus": "IC"
												};
												this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
													"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
													"',ContainerNo='" +
													contNo + "')", payload, {
														method: "PUT",
														success: function(response) {
															MessageBox.success("Container Inspection has been completed successfully");
															this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
																filters: this.aStatusFilter,
																success: function(oExtraData) {
																	this.getView().getModel("TripModel").setData(oExtraData.results[0]);
																	this.getView().getModel("TripOBDModel").setProperty("/Items", oExtraData.results);
																	this.tripStatus = this.getView().getModel("TripModel").getData().TripStatus;
																	this.timeLineUpdate();
																	if (this.tripStatus !== "" || this.tripStatus !== undefined) {
																		this.attachmentsSection();
																	}
																	this.getView().getModel("TripModel").refresh(true);
																	this.callEnableDisableFunction();
																	this.getView().byId("idLoadingMaterialsTab").destroyContent();
																	var oItems = this.getView().getModel("TripOBDModel").getProperty("/Items");
																	for (var ee = 0; ee < oItems.length; ee++) {
																		this.createLoadingMaterialsTabContent(ee);
																	}
																}.bind(this),
																error: function(oError) {
																	MessageBox.warning("Error occurred while reading Header data");
																}
															});
														}.bind(this),
														error: function(error) {
															MessageBox.warning("Error occurred while updating the data");
														}
													});
											} else {
												MessageBox.error("Please complete Inspection for all the containers");
											}
											this.getView().getModel("InspectionModel").refresh(true);
										}.bind(this)
									});
								} else {
									MessageBox.error("Please complete Inspection");
								}
							}.bind(this),
							enabled: this.inspectionButtonParameters()
						}).addStyleClass("sapUiSmallMarginEnd"),
						new sap.m.Button({
							text: "Reject",
							visible: vis,
							type: "Reject",
							press: function(oEvent) {
								MessageBox.confirm("Do you really want to Reject?", {
									title: "Confirm",
									onClose: function(oPressEvent) {
										var oPressText = oPressEvent;
										if (oPressText === "OK") {
											var payload = {
												"Markasdelete": true,
												"TripStatus": "CL"
											};
											this.getOwnerComponent().getModel().update("/PLMS_outbound_HdrSet(TruckNumber='" + this.truckNumber +
												"',ObdNumber='" +
												this.obdNumber +
												"',TripNumber='" + this.tripNumber + "')", payload, {
													success: function(oData) {
														this.readHeaderEntitySet();
														this.goToMain();
													}.bind(this),
													error: function(error) {
														MessageBox.error("Error in cancelling the trip");
													}
												});
										}
									}.bind(this)
								});
							}.bind(this),
							enabled: this.inspectionButtonParameters()
						})
					]
				});
				var oPanel = new sap.m.Panel("idMainPanel" + contNo + contBoxNo, {
					headerText: "Container No: " + contNo,
					expanded: false,
					expandable: true,
					content: [oEmptyContainer, oRubber, oJumbo, oSide, oFumi, oCleanCont, oCSC, oFlex]
				});
				this.getView().byId("idOverAllCheckPoints").addContent(oPanel);
			}
		},
		createContainerInnerCheckListCC: function(contBoxNo, contNo, contPanelHeader, contRefId, contQuestion, bindingIndex) {
			var items = this.getView().getModel("InspectionModel").getProperty("/Items");
			var data = items[bindingIndex];
			var contPanelHeader1;
			if (data.VehicleCheck) {
				if (data.VehicleIssue === 1 || data.VehicleIssue === 2) {
					contPanelHeader1 = contPanelHeader + " (COMPLETED)";
				} else {
					contPanelHeader1 = contPanelHeader + " (Completed with Observations)";
				}
			}
			if (data.VehicleCheck === false || data.VehicleCheck === undefined) {
				contPanelHeader1 = contPanelHeader + " (PENDING)";
			}
			var oSimpleForm = new sap.ui.layout.form.SimpleForm({
				layout: sap.ui.layout.form.SimpleFormLayout.ResponsiveGridLayout,
				editable: true,
				labelSpanL: 3,
				labelSpanM: 3,
				labelSpanS: 4,
				emptySpanL: 0,
				emptySpanM: 0,
				content: [new sap.m.Label({
						text: contQuestion,
						required: true
					}),
					new sap.m.RadioButtonGroup("id" + contRefId + contBoxNo + contNo, {
						columns: 3,
						selectedIndex: data.VehicleIssue,
						buttons: [
							new sap.m.RadioButton({
								text: "YES",
								selected: true
							}),
							new sap.m.RadioButton({
								text: "NO"
							}),
							new sap.m.RadioButton({
								text: "NA"
							})
						],
						enabled: this.checkInspectionParameters(),
						select: function(oEvent) {
							var buttonSelected = oEvent.getSource().getSelectedIndex();
							if (buttonSelected === 0) {
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setEnabled(
									true);
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setEnabled(
									true);
							}
							if (buttonSelected === 1 || buttonSelected === 2) {
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setEnabled(
									false);
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setEnabled(
									false);
								/*oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setValue("");
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setValue("");*/
							}
						}
					}),
					new sap.m.FlexBox({
						justifyContent: sap.m.FlexAlignItems.Center,
						alignContent: sap.m.FlexAlignItems.Center,
						items: [
							new sap.m.Button({
								text: "Edit",
								enabled: this.inspectionButtonParameters(), //inspectionEditEnableModel.getProperty("/InspectionEditSaveButtons"),
								press: function(oEvent) {
									var vehChk, vehAppr;
									var oItems = this.getView().getModel("InspectionModel").getProperty("/Items");
									for (var i = 0; i < oItems.length; i++) {
										if (oItems[i].ContainerNo === data.ContainerNo) {
											vehChk = oItems[i].VehicleCheck;
											vehAppr = oItems[i].VehApprNeed;
										}
									}
									var radio = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
											0]
										._aElements[1].getSelectedIndex();
									if (radio === 1 || radio === 2) {
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											1].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											8].setEnabled(true);
									}
									if (radio === 0) {
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											1].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											4].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											6].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											8].setEnabled(true);
									}
								}.bind(this)
							}).addStyleClass("sapUiSmallMarginEnd"),
							new sap.m.Button({
								text: "Save and Continue",
								type: "Emphasized",
								enabled: /*inspectionEditEnableModel.getProperty("/InspectionEditSaveButtons"),*/ this.inspectionButtonParameters(),
								press: function(oEvent) {
									var panelObject = oEvent.getSource().getParent().getParent().getParent().getParent().getParent();
									var VehicleIssue = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
										0]._aElements[1].getSelectedIndex();
									var VehObservations = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
										0]._aElements[4].getValue();
									var VehCorrMeasure = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
										0]._aElements[6].getValue();
									var check = true,
										vehChk, vehAppr;
									var oItems = this.getView().getModel("InspectionModel").getProperty("/Items");
									for (var i = 0; i < oItems.length; i++) {
										if (oItems[i].ContainerNo === data.ContainerNo) {
											vehChk = oItems[i].VehicleCheck;
											vehAppr = oItems[i].VehApprNeed;
										}
									}
									var oFileUploader = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
										0]._aElements[8];
									var payload = {
										"VehicleIssue": VehicleIssue,
										"VehObservations": VehObservations,
										"VehCorrMeasure": VehCorrMeasure,
										"TruckNumber": this.truckNumber,
										"TripNumber": this.tripNumber,
										"ContainerNo": contNo,
										"InspectionStatus": "IP",
										"ContainerBoxNo": contBoxNo,
										"VehicleCheck": check
									};
									if (VehicleIssue === 0) {
										if (!vehChk) {
											this.oCCEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (payload.VehObservations !== "" && payload.VehCorrMeasure !== "") {
												if (this.fileCCName) {
													if (this.fileCCType === "image/jpeg") {
														oFileUploader.destroyHeaderParameters();
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "SLUG",
															value: this.fileCCName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
																'"/"' +
																contNo + '"/"' + contBoxNo + '"/"' + 3
														}));
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "Content-Type",
															value: this.fileCCType
														}));
														this.getOwnerComponent().getModel().refreshSecurityToken();
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "x-csrf-token",
															value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
														}));
														oFileUploader.setSendXHR(true);
														oFileUploader.upload();
													} else {
														MessageBox.error("File format should be JPG");
													}
												}
												this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
													"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
													"',ContainerNo='" +
													contNo + "')", payload, {
														method: "PUT",
														success: function(response) {
															MessageBox.success("Empty Container Check has been done successfully");
															this.oCCEvent._aElements[1].setEnabled(false);
															this.oCCEvent._aElements[4].setEnabled(false);
															this.oCCEvent._aElements[6].setEnabled(false);
															this.oCCEvent._aElements[8].setEnabled(false);
															this.readHeaderEntitySet();
															this.readInspectionEntitySetforContainer();
														}.bind(this),
														error: function(error) {
															MessageBox.warning("Error occurred while updating the data");
														}
													});
											} else {
												MessageBox.error("Please update all parameters");
											}
										}
										if (vehChk) {
											this.oCCEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileCCName) {
												if (this.fileCCType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileCCName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 3
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileCCType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oCCEvent._aElements[1].setEnabled(false);
														this.oCCEvent._aElements[4].setEnabled(false);
														this.oCCEvent._aElements[6].setEnabled(false);
														this.oCCEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
									if (VehicleIssue === 1) {
										if (!vehChk) {
											this.oCCEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileCCName) {
												if (this.fileCCType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileCCName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 3
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileCCType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();
												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														MessageBox.success("Empty Container Check has been done successfully");
														this.oCCEvent._aElements[1].setEnabled(false);
														this.oCCEvent._aElements[4].setEnabled(false);
														this.oCCEvent._aElements[6].setEnabled(false);
														this.oCCEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
										if (vehChk) {
											this.oCCEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileCCName) {
												if (this.fileCCType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileCCName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 3
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileCCType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oCCEvent._aElements[1].setEnabled(false);
														this.oCCEvent._aElements[4].setEnabled(false);
														this.oCCEvent._aElements[6].setEnabled(false);
														this.oCCEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
									if (VehicleIssue === 2) {
										this.oCCEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
											0];
										if (!vehChk) {
											if (this.fileCCName) {
												if (this.fileCCType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileCCName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 3
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileCCType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														MessageBox.success("Empty Container Check has been done successfully");
														this.oCCEvent._aElements[1].setEnabled(false);
														this.oCCEvent._aElements[4].setEnabled(false);
														this.oCCEvent._aElements[6].setEnabled(false);
														this.oCCEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
										if (vehChk) {
											this.oCCEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileCCName) {
												if (this.fileCCType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileCCName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 3
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileCCType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oCCEvent._aElements[1].setEnabled(false);
														this.oCCEvent._aElements[4].setEnabled(false);
														this.oCCEvent._aElements[6].setEnabled(false);
														this.oCCEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
								}.bind(this)
							})
						]
					}),
					new sap.m.Label({
						text: "Observations",
						required: true
					}),
					new sap.m.TextArea("id" + contRefId + "Observations" + contBoxNo + contNo, {
						value: data.VehObservations,
						enabled: this.checkNewSHInspectionParameters(data.VehicleIssue),
						maxLength: 100
					}),
					new sap.m.Label({
						text: "Corrective Measures",
						required: true
					}),
					new sap.m.TextArea("id" + contRefId + "CorectiveMeasures" + contBoxNo + contNo, {
						enabled: this.checkNewSHInspectionParameters(data.VehicleIssue),
						value: data.VehCorrMeasure,
						maxLength: 100
					}),
					new sap.m.Label({
						text: "Upload Photo"
					}),
					new sap.ui.unified.FileUploader("id" + contRefId + "FileUpload" + contBoxNo + contNo, {
						enabled: this.checkInspectionParameters(),
						uploadUrl: "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet",
						uploadComplete: "handleUploadComplete",
						change: function(oEvent) {
							this.fileCCName = oEvent.getParameter("files")[0].name;
							this.fileCCType = oEvent.getParameter("files")[0].type;
							this.fileCCSize = oEvent.getParameter("files")[0].size;
							if (oEvent.getSource().oFileUpload.files.length > 0) {
								var file = oEvent.getSource().oFileUpload.files;
								var blobObj = new Blob(file, {
									type: "	image/jpeg"
								});
								var path = URL.createObjectURL(blobObj);
								oEvent.getSource().getParent().getFields()[1].setSrc(path);
							}
						}.bind(this),
						fileType: "jpg",
						style: "Emphasized",
						sendXHR: true,
						useMultipart: false,
						placeholder: "Choose the Container Image"

					}),
					new sap.m.Image("id" + contRefId + "Image" + contBoxNo + contNo, {
						width: "50%",
						height: "50%"
					})
				]
			});
			var oPanel = new sap.m.Panel({
				headerText: contPanelHeader1,
				expanded: false,
				expandable: true,
				content: [oSimpleForm]
			});
			return oPanel;
		},
		createContainerInnerCheckListRS: function(contBoxNo, contNo, contPanelHeader, contRefId, contQuestion, bindingIndex) {
			var items = this.getView().getModel("InspectionModel").getProperty("/Items");
			var data = items[bindingIndex];
			var contPanelHeader1;
			if (data.RubberSealChk) {
				if (data.RubberSealIssue === 0 || data.RubberSealIssue === 2) {
					contPanelHeader1 = contPanelHeader + " (COMPLETED)";
				} else {
					contPanelHeader1 = contPanelHeader + " (Completed with Observations)";
				}
			}
			if (data.RubberSealChk === false || data.RubberSealChk === undefined) {
				contPanelHeader1 = contPanelHeader + " (PENDING)";
			}
			var oSimpleForm = new sap.ui.layout.form.SimpleForm({
				layout: sap.ui.layout.form.SimpleFormLayout.ResponsiveGridLayout,
				editable: true,
				labelSpanL: 3,
				labelSpanM: 3,
				labelSpanS: 4,
				emptySpanL: 0,
				emptySpanM: 0,
				content: [new sap.m.Label({
						text: contQuestion,
						required: true
					}),
					new sap.m.RadioButtonGroup("id" + contRefId + contBoxNo + contNo, {
						columns: 3,
						selectedIndex: data.RubberSealIssue,
						buttons: [
							new sap.m.RadioButton({
								text: "YES",
								selected: true
							}),
							new sap.m.RadioButton({
								text: "NO"
							}),
							new sap.m.RadioButton({
								text: "NA"
							})
						],
						enabled: this.checkInspectionParameters(),
						select: function(oEvent) {
							var buttonSelected = oEvent.getSource().getSelectedIndex();
							if (buttonSelected === 1) {
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setEnabled(
									true);
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setEnabled(
									true);
							}
							if (buttonSelected === 0 || buttonSelected === 2) {
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setEnabled(
									false);
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setEnabled(
									false);
								/*oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setValue("");
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setValue("");*/
							}
						}
					}),
					new sap.m.FlexBox({
						justifyContent: sap.m.FlexAlignItems.Center,
						alignContent: sap.m.FlexAlignItems.Center,
						items: [
							new sap.m.Button({
								text: "Edit",
								enabled: this.inspectionButtonParameters(), //inspectionEditEnableModel.getProperty("/InspectionEditSaveButtons"),
								press: function(oEvent) {
									var check = true,
										vehChk, vehAppr;
									var oItems = this.getView().getModel("InspectionModel").getProperty("/Items");
									for (var i = 0; i < oItems.length; i++) {
										if (oItems[i].ContainerNo === data.ContainerNo) {
											vehChk = oItems[i].RubberSealChk;
											vehAppr = oItems[i].RubberSealApprNeed;
										}
									}
									var radio = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
											0]
										._aElements[1].getSelectedIndex();
									if (radio === 0 || radio === 2) {
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											1].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											8].setEnabled(true);
									}
									if (radio === 1) {
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											1].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											4].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											6].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											8].setEnabled(true);
									}
								}
							}).addStyleClass("sapUiSmallMarginEnd"),
							new sap.m.Button({
								text: "Save and Continue",
								type: "Emphasized",
								enabled: this.inspectionButtonParameters(), //inspectionEditEnableModel.getProperty("/InspectionEditSaveButtons"),
								press: function(oEvent) {
									var RubberSealIssue = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
										0]._aElements[1].getSelectedIndex();
									var RubberSealObservations = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent()
										.getContent()[0]._aElements[4].getValue();
									var RubberSealCorrMeasure = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent()
										.getContent()[0]._aElements[6].getValue();
									var check = true,
										vehChk, vehAppr;
									var oItems = this.getView().getModel("InspectionModel").getProperty("/Items");
									for (var i = 0; i < oItems.length; i++) {
										if (oItems[i].ContainerNo === data.ContainerNo) {
											vehChk = oItems[i].RubberSealChk;
											vehAppr = oItems[i].RubberSealApprNeed;
										}
									}
									var oFileUploader = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
										0]._aElements[8];
									var payload = {
										"RubberSealIssue": RubberSealIssue,
										"RubberSealObservations": RubberSealObservations,
										"RubberSealCorrMeasure": RubberSealCorrMeasure,
										"TruckNumber": this.truckNumber,
										"TripNumber": this.tripNumber,
										"ContainerNo": contNo,
										"InspectionStatus": "IP",
										"ContainerBoxNo": contBoxNo,
										"RubberSealChk": check
									};
									if (RubberSealIssue === 1) {
										if (!vehChk) {
											this.oRSEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (payload.RubberSealObservations !== "" && payload.RubberSealCorrMeasure !== "") {
												if (this.fileRSName) {
													if (this.fileRSType === "image/jpeg") {
														oFileUploader.destroyHeaderParameters();
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "SLUG",
															value: this.fileRSName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
																'"/"' +
																contNo + '"/"' + contBoxNo + '"/"' + 5
														}));
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "Content-Type",
															value: this.fileRSType
														}));
														this.getOwnerComponent().getModel().refreshSecurityToken();
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "x-csrf-token",
															value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
														}));
														oFileUploader.setSendXHR(true);
														oFileUploader.upload();
													} else {
														MessageBox.error("File format should be JPG");
													}
												}
												this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
													"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
													"',ContainerNo='" +
													contNo + "')", payload, {
														method: "PUT",
														success: function(response) {
															MessageBox.success("Rubber Sealing Check has been done successfully", {
																onClose: function() {
																	this.oRSEvent._aElements[1].setEnabled(false);
																	this.oRSEvent._aElements[4].setEnabled(false);
																	this.oRSEvent._aElements[6].setEnabled(false);
																	this.oRSEvent._aElements[8].setEnabled(false);
																	this.readHeaderEntitySet();
																	this.readInspectionEntitySetforContainer();
																}.bind(this)
															});
														}.bind(this),
														error: function(error) {
															MessageBox.warning("Error occurred while updating the data");
														}
													});
											} else {
												MessageBox.error("Please fill all the mandatory feilds");
											}
										}
										if (vehChk) {
											this.oRSEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileRSName) {
												if (this.fileRSType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileRSName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 5
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileRSType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oRSEvent._aElements[1].setEnabled(false);
														this.oRSEvent._aElements[4].setEnabled(false);
														this.oRSEvent._aElements[6].setEnabled(false);
														this.oRSEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
									if (RubberSealIssue === 0) {
										if (!vehChk) {
											this.oRSEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileRSName) {
												if (this.fileRSType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileRSName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 5
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileRSType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();
												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														MessageBox.success("Rubber Sealing Check has been done successfully", {
															onClose: function() {
																this.oRSEvent._aElements[1].setEnabled(false);
																this.oRSEvent._aElements[4].setEnabled(false);
																this.oRSEvent._aElements[6].setEnabled(false);
																this.oRSEvent._aElements[8].setEnabled(false);
																this.readHeaderEntitySet();
																this.readInspectionEntitySetforContainer();
															}.bind(this)
														});
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
										if (vehChk) {
											this.oRSEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileRSName) {
												if (this.fileRSType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileRSName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 5
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileRSType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oRSEvent._aElements[1].setEnabled(false);
														this.oRSEvent._aElements[4].setEnabled(false);
														this.oRSEvent._aElements[6].setEnabled(false);
														this.oRSEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
									if (RubberSealIssue === 2) {
										if (!vehChk) {
											this.oRSEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileRSName) {
												if (this.fileRSType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileRSName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 5
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileRSType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														MessageBox.success("Rubber Sealing Check has been done successfully", {
															onClose: function() {
																this.oRSEvent._aElements[1].setEnabled(false);
																this.oRSEvent._aElements[4].setEnabled(false);
																this.oRSEvent._aElements[6].setEnabled(false);
																this.oRSEvent._aElements[8].setEnabled(false);
																this.readHeaderEntitySet();
																this.readInspectionEntitySetforContainer();
															}.bind(this)
														});
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
										if (vehChk) {
											this.oRSEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileRSName) {
												if (this.fileRSType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileRSName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 5
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileRSType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oRSEvent._aElements[1].setEnabled(false);
														this.oRSEvent._aElements[4].setEnabled(false);
														this.oRSEvent._aElements[6].setEnabled(false);
														this.oRSEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
								}.bind(this)
							})
						]
					}),
					new sap.m.Label({
						text: "Observations",
						required: true
					}),
					new sap.m.TextArea("id" + contRefId + "Observations" + contBoxNo + contNo, {
						enabled: this.checkNewInspectionParameters(data.RubberSealIssue),
						value: data.RubberSealObservations,
						maxLength: 100
					}),
					new sap.m.Label({
						text: "Corrective Measures",
						required: true
					}),
					new sap.m.TextArea("id" + contRefId + "CorectiveMeasures" + contBoxNo + contNo, {
						value: data.RubberSealCorrMeasure,
						maxLength: 100,
						enabled: this.checkNewInspectionParameters(data.RubberSealIssue)
					}),
					new sap.m.Label({
						text: "Upload Photo"
					}),
					new sap.ui.unified.FileUploader("id" + contRefId + "FileUpload" + contBoxNo + contNo, {
						uploadUrl: "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet",
						uploadComplete: "handleUploadComplete",
						change: function(oEvent) {
							this.fileRSName = oEvent.getParameter("files")[0].name;
							this.fileRSType = oEvent.getParameter("files")[0].type;
							this.fileRSSize = oEvent.getParameter("files")[0].size;
							if (oEvent.getSource().oFileUpload.files.length > 0) {
								var file = oEvent.getSource().oFileUpload.files;
								var blobObj = new Blob(file, {
									type: "	image/jpeg"
								});
								var path = URL.createObjectURL(blobObj);
								oEvent.getSource().getParent().getFields()[1].setSrc(path);
							}
						}.bind(this),
						fileType: "jpg",
						style: "Emphasized",
						sendXHR: true,
						useMultipart: false,
						placeholder: "Choose the Container Image",
						enabled: this.checkInspectionParameters()
					}),
					new sap.m.Image("id" + contRefId + "Image" + contBoxNo + contNo, {
						width: "50%",
						height: "50%"
					})
				]
			});
			var oPanel = new sap.m.Panel({
				headerText: contPanelHeader1,
				expanded: false,
				expandable: true,
				content: [oSimpleForm]
			});
			return oPanel;
		},
		createContainerInnerCheckListSH: function(contBoxNo, contNo, contPanelHeader, contRefId, contQuestion, bindingIndex) {
			var items = this.getView().getModel("InspectionModel").getProperty("/Items");
			var data = items[bindingIndex];
			var contPanelHeader1;
			if (data.ContainerChk) {
				if (data.ContainerIssue === 1 || data.ContainerIssue === 2) {
					contPanelHeader1 = contPanelHeader + " (COMPLETED)";
				} else {
					contPanelHeader1 = contPanelHeader + " (Completed with Observations)";
				}
			}
			if (data.ContainerChk === false || data.ContainerChk === undefined) {
				contPanelHeader1 = contPanelHeader + " (PENDING)";
			}
			var oSimpleForm = new sap.ui.layout.form.SimpleForm({
				layout: sap.ui.layout.form.SimpleFormLayout.ResponsiveGridLayout,
				editable: true,
				labelSpanL: 3,
				labelSpanM: 3,
				labelSpanS: 4,
				emptySpanL: 0,
				emptySpanM: 0,
				content: [new sap.m.Label({
						text: contQuestion,
						required: true
					}),
					new sap.m.RadioButtonGroup("id" + contRefId + contBoxNo + contNo, {
						columns: 3,
						selectedIndex: data.ContainerIssue,
						buttons: [
							new sap.m.RadioButton({
								text: "YES",
								selected: true
							}),
							new sap.m.RadioButton({
								text: "NO"
							}),
							new sap.m.RadioButton({
								text: "NA"
							})
						],
						enabled: this.checkInspectionParameters(),
						select: function(oEvent) {
							var buttonSelected = oEvent.getSource().getSelectedIndex();
							if (buttonSelected === 0) {
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setEnabled(
									true);
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setEnabled(
									true);
							}
							if (buttonSelected === 1 || buttonSelected === 2) {
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setEnabled(
									false);
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setEnabled(
									false);
								/*oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setValue("");
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setValue("");*/
							}
						}
					}),
					new sap.m.FlexBox({
						justifyContent: sap.m.FlexAlignItems.Center,
						alignContent: sap.m.FlexAlignItems.Center,
						items: [
							new sap.m.Button({
								text: "Edit",
								enabled: this.inspectionButtonParameters(), //inspectionEditEnableModel.getProperty("/InspectionEditSaveButtons"),
								press: function(oEvent) {
									var vehChk, vehAppr;
									var oItems = this.getView().getModel("InspectionModel").getProperty("/Items");
									for (var i = 0; i < oItems.length; i++) {
										if (oItems[i].ContainerNo === data.ContainerNo) {
											vehChk = oItems[i].ContainerChk;
											vehAppr = oItems[i].ContInspApprNeed;
										}
									}
									var radio = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
											0]
										._aElements[1].getSelectedIndex();
									if (radio === 0 || radio === 2) {
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											1].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											8].setEnabled(true);
									}
									if (radio === 1) {
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											1].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											4].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											6].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											8].setEnabled(true);
									}
								}
							}).addStyleClass("sapUiSmallMarginEnd"),
							new sap.m.Button({
								text: "Save and Continue",
								enabled: this.inspectionButtonParameters(), //inspectionEditEnableModel.getProperty("/InspectionEditSaveButtons"),
								type: "Emphasized",
								press: function(oEvent) {
									var ContainerIssue = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
										0]._aElements[1].getSelectedIndex();
									var ContObservations = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
										0]._aElements[4].getValue();
									var ContCorrMeasure = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
										0]._aElements[6].getValue();
									var check = true,
										vehChk, vehAppr;
									var oItems = this.getView().getModel("InspectionModel").getProperty("/Items");
									for (var i = 0; i < oItems.length; i++) {
										if (oItems[i].ContainerNo === data.ContainerNo) {
											vehChk = oItems[i].ContainerChk;
											vehAppr = oItems[i].ContInspApprNeed;
										}
									}
									var oFileUploader = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
										0]._aElements[8];
									var payload = {
										"ContainerIssue": ContainerIssue,
										"ContObservations": ContObservations,
										"ContCorrMeasure": ContCorrMeasure,
										"TruckNumber": this.truckNumber,
										"TripNumber": this.tripNumber,
										"ContainerNo": contNo,
										"InspectionStatus": "IP",
										"ContainerBoxNo": contBoxNo,
										"ContainerChk": check
									};
									if (ContainerIssue === 0) {
										if (!vehChk) {
											this.oSHEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (payload.ContObservations !== "" && payload.ContCorrMeasure !== "") {
												if (this.fileSHName) {
													if (this.fileSHType === "image/jpeg") {
														oFileUploader.destroyHeaderParameters();
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "SLUG",
															value: this.fileSHName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
																'"/"' +
																contNo + '"/"' + contBoxNo + '"/"' + 14
														}));
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "Content-Type",
															value: this.fileSHType
														}));
														this.getOwnerComponent().getModel().refreshSecurityToken();
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "x-csrf-token",
															value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
														}));
														oFileUploader.setSendXHR(true);
														oFileUploader.upload();
													} else {
														MessageBox.error("File format should be JPG");
													}
												}
												this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
													"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
													"',ContainerNo='" +
													contNo + "')", payload, {
														method: "PUT",
														success: function(response) {
															MessageBox.success("Side Holes  have been updated successfully", {
																onClose: function() {
																	this.oSHEvent._aElements[1].setEnabled(false);
																	this.oSHEvent._aElements[4].setEnabled(false);
																	this.oSHEvent._aElements[6].setEnabled(false);
																	this.oSHEvent._aElements[8].setEnabled(false);
																	this.readHeaderEntitySet();
																	this.readInspectionEntitySetforContainer();
																}.bind(this)
															});
														}.bind(this),
														error: function(error) {
															MessageBox.warning("Error occurred while updating the data");
														}
													});
											} else {
												MessageBox.error("Please update all parameters");
											}
										}
										if (vehChk) {
											this.oSHEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileSHName) {
												if (this.fileSHType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileSHName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 14
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileSHType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oSHEvent._aElements[1].setEnabled(false);
														this.oSHEvent._aElements[4].setEnabled(false);
														this.oSHEvent._aElements[6].setEnabled(false);
														this.oSHEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
									if (ContainerIssue === 1) {
										if (!vehChk) {
											this.oSHEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileSHName) {
												if (this.fileSHType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileSHName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 14
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileSHType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();
												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														MessageBox.success("Side Holes  have been updated successfully", {
															onClose: function() {
																this.oSHEvent._aElements[1].setEnabled(false);
																this.oSHEvent._aElements[4].setEnabled(false);
																this.oSHEvent._aElements[6].setEnabled(false);
																this.oSHEvent._aElements[8].setEnabled(false);
																this.readHeaderEntitySet();
																this.readInspectionEntitySetforContainer();
															}.bind(this)
														});
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
										if (vehChk) {
											this.oSHEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileSHName) {
												if (this.fileSHType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileSHName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 14
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileSHType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();
												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oSHEvent._aElements[1].setEnabled(false);
														this.oSHEvent._aElements[4].setEnabled(false);
														this.oSHEvent._aElements[6].setEnabled(false);
														this.oSHEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
									if (ContainerIssue === 2) {
										if (!vehChk) {
											this.oSHEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileSHName) {
												if (this.fileSHType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileSHName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 14
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileSHType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														MessageBox.success("Side Holes  have been updated successfully", {
															onClose: function() {
																this.oSHEvent._aElements[1].setEnabled(false);
																this.oSHEvent._aElements[4].setEnabled(false);
																this.oSHEvent._aElements[6].setEnabled(false);
																this.oSHEvent._aElements[8].setEnabled(false);
																this.readHeaderEntitySet();
																this.readInspectionEntitySetforContainer();
															}.bind(this)
														});
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
										if (vehChk) {
											this.oSHEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileSHName) {
												if (this.fileSHType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileSHName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 14
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileSHType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oSHEvent._aElements[1].setEnabled(false);
														this.oSHEvent._aElements[4].setEnabled(false);
														this.oSHEvent._aElements[6].setEnabled(false);
														this.oSHEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
								}.bind(this)
							})
						]
					}),
					new sap.m.Label({
						text: "Observations",
						required: true
					}),
					new sap.m.TextArea("id" + contRefId + "Observations" + contBoxNo + contNo, {
						value: data.ContObservations,
						maxLength: 100,
						enabled: this.checkNewSHInspectionParameters(data.ContainerIssue)
					}),
					new sap.m.Label({
						text: "Corrective Measures",
						required: true
					}),
					new sap.m.TextArea("id" + contRefId + "CorectiveMeasures" + contBoxNo + contNo, {
						value: data.ContCorrMeasure,
						maxLength: 100,
						enabled: this.checkNewSHInspectionParameters(data.ContainerIssue)
					}),
					new sap.m.Label({
						text: "Upload Photo"
					}),
					new sap.ui.unified.FileUploader("id" + contRefId + "FileUpload" + contBoxNo + contNo, {
						uploadUrl: "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet",
						uploadComplete: "handleUploadComplete",
						change: function(oEvent) {
							this.fileSHName = oEvent.getParameter("files")[0].name;
							this.fileSHType = oEvent.getParameter("files")[0].type;
							this.fileSHSize = oEvent.getParameter("files")[0].size;
							if (oEvent.getSource().oFileUpload.files.length > 0) {
								var file = oEvent.getSource().oFileUpload.files;
								var blobObj = new Blob(file, {
									type: "	image/jpeg"
								});
								var path = URL.createObjectURL(blobObj);
								oEvent.getSource().getParent().getFields()[1].setSrc(path);
							}
						}.bind(this),
						fileType: "jpg",
						style: "Emphasized",
						sendXHR: true,
						useMultipart: false,
						placeholder: "Choose the Container Image",
						enabled: this.checkInspectionParameters()
					}),
					new sap.m.Image("id" + contRefId + "Image" + contBoxNo + contNo, {
						width: "50%",
						height: "50%"
					})
				]
			});
			var oPanel = new sap.m.Panel({
				headerText: contPanelHeader1,
				expanded: false,
				expandable: true,
				content: [oSimpleForm]
			});
			return oPanel;
		},
		createContainerInnerCheckListFC: function(contBoxNo, contNo, contPanelHeader, contRefId, contQuestion, bindingIndex) {
			var items = this.getView().getModel("InspectionModel").getProperty("/Items");
			var data = items[bindingIndex];
			var contPanelHeader1;
			if (data.FumigationChk) {
				contPanelHeader1 = contPanelHeader + " (COMPLETED)";
			}
			if (data.FumigationChk === false || data.FumigationChk === undefined) {
				contPanelHeader1 = contPanelHeader + " (PENDING)";
			}
			var oSimpleForm = new sap.ui.layout.form.SimpleForm({
				layout: sap.ui.layout.form.SimpleFormLayout.ResponsiveGridLayout,
				editable: true,
				labelSpanL: 3,
				labelSpanM: 3,
				labelSpanS: 4,
				emptySpanL: 0,
				emptySpanM: 0,
				content: [new sap.m.Label({
						text: contQuestion,
						required: true
					}),
					new sap.m.RadioButtonGroup("id" + contRefId + contBoxNo + contNo, {
						columns: 3,
						selectedIndex: data.FumigationInspIssue,
						buttons: [
							new sap.m.RadioButton({
								text: "YES",
								selected: true
							}),
							new sap.m.RadioButton({
								text: "NO"
							}),
							new sap.m.RadioButton({
								text: "NA"
							})
						],
						enabled: this.checkInspectionParameters()
					}),
					new sap.m.FlexBox({
						justifyContent: sap.m.FlexAlignItems.Center,
						alignContent: sap.m.FlexAlignItems.Center,
						items: [
							new sap.m.Button({
								text: "Edit",
								enabled: this.inspectionButtonParameters(), //inspectionEditEnableModel.getProperty("/InspectionEditSaveButtons"),
								press: function(oEvent) {
									var check = true,
										vehChk, vehAppr;
									var oItems = this.getView().getModel("InspectionModel").getProperty("/Items");
									for (var i = 0; i < oItems.length; i++) {
										if (oItems[i].ContainerNo === data.ContainerNo) {
											vehChk = oItems[i].FumigationChk;
											vehAppr = oItems[i].FumigationInspApprNeed;
										}
									}
									var radio = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
											0]
										._aElements[1].getSelectedIndex();
									if (radio === 0 || radio === 2) {
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											1].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											8].setEnabled(true);
									}
									if (radio === 1) {
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											1].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											4].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											6].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											8].setEnabled(true);
									}
								}.bind(this)
							}).addStyleClass("sapUiSmallMarginEnd"),
							new sap.m.Button({
								text: "Save and Continue",
								type: "Emphasized",
								enabled: this.inspectionButtonParameters(), //inspectionEditEnableModel.getProperty("/InspectionEditSaveButtons"),
								press: function(oEvent) {
									var FumigationInspIssue = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent()
										.getContent()[
											0]._aElements[1].getSelectedIndex();
									var FumigationObservations = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent()
										.getContent()[0]._aElements[4].getValue();
									var FumigationCorrMeasure = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent()
										.getContent()[0]._aElements[6].getValue();
									var check = true,
										vehChk, vehAppr;
									var oItems = this.getView().getModel("InspectionModel").getProperty("/Items");
									for (var i = 0; i < oItems.length; i++) {
										if (oItems[i].ContainerNo === data.ContainerNo) {
											vehChk = oItems[i].FumigationChk;
											vehAppr = oItems[i].FumigationInspApprNeed;
										}
									}
									var oFileUploader = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
										0]._aElements[8];
									var payload = {
										"FumigationInspIssue": FumigationInspIssue,
										"FumigationObservations": FumigationObservations,
										"FumigationCorrMeasure": FumigationCorrMeasure,
										"TruckNumber": this.truckNumber,
										"TripNumber": this.tripNumber,
										"ContainerNo": contNo,
										"InspectionStatus": "IP",
										"ContainerBoxNo": contBoxNo,
										"FumigationChk": check
									};
									if (FumigationInspIssue === 0 || FumigationInspIssue === 1) {
										if (!vehChk) {
											this.oFCEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileFCType) {
												if (this.fileFCType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileFCName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 7
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileFCType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();
												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														MessageBox.success("Fumigation details have been updated successfully", {
															onClose: function() {
																this.oFCEvent._aElements[1].setEnabled(false);
																this.oFCEvent._aElements[4].setEnabled(false);
																this.oFCEvent._aElements[6].setEnabled(false);
																this.oFCEvent._aElements[8].setEnabled(false);
																this.readHeaderEntitySet();
																this.readInspectionEntitySetforContainer();
															}.bind(this)
														});
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
										if (vehChk) {
											this.oFCEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileFCName) {
												if (this.fileFCType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileFCName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 7
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileFCType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oFCEvent._aElements[1].setEnabled(false);
														this.oFCEvent._aElements[4].setEnabled(false);
														this.oFCEvent._aElements[6].setEnabled(false);
														this.oFCEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
									if (FumigationInspIssue === 2) {
										if (!vehChk) {
											this.oFCEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileFCType) {
												if (this.fileFCType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileFCName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 7
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileFCType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														MessageBox.success("Fumigation details have been updated successfully", {
															onClose: function() {
																this.oFCEvent._aElements[1].setEnabled(false);
																this.oFCEvent._aElements[4].setEnabled(false);
																this.oFCEvent._aElements[6].setEnabled(false);
																this.oFCEvent._aElements[8].setEnabled(false);
																this.readHeaderEntitySet();
																this.readInspectionEntitySetforContainer();
															}.bind(this)
														});
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
										if (vehChk) {
											this.oFCEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileFCName) {
												if (this.fileFCType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileFCName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 7
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileFCType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oFCEvent._aElements[1].setEnabled(false);
														this.oFCEvent._aElements[4].setEnabled(false);
														this.oFCEvent._aElements[6].setEnabled(false);
														this.oFCEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
								}.bind(this)
							})
						]
					}),
					new sap.m.Label({
						text: "Observations"
					}),
					new sap.m.TextArea("id" + contRefId + "Observations" + contBoxNo + contNo, {
						value: data.FumigationObservations,
						maxLength: 100,
						enabled: true
					}),
					new sap.m.Label({
						text: "Corrective Measures"
					}),
					new sap.m.TextArea("id" + contRefId + "CorectiveMeasures" + contBoxNo + contNo, {
						value: data.FumigationCorrMeasure,
						maxLength: 100,
						enabled: true //this.checkInspectionParameters()
					}),
					new sap.m.Label({
						text: "Upload Photo"
					}),
					new sap.ui.unified.FileUploader("id" + contRefId + "FileUpload" + contBoxNo + contNo, {
						uploadUrl: "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet",
						uploadComplete: "handleUploadComplete",
						change: function(oEvent) {
							this.fileFCName = oEvent.getParameter("files")[0].name;
							this.fileFCType = oEvent.getParameter("files")[0].type;
							this.fileFCSize = oEvent.getParameter("files")[0].size;
							if (oEvent.getSource().oFileUpload.files.length > 0) {
								var file = oEvent.getSource().oFileUpload.files;
								var blobObj = new Blob(file, {
									type: "	image/jpeg"
								});
								var path = URL.createObjectURL(blobObj);
								oEvent.getSource().getParent().getFields()[1].setSrc(path);
							}
						}.bind(this),
						fileType: "jpg",
						style: "Emphasized",
						sendXHR: true,
						useMultipart: false,
						placeholder: "Choose the Container Image",
						enabled: this.checkInspectionParameters()
					}),
					new sap.m.Image("id" + contRefId + "Image" + contBoxNo + contNo, {
						width: "50%",
						height: "50%"
					})
				]
			});
			var oPanel = new sap.m.Panel({
				headerText: contPanelHeader1,
				expanded: false,
				expandable: true,
				content: [oSimpleForm]
			});
			return oPanel;
		},
		createContainerInnerCheckListCHDPE: function(contBoxNo, contNo, contPanelHeader, contRefId, contQuestion, bindingIndex) {
			var items = this.getView().getModel("InspectionModel").getProperty("/Items");
			var data = items[bindingIndex];
			var contPanelHeader1;
			if (data.ContCleanChk) {
				if (data.ContCleanHdpeIssue === 0 || data.ContCleanHdpeIssue === 2) {
					contPanelHeader1 = contPanelHeader + " (COMPLETED)";
				} else {
					contPanelHeader1 = contPanelHeader + " (Completed with Observations)";
				}
			}
			if (data.ContCleanChk === false || data.ContCleanChk === undefined) {
				contPanelHeader1 = contPanelHeader + " (PENDING)";
			}
			var oSimpleForm = new sap.ui.layout.form.SimpleForm({
				layout: sap.ui.layout.form.SimpleFormLayout.ResponsiveGridLayout,
				editable: true,
				labelSpanL: 3,
				labelSpanM: 3,
				labelSpanS: 4,
				emptySpanL: 0,
				emptySpanM: 0,
				content: [new sap.m.Label({
						text: contQuestion,
						required: true
					}),
					new sap.m.RadioButtonGroup("id" + contRefId + contBoxNo + contNo, {
						columns: 3,
						selectedIndex: data.ContCleanHdpeIssue,
						buttons: [
							new sap.m.RadioButton({
								text: "YES",
								selected: true
							}),
							new sap.m.RadioButton({
								text: "NO"
							}),
							new sap.m.RadioButton({
								text: "NA"
							})
						],
						enabled: this.checkInspectionParameters(),
						select: function(oEvent) {
							var buttonSelected = oEvent.getSource().getSelectedIndex();
							if (buttonSelected === 1) {
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setEnabled(
									true);
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setEnabled(
									true);
							}
							if (buttonSelected === 0 || buttonSelected === 2) {
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setEnabled(
									false);
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setEnabled(
									false);
								/*oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setValue("");
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setValue("");*/
							}
						}
					}),
					new sap.m.FlexBox({
						justifyContent: sap.m.FlexAlignItems.Center,
						alignContent: sap.m.FlexAlignItems.Center,
						items: [
							new sap.m.Button({
								text: "Edit",
								enabled: this.inspectionButtonParameters(), //inspectionEditEnableModel.getProperty("/InspectionEditSaveButtons"),
								press: function(oEvent) {
									var check = true,
										vehChk, vehAppr;
									var oItems = this.getView().getModel("InspectionModel").getProperty("/Items");
									for (var i = 0; i < oItems.length; i++) {
										if (oItems[i].ContainerNo === data.ContainerNo) {
											vehChk = oItems[i].ContCleanChk;
											vehAppr = oItems[i].ContCleanHdpeApprNeed;
										}
									}
									var radio = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
											0]
										._aElements[1].getSelectedIndex();
									if (radio === 0 || radio === 2) {
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											1].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											8].setEnabled(true);
									}
									if (radio === 1) {
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											1].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											4].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											6].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											8].setEnabled(true);
									}
								}
							}).addStyleClass("sapUiSmallMarginEnd"),
							new sap.m.Button({
								text: "Save and Continue",
								type: "Emphasized",
								enabled: this.inspectionButtonParameters(), //inspectionEditEnableModel.getProperty("/InspectionEditSaveButtons"),
								press: function(oEvent) {
									var ContCleanHdpeIssue = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent()
										.getContent()[
											0]._aElements[1].getSelectedIndex();
									var ContCleanObservations = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent()
										.getContent()[0]._aElements[4].getValue();
									var ContCleanCorrMeasures = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent()
										.getContent()[0]._aElements[6].getValue();
									var check = true,
										vehChk, vehAppr;
									var oItems = this.getView().getModel("InspectionModel").getProperty("/Items");
									for (var i = 0; i < oItems.length; i++) {
										if (oItems[i].ContainerNo === data.ContainerNo) {
											vehChk = oItems[i].ContCleanChk;
											vehAppr = oItems[i].ContCleanHdpeApprNeed;
										}
									}
									var oFileUploader = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
										0]._aElements[8];
									var payload = {
										"ContCleanHdpeIssue": ContCleanHdpeIssue,
										"ContCleanObservations": ContCleanObservations,
										"ContCleanCorrMeasures": ContCleanCorrMeasures,
										"TruckNumber": this.truckNumber,
										"TripNumber": this.tripNumber,
										"ContainerNo": contNo,
										"InspectionStatus": "IP",
										"ContainerBoxNo": contBoxNo,
										"ContCleanChk": check
									};
									if (ContCleanHdpeIssue === 1) {
										if (!vehChk) {
											this.oHDPEEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (payload.ContCleanObser !== "" && payload.ContCleanCorrMeasures !== "") {
												if (this.fileHDPEName) {
													if (this.fileHDPEType === "image/jpeg") {
														oFileUploader.destroyHeaderParameters();
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "SLUG",
															value: this.fileHDPEName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
																'"/"' +
																contNo + '"/"' + contBoxNo + '"/"' + 9
														}));
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "Content-Type",
															value: this.fileHDPEType
														}));
														this.getOwnerComponent().getModel().refreshSecurityToken();
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "x-csrf-token",
															value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
														}));
														oFileUploader.setSendXHR(true);
														oFileUploader.upload();
													} else {
														MessageBox.error("File format should be JPG");
													}
												}
												this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
													"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
													"',ContainerNo='" +
													contNo + "')", payload, {
														method: "PUT",
														success: function(response) {
															MessageBox.success("HDPE details have been updated successfully");
															this.oHDPEEvent._aElements[1].setEnabled(false);
															this.oHDPEEvent._aElements[4].setEnabled(false);
															this.oHDPEEvent._aElements[6].setEnabled(false);
															this.oHDPEEvent._aElements[8].setEnabled(false);
															this.readHeaderEntitySet();
															this.readInspectionEntitySetforContainer();
														}.bind(this),
														error: function(error) {
															MessageBox.warning("Error occurred while updating the data");
														}
													});
											} else {
												MessageBox.error("Please update all parameters");
											}
										}
										if (vehChk) {
											this.oHDPEEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileHDPEName) {
												if (this.fileHDPEType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileHDPEName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 9
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileHDPEType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oHDPEEvent._aElements[1].setEnabled(false);
														this.oHDPEEvent._aElements[4].setEnabled(false);
														this.oHDPEEvent._aElements[6].setEnabled(false);
														this.oHDPEEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
									if (ContCleanHdpeIssue === 0) {
										if (!vehChk) {
											this.oHDPEEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileHDPEName) {
												if (this.fileHDPEType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileHDPEName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 9
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileHDPEType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();
												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														MessageBox.success("HDPE details have been updated successfully");
														this.oHDPEEvent._aElements[1].setEnabled(false);
														this.oHDPEEvent._aElements[4].setEnabled(false);
														this.oHDPEEvent._aElements[6].setEnabled(false);
														this.oHDPEEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
										if (vehChk) {
											this.oHDPEEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileHDPEName) {
												if (this.fileHDPEType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileHDPEName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 9
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileHDPEType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oHDPEEvent._aElements[1].setEnabled(false);
														this.oHDPEEvent._aElements[4].setEnabled(false);
														this.oHDPEEvent._aElements[6].setEnabled(false);
														this.oHDPEEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
									if (ContCleanHdpeIssue === 2) {
										if (!vehChk) {
											this.oHDPEEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileHDPEName) {
												if (this.fileHDPEType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileHDPEName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 9
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileHDPEType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														MessageBox.success("HDPE details have been updated successfully");
														this.oHDPEEvent._aElements[1].setEnabled(false);
														this.oHDPEEvent._aElements[4].setEnabled(false);
														this.oHDPEEvent._aElements[6].setEnabled(false);
														this.oHDPEEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
										if (vehChk) {
											this.oHDPEEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileHDPEName) {
												if (this.fileHDPEType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileHDPEName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 9
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileHDPEType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oHDPEEvent._aElements[1].setEnabled(false);
														this.oHDPEEvent._aElements[4].setEnabled(false);
														this.oHDPEEvent._aElements[6].setEnabled(false);
														this.oHDPEEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
								}.bind(this)
							})
						]
					}),
					new sap.m.Label({
						text: "Observations",
						required: true
					}),
					new sap.m.TextArea("id" + contRefId + "Observations" + contBoxNo + contNo, {
						value: data.ContCleanObservations,
						maxLength: 100,
						enabled: this.checkNewInspectionParameters(data.ContCleanHdpeIssue)
					}),
					new sap.m.Label({
						text: "Corrective Measures",
						required: true
					}),
					new sap.m.TextArea("id" + contRefId + "CorectiveMeasures" + contBoxNo + contNo, {
						value: data.ContCleanCorrMeasures,
						maxLength: 100,
						enabled: this.checkNewInspectionParameters(data.ContCleanHdpeIssue)
					}),
					new sap.m.Label({
						text: "Upload Photo"
					}),
					new sap.ui.unified.FileUploader("id" + contRefId + "FileUpload" + contBoxNo + contNo, {
						uploadUrl: "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet",
						uploadComplete: "handleUploadComplete",
						change: function(oEvent) {
							this.fileHDPEName = oEvent.getParameter("files")[0].name;
							this.fileHDPEType = oEvent.getParameter("files")[0].type;
							this.fileHDPESize = oEvent.getParameter("files")[0].size;
							if (oEvent.getSource().oFileUpload.files.length > 0) {
								var file = oEvent.getSource().oFileUpload.files;
								var blobObj = new Blob(file, {
									type: "	image/jpeg"
								});
								var path = URL.createObjectURL(blobObj);
								oEvent.getSource().getParent().getFields()[1].setSrc(path);
							}
						}.bind(this),
						fileType: "jpg",
						style: "Emphasized",
						sendXHR: true,
						useMultipart: false,
						placeholder: "Choose the Container Image",
						enabled: this.checkInspectionParameters()
					}),
					new sap.m.Image("id" + contRefId + "Image" + contBoxNo + contNo, {
						width: "50%",
						height: "50%"
					})
				]
			});
			var oPanel = new sap.m.Panel({
				headerText: contPanelHeader1,
				expanded: false,
				expandable: true,
				content: [oSimpleForm]
			});
			return oPanel;
		},
		createContainerInnerCheckListStuffCont: function(contBoxNo, contNo, contPanelHeader, contRefId, contQuestion, bindingIndex) {
			var items = this.getView().getModel("InspectionModel").getProperty("/Items");
			var data = items[bindingIndex];
			var contPanelHeader1;
			if (data.ContReadyChk) {
				if (data.ContReadyIssue === 0 || data.ContReadyIssue === 2) {
					contPanelHeader1 = contPanelHeader + " (COMPLETED)";
				} else {
					contPanelHeader1 = contPanelHeader + " (Completed with Observations)";
				}
			}
			if (data.ContReadyChk === false || data.ContReadyChk === undefined) {
				contPanelHeader1 = contPanelHeader + " (PENDING)";
			}
			var oSimpleForm = new sap.ui.layout.form.SimpleForm({
				layout: sap.ui.layout.form.SimpleFormLayout.ResponsiveGridLayout,
				editable: true,
				labelSpanL: 3,
				labelSpanM: 3,
				labelSpanS: 4,
				emptySpanL: 0,
				emptySpanM: 0,
				content: [new sap.m.Label({
						text: contQuestion,
						required: true
					}),
					new sap.m.RadioButtonGroup("id" + contRefId + contBoxNo + contNo, {
						columns: 3,
						selectedIndex: data.ContReadyIssue,
						buttons: [
							new sap.m.RadioButton({
								text: "YES",
								selected: true
							}),
							new sap.m.RadioButton({
								text: "NO"
							}),
							new sap.m.RadioButton({
								text: "NA"
							})
						],
						enabled: this.checkInspectionParameters(),
						select: function(oEvent) {
							var buttonSelected = oEvent.getSource().getSelectedIndex();
							if (buttonSelected === 1) {
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setEnabled(
									true);
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setEnabled(
									true);
							}
							if (buttonSelected === 0 || buttonSelected === 2) {
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setEnabled(
									false);
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setEnabled(
									false);
								/*oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setValue("");
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setValue("");*/
							}
						}
					}),
					new sap.m.FlexBox({
						justifyContent: sap.m.FlexAlignItems.Center,
						alignContent: sap.m.FlexAlignItems.Center,
						items: [
							new sap.m.Button({
								text: "Edit",
								enabled: this.inspectionButtonParameters(), //inspectionEditEnableModel.getProperty("/InspectionEditSaveButtons"),
								press: function(oEvent) {
									var check = true,
										vehChk, vehAppr;
									var oItems = this.getView().getModel("InspectionModel").getProperty("/Items");
									for (var i = 0; i < oItems.length; i++) {
										if (oItems[i].ContainerNo === data.ContainerNo) {
											vehChk = oItems[i].ContReadyChk;
											vehAppr = oItems[i].ContReadyApprNeed;
										}
									}
									var radio = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
											0]
										._aElements[1].getSelectedIndex();
									if (radio === 0 || radio === 2) {
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											1].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											8].setEnabled(true);
									}
									if (radio === 1) {
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											1].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											4].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											6].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											8].setEnabled(true);
									}
								}
							}).addStyleClass("sapUiSmallMarginEnd"),
							new sap.m.Button({
								text: "Save and Continue",
								type: "Emphasized",
								enabled: this.inspectionButtonParameters(), //inspectionEditEnableModel.getProperty("/InspectionEditSaveButtons"),
								press: function(oEvent) {
									var ContReadyIssue = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
										0]._aElements[1].getSelectedIndex();
									var ContReadyObservations = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent()
										.getContent()[0]._aElements[4].getValue();
									var ContReadyCorrMeasure = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent()
										.getContent()[
											0]._aElements[6].getValue();
									var check = true,
										vehChk, vehAppr;
									var oItems = this.getView().getModel("InspectionModel").getProperty("/Items");
									for (var i = 0; i < oItems.length; i++) {
										if (oItems[i].ContainerNo === data.ContainerNo) {
											vehChk = oItems[i].ContReadyChk;
											vehAppr = oItems[i].ContReadyApprNeed;
										}
									}
									var oFileUploader = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
										0]._aElements[8];
									var payload = {
										"ContReadyIssue": ContReadyIssue,
										"ContReadyObservations": ContReadyObservations,
										"ContReadyCorrMeasure": ContReadyCorrMeasure,
										"TruckNumber": this.truckNumber,
										"TripNumber": this.tripNumber,
										"ContainerNo": contNo,
										"InspectionStatus": "IP",
										"ContainerBoxNo": contBoxNo,
										"ContReadyChk": check
									};
									if (ContReadyIssue === 1) {
										if (!vehChk) {
											this.oSContEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (payload.ContReadyObservations !== "" && payload.ContReadyCorrMeasure !== "") {
												if (this.fileStffCntName) {
													if (this.fileStffCntType === "image/jpeg") {
														oFileUploader.destroyHeaderParameters();
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "SLUG",
															value: this.fileStffCntName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
																'"/"' +
																contNo + '"/"' + contBoxNo + '"/"' + 10
														}));
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "Content-Type",
															value: this.fileStffCntType
														}));
														this.getOwnerComponent().getModel().refreshSecurityToken();
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "x-csrf-token",
															value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
														}));
														oFileUploader.setSendXHR(true);
														oFileUploader.upload();
														this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
															"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
															"',ContainerNo='" +
															contNo + "')", payload, {
																method: "PUT",
																success: function(response) {
																	MessageBox.success("Container Stuffing details  have been updated successfully");
																	this.oSContEvent._aElements[1].setEnabled(false);
																	this.oSContEvent._aElements[4].setEnabled(false);
																	this.oSContEvent._aElements[6].setEnabled(false);
																	this.oSContEvent._aElements[8].setEnabled(false);
																	this.readHeaderEntitySet();
																	this.readInspectionEntitySetforContainer();
																}.bind(this),
																error: function(error) {
																	MessageBox.warning("Error occurred while updating the data");
																}
															});

													} else {
														MessageBox.error("File format should be JPG");
													}
												}
											} else {
												MessageBox.error("Please update all parameters");
											}
										}
										if (vehChk) {
											this.oSContEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileStffCntName) {
												if (this.fileStffCntType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileStffCntName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 10
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileStffCntType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oSContEvent._aElements[1].setEnabled(false);
														this.oSContEvent._aElements[4].setEnabled(false);
														this.oSContEvent._aElements[6].setEnabled(false);
														this.oSContEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
									if (ContReadyIssue === 0) {
										if (!vehChk) {
											this.oSContEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileStffCntName) {
												if (this.fileStffCntType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileStffCntName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 10
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileStffCntType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();
												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														MessageBox.success("Container Stuffing details  have been updated successfully");
														this.oSContEvent._aElements[1].setEnabled(false);
														this.oSContEvent._aElements[4].setEnabled(false);
														this.oSContEvent._aElements[6].setEnabled(false);
														this.oSContEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
										if (vehChk) {
											this.oSContEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileStffCntName) {
												if (this.fileStffCntType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileStffCntName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 10
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileStffCntType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oSContEvent._aElements[1].setEnabled(false);
														this.oSContEvent._aElements[4].setEnabled(false);
														this.oSContEvent._aElements[6].setEnabled(false);
														this.oSContEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
									if (ContReadyIssue === 2) {
										if (!vehChk) {
											this.oSContEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileStffCntName) {
												if (this.fileStffCntType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileStffCntName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 10
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileStffCntType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();
												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														MessageBox.success("Container Stuffing details  have been updated successfully");
														this.oSContEvent._aElements[1].setEnabled(false);
														this.oSContEvent._aElements[4].setEnabled(false);
														this.oSContEvent._aElements[6].setEnabled(false);
														this.oSContEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
										if (vehChk) {
											this.oSContEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileStffCntName) {
												if (this.fileStffCntType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileStffCntName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 10
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileStffCntType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oSContEvent._aElements[1].setEnabled(false);
														this.oSContEvent._aElements[4].setEnabled(false);
														this.oSContEvent._aElements[6].setEnabled(false);
														this.oSContEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
								}.bind(this)
							})
						]
					}),
					new sap.m.Label({
						text: "Observations",
						required: true
					}),
					new sap.m.TextArea("id" + contRefId + "Observations" + contBoxNo + contNo, {
						value: data.ContReadyObservations,
						maxLength: 100,
						enabled: this.checkNewInspectionParameters(data.ContReadyIssue)
					}),
					new sap.m.Label({
						text: "Corrective Measures",
						required: true
					}),
					new sap.m.TextArea("id" + contRefId + "CorectiveMeasures" + contBoxNo + contNo, {
						value: data.ContReadyCorrMeasure,
						maxLength: 100,
						enabled: this.checkNewInspectionParameters(data.ContReadyIssue)
					}),
					new sap.m.Label({
						text: "Upload Photo"
					}),
					new sap.ui.unified.FileUploader("id" + contRefId + "FileUpload" + contBoxNo + contNo, {
						uploadUrl: "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet",
						uploadComplete: "handleUploadComplete",
						change: function(oEvent) {
							this.fileStffCntName = oEvent.getParameter("files")[0].name;
							this.fileStffCntType = oEvent.getParameter("files")[0].type;
							this.fileStffCntSize = oEvent.getParameter("files")[0].size;
							if (oEvent.getSource().oFileUpload.files.length > 0) {
								var file = oEvent.getSource().oFileUpload.files;
								var blobObj = new Blob(file, {
									type: "	image/jpeg"
								});
								var path = URL.createObjectURL(blobObj);
								oEvent.getSource().getParent().getFields()[1].setSrc(path);
							}
						}.bind(this),
						fileType: "jpg",
						style: "Emphasized",
						sendXHR: true,
						useMultipart: false,
						placeholder: "Choose the Container Image",
						enabled: this.checkInspectionParameters()
					}),
					new sap.m.Image("id" + contRefId + "Image" + contBoxNo + contNo, {
						width: "50%",
						height: "50%"
					})
				]
			});
			var oPanel = new sap.m.Panel({
				headerText: contPanelHeader1,
				expanded: false,
				expandable: true,
				content: [oSimpleForm]
			});
			return oPanel;
		},
		createContainerInnerCheckListCleanCont: function(contBoxNo, contNo, contPanelHeader, contRefId, contQuestion, bindingIndex) {
			var items = this.getView().getModel("InspectionModel").getProperty("/Items");
			var data = items[bindingIndex];
			var contPanelHeader1;
			if (data.ContLoadCleanChk) {
				if (data.ContLoadCleanIssue === 0 || data.ContLoadCleanIssue === 2) {
					contPanelHeader1 = contPanelHeader + " (COMPLETED)";
				} else {
					contPanelHeader1 = contPanelHeader + " (Completed with Observations)";
				}
			}
			if (data.ContLoadCleanChk === false || data.ContLoadCleanChk === undefined) {
				contPanelHeader1 = contPanelHeader + " (PENDING)";
			}
			var oSimpleForm = new sap.ui.layout.form.SimpleForm({
				layout: sap.ui.layout.form.SimpleFormLayout.ResponsiveGridLayout,
				editable: true,
				labelSpanL: 3,
				labelSpanM: 3,
				labelSpanS: 4,
				emptySpanL: 0,
				emptySpanM: 0,
				content: [new sap.m.Label({
						text: contQuestion,
						required: true
					}),
					new sap.m.RadioButtonGroup("id" + contRefId + contBoxNo + contNo, {
						columns: 3,
						selectedIndex: data.ContLoadCleanIssue,
						buttons: [
							new sap.m.RadioButton({
								text: "YES",
								selected: true
							}),
							new sap.m.RadioButton({
								text: "NO"
							}),
							new sap.m.RadioButton({
								text: "NA"
							})
						],
						enabled: this.checkInspectionParameters(),
						select: function(oEvent) {
							var buttonSelected = oEvent.getSource().getSelectedIndex();
							if (buttonSelected === 1) {
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setEnabled(
									true);
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setEnabled(
									true);
							}
							if (buttonSelected === 0 || buttonSelected === 2) {
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setEnabled(
									false);
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setEnabled(
									false);
								/*oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setValue("");
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setValue("");*/
							}
						}
					}),
					new sap.m.FlexBox({
						justifyContent: sap.m.FlexAlignItems.Center,
						alignContent: sap.m.FlexAlignItems.Center,
						items: [
							new sap.m.Button({
								text: "Edit",
								enabled: this.inspectionButtonParameters(), //inspectionEditEnableModel.getProperty("/InspectionEditSaveButtons"),
								press: function(oEvent) {
									var check = true,
										vehChk, vehAppr;
									var oItems = this.getView().getModel("InspectionModel").getProperty("/Items");
									for (var i = 0; i < oItems.length; i++) {
										if (oItems[i].ContainerNo === data.ContainerNo) {
											vehChk = oItems[i].ContLoadCleanChk;
											vehAppr = oItems[i].ContLoadApprNeed;
										}
									}
									var radio = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
											0]
										._aElements[1].getSelectedIndex();
									if (radio === 0 || radio === 2) {
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											1].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											8].setEnabled(true);
									}
									if (radio === 1) {
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											1].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											4].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											6].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											8].setEnabled(true);
									}
								}
							}).addStyleClass("sapUiSmallMarginEnd"),
							new sap.m.Button({
								text: "Save and Continue",
								type: "Emphasized",
								enabled: this.inspectionButtonParameters(), //inspectionEditEnableModel.getProperty("/InspectionEditSaveButtons"),
								press: function(oEvent) {
									var ContLoadCleanIssue = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent()
										.getContent()[
											0]._aElements[1].getSelectedIndex();
									var ContLoadObservations = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent()
										.getContent()[
											0]._aElements[4].getValue();
									var ContLoadCorrMeasure = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent()
										.getContent()[
											0]._aElements[6].getValue();
									var check = true,
										vehChk, vehAppr;
									var oItems = this.getView().getModel("InspectionModel").getProperty("/Items");
									for (var i = 0; i < oItems.length; i++) {
										if (oItems[i].ContainerNo === data.ContainerNo) {
											vehChk = oItems[i].ContLoadCleanChk;
											vehAppr = oItems[i].ContLoadApprNeed;
										}
									}
									var oFileUploader = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
										0]._aElements[8];
									var payload = {
										"ContLoadCleanIssue": ContLoadCleanIssue,
										"ContLoadObservations": ContLoadObservations,
										"ContLoadCorrMeasure": ContLoadCorrMeasure,
										"TruckNumber": this.truckNumber,
										"TripNumber": this.tripNumber,
										"ContainerNo": contNo,
										"InspectionStatus": "IP",
										"ContainerBoxNo": contBoxNo,
										"ContLoadCleanChk": check
									};
									if (ContLoadCleanIssue === 1) {
										if (!vehChk) {
											this.oCleanCont = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (payload.ContLoadObservations !== "" && payload.ContLoadCorrMeasure !== "") {
												if (this.fileCleanCName) {
													if (this.fileCleanCType === "image/jpeg") {
														oFileUploader.destroyHeaderParameters();
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "SLUG",
															value: this.fileCleanCName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
																'"/"' +
																contNo + '"/"' + contBoxNo + '"/"' + 11
														}));
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "Content-Type",
															value: this.fileCleanCType
														}));
														this.getOwnerComponent().getModel().refreshSecurityToken();
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "x-csrf-token",
															value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
														}));
														oFileUploader.setSendXHR(true);
														oFileUploader.upload();
													} else {
														MessageBox.error("File format should be JPG");
													}
												}
												this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
													"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
													"',ContainerNo='" +
													contNo + "')", payload, {
														method: "PUT",
														success: function(response) {
															MessageBox.success("Container cleaning details have been updated successfully");
															this.oCleanCont._aElements[1].setEnabled(false);
															this.oCleanCont._aElements[4].setEnabled(false);
															this.oCleanCont._aElements[6].setEnabled(false);
															this.oCleanCont._aElements[8].setEnabled(false);
															this.readHeaderEntitySet();
															this.readInspectionEntitySetforContainer();
														}.bind(this),
														error: function(error) {
															MessageBox.warning("Error occurred while updating the data");
														}
													});
											} else {
												MessageBox.error("Please update all parameters");
											}
										}
										if (vehChk) {
											this.oCleanCont = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileCleanCName) {
												if (this.fileCleanCType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileCleanCName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 11
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileCleanCType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();
												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oCleanCont._aElements[1].setEnabled(false);
														this.oCleanCont._aElements[4].setEnabled(false);
														this.oCleanCont._aElements[6].setEnabled(false);
														this.oCleanCont._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
									if (ContLoadCleanIssue === 0) {
										if (!vehChk) {
											this.oCleanCont = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileCleanCName) {
												if (this.fileCleanCType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileCleanCName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 11
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileCleanCType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();
												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														MessageBox.success("Container cleaning details have been updated successfully");
														this.oCleanCont._aElements[1].setEnabled(false);
														this.oCleanCont._aElements[4].setEnabled(false);
														this.oCleanCont._aElements[6].setEnabled(false);
														this.oCleanCont._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
										if (vehChk) {
											this.oCleanCont = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileCleanCName) {
												if (this.fileCleanCType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileCleanCName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 11
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileCleanCType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oCleanCont._aElements[1].setEnabled(false);
														this.oCleanCont._aElements[4].setEnabled(false);
														this.oCleanCont._aElements[6].setEnabled(false);
														this.oCleanCont._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
									if (ContLoadCleanIssue === 2) {
										if (!vehChk) {
											this.oCleanCont = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileCleanCName) {
												if (this.fileCleanCType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileCleanCName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 11
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileCleanCType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														MessageBox.success("Container cleaning details have been updated successfully");
														this.oCleanCont._aElements[1].setEnabled(false);
														this.oCleanCont._aElements[4].setEnabled(false);
														this.oCleanCont._aElements[6].setEnabled(false);
														this.oCleanCont._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
										if (vehChk) {
											this.oCleanCont = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileCleanCName) {
												if (this.fileCleanCType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileCleanCName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 11
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileCleanCType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oCleanCont._aElements[1].setEnabled(false);
														this.oCleanCont._aElements[4].setEnabled(false);
														this.oCleanCont._aElements[6].setEnabled(false);
														this.oCleanCont._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
								}.bind(this)
							})
						]
					}),
					new sap.m.Label({
						text: "Observations",
						required: true
					}),
					new sap.m.TextArea("id" + contRefId + "Observations" + contBoxNo + contNo, {
						value: data.ContLoadObservations,
						maxLength: 100,
						enabled: this.checkNewInspectionParameters(data.ContLoadCleanIssue)
					}),
					new sap.m.Label({
						text: "Corrective Measures",
						required: true
					}),
					new sap.m.TextArea("id" + contRefId + "CorectiveMeasures" + contBoxNo + contNo, {
						value: data.ContLoadCorrMeasure,
						maxLength: 100,
						enabled: this.checkNewInspectionParameters(data.ContLoadCleanIssue)
					}),
					new sap.m.Label({
						text: "Upload Photo"
					}),
					new sap.ui.unified.FileUploader("id" + contRefId + "FileUpload" + contBoxNo + contNo, {
						uploadUrl: "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet",
						uploadComplete: "handleUploadComplete",
						change: function(oEvent) {
							this.fileCleanCName = oEvent.getParameter("files")[0].name;
							this.fileCleanCType = oEvent.getParameter("files")[0].type;
							this.fileCleanCSize = oEvent.getParameter("files")[0].size;
							if (oEvent.getSource().oFileUpload.files.length > 0) {
								var file = oEvent.getSource().oFileUpload.files;
								var blobObj = new Blob(file, {
									type: "	image/jpeg"
								});
								var path = URL.createObjectURL(blobObj);
								oEvent.getSource().getParent().getFields()[1].setSrc(path);
							}
						}.bind(this),
						fileType: "jpg",
						style: "Emphasized",
						sendXHR: true,
						useMultipart: false,
						placeholder: "Choose the Container Image",
						enabled: this.checkInspectionParameters()
					}),
					new sap.m.Image("id" + contRefId + "Image" + contBoxNo + contNo, {
						width: "50%",
						height: "50%"
					})
				]
			});
			var oPanel = new sap.m.Panel({
				headerText: contPanelHeader1,
				expanded: false,
				expandable: true,
				content: [oSimpleForm]
			});
			return oPanel;
		},
		createContainerInnerCheckListDCheck: function(contBoxNo, contNo, contPanelHeader, contRefId, contQuestion, bindingIndex) {
			var items = this.getView().getModel("InspectionModel").getProperty("/Items");
			var data = items[bindingIndex];
			var contPanelHeader1;
			if (data.ContLockChk) {
				if (data.ContLockIssue === 0 || data.ContLockIssue === 2) {
					contPanelHeader1 = contPanelHeader + " (COMPLETED)";
				} else {
					contPanelHeader1 = contPanelHeader + " (Completed with Observations)";
				}
			}
			if (data.ContLockChk === false || data.ContLockChk === undefined) {
				contPanelHeader1 = contPanelHeader + " (PENDING)";
			}
			var oSimpleForm = new sap.ui.layout.form.SimpleForm({
				layout: sap.ui.layout.form.SimpleFormLayout.ResponsiveGridLayout,
				editable: true,
				labelSpanL: 3,
				labelSpanM: 3,
				labelSpanS: 4,
				emptySpanL: 0,
				emptySpanM: 0,
				content: [new sap.m.Label({
						text: contQuestion,
						required: true
					}),
					new sap.m.RadioButtonGroup("id" + contRefId + contBoxNo + contNo, {
						columns: 3,
						selectedIndex: data.ContLockIssue,
						buttons: [
							new sap.m.RadioButton({
								text: "YES",
								selected: true
							}),
							new sap.m.RadioButton({
								text: "NO"
							}),
							new sap.m.RadioButton({
								text: "NA"
							})
						],
						enabled: this.checkInspectionParameters(),
						select: function(oEvent) {
							var buttonSelected = oEvent.getSource().getSelectedIndex();
							if (buttonSelected === 1) {
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setEnabled(
									true);
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setEnabled(
									true);
							}
							if (buttonSelected === 0 || buttonSelected === 2) {
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setEnabled(
									false);
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setEnabled(
									false);
								/*oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setValue("");
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setValue("");*/
							}
						}
					}),
					new sap.m.FlexBox({
						justifyContent: sap.m.FlexAlignItems.Center,
						alignContent: sap.m.FlexAlignItems.Center,
						items: [
							new sap.m.Button({
								text: "Edit",
								enabled: this.inspectionButtonParameters(), //inspectionEditEnableModel.getProperty("/InspectionEditSaveButtons"),
								press: function(oEvent) {
									var check = true,
										vehChk, vehAppr;
									var oItems = this.getView().getModel("InspectionModel").getProperty("/Items");
									for (var i = 0; i < oItems.length; i++) {
										if (oItems[i].ContainerNo === data.ContainerNo) {
											vehChk = oItems[i].ContLockChk;
											vehAppr = oItems[i].ContLockApprNeed;
										}
									}
									var radio = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
											0]
										._aElements[1].getSelectedIndex();
									if (radio === 0 || radio === 2) {
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											1].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											8].setEnabled(true);
									}
									if (radio === 1) {
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											1].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											4].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											6].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											8].setEnabled(true);
									}
								}
							}).addStyleClass("sapUiSmallMarginEnd"),
							new sap.m.Button({
								text: "Save and Continue",
								type: "Emphasized",
								enabled: this.inspectionButtonParameters(), //inspectionEditEnableModel.getProperty("/InspectionEditSaveButtons"),
								press: function(oEvent) {
									var ContLockIssue = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
										0]._aElements[1].getSelectedIndex();
									var ContLockObservations = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent()
										.getContent()[
											0]._aElements[4].getValue();
									var ContLockCorrectMeasure = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent()
										.getContent()[0]._aElements[6].getValue();
									var check = true,
										vehChk, vehAppr;
									var oItems = this.getView().getModel("InspectionModel").getProperty("/Items");
									for (var i = 0; i < oItems.length; i++) {
										if (oItems[i].ContainerNo === data.ContainerNo) {
											vehChk = oItems[i].ContLockChk;
											vehAppr = oItems[i].ContLockApprNeed;
										}
									}
									var oFileUploader = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
										0]._aElements[8];
									var payload = {
										"ContLockIssue": ContLockIssue,
										"ContLockObservations": ContLockObservations,
										"ContLockCorrectMeasure": ContLockCorrectMeasure,
										"TruckNumber": this.truckNumber,
										"TripNumber": this.tripNumber,
										"ContainerNo": contNo,
										"InspectionStatus": "IP",
										"ContainerBoxNo": contBoxNo,
										"ContLockChk": check
									};
									if (ContLockIssue === 1) {
										if (!vehChk) {
											this.oDCheckEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (payload.ContLockObservations !== "" && payload.ContLockCorrMeasure !== "") {
												if (this.fileDCheckName) {
													if (this.fileDCheckType === "image/jpeg") {
														oFileUploader.destroyHeaderParameters();
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "SLUG",
															value: this.fileDCheckName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
																'"/"' +
																contNo + '"/"' + contBoxNo + '"/"' + 13
														}));
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "Content-Type",
															value: this.fileDCheckType
														}));
														this.getOwnerComponent().getModel().refreshSecurityToken();
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "x-csrf-token",
															value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
														}));
														oFileUploader.setSendXHR(true);
														oFileUploader.upload();
													} else {
														MessageBox.error("File format should be JPG");
													}
												}
												this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
													"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
													"',ContainerNo='" +
													contNo + "')", payload, {
														method: "PUT",
														success: function(response) {
															MessageBox.success("Container door details have been updated successfully");
															this.oDCheckEvent._aElements[1].setEnabled(false);
															this.oDCheckEvent._aElements[4].setEnabled(false);
															this.oDCheckEvent._aElements[6].setEnabled(false);
															this.oDCheckEvent._aElements[8].setEnabled(false);
															this.readHeaderEntitySet();
															this.readInspectionEntitySetforContainer();
														}.bind(this),
														error: function(error) {
															MessageBox.warning("Error occurred while updating the data");
														}
													});
											} else {
												MessageBox.error("Please update all parameters");
											}
										}
										if (vehChk) {
											this.oDCheckEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileDCheckName) {
												if (this.fileDCheckType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileDCheckName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 13
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileDCheckType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oDCheckEvent._aElements[1].setEnabled(false);
														this.oDCheckEvent._aElements[4].setEnabled(false);
														this.oDCheckEvent._aElements[6].setEnabled(false);
														this.oDCheckEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
									if (ContLockIssue === 0) {
										if (!vehChk) {
											this.oDCheckEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileDCheckName) {
												if (this.fileDCheckType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileDCheckName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 13
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileDCheckType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();
												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														MessageBox.success("Container door details have been updated successfully");
														this.oDCheckEvent._aElements[1].setEnabled(false);
														this.oDCheckEvent._aElements[4].setEnabled(false);
														this.oDCheckEvent._aElements[6].setEnabled(false);
														this.oDCheckEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
										if (vehChk) {
											this.oDCheckEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileDCheckName) {
												if (this.fileDCheckType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileDCheckName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 13
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileDCheckType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oDCheckEvent._aElements[1].setEnabled(false);
														this.oDCheckEvent._aElements[4].setEnabled(false);
														this.oDCheckEvent._aElements[6].setEnabled(false);
														this.oDCheckEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
									if (ContLockIssue === 2) {
										if (!vehChk) {
											this.oDCheckEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileDCheckName) {
												if (this.fileDCheckType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileDCheckName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 13
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileDCheckType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														MessageBox.success("Container door details have been updated successfully");
														this.oDCheckEvent._aElements[1].setEnabled(false);
														this.oDCheckEvent._aElements[4].setEnabled(false);
														this.oDCheckEvent._aElements[6].setEnabled(false);
														this.oDCheckEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
										if (vehChk) {
											this.oDCheckEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileDCheckName) {
												if (this.fileDCheckType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileDCheckName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 13
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileDCheckType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oDCheckEvent._aElements[1].setEnabled(false);
														this.oDCheckEvent._aElements[4].setEnabled(false);
														this.oDCheckEvent._aElements[6].setEnabled(false);
														this.oDCheckEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
								}.bind(this)
							})
						]
					}),
					new sap.m.Label({
						text: "Observations",
						required: true
					}),
					new sap.m.TextArea("id" + contRefId + "Observations" + contBoxNo + contNo, {
						value: data.ContLockObservations,
						maxLength: 100,
						enabled: this.checkNewInspectionParameters(data.ContLockIssue)
					}),
					new sap.m.Label({
						text: "Corrective Measures",
						required: true
					}),
					new sap.m.TextArea("id" + contRefId + "CorectiveMeasures" + contBoxNo + contNo, {
						value: data.ContLockCorrectMeasure,
						maxLength: 100,
						enabled: this.checkNewInspectionParameters(data.ContLockIssue)
					}),
					new sap.m.Label({
						text: "Upload Photo"
					}),
					new sap.ui.unified.FileUploader("id" + contRefId + "FileUpload" + contBoxNo + contNo, {
						uploadUrl: "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet",
						uploadComplete: "handleUploadComplete",
						change: function(oEvent) {
							this.fileDCheckName = oEvent.getParameter("files")[0].name;
							this.fileDCheckType = oEvent.getParameter("files")[0].type;
							this.fileDCheckSize = oEvent.getParameter("files")[0].size;
							if (oEvent.getSource().oFileUpload.files.length > 0) {
								var file = oEvent.getSource().oFileUpload.files;
								var blobObj = new Blob(file, {
									type: "	image/jpeg"
								});
								var path = URL.createObjectURL(blobObj);
								oEvent.getSource().getParent().getFields()[1].setSrc(path);
							}
						}.bind(this),
						fileType: "jpg",
						style: "Emphasized",
						sendXHR: true,
						useMultipart: false,
						placeholder: "Choose the Container Image",
						enabled: this.checkInspectionParameters()
					}),
					new sap.m.Image("id" + contRefId + "Image" + contBoxNo + contNo, {
						width: "50%",
						height: "50%"
					})
				]
			});
			var oPanel = new sap.m.Panel({
				headerText: contPanelHeader1,
				expanded: false,
				expandable: true,
				content: [oSimpleForm]
			});
			return oPanel;
		},
		createContainerInnerCheckListJumbo: function(contBoxNo, contNo, contPanelHeader, contRefId, contQuestion, bindingIndex) {
			var items = this.getView().getModel("InspectionModel").getProperty("/Items");
			var data = items[bindingIndex];
			var contPanelHeader1;
			if (data.BagsStripChk) {
				if (data.BagsStripChkIssue === 0 || data.BagsStripChkIssue === 2) {
					contPanelHeader1 = contPanelHeader + " (COMPLETED)";
				} else {
					contPanelHeader1 = contPanelHeader + " (Completed with Observations)";
				}
			}
			if (data.BagsStripChk === false || data.BagsStripChk === undefined) {
				contPanelHeader1 = contPanelHeader + " (PENDING)";
			}
			var oSimpleForm = new sap.ui.layout.form.SimpleForm({
				layout: sap.ui.layout.form.SimpleFormLayout.ResponsiveGridLayout,
				editable: true,
				labelSpanL: 3,
				labelSpanM: 3,
				labelSpanS: 4,
				emptySpanL: 0,
				emptySpanM: 0,
				content: [new sap.m.Label({
						text: contQuestion,
						required: true
					}),
					new sap.m.RadioButtonGroup("id" + contRefId + contBoxNo + contNo, {
						columns: 3,
						selectedIndex: data.BagsStripChkIssue,
						buttons: [
							new sap.m.RadioButton({
								text: "YES",
								selected: true
							}),
							new sap.m.RadioButton({
								text: "NO"
							}),
							new sap.m.RadioButton({
								text: "NA"
							})
						],
						enabled: this.checkInspectionParameters(),
						select: function(oEvent) {
							var buttonSelected = oEvent.getSource().getSelectedIndex();
							if (buttonSelected === 1) {
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setEnabled(
									true);
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setEnabled(
									true);
							}
							if (buttonSelected === 0 || buttonSelected === 2) {
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setEnabled(
									false);
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setEnabled(
									false);
								/*	oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setValue("");
									oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setValue("");*/
							}
						}
					}),
					new sap.m.FlexBox({
						justifyContent: sap.m.FlexAlignItems.Center,
						alignContent: sap.m.FlexAlignItems.Center,
						items: [
							new sap.m.Button({
								text: "Edit",
								enabled: this.inspectionButtonParameters(), //inspectionEditEnableModel.getProperty("/InspectionEditSaveButtons"),
								press: function(oEvent) {
									var check = true,
										vehChk, vehAppr;
									var oItems = this.getView().getModel("InspectionModel").getProperty("/Items");
									for (var i = 0; i < oItems.length; i++) {
										if (oItems[i].ContainerNo === data.ContainerNo) {
											vehChk = oItems[i].BagsStripChk;
											vehAppr = oItems[i].BagStripApprNeed;
										}
									}
									var radio = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
											0]
										._aElements[1].getSelectedIndex();
									if (radio === 0 || radio === 2) {
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											1].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											8].setEnabled(true);
									}
									if (radio === 1) {
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											1].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											4].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											6].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											8].setEnabled(true);
									}
								}
							}).addStyleClass("sapUiSmallMarginEnd"),
							new sap.m.Button({
								text: "Save and Continue",
								type: "Emphasized",
								enabled: this.inspectionButtonParameters(), //inspectionEditEnableModel.getProperty("/InspectionEditSaveButtons"),
								press: function(oEvent) {
									var BagsStripChkIssue = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent()
										.getContent()[
											0]._aElements[1].getSelectedIndex();
									var BagsStripObservations = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent()
										.getContent()[0]._aElements[4].getValue();
									var BagStripCorrMeasure = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent()
										.getContent()[
											0]._aElements[6].getValue();
									var check = true,
										vehChk, vehAppr;
									var oItems = this.getView().getModel("InspectionModel").getProperty("/Items");
									for (var i = 0; i < oItems.length; i++) {
										if (oItems[i].ContainerNo === data.ContainerNo) {
											vehChk = oItems[i].BagsStripChk;
											vehAppr = oItems[i].BagStripApprNeed;
										}
									}
									var oFileUploader = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
										0]._aElements[8];
									var payload = {
										"BagsStripChkIssue": BagsStripChkIssue,
										"BagsStripObservations": BagsStripObservations,
										"BagStripCorrMeasure": BagStripCorrMeasure,
										"TruckNumber": this.truckNumber,
										"TripNumber": this.tripNumber,
										"ContainerNo": contNo,
										"InspectionStatus": "IP",
										"ContainerBoxNo": contBoxNo,
										"BagsStripChk": check
									};
									if (BagsStripChkIssue === 1) {
										if (!vehChk) {
											this.oJumbo = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (payload.BagsStripObservations !== "" && payload.BagStripCorrMeasure !== "") {
												if (this.fileJumboName) {
													if (this.fileJumboType === "image/jpeg") {
														oFileUploader.destroyHeaderParameters();
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "SLUG",
															value: this.fileJumboName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
																'"/"' +
																contNo + '"/"' + contBoxNo + '"/"' + 4
														}));
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "Content-Type",
															value: this.fileJumboType
														}));
														this.getOwnerComponent().getModel().refreshSecurityToken();
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "x-csrf-token",
															value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
														}));
														oFileUploader.setSendXHR(true);
														oFileUploader.upload();
													} else {
														MessageBox.error("File format should be JPG");
													}
												}
												this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
													"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
													"',ContainerNo='" +
													contNo + "')", payload, {
														method: "PUT",
														success: function(response) {
															MessageBox.success("JumboBags details have been updated successfully");
															this.oJumbo._aElements[1].setEnabled(false);
															this.oJumbo._aElements[4].setEnabled(false);
															this.oJumbo._aElements[6].setEnabled(false);
															this.oJumbo._aElements[8].setEnabled(false);
															this.readHeaderEntitySet();
															this.readInspectionEntitySetforContainer();
														}.bind(this),
														error: function(error) {
															MessageBox.warning("Error occurred while updating the data");
														}
													});
											} else {
												MessageBox.error("Please update all parameters");
											}
										}
										if (vehChk) {
											this.oJumbo = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileJumboName) {
												if (this.fileJumboType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileJumboName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 4
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileJumboType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oJumbo._aElements[1].setEnabled(false);
														this.oJumbo._aElements[4].setEnabled(false);
														this.oJumbo._aElements[6].setEnabled(false);
														this.oJumbo._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
									if (BagsStripChkIssue === 0) {
										if (!vehChk) {
											this.oJumbo = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileJumboName) {
												if (this.fileJumboType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileJumboName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 4
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileJumboType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();
												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														MessageBox.success("JumboBags details have been updated successfully");
														this.oJumbo._aElements[1].setEnabled(false);
														this.oJumbo._aElements[4].setEnabled(false);
														this.oJumbo._aElements[6].setEnabled(false);
														this.oJumbo._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
										if (vehChk) {
											this.oJumbo = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileJumboName) {
												if (this.fileJumboType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileJumboName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 4
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileJumboType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();
												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oJumbo._aElements[1].setEnabled(false);
														this.oJumbo._aElements[4].setEnabled(false);
														this.oJumbo._aElements[6].setEnabled(false);
														this.oJumbo._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
									if (BagsStripChkIssue === 2) {
										if (!vehChk) {
											this.oJumbo = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileJumboName) {
												if (this.fileJumboType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileJumboName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 4
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileJumboType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();
												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														MessageBox.success("JumboBags details have been updated successfully");
														this.oJumbo._aElements[1].setEnabled(false);
														this.oJumbo._aElements[4].setEnabled(false);
														this.oJumbo._aElements[6].setEnabled(false);
														this.oJumbo._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
										if (vehChk) {
											this.oJumbo = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileJumboName) {
												if (this.fileJumboType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileJumboName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 4
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileJumboType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oJumbo._aElements[1].setEnabled(false);
														this.oJumbo._aElements[4].setEnabled(false);
														this.oJumbo._aElements[6].setEnabled(false);
														this.oJumbo._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
								}.bind(this)
							})
						]
					}),
					new sap.m.Label({
						text: "Observations",
						required: true
					}),
					new sap.m.TextArea("id" + contRefId + "Observations" + contBoxNo + contNo, {
						value: data.BagsStripObservations,
						maxLength: 100,
						enabled: this.checkNewInspectionParameters(data.BagsStripChkIssue)
					}),
					new sap.m.Label({
						text: "Corrective Measures",
						required: true
					}),
					new sap.m.TextArea("id" + contRefId + "CorectiveMeasures" + contBoxNo + contNo, {
						value: data.BagStripCorrMeasure,
						maxLength: 100,
						enabled: this.checkNewInspectionParameters(data.BagsStripChkIssue)
					}),
					new sap.m.Label({
						text: "Upload Photo"
					}),
					new sap.ui.unified.FileUploader("id" + contRefId + "FileUpload" + contBoxNo + contNo, {
						uploadUrl: "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet",
						uploadComplete: "handleUploadComplete",
						change: function(oEvent) {
							this.fileJumboName = oEvent.getParameter("files")[0].name;
							this.fileJumboType = oEvent.getParameter("files")[0].type;
							this.fileJumboSize = oEvent.getParameter("files")[0].size;
							if (oEvent.getSource().oFileUpload.files.length > 0) {
								var file = oEvent.getSource().oFileUpload.files;
								var blobObj = new Blob(file, {
									type: "	image/jpeg"
								});
								var path = URL.createObjectURL(blobObj);
								oEvent.getSource().getParent().getFields()[1].setSrc(path);
							}
						}.bind(this),
						fileType: "jpg",
						style: "Emphasized",
						sendXHR: true,
						useMultipart: false,
						placeholder: "Choose the Container Image",
						enabled: this.checkInspectionParameters()
					}),
					new sap.m.Image("id" + contRefId + "Image" + contBoxNo + contNo, {
						width: "50%",
						height: "50%"
					})
				]
			});
			var oPanel = new sap.m.Panel({
				headerText: contPanelHeader1,
				expanded: false,
				expandable: true,
				content: [oSimpleForm]
			});
			return oPanel;
		},
		createContainerInnerCheckListCSC: function(contBoxNo, contNo, contPanelHeader, contRefId, contQuestion, bindingIndex) {
			var items = this.getView().getModel("InspectionModel").getProperty("/Items");
			var data = items[bindingIndex];
			var contPanelHeader1;
			if (data.CscSafetyChk) {
				if (data.CscSafetyStrip === 0 || data.CscSafetyStrip === 2) {
					contPanelHeader1 = contPanelHeader + " (COMPLETED)";
				} else {
					contPanelHeader1 = contPanelHeader + " (Completed with Observations)";
				}
			}
			if (data.CscSafetyChk === false || data.CscSafetyChk === undefined) {
				contPanelHeader1 = contPanelHeader + " (PENDING)";
			}
			var oSimpleForm = new sap.ui.layout.form.SimpleForm({
				layout: sap.ui.layout.form.SimpleFormLayout.ResponsiveGridLayout,
				editable: true,
				labelSpanL: 3,
				labelSpanM: 3,
				labelSpanS: 4,
				emptySpanL: 0,
				emptySpanM: 0,
				content: [new sap.m.Label({
						text: contQuestion,
						required: true
					}),
					new sap.m.RadioButtonGroup("id" + contRefId + contBoxNo + contNo, {
						columns: 3,
						selectedIndex: data.CscSafetyStrip,
						buttons: [
							new sap.m.RadioButton({
								text: "YES",
								selected: true
							}),
							new sap.m.RadioButton({
								text: "NO"
							}),
							new sap.m.RadioButton({
								text: "NA"
							})
						],
						enabled: this.checkInspectionParameters(),
						select: function(oEvent) {
							var buttonSelected = oEvent.getSource().getSelectedIndex();
							if (buttonSelected === 1) {
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setEnabled(
									true);
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setEnabled(
									true);
							}
							if (buttonSelected === 0 || buttonSelected === 2) {
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setEnabled(
									false);
								oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setEnabled(
									false);
								/*	oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[4].setValue("");
									oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[6].setValue("");*/
							}
						}
					}),
					new sap.m.FlexBox({
						justifyContent: sap.m.FlexAlignItems.Center,
						alignContent: sap.m.FlexAlignItems.Center,
						items: [
							new sap.m.Button({
								text: "Edit",
								enabled: this.inspectionButtonParameters(), //inspectionEditEnableModel.getProperty("/InspectionEditSaveButtons"),
								press: function(oEvent) {
									var check = true,
										vehChk, vehAppr;
									var oItems = this.getView().getModel("InspectionModel").getProperty("/Items");
									for (var i = 0; i < oItems.length; i++) {
										if (oItems[i].ContainerNo === data.ContainerNo) {
											vehChk = oItems[i].CscSafetyChk;
											vehAppr = oItems[i].CscSafetyApprNeed;
										}
									}
									var radio = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
											0]
										._aElements[1].getSelectedIndex();
									if (radio === 0 || radio === 2) {
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											1].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											8].setEnabled(true);
									}
									if (radio === 1) {
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											1].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											4].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											6].setEnabled(true);
										oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[0]._aElements[
											8].setEnabled(true);
									}
								}
							}).addStyleClass("sapUiSmallMarginEnd"),
							new sap.m.Button({
								text: "Save and Continue",
								type: "Emphasized",
								enabled: this.inspectionButtonParameters(), //inspectionEditEnableModel.getProperty("/InspectionEditSaveButtons"),
								press: function(oEvent) {
									var CscSafetyStrip = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
										0]._aElements[1].getSelectedIndex();
									var CscSafetyObser = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
										0]._aElements[4].getValue();
									var CscSafetyCorrMeasure = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent()
										.getContent()[
											0]._aElements[6].getValue();
									var check = true,
										vehChk, vehAppr;
									var oItems = this.getView().getModel("InspectionModel").getProperty("/Items");
									for (var i = 0; i < oItems.length; i++) {
										if (oItems[i].ContainerNo === data.ContainerNo) {
											vehChk = oItems[i].CscSafetyChk;
											vehAppr = oItems[i].CscSafetyApprNeed;
										}
									}
									var oFileUploader = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
										0]._aElements[8];
									var payload = {
										"CscSafetyStrip": CscSafetyStrip,
										"CscSafetyObser": CscSafetyObser,
										"CscSafetyCorrMeasure": CscSafetyCorrMeasure,
										"TruckNumber": this.truckNumber,
										"TripNumber": this.tripNumber,
										"ContainerNo": contNo,
										"InspectionStatus": "IP",
										"ContainerBoxNo": contBoxNo,
										"CscSafetyChk": check
									};
									if (CscSafetyStrip === 1) {
										if (!vehChk) {
											this.oCSCEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (payload.CscSafetyObservation !== "" && payload.CscSafetyCorrMeasure !== "") {
												if (this.fileCSCName) {
													if (this.fileCSCType === "image/jpeg") {
														oFileUploader.destroyHeaderParameters();
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "SLUG",
															value: this.fileCSCName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
																'"/"' +
																contNo + '"/"' + contBoxNo + '"/"' + 15
														}));
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "Content-Type",
															value: this.fileCSCType
														}));
														this.getOwnerComponent().getModel().refreshSecurityToken();
														oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
															name: "x-csrf-token",
															value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
														}));
														oFileUploader.setSendXHR(true);
														oFileUploader.upload();
													} else {
														MessageBox.error("File format should be JPG");
													}
												}
												this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
													"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
													"',ContainerNo='" +
													contNo + "')", payload, {
														method: "PUT",
														success: function(response) {
															MessageBox.success("CS Safety plate details have been updated successfully");
															this.oCSCEvent._aElements[1].setEnabled(false);
															this.oCSCEvent._aElements[4].setEnabled(false);
															this.oCSCEvent._aElements[6].setEnabled(false);
															this.oCSCEvent._aElements[8].setEnabled(false);
															this.readHeaderEntitySet();
															this.readInspectionEntitySetforContainer();
														}.bind(this),
														error: function(error) {
															MessageBox.warning("Error occurred while updating the data");
														}
													});
											} else {
												MessageBox.error("Please fill mandatory feilds");
											}
										}
										if (vehChk) {
											this.oCSCEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileCSCName) {
												if (this.fileCSCType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileCSCName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 15
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileCSCType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oCSCEvent._aElements[1].setEnabled(false);
														this.oCSCEvent._aElements[4].setEnabled(false);
														this.oCSCEvent._aElements[6].setEnabled(false);
														this.oCSCEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
									if (CscSafetyStrip === 0) {
										if (!vehChk) {
											this.oCSCEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileCSCName) {
												if (this.fileCSCType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileCSCName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 15
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileCSCType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();
												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														MessageBox.success("CS Safety plate details have been updated successfully");
														this.oCSCEvent._aElements[1].setEnabled(false);
														this.oCSCEvent._aElements[4].setEnabled(false);
														this.oCSCEvent._aElements[6].setEnabled(false);
														this.oCSCEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
										if (vehChk) {
											this.oCSCEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileCSCName) {
												if (this.fileCSCType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileCSCName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 15
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileCSCType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oCSCEvent._aElements[1].setEnabled(false);
														this.oCSCEvent._aElements[4].setEnabled(false);
														this.oCSCEvent._aElements[6].setEnabled(false);
														this.oCSCEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
									if (CscSafetyStrip === 2) {
										if (!vehChk) {
											this.oCSCEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileCSCName) {
												if (this.fileCSCType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileCSCName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 15
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileCSCType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														MessageBox.success("CS Safety plate details have been updated successfully");
														this.oCSCEvent._aElements[1].setEnabled(false);
														this.oCSCEvent._aElements[4].setEnabled(false);
														this.oCSCEvent._aElements[6].setEnabled(false);
														this.oCSCEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
										if (vehChk) {
											this.oCSCEvent = oEvent.getSource().getParent().getParent().getParent().getParent().getParent().getParent().getContent()[
												0];
											if (this.fileCSCName) {
												if (this.fileCSCType === "image/jpeg") {
													oFileUploader.destroyHeaderParameters();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "SLUG",
														value: this.fileCSCName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
															'"/"' +
															contNo + '"/"' + contBoxNo + '"/"' + 15
													}));
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "Content-Type",
														value: this.fileCSCType
													}));
													this.getOwnerComponent().getModel().refreshSecurityToken();
													oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
														name: "x-csrf-token",
														value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
													}));
													oFileUploader.setSendXHR(true);
													oFileUploader.upload();

												} else {
													MessageBox.error("File format should be JPG");
												}
											}
											this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
												"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
												"',ContainerNo='" +
												contNo + "')", payload, {
													method: "PUT",
													success: function(response) {
														this.oCSCEvent._aElements[1].setEnabled(false);
														this.oCSCEvent._aElements[4].setEnabled(false);
														this.oCSCEvent._aElements[6].setEnabled(false);
														this.oCSCEvent._aElements[8].setEnabled(false);
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforContainer();
													}.bind(this),
													error: function(error) {
														MessageBox.warning("Error occurred while updating the data");
													}
												});
										}
									}
								}.bind(this)
							})
						]
					}),
					new sap.m.Label({
						text: "Observations",
						required: true
					}),
					new sap.m.TextArea("id" + contRefId + "Observations" + contBoxNo + contNo, {
						value: data.CscSafetyObser,
						maxLength: 100,
						enabled: this.checkNewInspectionParameters(data.CscSafetyStrip)
					}),
					new sap.m.Label({
						text: "Corrective Measures",
						required: true
					}),
					new sap.m.TextArea("id" + contRefId + "CorectiveMeasures" + contBoxNo + contNo, {
						value: data.CscSafetyCorrMeasure,
						maxLength: 100,
						enabled: this.checkNewInspectionParameters(data.CscSafetyStrip)
					}),
					new sap.m.Label({
						text: "Upload Photo"
					}),
					new sap.ui.unified.FileUploader("id" + contRefId + "FileUpload" + contBoxNo + contNo, {
						uploadUrl: "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet",
						uploadComplete: "handleUploadComplete",
						change: function(oEvent) {
							this.fileCSCName = oEvent.getParameter("files")[0].name;
							this.fileCSCType = oEvent.getParameter("files")[0].type;
							this.fileCSCSize = oEvent.getParameter("files")[0].size;
							if (oEvent.getSource().oFileUpload.files.length > 0) {
								var file = oEvent.getSource().oFileUpload.files;
								var blobObj = new Blob(file, {
									type: "	image/jpeg"
								});
								var path = URL.createObjectURL(blobObj);
								oEvent.getSource().getParent().getFields()[1].setSrc(path);
							}
						}.bind(this),
						fileType: "jpg",
						style: "Emphasized",
						sendXHR: true,
						useMultipart: false,
						placeholder: "Choose the Container Image",
						enabled: this.checkInspectionParameters()
					}),
					new sap.m.Image("id" + contRefId + "Image" + contBoxNo + contNo, {
						width: "50%",
						height: "50%"
					})
				]
			});
			var oPanel = new sap.m.Panel({
				headerText: contPanelHeader1,
				expanded: false,
				expandable: true,
				content: [oSimpleForm]
			});
			return oPanel;
		},
		onTruckCanvasCheckSave: function(oEvent) {
			var TruckCanvas = this.getView().byId("idTruckCanvasDropdown").getSelectedKey();
			var ContCleanHdpeIssue = this.getView().byId("idCanvasCheck").getSelectedIndex();
			var ContCleanObservations = this.getView().byId("idCanvasCheckObservations").getValue();
			var ContCleanCorrMeasures = this.getView().byId("idCanvasCheckCorectiveMeasures").getValue();
			var items = this.getView().getModel("InspectionModel").getData();
			var select = items.ContCleanChk;
			var oFileUploader = this.getView().byId("idCanvasCheckFileUpload");
			var contNum = this.getView().getModel("TripModel").getData().ContainerNo;
			var contBoxNo = "000";
			var payload;
			var createPayload = {
				"TruckCanvas": TruckCanvas,
				"ContCleanHdpeIssue": ContCleanHdpeIssue,
				"ContCleanObservations": ContCleanObservations,
				"ContCleanCorrMeasures": ContCleanCorrMeasures,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": contNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Truck",
				"ContCleanChk": true
			};
			var updatePayload = {
				"TruckCanvas": TruckCanvas,
				"ContCleanHdpeIssue": ContCleanHdpeIssue,
				"ContCleanObservations": ContCleanObservations,
				"ContCleanCorrMeasures": ContCleanCorrMeasures,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": contNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Truck",
				"ContCleanChk": true
			};
			if (ContCleanHdpeIssue === 1) {
				payload = createPayload;
				if (!select || select == undefined) {
					if (payload.ContCleanObservations !== "" && payload.ContCleanCorrMeasures !== "") {
						if (this.fileNameTruckCanvas) {
							if (this.fileTypeTruckCanvas === "image/jpeg") {
								oFileUploader.destroyHeaderParameters();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "SLUG",
									value: this.fileNameTruckCanvas + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
										contNum +
										'"/"' + contBoxNo + '"/"' + 9
								}));
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "Content-Type",
									value: this.fileTypeTruckCanvas
								}));
								this.getOwnerComponent().getModel().refreshSecurityToken();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "x-csrf-token",
									value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
								}));
								oFileUploader.setSendXHR(true);
								oFileUploader.upload();
								if (this.tripStatus === "RD") {
									this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
										method: "POST",
										success: function(response) {
											MessageBox.success("Canvas selection details have been updated successfully", {
												onClose: function() {
													this.readHeaderEntitySet();
													this.readInspectionEntitySetforTruckandTank();
													this.getView().byId("idTruckCanvasDropdown").setEnabled(false);
													this.getView().byId("idCanvasCheck").setEnabled(false);
													this.getView().byId("idCanvasCheckObservations").setEnabled(false);
													this.getView().byId("idCanvasCheckCorectiveMeasures").setEnabled(false);
													this.getView().byId("idCanvasCheckFileUpload").setEnabled(false);
													this.getView().byId("idCanvasCheckPanel").setExpanded(false);
												}.bind(this)
											});
										}.bind(this),
										error: function(error) {
											MessageBox.warning("Error occurred while updating the data");
										}
									});
								}
								if (this.tripStatus === "IP") {
									this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
										"',TripNumber='" +
										this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
										"',ContainerNo='" +
										contNum + "')", payload, {
											method: "PUT",
											success: function(response) {
												MessageBox.success("Canvas selection details have been updated successfully", {
													onClose: function() {
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforTruckandTank();
														this.getView().byId("idTruckCanvasDropdown").setEnabled(false);
														this.getView().byId("idCanvasCheck").setEnabled(false);
														this.getView().byId("idCanvasCheckObservations").setEnabled(false);
														this.getView().byId("idCanvasCheckCorectiveMeasures").setEnabled(false);
														this.getView().byId("idCanvasCheckFileUpload").setEnabled(false);
														this.getView().byId("idCanvasCheckPanel").setExpanded(false);
													}.bind(this)
												});
											}.bind(this),
											error: function(error) {
												MessageBox.warning("Error occurred while updating the data");
											}
										});
								}
							} else {
								MessageBox.error("File format should be JPG");
							}
						} else {
							if (this.tripStatus === "RD") {
								this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
									method: "POST",
									success: function(response) {
										MessageBox.success("Canvas selection details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idTruckCanvasDropdown").setEnabled(false);
												this.getView().byId("idCanvasCheck").setEnabled(false);
												this.getView().byId("idCanvasCheckObservations").setEnabled(false);
												this.getView().byId("idCanvasCheckCorectiveMeasures").setEnabled(false);
												this.getView().byId("idCanvasCheckFileUpload").setEnabled(false);
												this.getView().byId("idCanvasCheckPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
							}
							if (this.tripStatus === "IP") {
								this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
									"',TripNumber='" +
									this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
									"',ContainerNo='" +
									contNum + "')", payload, {
										method: "PUT",
										success: function(response) {
											MessageBox.success("Canvas selection details have been updated successfully", {
												onClose: function() {
													this.readHeaderEntitySet();
													this.readInspectionEntitySetforTruckandTank();
													this.getView().byId("idTruckCanvasDropdown").setEnabled(false);
													this.getView().byId("idCanvasCheck").setEnabled(false);
													this.getView().byId("idCanvasCheckObservations").setEnabled(false);
													this.getView().byId("idCanvasCheckCorectiveMeasures").setEnabled(false);
													this.getView().byId("idCanvasCheckFileUpload").setEnabled(false);
													this.getView().byId("idCanvasCheckPanel").setExpanded(false);
												}.bind(this)
											});
										}.bind(this),
										error: function(error) {
											MessageBox.warning("Error occurred while updating the data");
										}
									});
							}
						}
					} else {
						MessageBox.error("Please fill all the mandatory feilds");
					}
				}
				if (select) {
					if (this.fileNameTruckCanvas) {
						if (this.fileTypeTruckCanvas === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTruckCanvas + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									contNum +
									'"/"' + contBoxNo + '"/"' + 9
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTruckCanvas
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							contNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idTruckCanvasDropdown").setEnabled(false);
									this.getView().byId("idCanvasCheck").setEnabled(false);
									this.getView().byId("idCanvasCheckObservations").setEnabled(false);
									this.getView().byId("idCanvasCheckCorectiveMeasures").setEnabled(false);
									this.getView().byId("idCanvasCheckFileUpload").setEnabled(false);
									this.getView().byId("idCanvasCheckPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
			if (ContCleanHdpeIssue === 0 || ContCleanHdpeIssue === 2) {
				payload = updatePayload;
				if (!select || select == undefined) {
					if (this.fileNameTruckCanvas) {
						if (this.fileTypeTruckCanvas === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTruckCanvas + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									contNum +
									'"/"' + contBoxNo + '"/"' + 9
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTruckCanvas
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();
							if (this.tripStatus === "RD") {
								this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
									method: "POST",
									success: function(response) {
										MessageBox.success("Canvas selection details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idTruckCanvasDropdown").setEnabled(false);
												this.getView().byId("idCanvasCheck").setEnabled(false);
												this.getView().byId("idCanvasCheckObservations").setEnabled(false);
												this.getView().byId("idCanvasCheckCorectiveMeasures").setEnabled(false);
												this.getView().byId("idCanvasCheckFileUpload").setEnabled(false);
												this.getView().byId("idCanvasCheckPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
							}
							if (this.tripStatus === "IP") {
								this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
									"',TripNumber='" +
									this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
									"',ContainerNo='" +
									contNum + "')", payload, {
										method: "PUT",
										success: function(response) {
											MessageBox.success("Canvas selection details have been updated successfully", {
												onClose: function() {
													this.readHeaderEntitySet();
													this.readInspectionEntitySetforTruckandTank();
													this.getView().byId("idTruckCanvasDropdown").setEnabled(false);
													this.getView().byId("idCanvasCheck").setEnabled(false);
													this.getView().byId("idCanvasCheckObservations").setEnabled(false);
													this.getView().byId("idCanvasCheckCorectiveMeasures").setEnabled(false);
													this.getView().byId("idCanvasCheckFileUpload").setEnabled(false);
													this.getView().byId("idCanvasCheckPanel").setExpanded(false);
												}.bind(this)
											});
										}.bind(this),
										error: function(error) {
											MessageBox.warning("Error occurred while updating the data");
										}
									});
							}

						} else {
							MessageBox.error("File format should be JPG");
						}
					} else {
						if (this.tripStatus === "RD") {
							this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
								method: "POST",
								success: function(response) {
									MessageBox.success("Canvas selection details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idTruckCanvasDropdown").setEnabled(false);
											this.getView().byId("idCanvasCheck").setEnabled(false);
											this.getView().byId("idCanvasCheckObservations").setEnabled(false);
											this.getView().byId("idCanvasCheckCorectiveMeasures").setEnabled(false);
											this.getView().byId("idCanvasCheckFileUpload").setEnabled(false);
											this.getView().byId("idCanvasCheckPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
						}
						if (this.tripStatus === "IP") {
							this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
								"',TripNumber='" +
								this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
								"',ContainerNo='" +
								contNum + "')", payload, {
									method: "PUT",
									success: function(response) {
										MessageBox.success("Canvas selection details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idTruckCanvasDropdown").setEnabled(false);
												this.getView().byId("idCanvasCheck").setEnabled(false);
												this.getView().byId("idCanvasCheckObservations").setEnabled(false);
												this.getView().byId("idCanvasCheckCorectiveMeasures").setEnabled(false);
												this.getView().byId("idCanvasCheckFileUpload").setEnabled(false);
												this.getView().byId("idCanvasCheckPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
						}
					}
				}
				if (select) {
					if (this.fileNameTruckCanvas) {
						if (this.fileTypeTruckCanvas === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTruckCanvas + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									contNum +
									'"/"' + contBoxNo + '"/"' + 9
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTruckCanvas
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							contNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idTruckCanvasDropdown").setEnabled(false);
									this.getView().byId("idCanvasCheck").setEnabled(false);
									this.getView().byId("idCanvasCheckObservations").setEnabled(false);
									this.getView().byId("idCanvasCheckCorectiveMeasures").setEnabled(false);
									this.getView().byId("idCanvasCheckFileUpload").setEnabled(false);
									this.getView().byId("idCanvasCheckPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
		},
		onTruckCanvasCheckEdit: function(oEvent) {
			var radio = this.getView().byId("idCanvasCheck").getSelectedIndex();
			this.getView().byId("idTruckCanvasDropdown").setEnabled(true);
			if (radio === 0 || radio === 2) {
				this.getView().byId("idCanvasCheck").setEnabled(true);
				this.getView().byId("idCanvasCheckFileUpload").setEnabled(true);
			}
			if (radio === 1) {
				this.getView().byId("idCanvasCheck").setEnabled(true);
				this.getView().byId("idCanvasCheckObservations").setEnabled(true);
				this.getView().byId("idCanvasCheckCorectiveMeasures").setEnabled(true);
				this.getView().byId("idCanvasCheckFileUpload").setEnabled(true);
			}
		},
		onTruckRopeSave: function() {
			var RubberSealIssue = this.getView().byId("idRope").getSelectedIndex();
			var RubberSealObservations = this.getView().byId("idRopeObservations").getValue();
			var RubberSealCorrMeasure = this.getView().byId("idRopeCorectiveMeasures").getValue();
			var check = true;
			var items = this.getView().getModel("InspectionModel").getData();
			var select = items.RubberSealChk;
			var contNum = this.getView().getModel("TripModel").getData().ContainerNo;
			var contBoxNo = "000";
			var oFileUploader = this.getView().byId("idRopeFileUpload");
			var payload;
			var createPayload = {
				"RubberSealIssue": RubberSealIssue,
				"RubberSealObservations": RubberSealObservations,
				"RubberSealCorrMeasure": RubberSealCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": contNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Truck",
				"RubberSealChk": check
			};
			var updatePayload = {
				"RubberSealIssue": RubberSealIssue,
				"RubberSealObservations": RubberSealObservations,
				"RubberSealCorrMeasure": RubberSealCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": contNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Truck",
				"RubberSealChk": check
			};
			if (RubberSealIssue === 1) {
				payload = createPayload;
				if (!select || select == undefined) {
					if (payload.RubberSealObservations !== "" && payload.RubberSealCorrMeasure !== "") {
						if (this.fileNameTruckRope) {
							if (this.fileTypeTruckRope === "image/jpeg") {
								oFileUploader.destroyHeaderParameters();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "SLUG",
									value: this.fileNameTruckRope + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
										contNum +
										'"/"' + contBoxNo + '"/"' + 5
								}));
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "Content-Type",
									value: this.fileTypeTruckRope
								}));
								this.getOwnerComponent().getModel().refreshSecurityToken();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "x-csrf-token",
									value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
								}));
								oFileUploader.setSendXHR(true);
								oFileUploader.upload();
								if (this.tripStatus === "RD") {
									this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
										method: "POST",
										success: function(response) {
											MessageBox.success("Rope details have been updated successfully", {
												onClose: function() {
													this.readHeaderEntitySet();
													this.readInspectionEntitySetforTruckandTank();
													this.getView().byId("idRope").setEnabled(false);
													this.getView().byId("idRopeObservations").setEnabled(false);
													this.getView().byId("idRopeCorectiveMeasures").setEnabled(false);
													this.getView().byId("idRopeFileUpload").setEnabled(false);
													this.getView().byId("idRopePanel").setExpanded(false);
												}.bind(this)
											});
										}.bind(this),
										error: function(error) {
											MessageBox.warning("Error occurred while updating the data");
										}
									});
								}
								if (this.tripStatus === "IP") {
									this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
										"',TripNumber='" +
										this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
										"',ContainerNo='" +
										contNum + "')", payload, {
											method: "PUT",
											success: function(response) {
												MessageBox.success("Rope details have been updated successfully", {
													onClose: function() {
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforTruckandTank();
														this.getView().byId("idRope").setEnabled(false);
														this.getView().byId("idRopeObservations").setEnabled(false);
														this.getView().byId("idRopeCorectiveMeasures").setEnabled(false);
														this.getView().byId("idRopeFileUpload").setEnabled(false);
														this.getView().byId("idRopePanel").setExpanded(false);
													}.bind(this)
												});
											}.bind(this),
											error: function(error) {
												MessageBox.warning("Error occurred while updating the data");
											}
										});
								}

							} else {
								MessageBox.error("File format should be JPG");
							}
						} else {
							if (this.tripStatus === "RD") {
								this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
									method: "POST",
									success: function(response) {
										MessageBox.success("Rope details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idRope").setEnabled(false);
												this.getView().byId("idRopeObservations").setEnabled(false);
												this.getView().byId("idRopeCorectiveMeasures").setEnabled(false);
												this.getView().byId("idRopeFileUpload").setEnabled(false);
												this.getView().byId("idRopePanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
							}
							if (this.tripStatus === "IP") {
								this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
									"',TripNumber='" +
									this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
									"',ContainerNo='" +
									contNum + "')", payload, {
										method: "PUT",
										success: function(response) {
											MessageBox.success("Rope details have been updated successfully", {
												onClose: function() {
													this.readHeaderEntitySet();
													this.readInspectionEntitySetforTruckandTank();
													this.getView().byId("idRope").setEnabled(false);
													this.getView().byId("idRopeObservations").setEnabled(false);
													this.getView().byId("idRopeCorectiveMeasures").setEnabled(false);
													this.getView().byId("idRopeFileUpload").setEnabled(false);
													this.getView().byId("idRopePanel").setExpanded(false);
												}.bind(this)
											});
										}.bind(this),
										error: function(error) {
											MessageBox.warning("Error occurred while updating the data");
										}
									});
							}
						}
					} else {
						MessageBox.error("Please fill all the mandatory feilds");
					}
				}
				if (select) {
					if (this.fileNameTruckRope) {
						if (this.fileTypeTruckRope === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTruckRope + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									contNum +
									'"/"' + contBoxNo + '"/"' + 5
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTruckRope
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							contNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idRope").setEnabled(false);
									this.getView().byId("idRopeObservations").setEnabled(false);
									this.getView().byId("idRopeCorectiveMeasures").setEnabled(false);
									this.getView().byId("idRopeFileUpload").setEnabled(false);
									this.getView().byId("idRopePanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
			if (RubberSealIssue === 0 || RubberSealIssue === 2) {
				payload = updatePayload;
				if (!select || select == undefined) {
					if (this.fileNameTruckRope) {
						if (this.fileTypeTruckRope === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTruckRope + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									contNum +
									'"/"' + contBoxNo + '"/"' + 5
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTruckRope
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();
							if (this.tripStatus === "RD") {
								this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
									method: "POST",
									success: function(response) {
										MessageBox.success("Rope details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idRope").setEnabled(false);
												this.getView().byId("idRopeObservations").setEnabled(false);
												this.getView().byId("idRopeCorectiveMeasures").setEnabled(false);
												this.getView().byId("idRopeFileUpload").setEnabled(false);
												this.getView().byId("idRopePanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
							}
							if (this.tripStatus === "IP") {
								this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
									"',TripNumber='" +
									this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
									"',ContainerNo='" +
									contNum + "')", payload, {
										method: "PUT",
										success: function(response) {
											MessageBox.success("Rope details have been updated successfully", {
												onClose: function() {
													this.readHeaderEntitySet();
													this.readInspectionEntitySetforTruckandTank();
													this.getView().byId("idRope").setEnabled(false);
													this.getView().byId("idRopeObservations").setEnabled(false);
													this.getView().byId("idRopeCorectiveMeasures").setEnabled(false);
													this.getView().byId("idRopeFileUpload").setEnabled(false);
													this.getView().byId("idRopePanel").setExpanded(false);
												}.bind(this)
											});
										}.bind(this),
										error: function(error) {
											MessageBox.warning("Error occurred while updating the data");
										}
									});
							}

						} else {
							MessageBox.error("File format should be JPG");
						}
					} else {
						if (this.tripStatus === "RD") {
							this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
								method: "POST",
								success: function(response) {
									MessageBox.success("Rope details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idRope").setEnabled(false);
											this.getView().byId("idRopeObservations").setEnabled(false);
											this.getView().byId("idRopeCorectiveMeasures").setEnabled(false);
											this.getView().byId("idRopeFileUpload").setEnabled(false);
											this.getView().byId("idRopePanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
						}
						if (this.tripStatus === "IP") {
							this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
								"',TripNumber='" +
								this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
								"',ContainerNo='" +
								contNum + "')", payload, {
									method: "PUT",
									success: function(response) {
										MessageBox.success("Rope details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idRope").setEnabled(false);
												this.getView().byId("idRopeObservations").setEnabled(false);
												this.getView().byId("idRopeCorectiveMeasures").setEnabled(false);
												this.getView().byId("idRopeFileUpload").setEnabled(false);
												this.getView().byId("idRopePanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
						}
					}
				}
				if (select) {
					if (this.fileNameTruckRope) {
						if (this.fileTypeTruckRope === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTruckRope + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									contNum +
									'"/"' + contBoxNo + '"/"' + 5
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTruckRope
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							contNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idRope").setEnabled(false);
									this.getView().byId("idRopeObservations").setEnabled(false);
									this.getView().byId("idRopeCorectiveMeasures").setEnabled(false);
									this.getView().byId("idRopeFileUpload").setEnabled(false);
									this.getView().byId("idRopePanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
		},
		onTruckRopeEdit: function() {
			var radio = this.getView().byId("idRope").getSelectedIndex();
			if (radio === 0 || radio === 2) {
				this.getView().byId("idRope").setEnabled(true);
				this.getView().byId("idRopeFileUpload").setEnabled(true);
			}
			if (radio === 1) {
				this.getView().byId("idRope").setEnabled(true);
				this.getView().byId("idRopeObservations").setEnabled(true);
				this.getView().byId("idRopeCorectiveMeasures").setEnabled(true);
				this.getView().byId("idRopeFileUpload").setEnabled(true);
			}
		},
		onTruckFloorWallsSave: function() {
			var ContainerIssue = this.getView().byId("idFW").getSelectedIndex();
			var ContObservations = this.getView().byId("idFWObservations").getValue();
			var ContCorrMeasure = this.getView().byId("idFWCorectiveMeasures").getValue();
			var check = true;
			var items = this.getView().getModel("InspectionModel").getData();
			var select = items.ContainerChk;
			var contNum = this.getView().getModel("TripModel").getData().ContainerNo;
			var contBoxNo = "000";
			var oFileUploader = this.getView().byId("idFWFileUpload");
			var createPayload = {
				"ContainerIssue": ContainerIssue,
				"ContObservations": ContObservations,
				"ContCorrMeasure": ContCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": contNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Truck",
				"ContainerChk": check
			};
			var updatePayload = {
				"ContainerIssue": ContainerIssue,
				"ContObservations": ContObservations,
				"ContCorrMeasure": ContCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": contNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Truck",
				"ContainerChk": check
			};
			var payload;
			if (ContainerIssue === 1) {
				payload = createPayload;
				if (!select || select == undefined) {
					if (payload.ContObservations !== "" && payload.ContCorrMeasure !== "") {
						if (this.fileNameTruckFloorWalls) {
							if (this.fileTypeTruckFloorWalls === "image/jpeg") {
								oFileUploader.destroyHeaderParameters();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "SLUG",
									value: this.fileNameTruckFloorWalls + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
										'"/"' +
										contNum + '"/"' + contBoxNo + '"/"' + 14
								}));
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "Content-Type",
									value: this.fileTypeTruckFloorWalls
								}));
								this.getOwnerComponent().getModel().refreshSecurityToken();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "x-csrf-token",
									value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
								}));
								oFileUploader.setSendXHR(true);
								oFileUploader.upload();
								if (this.tripStatus === "RD") {
									this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
										method: "POST",
										success: function(response) {
											MessageBox.success("Floor and Walls details have been updated successfully", {
												onClose: function() {
													this.readHeaderEntitySet();
													this.readInspectionEntitySetforTruckandTank();
													this.getView().byId("idFW").setEnabled(false);
													this.getView().byId("idFWObservations").setEnabled(false);
													this.getView().byId("idFWCorectiveMeasures").setEnabled(false);
													this.getView().byId("idFWFileUpload").setEnabled(false);
													this.getView().byId("idFWPanel").setExpanded(false);
												}.bind(this)
											});
										}.bind(this),
										error: function(error) {
											MessageBox.warning("Error occurred while updating the data");
										}
									});
								}
								if (this.tripStatus === "IP") {
									this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
										"',TripNumber='" +
										this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
										"',ContainerNo='" +
										contNum + "')", payload, {
											method: "PUT",
											success: function(response) {
												MessageBox.success("Floor and Wall details have been updated successfully", {
													onClose: function() {
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforTruckandTank();
														this.getView().byId("idFW").setEnabled(false);
														this.getView().byId("idFWObservations").setEnabled(false);
														this.getView().byId("idFWCorectiveMeasures").setEnabled(false);
														this.getView().byId("idFWFileUpload").setEnabled(false);
														this.getView().byId("idFWPanel").setExpanded(false);
													}.bind(this)
												});
											}.bind(this),
											error: function(error) {
												MessageBox.warning("Error occurred while updating the data");
											}
										});
								}
							} else {
								MessageBox.error("File format should be JPG");
							}
						} else {
							if (this.tripStatus === "RD") {
								this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
									method: "POST",
									success: function(response) {
										MessageBox.success("Floor and Walls details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idFW").setEnabled(false);
												this.getView().byId("idFWObservations").setEnabled(false);
												this.getView().byId("idFWCorectiveMeasures").setEnabled(false);
												this.getView().byId("idFWFileUpload").setEnabled(false);
												this.getView().byId("idFWPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
							}
							if (this.tripStatus === "IP") {
								this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
									"',TripNumber='" +
									this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
									"',ContainerNo='" +
									contNum + "')", payload, {
										method: "PUT",
										success: function(response) {
											MessageBox.success("Floor and Wall details have been updated successfully", {
												onClose: function() {
													this.readHeaderEntitySet();
													this.readInspectionEntitySetforTruckandTank();
													this.getView().byId("idFW").setEnabled(false);
													this.getView().byId("idFWObservations").setEnabled(false);
													this.getView().byId("idFWCorectiveMeasures").setEnabled(false);
													this.getView().byId("idFWFileUpload").setEnabled(false);
													this.getView().byId("idFWPanel").setExpanded(false);
												}.bind(this)
											});
										}.bind(this),
										error: function(error) {
											MessageBox.warning("Error occurred while updating the data");
										}
									});
							}
						}
					} else {
						MessageBox.error("Please fill all the mandatory feilds");
					}
				}
				if (select) {
					if (this.fileNameTruckFloorWalls) {
						if (this.fileTypeTruckFloorWalls) {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTruckFloorWalls + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
									'"/"' +
									contNum + '"/"' + contBoxNo + '"/"' + 14
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTruckFloorWalls
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();
						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							contNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idFW").setEnabled(false);
									this.getView().byId("idFWObservations").setEnabled(false);
									this.getView().byId("idFWCorectiveMeasures").setEnabled(false);
									this.getView().byId("idFWFileUpload").setEnabled(false);
									this.getView().byId("idFWPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
			if (ContainerIssue === 0 || ContainerIssue === 2) {
				payload = updatePayload;
				if (!select || select == undefined) {
					if (this.fileNameTruckFloorWalls) {
						if (this.fileTypeTruckFloorWalls === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTruckFloorWalls + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
									'"/"' +
									contNum + '"/"' + contBoxNo + '"/"' + 14
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTruckFloorWalls
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();
							if (this.tripStatus === "RD") {
								this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
									method: "POST",
									success: function(response) {
										MessageBox.success("Floor and Walls details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idFW").setEnabled(false);
												this.getView().byId("idFWObservations").setEnabled(false);
												this.getView().byId("idFWCorectiveMeasures").setEnabled(false);
												this.getView().byId("idFWFileUpload").setEnabled(false);
												this.getView().byId("idFWPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
							}
							if (this.tripStatus === "IP") {
								this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
									"',TripNumber='" +
									this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
									"',ContainerNo='" +
									contNum + "')", payload, {
										method: "PUT",
										success: function(response) {
											MessageBox.success("Floor and Wall details have been updated successfully", {
												onClose: function() {
													this.readHeaderEntitySet();
													this.readInspectionEntitySetforTruckandTank();
													this.getView().byId("idFW").setEnabled(false);
													this.getView().byId("idFWObservations").setEnabled(false);
													this.getView().byId("idFWCorectiveMeasures").setEnabled(false);
													this.getView().byId("idFWFileUpload").setEnabled(false);
													this.getView().byId("idFWPanel").setExpanded(false);
												}.bind(this)
											});
										}.bind(this),
										error: function(error) {
											MessageBox.warning("Error occurred while updating the data");
										}
									});
							}

						} else {
							MessageBox.error("File format should be JPG");
						}
					} else {
						if (this.tripStatus === "RD") {
							this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
								method: "POST",
								success: function(response) {
									MessageBox.success("Floor and Walls details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idFW").setEnabled(false);
											this.getView().byId("idFWObservations").setEnabled(false);
											this.getView().byId("idFWCorectiveMeasures").setEnabled(false);
											this.getView().byId("idFWFileUpload").setEnabled(false);
											this.getView().byId("idFWPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
						}
						if (this.tripStatus === "IP") {
							this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
								"',TripNumber='" +
								this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
								"',ContainerNo='" +
								contNum + "')", payload, {
									method: "PUT",
									success: function(response) {
										MessageBox.success("Floor and Wall details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idFW").setEnabled(false);
												this.getView().byId("idFWObservations").setEnabled(false);
												this.getView().byId("idFWCorectiveMeasures").setEnabled(false);
												this.getView().byId("idFWFileUpload").setEnabled(false);
												this.getView().byId("idFWPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
						}
					}
				}
				if (select) {
					if (this.fileNameTruckFloorWalls) {
						if (this.fileTypeTruckFloorWalls === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTruckFloorWalls + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
									'"/"' +
									contNum + '"/"' + contBoxNo + '"/"' + 14
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTruckFloorWalls
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							contNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idFW").setEnabled(false);
									this.getView().byId("idFWObservations").setEnabled(false);
									this.getView().byId("idFWCorectiveMeasures").setEnabled(false);
									this.getView().byId("idFWFileUpload").setEnabled(false);
									this.getView().byId("idFWPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
		},
		onTruckFloorWallsEdit: function() {
			var radio = this.getView().byId("idFW").setEnabled(true);
			if (radio === 0 || radio === 2) {
				this.getView().byId("idFW").setEnabled(true);
				this.getView().byId("idFWFileUpload").setEnabled(true);
			}
			if (radio === 1) {
				this.getView().byId("idFW").setEnabled(true);
				this.getView().byId("idFWObservations").setEnabled(true);
				this.getView().byId("idFWCorectiveMeasures").setEnabled(true);
				this.getView().byId("idFWFileUpload").setEnabled(true);
			}
		},
		onTruckVehicleSave: function() {
			var VehicleIssue = this.getView().byId("idVehicle").getSelectedIndex();
			var VehObservations = this.getView().byId("idVehicleObservations").getValue();
			var VehCorrMeasure = this.getView().byId("idVehicleCorectiveMeasures").getValue();
			var check = true;
			var items = this.getView().getModel("InspectionModel").getData();
			var select = items.VehicleCheck;
			var oFileUploader = this.getView().byId("idVehicleFileUpload");
			var contNum = this.getView().getModel("TripModel").getData().ContainerNo;
			var contBoxNo = "000";
			var payload;
			var createPayload = {
				"VehicleIssue": VehicleIssue,
				"VehObservations": VehObservations,
				"VehCorrMeasure": VehCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": contNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Truck",
				"VehicleCheck": check
			};
			var updatePayload = {
				"VehicleIssue": VehicleIssue,
				"VehObservations": VehObservations,
				"VehCorrMeasure": VehCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": contNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Truck",
				"VehicleCheck": check
			};
			if (VehicleIssue === 1) {
				payload = createPayload;
				if (!select || select == undefined) {
					if (payload.VehObservations !== "" && payload.VehCorrMeasure !== "") {
						if (this.fileNameTruckVehicle) {
							if (this.fileTypeTruckVehicle === "image/jpeg") {
								oFileUploader.destroyHeaderParameters();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "SLUG",
									value: this.fileNameTruckVehicle + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
										contNum + '"/"' + contBoxNo + '"/"' + 3
								}));
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "Content-Type",
									value: this.fileTypeTruckVehicle
								}));
								this.getOwnerComponent().getModel().refreshSecurityToken();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "x-csrf-token",
									value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
								}));
								oFileUploader.setSendXHR(true);
								oFileUploader.upload();
								if (this.tripStatus === "RD") {
									this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
										method: "POST",
										success: function(response) {
											MessageBox.success("Vehicle details have been updated successfully", {
												onClose: function() {
													this.readHeaderEntitySet();
													this.readInspectionEntitySetforTruckandTank();
													this.getView().byId("idVehicle").setEnabled(false);
													this.getView().byId("idVehicleObservations").setEnabled(false);
													this.getView().byId("idVehicleCorectiveMeasures").setEnabled(false);
													this.getView().byId("idVehicleFileUpload").setEnabled(false);
													this.getView().byId("idVehiclePanel").setExpanded(false);
												}.bind(this)
											});
										}.bind(this),
										error: function(error) {
											MessageBox.warning("Error occurred while updating the data");
										}
									});
								}
								if (this.tripStatus === "IP") {
									this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
										"',TripNumber='" +
										this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
										"',ContainerNo='" +
										contNum + "')", payload, {
											method: "PUT",
											success: function(response) {
												MessageBox.success("Vehicle details have been updated successfully", {
													onClose: function() {
														this.readHeaderEntitySet();
														this.readInspectionEntitySetforTruckandTank();
														this.getView().byId("idVehicle").setEnabled(false);
														this.getView().byId("idVehicleObservations").setEnabled(false);
														this.getView().byId("idVehicleCorectiveMeasures").setEnabled(false);
														this.getView().byId("idVehicleFileUpload").setEnabled(false);
														this.getView().byId("idVehiclePanel").setExpanded(false);
													}.bind(this)
												});
											}.bind(this),
											error: function(error) {
												MessageBox.warning("Error occurred while updating the data");
											}
										});
								}

							} else {
								MessageBox.error("File format should be JPG");
							}
						} else {
							if (this.tripStatus === "RD") {
								this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
									method: "POST",
									success: function(response) {
										MessageBox.success("Vehicle details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idVehicle").setEnabled(false);
												this.getView().byId("idVehicleObservations").setEnabled(false);
												this.getView().byId("idVehicleCorectiveMeasures").setEnabled(false);
												this.getView().byId("idVehicleFileUpload").setEnabled(false);
												this.getView().byId("idVehiclePanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
							}
							if (this.tripStatus === "IP") {
								this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
									"',TripNumber='" +
									this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
									"',ContainerNo='" +
									contNum + "')", payload, {
										method: "PUT",
										success: function(response) {
											MessageBox.success("Vehicle details have been updated successfully", {
												onClose: function() {
													this.readHeaderEntitySet();
													this.readInspectionEntitySetforTruckandTank();
													this.getView().byId("idVehicle").setEnabled(false);
													this.getView().byId("idVehicleObservations").setEnabled(false);
													this.getView().byId("idVehicleCorectiveMeasures").setEnabled(false);
													this.getView().byId("idVehicleFileUpload").setEnabled(false);
													this.getView().byId("idVehiclePanel").setExpanded(false);
												}.bind(this)
											});
										}.bind(this),
										error: function(error) {
											MessageBox.warning("Error occurred while updating the data");
										}
									});
							}
						}
					} else {
						MessageBox.error("Please fill all the mandatory feilds");
					}
				}
				if (select) {
					if (this.fileNameTruckVehicle) {
						if (this.fileTypeTruckVehicle === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTruckVehicle + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									contNum + '"/"' + contBoxNo + '"/"' + 3
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTruckVehicle
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							contNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idVehicle").setEnabled(false);
									this.getView().byId("idVehicleObservations").setEnabled(false);
									this.getView().byId("idVehicleCorectiveMeasures").setEnabled(false);
									this.getView().byId("idVehicleFileUpload").setEnabled(false);
									this.getView().byId("idVehiclePanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
			if (VehicleIssue === 0 || VehicleIssue === 2) {
				payload = updatePayload;
				if (!select || select == undefined) {
					if (this.fileNameTruckVehicle) {
						if (this.fileTypeTruckVehicle === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTruckVehicle + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									contNum + '"/"' + contBoxNo + '"/"' + 3
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTruckVehicle
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();
							if (this.tripStatus === "RD") {
								this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
									method: "POST",
									success: function(response) {
										MessageBox.success("Vehicle details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idVehicle").setEnabled(false);
												this.getView().byId("idVehicleObservations").setEnabled(false);
												this.getView().byId("idVehicleCorectiveMeasures").setEnabled(false);
												this.getView().byId("idVehicleFileUpload").setEnabled(false);
												this.getView().byId("idVehiclePanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
							}
							if (this.tripStatus === "IP") {
								this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
									"',TripNumber='" +
									this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
									"',ContainerNo='" +
									contNum + "')", payload, {
										method: "PUT",
										success: function(response) {
											MessageBox.success("Vehicle details have been updated successfully", {
												onClose: function() {
													this.readHeaderEntitySet();
													this.readInspectionEntitySetforTruckandTank();
													this.getView().byId("idVehicle").setEnabled(false);
													this.getView().byId("idVehicleObservations").setEnabled(false);
													this.getView().byId("idVehicleCorectiveMeasures").setEnabled(false);
													this.getView().byId("idVehicleFileUpload").setEnabled(false);
													this.getView().byId("idVehiclePanel").setExpanded(false);
												}.bind(this)
											});
										}.bind(this),
										error: function(error) {
											MessageBox.warning("Error occurred while updating the data");
										}
									});
							}

						} else {
							MessageBox.error("File format should be JPG");
						}
					} else {
						if (this.tripStatus === "RD") {
							this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
								method: "POST",
								success: function(response) {
									MessageBox.success("Vehicle details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idVehicle").setEnabled(false);
											this.getView().byId("idVehicleObservations").setEnabled(false);
											this.getView().byId("idVehicleCorectiveMeasures").setEnabled(false);
											this.getView().byId("idVehicleFileUpload").setEnabled(false);
											this.getView().byId("idVehiclePanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
						}
						if (this.tripStatus === "IP") {
							this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
								"',TripNumber='" +
								this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
								"',ContainerNo='" +
								contNum + "')", payload, {
									method: "PUT",
									success: function(response) {
										MessageBox.success("Vehicle details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idVehicle").setEnabled(false);
												this.getView().byId("idVehicleObservations").setEnabled(false);
												this.getView().byId("idVehicleCorectiveMeasures").setEnabled(false);
												this.getView().byId("idVehicleFileUpload").setEnabled(false);
												this.getView().byId("idVehiclePanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
						}
					}
				}
				if (select) {
					if (this.fileNameTruckVehicle) {
						if (this.fileTypeTruckVehicle === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTruckVehicle + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									contNum + '"/"' + contBoxNo + '"/"' + 3
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTruckVehicle
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							contNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idVehicle").setEnabled(false);
									this.getView().byId("idVehicleObservations").setEnabled(false);
									this.getView().byId("idVehicleCorectiveMeasures").setEnabled(false);
									this.getView().byId("idVehicleFileUpload").setEnabled(false);
									this.getView().byId("idVehiclePanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
		},
		onTruckVehicleEdit: function() {
			var radio = this.getView().byId("idVehicle").getSelectedIndex();
			if (radio === 0 || radio === 2) {
				this.getView().byId("idVehicle").setEnabled(true);
				this.getView().byId("idVehicleFileUpload").setEnabled(true);
			}
			if (radio === 1) {
				this.getView().byId("idVehicle").setEnabled(true);
				this.getView().byId("idVehicleObservations").setEnabled(true);
				this.getView().byId("idVehicleCorectiveMeasures").setEnabled(true);
				this.getView().byId("idVehicleFileUpload").setEnabled(true);
			}
		},
		onTruckCleanSave: function() {
			var ContLoadCleanIssue = this.getView().byId("idVehicleClean").getSelectedIndex();
			var ContLoadObservations = this.getView().byId("idVehicleCleanObservations").getValue();
			var ContLoadCorrMeasure = this.getView().byId("idVehicleCleanCorectiveMeasures").getValue();
			var check = true;
			var items = this.getView().getModel("InspectionModel").getData();
			var select = items.ContLoadCleanChk;
			var oFileUploader = this.getView().byId("idVehicleCleanFileUpload");
			var contNum = this.getView().getModel("TripModel").getData().ContainerNo;
			var contBoxNo = "000";
			var payload;
			var createPayload = {
				"ContLoadCleanIssue": ContLoadCleanIssue,
				"ContLoadObservations": ContLoadObservations,
				"ContLoadCorrMeasure": ContLoadCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": contNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Truck",
				"ContLoadCleanChk": check
			};
			var updatePayload = {
				"ContLoadCleanIssue": ContLoadCleanIssue,
				"ContLoadObservations": ContLoadObservations,
				"ContLoadCorrMeasure": ContLoadCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": contNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Truck",
				"ContLoadCleanChk": check
			};
			if (ContLoadCleanIssue === 1) {
				payload = createPayload;
				if (!select || select == undefined) {
					if (payload.ContLoadObservations !== "" && payload.ContLoadCorrMeasure !== "") {
						if (this.fileNameTruckCleanSave) {
							if (this.fileTypeTruckCleanSave === "image/jpeg") {
								oFileUploader.destroyHeaderParameters();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "SLUG",
									value: this.fileNameTruckCleanSave + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
										'"/"' +
										contNum + '"/"' + contBoxNo + '"/"' + 11
								}));
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "Content-Type",
									value: this.fileTypeTruckCleanSave
								}));
								this.getOwnerComponent().getModel().refreshSecurityToken();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "x-csrf-token",
									value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
								}));
								oFileUploader.setSendXHR(true);
								oFileUploader.upload();
							} else {
								MessageBox.error("File format should be JPG");
							}
						}
						if (this.tripStatus === "RD") {
							this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
								method: "POST",
								success: function(response) {
									MessageBox.success("Vehicle cleanliness details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idVehicleClean").setEnabled(false);
											this.getView().byId("idVehicleCleanObservations").setEnabled(false);
											this.getView().byId("idVehicleCleanCorectiveMeasures").setEnabled(false);
											this.getView().byId("idVehicleCleanFileUpload").setEnabled(false);
											this.getView().byId("idVehicleCleanPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
						}
						if (this.tripStatus === "IP") {
							this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
								"',TripNumber='" +
								this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
								"',ContainerNo='" +
								contNum + "')", payload, {
									method: "PUT",
									success: function(response) {
										MessageBox.success("Vehicle Cleanliness details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idVehicleClean").setEnabled(false);
												this.getView().byId("idVehicleCleanObservations").setEnabled(false);
												this.getView().byId("idVehicleCleanCorectiveMeasures").setEnabled(false);
												this.getView().byId("idVehicleCleanFileUpload").setEnabled(false);
												this.getView().byId("idVehicleCleanPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
						}
					} else {
						MessageBox.error("Please fill all the mandatory feilds");
					}
				}
				if (select) {
					if (this.fileNameTruckCleanSave) {
						if (this.fileTypeTruckCleanSave === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTruckCleanSave + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
									'"/"' +
									contNum + '"/"' + contBoxNo + '"/"' + 11
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTruckCleanSave
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							contNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idVehicleClean").setEnabled(false);
									this.getView().byId("idVehicleCleanObservations").setEnabled(false);
									this.getView().byId("idVehicleCleanCorectiveMeasures").setEnabled(false);
									this.getView().byId("idVehicleCleanFileUpload").setEnabled(false);
									this.getView().byId("idVehicleCleanPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
			if (ContLoadCleanIssue === 0) {
				payload = updatePayload;
				if (!select || select == undefined) {
					if (this.fileNameTruckCleanSave) {
						if (this.fileTypeTruckCleanSave === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTruckCleanSave + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
									'"/"' +
									contNum + '"/"' + contBoxNo + '"/"' + 11
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTruckCleanSave
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();
						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "RD") {
						this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
							method: "POST",
							success: function(response) {
								MessageBox.success("Vehicle cleanliness details have been updated successfully", {
									onClose: function() {
										this.readHeaderEntitySet();
										this.readInspectionEntitySetforTruckandTank();
										this.getView().byId("idVehicleClean").setEnabled(false);
										this.getView().byId("idVehicleCleanObservations").setEnabled(false);
										this.getView().byId("idVehicleCleanCorectiveMeasures").setEnabled(false);
										this.getView().byId("idVehicleCleanFileUpload").setEnabled(false);
										this.getView().byId("idVehicleCleanPanel").setExpanded(false);
									}.bind(this)
								});
							}.bind(this),
							error: function(error) {
								MessageBox.warning("Error occurred while updating the data");
							}
						});
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							contNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									MessageBox.success("Vehicle Cleanliness details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idVehicleClean").setEnabled(false);
											this.getView().byId("idVehicleCleanObservations").setEnabled(false);
											this.getView().byId("idVehicleCleanCorectiveMeasures").setEnabled(false);
											this.getView().byId("idVehicleCleanFileUpload").setEnabled(false);
											this.getView().byId("idVehicleCleanPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
				if (select) {
					if (this.fileNameTruckCleanSave) {
						if (this.fileTypeTruckCleanSave === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTruckCleanSave + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
									'"/"' +
									contNum + '"/"' + contBoxNo + '"/"' + 11
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTruckCleanSave
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();
						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							contNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idVehicleClean").setEnabled(false);
									this.getView().byId("idVehicleCleanObservations").setEnabled(false);
									this.getView().byId("idVehicleCleanCorectiveMeasures").setEnabled(false);
									this.getView().byId("idVehicleCleanFileUpload").setEnabled(false);
									this.getView().byId("idVehicleCleanPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
			if (ContLoadCleanIssue === 2) {
				payload = updatePayload;
				if (!select || select == undefined) {
					if (this.fileNameTruckCleanSave) {
						if (this.fileTypeTruckCleanSave === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTruckCleanSave + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
									'"/"' +
									contNum + '"/"' + contBoxNo + '"/"' + 11
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTruckCleanSave
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "RD") {
						this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
							method: "POST",
							success: function(response) {
								MessageBox.success("Vehicle cleanliness details have been updated successfully", {
									onClose: function() {
										this.readHeaderEntitySet();
										this.readInspectionEntitySetforTruckandTank();
										this.getView().byId("idVehicleClean").setEnabled(false);
										this.getView().byId("idVehicleCleanObservations").setEnabled(false);
										this.getView().byId("idVehicleCleanCorectiveMeasures").setEnabled(false);
										this.getView().byId("idVehicleCleanFileUpload").setEnabled(false);
										this.getView().byId("idVehicleCleanPanel").setExpanded(false);
									}.bind(this)
								});
							}.bind(this),
							error: function(error) {
								MessageBox.warning("Error occurred while updating the data");
							}
						});
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							contNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									MessageBox.success("Vehicle Cleanliness details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idVehicleClean").setEnabled(false);
											this.getView().byId("idVehicleCleanObservations").setEnabled(false);
											this.getView().byId("idVehicleCleanCorectiveMeasures").setEnabled(false);
											this.getView().byId("idVehicleCleanFileUpload").setEnabled(false);
											this.getView().byId("idVehicleCleanPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
				if (select) {
					if (this.fileNameTruckCleanSave) {
						if (this.fileTypeTruckCleanSave === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTruckCleanSave + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
									'"/"' +
									contNum + '"/"' + contBoxNo + '"/"' + 11
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTruckCleanSave
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							contNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idVehicleClean").setEnabled(false);
									this.getView().byId("idVehicleCleanObservations").setEnabled(false);
									this.getView().byId("idVehicleCleanCorectiveMeasures").setEnabled(false);
									this.getView().byId("idVehicleCleanFileUpload").setEnabled(false);
									this.getView().byId("idVehicleCleanPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
		},
		onTruckCleanEdit: function() {
			var radio = this.getView().byId("idVehicleClean").getSelectedIndex();
			if (radio === 0 || radio == 2) {
				this.getView().byId("idVehicleClean").setEnabled(true);
				this.getView().byId("idVehicleCleanFileUpload").setEnabled(true);
			}
			if (radio === 1) {
				this.getView().byId("idVehicleClean").setEnabled(true);
				this.getView().byId("idVehicleCleanObservations").setEnabled(true);
				this.getView().byId("idVehicleCleanCorectiveMeasures").setEnabled(true);
				this.getView().byId("idVehicleCleanFileUpload").setEnabled(true);
			}
		},
		onTruckBodySave: function() {
			var FumigationInspIssue = this.getView().byId("idBody").getSelectedIndex();
			var FumigationObservations = this.getView().byId("idBodyObservations").getValue();
			var FumigationCorrMeasure = this.getView().byId("idBodyCorectiveMeasures").getValue();
			var check = true;
			var items = this.getView().getModel("InspectionModel").getData();
			var select = items.FumigationChk;
			var oFileUploader = this.getView().byId("idBodyFileUpload");
			var contNum = this.getView().getModel("TripModel").getData().ContainerNo;
			var contBoxNo = "000";
			var payload;
			var createPayload = {
				"FumigationInspIssue": FumigationInspIssue,
				"FumigationObservations": FumigationObservations,
				"FumigationCorrMeasure": FumigationCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": contNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Truck",
				"FumigationChk": check
			};
			var updatePayload = {
				"FumigationInspIssue": FumigationInspIssue,
				"FumigationObservations": FumigationObservations,
				"FumigationCorrMeasure": FumigationCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": contNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Truck",
				"FumigationChk": check
			};
			if (FumigationInspIssue === 1) {
				payload = createPayload;
				if (!select || select == undefined) {
					if (payload.FumigationObservations !== "" && payload.FumigationCorrMeasure !== "") {
						if (this.fileNameTruckBodySave) {
							if (this.fileTypeTruckBodySave === "image/jpeg") {
								oFileUploader.destroyHeaderParameters();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "SLUG",
									value: this.fileNameTruckBodySave + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
										'"/"' +
										contNum + '"/"' + contBoxNo + '"/"' + 12
								}));
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "Content-Type",
									value: this.fileTypeTruckBodySave
								}));
								this.getOwnerComponent().getModel().refreshSecurityToken();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "x-csrf-token",
									value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
								}));
								oFileUploader.setSendXHR(true);
								oFileUploader.upload();
							} else {
								MessageBox.error("File format should be JPG");
							}
						}
						if (this.tripStatus === "RD") {
							this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
								method: "POST",
								success: function(response) {
									MessageBox.success("Vehicle Body details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idBody").setEnabled(false);
											this.getView().byId("idBodyObservations").setEnabled(false);
											this.getView().byId("idBodyCorectiveMeasures").setEnabled(false);
											this.getView().byId("idBodyFileUpload").setEnabled(false);
											this.getView().byId("idBodyPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
						}
						if (this.tripStatus === "IP") {
							this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
								"',TripNumber='" +
								this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
								"',ContainerNo='" +
								contNum + "')", payload, {
									method: "PUT",
									success: function(response) {
										MessageBox.success("Vehicle body details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idBody").setEnabled(false);
												this.getView().byId("idBodyObservations").setEnabled(false);
												this.getView().byId("idBodyCorectiveMeasures").setEnabled(false);
												this.getView().byId("idBodyFileUpload").setEnabled(false);
												this.getView().byId("idBodyPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
						}
					} else {
						MessageBox.error("Please fill all the mandatory feilds");
					}
				}
				if (select) {
					if (this.fileNameTruckBodySave) {
						if (this.fileTypeTruckBodySave === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTruckBodySave + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									contNum + '"/"' + contBoxNo + '"/"' + 12
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTruckBodySave
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();
						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							contNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idBody").setEnabled(false);
									this.getView().byId("idBodyObservations").setEnabled(false);
									this.getView().byId("idBodyCorectiveMeasures").setEnabled(false);
									this.getView().byId("idBodyFileUpload").setEnabled(false);
									this.getView().byId("idBodyPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
			if (FumigationInspIssue === 0) {
				payload = updatePayload;
				if (!select || select == undefined) {
					if (this.fileNameTruckBodySave) {
						if (this.fileTypeTruckBodySave === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTruckBodySave + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									contNum + '"/"' + contBoxNo + '"/"' + 12
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTruckBodySave
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();
						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "RD") {
						this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
							method: "POST",
							success: function(response) {
								MessageBox.success("Vehicle Body details have been updated successfully", {
									onClose: function() {
										this.readHeaderEntitySet();
										this.readInspectionEntitySetforTruckandTank();
										this.getView().byId("idBody").setEnabled(false);
										this.getView().byId("idBodyObservations").setEnabled(false);
										this.getView().byId("idBodyCorectiveMeasures").setEnabled(false);
										this.getView().byId("idBodyFileUpload").setEnabled(false);
										this.getView().byId("idBodyPanel").setExpanded(false);
									}.bind(this)
								});
							}.bind(this),
							error: function(error) {
								MessageBox.warning("Error occurred while updating the data");
							}
						});
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							contNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									MessageBox.success("Vehicle body details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idBody").setEnabled(false);
											this.getView().byId("idBodyObservations").setEnabled(false);
											this.getView().byId("idBodyCorectiveMeasures").setEnabled(false);
											this.getView().byId("idBodyFileUpload").setEnabled(false);
											this.getView().byId("idBodyPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
				if (select) {
					if (this.fileNameTruckBodySave) {
						if (this.fileTypeTruckBodySave === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTruckBodySave + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									contNum + '"/"' + contBoxNo + '"/"' + 12
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTruckBodySave
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();
						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							contNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idBody").setEnabled(false);
									this.getView().byId("idBodyObservations").setEnabled(false);
									this.getView().byId("idBodyCorectiveMeasures").setEnabled(false);
									this.getView().byId("idBodyFileUpload").setEnabled(false);
									this.getView().byId("idBodyPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
			if (FumigationInspIssue === 2) {
				payload = updatePayload;
				if (!select || select == undefined) {
					if (this.fileNameTruckBodySave) {
						if (this.fileTypeTruckBodySave === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTruckBodySave + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									contNum + '"/"' + contBoxNo + '"/"' + 12
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTruckBodySave
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();
						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "RD") {
						this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
							method: "POST",
							success: function(response) {
								MessageBox.success("Vehicle Body details have been updated successfully", {
									onClose: function() {
										this.readHeaderEntitySet();
										this.readInspectionEntitySetforTruckandTank();
										this.getView().byId("idBody").setEnabled(false);
										this.getView().byId("idBodyObservations").setEnabled(false);
										this.getView().byId("idBodyCorectiveMeasures").setEnabled(false);
										this.getView().byId("idBodyFileUpload").setEnabled(false);
										this.getView().byId("idBodyPanel").setExpanded(false);
									}.bind(this)
								});
							}.bind(this),
							error: function(error) {
								MessageBox.warning("Error occurred while updating the data");
							}
						});
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							contNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									MessageBox.success("Vehicle body details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idBody").setEnabled(false);
											this.getView().byId("idBodyObservations").setEnabled(false);
											this.getView().byId("idBodyCorectiveMeasures").setEnabled(false);
											this.getView().byId("idBodyFileUpload").setEnabled(false);
											this.getView().byId("idBodyPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
				if (select) {
					if (this.fileNameTruckBodySave) {
						if (this.fileTypeTruckBodySave === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTruckBodySave + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									contNum + '"/"' + contBoxNo + '"/"' + 12
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTruckBodySave
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();
						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							contNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idBody").setEnabled(false);
									this.getView().byId("idBodyObservations").setEnabled(false);
									this.getView().byId("idBodyCorectiveMeasures").setEnabled(false);
									this.getView().byId("idBodyFileUpload").setEnabled(false);
									this.getView().byId("idBodyPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
		},
		onTruckBodyEdit: function() {
			var radio = this.getView().byId("idBody").getSelectedIndex();
			if (radio === 0 || radio === 2) {
				this.getView().byId("idBody").setEnabled(true);
				this.getView().byId("idBodyFileUpload").setEnabled(true);
			}
			if (radio === 1) {
				this.getView().byId("idBody").setEnabled(true);
				this.getView().byId("idBodyObservations").setEnabled(true);
				this.getView().byId("idBodyCorectiveMeasures").setEnabled(true);
				this.getView().byId("idBodyFileUpload").setEnabled(true);
			}
		},
		onTankCleanSave: function() {
			var VehicleIssue = this.getView().byId("idTankerClean").getSelectedIndex();
			var VehObservations = this.getView().byId("idTankerCleanObservations").getValue();
			var VehCorrMeasure = this.getView().byId("idTankerCleanCorectiveMeasures").getValue();
			var check = true;
			var items = this.getView().getModel("InspectionModel").getData();
			var select = items.VehicleCheck;
			var oFileUploader = this.getView().byId("idTankerCleanFileUpload");
			var tankNum = this.getView().getModel("TripModel").getData().ContainerNo;
			var contBoxNo = "000";
			var payload;
			var createPayload = {
				"VehicleIssue": VehicleIssue,
				"VehObservations": VehObservations,
				"VehCorrMeasure": VehCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": tankNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Tank lorry",
				"VehicleCheck": check
			};
			var updatePayload = {
				"VehicleIssue": VehicleIssue,
				"VehObservations": VehObservations,
				"VehCorrMeasure": VehCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": tankNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Tank lorry",
				"VehicleCheck": check
			};
			if (VehicleIssue === 1) {
				payload = createPayload;
				if (!select || select == undefined) {
					if (payload.VehObservations !== "" && payload.VehCorrMeasure !== "") {
						if (this.fileNameTankClean) {
							if (this.fileTypeTankClean === "image/jpeg") {
								oFileUploader.destroyHeaderParameters();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "SLUG",
									value: this.fileNameTankClean + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
										tankNum +
										'"/"' + contBoxNo + '"/"' + 3
								}));
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "Content-Type",
									value: this.fileTypeTankClean
								}));
								this.getOwnerComponent().getModel().refreshSecurityToken();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "x-csrf-token",
									value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
								}));
								oFileUploader.setSendXHR(true);
								oFileUploader.upload();

							} else {
								MessageBox.error("File format should be JPG");
							}

							if (this.tripStatus === "RD") {
								this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
									method: "POST",
									success: function(response) {
										MessageBox.success("Canvas selection details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idTankerClean").setEnabled(false);
												this.getView().byId("idTankerCleanObservations").setEnabled(false);
												this.getView().byId("idTankerCleanCorectiveMeasures").setEnabled(false);
												this.getView().byId("idTankerCleanFileUpload").setEnabled(false);
												this.getView().byId("idTankerCleanPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
							}
							if (this.tripStatus === "IP") {
								this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
									"',TripNumber='" +
									this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
									"',ContainerNo='" +
									tankNum + "')", payload, {
										method: "PUT",
										success: function(response) {
											MessageBox.success("Vehicle details have been updated successfully", {
												onClose: function() {
													this.readHeaderEntitySet();
													this.readInspectionEntitySetforTruckandTank();
													this.getView().byId("idTankerClean").setEnabled(false);
													this.getView().byId("idTankerCleanObservations").setEnabled(false);
													this.getView().byId("idTankerCleanCorectiveMeasures").setEnabled(false);
													this.getView().byId("idTankerCleanFileUpload").setEnabled(false);
													this.getView().byId("idTankerCleanPanel").setExpanded(false);
												}.bind(this)
											});
										}.bind(this),
										error: function(error) {
											MessageBox.warning("Error occurred while updating the data");
										}
									});
							}
						} else {
							if (this.tripStatus === "RD") {
								this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
									method: "POST",
									success: function(response) {
										MessageBox.success("Canvas selection details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idTankerClean").setEnabled(false);
												this.getView().byId("idTankerCleanObservations").setEnabled(false);
												this.getView().byId("idTankerCleanCorectiveMeasures").setEnabled(false);
												this.getView().byId("idTankerCleanFileUpload").setEnabled(false);
												this.getView().byId("idTankerCleanPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
							}
							if (this.tripStatus === "IP") {
								this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
									"',TripNumber='" +
									this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
									"',ContainerNo='" +
									tankNum + "')", payload, {
										method: "PUT",
										success: function(response) {
											MessageBox.success("Vehicle details have been updated successfully", {
												onClose: function() {
													this.readHeaderEntitySet();
													this.readInspectionEntitySetforTruckandTank();
													this.getView().byId("idTankerClean").setEnabled(false);
													this.getView().byId("idTankerCleanObservations").setEnabled(false);
													this.getView().byId("idTankerCleanCorectiveMeasures").setEnabled(false);
													this.getView().byId("idTankerCleanFileUpload").setEnabled(false);
													this.getView().byId("idTankerCleanPanel").setExpanded(false);
												}.bind(this)
											});
										}.bind(this),
										error: function(error) {
											MessageBox.warning("Error occurred while updating the data");
										}
									});
							}
						}
					} else {
						MessageBox.error("Please fill all the mandatory feilds");
					}
				}
				if (select) {
					if (this.fileNameTankClean) {
						if (this.fileTypeTankClean === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTankClean + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									tankNum +
									'"/"' + contBoxNo + '"/"' + 3
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTankClean
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							tankNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idTankerClean").setEnabled(false);
									this.getView().byId("idTankerCleanObservations").setEnabled(false);
									this.getView().byId("idTankerCleanCorectiveMeasures").setEnabled(false);
									this.getView().byId("idTankerCleanFileUpload").setEnabled(false);
									this.getView().byId("idTankerCleanPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
			if (VehicleIssue === 0 || VehicleIssue === 2) {
				payload = updatePayload;
				if (!select || select == undefined) {
					if (this.fileNameTankClean) {
						if (this.fileTypeTankClean === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTankClean + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									tankNum +
									'"/"' + contBoxNo + '"/"' + 3
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTankClean
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}

						if (this.tripStatus === "RD") {
							this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
								method: "POST",
								success: function(response) {
									MessageBox.success("Canvas selection details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idTankerClean").setEnabled(false);
											this.getView().byId("idTankerCleanObservations").setEnabled(false);
											this.getView().byId("idTankerCleanCorectiveMeasures").setEnabled(false);
											this.getView().byId("idTankerCleanFileUpload").setEnabled(false);
											this.getView().byId("idTankerCleanPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
						}
						if (this.tripStatus === "IP") {
							this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
								"',TripNumber='" +
								this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
								"',ContainerNo='" +
								tankNum + "')", payload, {
									method: "PUT",
									success: function(response) {
										MessageBox.success("Vehicle details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idTankerClean").setEnabled(false);
												this.getView().byId("idTankerCleanObservations").setEnabled(false);
												this.getView().byId("idTankerCleanCorectiveMeasures").setEnabled(false);
												this.getView().byId("idTankerCleanFileUpload").setEnabled(false);
												this.getView().byId("idTankerCleanPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
						}
					} else {
						if (this.tripStatus === "RD") {
							this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
								method: "POST",
								success: function(response) {
									MessageBox.success("Canvas selection details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idTankerClean").setEnabled(false);
											this.getView().byId("idTankerCleanObservations").setEnabled(false);
											this.getView().byId("idTankerCleanCorectiveMeasures").setEnabled(false);
											this.getView().byId("idTankerCleanFileUpload").setEnabled(false);
											this.getView().byId("idTankerCleanPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
						}
						if (this.tripStatus === "IP") {
							this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
								"',TripNumber='" +
								this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
								"',ContainerNo='" +
								tankNum + "')", payload, {
									method: "PUT",
									success: function(response) {
										MessageBox.success("Vehicle details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idTankerClean").setEnabled(false);
												this.getView().byId("idTankerCleanObservations").setEnabled(false);
												this.getView().byId("idTankerCleanCorectiveMeasures").setEnabled(false);
												this.getView().byId("idTankerCleanFileUpload").setEnabled(false);
												this.getView().byId("idTankerCleanPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
						}
					}
				}
				if (select) {
					if (this.fileNameTankClean) {
						if (this.fileTypeTankClean === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTankClean + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									tankNum +
									'"/"' + contBoxNo + '"/"' + 3
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTankClean
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							tankNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idTankerClean").setEnabled(false);
									this.getView().byId("idTankerCleanObservations").setEnabled(false);
									this.getView().byId("idTankerCleanCorectiveMeasures").setEnabled(false);
									this.getView().byId("idTankerCleanFileUpload").setEnabled(false);
									this.getView().byId("idTankerCleanPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
		},
		onTankCleanEdit: function() {
			var radio = this.getView().byId("idTankerClean").getSelectedIndex();
			if (radio === 0 || radio === 2) {
				this.getView().byId("idTankerClean").setEnabled(true);
				this.getView().byId("idTankerCleanFileUpload").setEnabled(true);
			}
			if (radio === 1) {
				this.getView().byId("idTankerClean").setEnabled(true);
				this.getView().byId("idTankerCleanObservations").setEnabled(true);
				this.getView().byId("idTankerCleanCorectiveMeasures").setEnabled(true);
				this.getView().byId("idTankerCleanFileUpload").setEnabled(true);
			}
		},
		onTankBottomSealSave: function() {
			var RubberSealIssue = this.getView().byId("idBottomSeal").getSelectedIndex();
			var RubberSealObservations = this.getView().byId("idBottomSealObservations").getValue();
			var RubberSealCorrMeasure = this.getView().byId("idBottomSealCorectiveMeasures").getValue();
			var check = true;
			var items = this.getView().getModel("InspectionModel").getData();
			var select = items.RubberSealChk;
			var oFileUploader = this.getView().byId("idBottomSealFileUpload");
			var tankNum = this.getView().getModel("TripModel").getData().ContainerNo;
			var contBoxNo = "000";
			var payload;
			var createPayload = {
				"RubberSealIssue": RubberSealIssue,
				"RubberSealObservations": RubberSealObservations,
				"RubberSealCorrMeasure": RubberSealCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": tankNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Tank lorry",
				"RubberSealChk": check
			};
			var updatePayload = {
				"RubberSealIssue": RubberSealIssue,
				"RubberSealObservations": RubberSealObservations,
				"RubberSealCorrMeasure": RubberSealCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": tankNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Tank lorry",
				"RubberSealChk": check
			};
			if (RubberSealIssue === 1) {
				payload = createPayload;
				if (!select || select == undefined) {
					if (payload.RubberSealObservations !== "" && payload.RubberSealCorrMeasure !== "") {
						if (this.fileNameTankBottomSeal) {
							if (this.fileTypeTankBottomSeal === "image/jpeg") {
								oFileUploader.destroyHeaderParameters();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "SLUG",
									value: this.fileNameTankBottomSeal + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
										'"/"' +
										tankNum + '"/"' + contBoxNo + '"/"' + 5
								}));
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "Content-Type",
									value: this.fileTypeTankBottomSeal
								}));
								this.getOwnerComponent().getModel().refreshSecurityToken();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "x-csrf-token",
									value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
								}));
								oFileUploader.setSendXHR(true);
								oFileUploader.upload();
							} else {
								MessageBox.error("File format should be JPG");
							}
						}
						if (this.tripStatus === "RD") {
							this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
								method: "POST",
								success: function(response) {
									MessageBox.success("Canvas selection details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idBottomSeal").setEnabled(false);
											this.getView().byId("idBottomSealObservations").setEnabled(false);
											this.getView().byId("idBottomSealCorectiveMeasures").setEnabled(false);
											this.getView().byId("idBottomSealFileUpload").setEnabled(false);
											this.getView().byId("idBottomSealPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
						}
						if (this.tripStatus === "IP") {
							this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
								"',TripNumber='" +
								this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
								"',ContainerNo='" +
								tankNum + "')", payload, {
									method: "PUT",
									success: function(response) {
										MessageBox.success("Vehicle details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idBottomSeal").setEnabled(false);
												this.getView().byId("idBottomSealObservations").setEnabled(false);
												this.getView().byId("idBottomSealCorectiveMeasures").setEnabled(false);
												this.getView().byId("idBottomSealFileUpload").setEnabled(false);
												this.getView().byId("idBottomSealPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
						}
					} else {
						MessageBox.error("Please fill all the mandatory feilds");
					}
				}
				if (select) {
					if (this.fileNameTankBottomSeal) {
						if (this.fileTypeTankBottomSeal === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTankBottomSeal + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
									'"/"' +
									tankNum + '"/"' + contBoxNo + '"/"' + 5
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTankBottomSeal
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							tankNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idBottomSeal").setEnabled(false);
									this.getView().byId("idBottomSealObservations").setEnabled(false);
									this.getView().byId("idBottomSealCorectiveMeasures").setEnabled(false);
									this.getView().byId("idBottomSealFileUpload").setEnabled(false);
									this.getView().byId("idBottomSealPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
			if (RubberSealIssue === 0) {
				payload = updatePayload;
				if (!select || select == undefined) {
					if (this.fileNameTankBottomSeal) {
						if (this.fileTypeTankBottomSeal === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTankBottomSeal + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
									'"/"' +
									tankNum + '"/"' + contBoxNo + '"/"' + 5
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTankBottomSeal
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "RD") {
						this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
							method: "POST",
							success: function(response) {
								MessageBox.success("Canvas selection details have been updated successfully", {
									onClose: function() {
										this.readHeaderEntitySet();
										this.readInspectionEntitySetforTruckandTank();
										this.getView().byId("idBottomSeal").setEnabled(false);
										this.getView().byId("idBottomSealObservations").setEnabled(false);
										this.getView().byId("idBottomSealCorectiveMeasures").setEnabled(false);
										this.getView().byId("idBottomSealFileUpload").setEnabled(false);
										this.getView().byId("idBottomSealPanel").setExpanded(false);
									}.bind(this)
								});
							}.bind(this),
							error: function(error) {
								MessageBox.warning("Error occurred while updating the data");
							}
						});
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							tankNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									MessageBox.success("Vehicle details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idBottomSeal").setEnabled(false);
											this.getView().byId("idBottomSealObservations").setEnabled(false);
											this.getView().byId("idBottomSealCorectiveMeasures").setEnabled(false);
											this.getView().byId("idBottomSealFileUpload").setEnabled(false);
											this.getView().byId("idBottomSealPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
				if (select) {
					if (this.fileNameTankBottomSeal) {
						if (this.fileTypeTankBottomSeal === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTankBottomSeal + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
									'"/"' +
									tankNum + '"/"' + contBoxNo + '"/"' + 5
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTankBottomSeal
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							tankNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idBottomSeal").setEnabled(false);
									this.getView().byId("idBottomSealObservations").setEnabled(false);
									this.getView().byId("idBottomSealCorectiveMeasures").setEnabled(false);
									this.getView().byId("idBottomSealFileUpload").setEnabled(false);
									this.getView().byId("idBottomSealPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
			if (RubberSealIssue === 2) {
				payload = updatePayload;
				if (!select || select == undefined) {
					if (this.fileNameTankBottomSeal) {
						if (this.fileTypeTankBottomSeal === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTankBottomSeal + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
									'"/"' +
									tankNum + '"/"' + contBoxNo + '"/"' + 5
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTankBottomSeal
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "RD") {
						this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
							method: "POST",
							success: function(response) {
								MessageBox.success("Canvas selection details have been updated successfully", {
									onClose: function() {
										this.readHeaderEntitySet();
										this.readInspectionEntitySetforTruckandTank();
										this.getView().byId("idBottomSeal").setEnabled(false);
										this.getView().byId("idBottomSealObservations").setEnabled(false);
										this.getView().byId("idBottomSealCorectiveMeasures").setEnabled(false);
										this.getView().byId("idBottomSealFileUpload").setEnabled(false);
										this.getView().byId("idBottomSealPanel").setExpanded(false);
									}.bind(this)
								});
							}.bind(this),
							error: function(error) {
								MessageBox.warning("Error occurred while updating the data");
							}
						});
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							tankNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									MessageBox.success("Vehicle details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idBottomSeal").setEnabled(false);
											this.getView().byId("idBottomSealObservations").setEnabled(false);
											this.getView().byId("idBottomSealCorectiveMeasures").setEnabled(false);
											this.getView().byId("idBottomSealFileUpload").setEnabled(false);
											this.getView().byId("idBottomSealPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
				if (select) {
					if (this.fileNameTankBottomSeal) {
						if (this.fileTypeTankBottomSeal === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTankBottomSeal + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
									'"/"' +
									tankNum + '"/"' + contBoxNo + '"/"' + 5
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTankBottomSeal
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							tankNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idBottomSeal").setEnabled(false);
									this.getView().byId("idBottomSealObservations").setEnabled(false);
									this.getView().byId("idBottomSealCorectiveMeasures").setEnabled(false);
									this.getView().byId("idBottomSealFileUpload").setEnabled(false);
									this.getView().byId("idBottomSealPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
		},
		onTankBottomSealEdit: function() {
			var radio = this.getView().byId("idBottomSeal").getSelectedIndex();
			if (radio === 0 || radio === 2) {
				this.getView().byId("idBottomSeal").setEnabled(true);
				this.getView().byId("idBottomSealFileUpload").setEnabled(true);
			}
			if (radio === 1) {
				this.getView().byId("idBottomSeal").setEnabled(true);
				this.getView().byId("idBottomSealObservations").setEnabled(true);
				this.getView().byId("idBottomSealCorectiveMeasures").setEnabled(true);
				this.getView().byId("idBottomSealFileUpload").setEnabled(true);
			}
		},
		onTankForeignSave: function() {
			var ContainerIssue = this.getView().byId("idForeign").getSelectedIndex();
			var ContObservations = this.getView().byId("idForeignObservations").getValue();
			var ContCorrMeasure = this.getView().byId("idForeignCorectiveMeasures").getValue();
			var check = true;
			var items = this.getView().getModel("InspectionModel").getData();
			var select = items.ContainerChk;
			var oFileUploader = this.getView().byId("idForeignFileUpload");
			var tankNum = this.getView().getModel("TripModel").getData().ContainerNo;
			var contBoxNo = "000";
			var payload;
			var createPayload = {
				"ContainerIssue": ContainerIssue,
				"ContObservations": ContObservations,
				"ContCorrMeasure": ContCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": tankNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Tank lorry",
				"ContainerChk": check
			};
			var updatePayload = {
				"ContainerIssue": ContainerIssue,
				"ContObservations": ContObservations,
				"ContCorrMeasure": ContCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": tankNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Tank lorry",
				"ContainerChk": check
			};
			if (ContainerIssue === 1) {
				payload = createPayload;
				if (!select || select == undefined) {
					if (payload.ContObservations !== "" && payload.ContCorrMeasure !== "") {
						if (this.fileNameTankForeign) {
							if (this.fileTypeTankForeign === "image/jpeg") {
								oFileUploader.destroyHeaderParameters();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "SLUG",
									value: this.fileNameTankForeign + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
										tankNum +
										'"/"' + contBoxNo + '"/"' + 14
								}));
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "Content-Type",
									value: this.fileTypeTankForeign
								}));
								this.getOwnerComponent().getModel().refreshSecurityToken();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "x-csrf-token",
									value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
								}));
								oFileUploader.setSendXHR(true);
								oFileUploader.upload();

							} else {
								MessageBox.error("File format should be JPG");
							}

							if (this.tripStatus === "RD") {
								this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
									method: "POST",
									success: function(response) {
										MessageBox.success("Canvas selection details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idForeign").setEnabled(false);
												this.getView().byId("idForeignObservations").setEnabled(false);
												this.getView().byId("idForeignCorectiveMeasures").setEnabled(false);
												this.getView().byId("idForeignFileUpload").setEnabled(false);
												this.getView().byId("idForeignPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
							}
							if (this.tripStatus === "IP") {
								this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
									"',TripNumber='" +
									this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
									"',ContainerNo='" +
									tankNum + "')", payload, {
										method: "PUT",
										success: function(response) {
											MessageBox.success("Vehicle details have been updated successfully", {
												onClose: function() {
													this.readHeaderEntitySet();
													this.readInspectionEntitySetforTruckandTank();
													this.getView().byId("idForeign").setEnabled(false);
													this.getView().byId("idForeignObservations").setEnabled(false);
													this.getView().byId("idForeignCorectiveMeasures").setEnabled(false);
													this.getView().byId("idForeignFileUpload").setEnabled(false);
													this.getView().byId("idForeignPanel").setExpanded(false);
												}.bind(this)
											});
										}.bind(this),
										error: function(error) {
											MessageBox.warning("Error occurred while updating the data");
										}
									});
							}
						} else {
							if (this.tripStatus === "RD") {
								this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
									method: "POST",
									success: function(response) {
										MessageBox.success("Canvas selection details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idForeign").setEnabled(false);
												this.getView().byId("idForeignObservations").setEnabled(false);
												this.getView().byId("idForeignCorectiveMeasures").setEnabled(false);
												this.getView().byId("idForeignFileUpload").setEnabled(false);
												this.getView().byId("idForeignPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
							}
							if (this.tripStatus === "IP") {
								this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
									"',TripNumber='" +
									this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
									"',ContainerNo='" +
									tankNum + "')", payload, {
										method: "PUT",
										success: function(response) {
											MessageBox.success("Vehicle details have been updated successfully", {
												onClose: function() {
													this.readHeaderEntitySet();
													this.readInspectionEntitySetforTruckandTank();
													this.getView().byId("idForeign").setEnabled(false);
													this.getView().byId("idForeignObservations").setEnabled(false);
													this.getView().byId("idForeignCorectiveMeasures").setEnabled(false);
													this.getView().byId("idForeignFileUpload").setEnabled(false);
													this.getView().byId("idForeignPanel").setExpanded(false);
												}.bind(this)
											});
										}.bind(this),
										error: function(error) {
											MessageBox.warning("Error occurred while updating the data");
										}
									});
							}
						}
					} else {
						MessageBox.error("Please fill all the mandatory feilds");
					}
				}
				if (select) {
					if (this.fileNameTankForeign) {
						if (this.fileTypeTankForeign === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTankForeign + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									tankNum +
									'"/"' + contBoxNo + '"/"' + 14
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTankForeign
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							tankNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idForeign").setEnabled(false);
									this.getView().byId("idForeignObservations").setEnabled(false);
									this.getView().byId("idForeignCorectiveMeasures").setEnabled(false);
									this.getView().byId("idForeignFileUpload").setEnabled(false);
									this.getView().byId("idForeignPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
			if (ContainerIssue === 0 || ContainerIssue === 2) {
				payload = updatePayload;
				if (!select || select == undefined) {
					if (this.fileNameTankForeign) {
						if (this.fileTypeTankForeign === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTankForeign + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									tankNum +
									'"/"' + contBoxNo + '"/"' + 14
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTankForeign
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}

						if (this.tripStatus === "RD") {
							this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
								method: "POST",
								success: function(response) {
									MessageBox.success("Canvas selection details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idForeign").setEnabled(false);
											this.getView().byId("idForeignObservations").setEnabled(false);
											this.getView().byId("idForeignCorectiveMeasures").setEnabled(false);
											this.getView().byId("idForeignFileUpload").setEnabled(false);
											this.getView().byId("idForeignPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
						}
						if (this.tripStatus === "IP") {
							this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
								"',TripNumber='" +
								this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
								"',ContainerNo='" +
								tankNum + "')", payload, {
									method: "PUT",
									success: function(response) {
										MessageBox.success("Vehicle details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idForeign").setEnabled(false);
												this.getView().byId("idForeignObservations").setEnabled(false);
												this.getView().byId("idForeignCorectiveMeasures").setEnabled(false);
												this.getView().byId("idForeignFileUpload").setEnabled(false);
												this.getView().byId("idForeignPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
						}
					} else {
						if (this.tripStatus === "RD") {
							this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
								method: "POST",
								success: function(response) {
									MessageBox.success("Canvas selection details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idForeign").setEnabled(false);
											this.getView().byId("idForeignObservations").setEnabled(false);
											this.getView().byId("idForeignCorectiveMeasures").setEnabled(false);
											this.getView().byId("idForeignFileUpload").setEnabled(false);
											this.getView().byId("idForeignPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
						}
						if (this.tripStatus === "IP") {
							this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
								"',TripNumber='" +
								this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
								"',ContainerNo='" +
								tankNum + "')", payload, {
									method: "PUT",
									success: function(response) {
										MessageBox.success("Vehicle details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idForeign").setEnabled(false);
												this.getView().byId("idForeignObservations").setEnabled(false);
												this.getView().byId("idForeignCorectiveMeasures").setEnabled(false);
												this.getView().byId("idForeignFileUpload").setEnabled(false);
												this.getView().byId("idForeignPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
						}
					}
				}
				if (select) {
					if (this.fileNameTankForeign) {
						if (this.fileTypeTankForeign === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTankForeign + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									tankNum +
									'"/"' + contBoxNo + '"/"' + 14
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTankForeign
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							tankNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idForeign").setEnabled(false);
									this.getView().byId("idForeignObservations").setEnabled(false);
									this.getView().byId("idForeignCorectiveMeasures").setEnabled(false);
									this.getView().byId("idForeignFileUpload").setEnabled(false);
									this.getView().byId("idForeignPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
		},
		onTankForeignEdit: function() {
			var radio = this.getView().byId("idForeign").getSelectedIndex();
			if (radio === 0 || radio === 2) {
				this.getView().byId("idForeign").setEnabled(true);
				this.getView().byId("idForeignFileUpload").setEnabled(true);
			}
			if (radio === 1) {
				this.getView().byId("idForeign").setEnabled(true);
				this.getView().byId("idForeignObservations").setEnabled(true);
				this.getView().byId("idForeignCorectiveMeasures").setEnabled(true);
				this.getView().byId("idForeignFileUpload").setEnabled(true);
			}
		},
		onTankCSCSave: function() {
			var FumigationInspIssue = this.getView().byId("idCSC").getSelectedIndex();
			var FumigationObservations = this.getView().byId("idCSCObservations").getValue();
			var FumigationCorrMeasure = this.getView().byId("idCSCCorectiveMeasures").getValue();
			var check = true;
			var items = this.getView().getModel("InspectionModel").getData();
			var select = items.FumigationChk;
			var oFileUploader = this.getView().byId("idCSCFileUpload");
			var tankNum = this.getView().getModel("TripModel").getData().ContainerNo;
			var contBoxNo = "000";
			var payload;
			var createPayload = {
				"FumigationInspIssue": FumigationInspIssue,
				"FumigationObservations": FumigationObservations,
				"FumigationCorrMeasure": FumigationCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": tankNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Tank lorry",
				"FumigationChk": check
			};
			var updatePayload = {
				"FumigationInspIssue": FumigationInspIssue,
				"FumigationObservations": FumigationObservations,
				"FumigationCorrMeasure": FumigationCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": tankNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Tank lorry",
				"FumigationChk": check
			};
			if (FumigationInspIssue === 1) {
				payload = createPayload;
				if (!select || select == undefined) {
					if (payload.FumigationObservations !== "" && payload.FumigationCorrMeasure !== "") {
						if (this.fileNameTankCSC) {
							if (this.fileTypeTankCSC === "image/jpeg") {
								oFileUploader.destroyHeaderParameters();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "SLUG",
									value: this.fileNameTankCSC + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
										tankNum +
										'"/"' + contBoxNo + '"/"' + 7
								}));
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "Content-Type",
									value: this.fileTypeTankCSC
								}));
								this.getOwnerComponent().getModel().refreshSecurityToken();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "x-csrf-token",
									value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
								}));
								oFileUploader.setSendXHR(true);
								oFileUploader.upload();
							}
							if (this.tripStatus === "RD") {
								this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
									method: "POST",
									success: function(response) {
										MessageBox.success("Canvas selection details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idCSC").setEnabled(false);
												this.getView().byId("idCSCObservations").setEnabled(false);
												this.getView().byId("idCSCCorectiveMeasures").setEnabled(false);
												this.getView().byId("idCSCFileUpload").setEnabled(false);
												this.getView().byId("idCSCPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
							}
							if (this.tripStatus === "IP") {
								this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
									"',TripNumber='" +
									this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
									"',ContainerNo='" +
									tankNum + "')", payload, {
										method: "PUT",
										success: function(response) {
											MessageBox.success("Vehicle details have been updated successfully", {
												onClose: function() {
													this.readHeaderEntitySet();
													this.readInspectionEntitySetforTruckandTank();
													this.getView().byId("idCSC").setEnabled(false);
													this.getView().byId("idCSCObservations").setEnabled(false);
													this.getView().byId("idCSCCorectiveMeasures").setEnabled(false);
													this.getView().byId("idCSCFileUpload").setEnabled(false);
													this.getView().byId("idCSCPanel").setExpanded(false);
												}.bind(this)
											});
										}.bind(this),
										error: function(error) {
											MessageBox.warning("Error occurred while updating the data");
										}
									});
							}
						} else {
							if (this.tripStatus === "RD") {
								this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
									method: "POST",
									success: function(response) {
										MessageBox.success("Canvas selection details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idCSC").setEnabled(false);
												this.getView().byId("idCSCObservations").setEnabled(false);
												this.getView().byId("idCSCCorectiveMeasures").setEnabled(false);
												this.getView().byId("idCSCFileUpload").setEnabled(false);
												this.getView().byId("idCSCPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
							}
							if (this.tripStatus === "IP") {
								this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
									"',TripNumber='" +
									this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
									"',ContainerNo='" +
									tankNum + "')", payload, {
										method: "PUT",
										success: function(response) {
											MessageBox.success("Vehicle details have been updated successfully", {
												onClose: function() {
													this.readHeaderEntitySet();
													this.readInspectionEntitySetforTruckandTank();
													this.getView().byId("idCSC").setEnabled(false);
													this.getView().byId("idCSCObservations").setEnabled(false);
													this.getView().byId("idCSCCorectiveMeasures").setEnabled(false);
													this.getView().byId("idCSCFileUpload").setEnabled(false);
													this.getView().byId("idCSCPanel").setExpanded(false);
												}.bind(this)
											});
										}.bind(this),
										error: function(error) {
											MessageBox.warning("Error occurred while updating the data");
										}
									});
							}
						}
					} else {
						MessageBox.error("Please fill all the mandatory feilds");
					}
				}
				if (select) {
					if (this.fileNameTankCSC) {
						if (this.fileTypeTankCSC === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTankCSC + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									tankNum +
									'"/"' + contBoxNo + '"/"' + 7
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTankCSC
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							tankNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idCSC").setEnabled(false);
									this.getView().byId("idCSCObservations").setEnabled(false);
									this.getView().byId("idCSCCorectiveMeasures").setEnabled(false);
									this.getView().byId("idCSCFileUpload").setEnabled(false);
									this.getView().byId("idCSCPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
			if (FumigationInspIssue === 0 || FumigationInspIssue === 2) {
				payload = updatePayload;
				if (!select || select == undefined) {
					if (this.fileNameTankCSC) {
						if (this.fileTypeTankCSC === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTankCSC + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									tankNum +
									'"/"' + contBoxNo + '"/"' + 7
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTankCSC
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();
						}
						if (this.tripStatus === "RD") {
							this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
								method: "POST",
								success: function(response) {
									MessageBox.success("Canvas selection details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idCSC").setEnabled(false);
											this.getView().byId("idCSCObservations").setEnabled(false);
											this.getView().byId("idCSCCorectiveMeasures").setEnabled(false);
											this.getView().byId("idCSCFileUpload").setEnabled(false);
											this.getView().byId("idCSCPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
						}
						if (this.tripStatus === "IP") {
							this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
								"',TripNumber='" +
								this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
								"',ContainerNo='" +
								tankNum + "')", payload, {
									method: "PUT",
									success: function(response) {
										MessageBox.success("Vehicle details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idCSC").setEnabled(false);
												this.getView().byId("idCSCObservations").setEnabled(false);
												this.getView().byId("idCSCCorectiveMeasures").setEnabled(false);
												this.getView().byId("idCSCFileUpload").setEnabled(false);
												this.getView().byId("idCSCPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
						}
					} else {
						if (this.tripStatus === "RD") {
							this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
								method: "POST",
								success: function(response) {
									MessageBox.success("Canvas selection details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idCSC").setEnabled(false);
											this.getView().byId("idCSCObservations").setEnabled(false);
											this.getView().byId("idCSCCorectiveMeasures").setEnabled(false);
											this.getView().byId("idCSCFileUpload").setEnabled(false);
											this.getView().byId("idCSCPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
						}
						if (this.tripStatus === "IP") {
							this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
								"',TripNumber='" +
								this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
								"',ContainerNo='" +
								tankNum + "')", payload, {
									method: "PUT",
									success: function(response) {
										MessageBox.success("Vehicle details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idCSC").setEnabled(false);
												this.getView().byId("idCSCObservations").setEnabled(false);
												this.getView().byId("idCSCCorectiveMeasures").setEnabled(false);
												this.getView().byId("idCSCFileUpload").setEnabled(false);
												this.getView().byId("idCSCPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
						}
					}
				}
				if (select) {
					if (this.fileNameTankCSC) {
						if (this.fileTypeTankCSC === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTankCSC + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									tankNum +
									'"/"' + contBoxNo + '"/"' + 7
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTankCSC
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							tankNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idCSC").setEnabled(false);
									this.getView().byId("idCSCObservations").setEnabled(false);
									this.getView().byId("idCSCCorectiveMeasures").setEnabled(false);
									this.getView().byId("idCSCFileUpload").setEnabled(false);
									this.getView().byId("idCSCPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
		},
		onTankCSCEdit: function() {
			var radio = this.getView().byId("idCSC").getSelectedIndex();
			if (radio === 0 || radio === 2) {
				this.getView().byId("idCSC").setEnabled(true);
				this.getView().byId("idCSCFileUpload").setEnabled(true);
			}
			if (radio === 1) {
				this.getView().byId("idCSC").setEnabled(true);
				this.getView().byId("idCSCObservations").setEnabled(true);
				this.getView().byId("idCSCCorectiveMeasures").setEnabled(true);
				this.getView().byId("idCSCFileUpload").setEnabled(true);
			}
		},
		onTankRubberSealSave: function() {
			var ContWeightLodingIssue = this.getView().byId("idTankerRS").getSelectedIndex();
			var ContWeightObservations = this.getView().byId("idTankerRSObservations").getValue();
			var ContWeightCorrMeasure = this.getView().byId("idTankerRSCorectiveMeasures").getValue();
			var check = true;
			var items = this.getView().getModel("InspectionModel").getData();
			var select = items.ContWeightApprNeed;
			var oFileUploader = this.getView().byId("idTankerRSFileUpload");
			var tankNum = this.getView().getModel("TripModel").getData().ContainerNo;
			var contBoxNo = "000";
			var payload;
			var createPayload = {
				"ContWeightLodingIssue": ContWeightLodingIssue,
				"ContWeightObservations": ContWeightObservations,
				"ContWeightCorrMeasure": ContWeightCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": tankNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Tank lorry",
				"ContWtChk": check
			};
			var updatePayload = {
				"ContWeightLodingIssue": ContWeightLodingIssue,
				"ContWeightObservations": ContWeightObservations,
				"ContWeightCorrMeasure": ContWeightCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": tankNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Tank lorry",
				"ContWtChk": check
			};
			if (ContWeightLodingIssue === 1) {
				payload = createPayload;
				if (!select || select == undefined) {
					if (payload.ContWeightObservations !== "" && payload.ContWeightCorrMeasure !== "") {
						if (this.fileNameTankRubberSeal) {
							if (this.fileTypeTankRubberSeal === "image/jpeg") {
								oFileUploader.destroyHeaderParameters();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "SLUG",
									value: this.fileNameTankRubberSeal + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
										'"/"' +
										tankNum + '"/"' + contBoxNo + '"/"' + 8
								}));
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "Content-Type",
									value: this.fileTypeTankRubberSeal
								}));
								this.getOwnerComponent().getModel().refreshSecurityToken();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "x-csrf-token",
									value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
								}));
								oFileUploader.setSendXHR(true);
								oFileUploader.upload();
							} else {
								MessageBox.error("File format should be JPG");
							}
						}
						if (this.tripStatus === "RD") {
							this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
								method: "POST",
								success: function(response) {
									MessageBox.success("Canvas selection details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idTankerRS").setEnabled(false);
											this.getView().byId("idTankerRSObservations").setEnabled(false);
											this.getView().byId("idTankerRSCorectiveMeasures").setEnabled(false);
											this.getView().byId("idTankerRSFileUpload").setEnabled(false);
											this.getView().byId("idTankerRSPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
						}
						if (this.tripStatus === "IP") {
							this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
								"',TripNumber='" +
								this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
								"',ContainerNo='" +
								tankNum + "')", payload, {
									method: "PUT",
									success: function(response) {
										MessageBox.success("Vehicle details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idTankerRS").setEnabled(false);
												this.getView().byId("idTankerRSObservations").setEnabled(false);
												this.getView().byId("idTankerRSCorectiveMeasures").setEnabled(false);
												this.getView().byId("idTankerRSFileUpload").setEnabled(false);
												this.getView().byId("idTankerRSPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
						}
					} else {
						MessageBox.error("Please fill all the mandatory feilds");
					}
				}
				if (select) {
					if (this.fileNameTankRubberSeal) {
						if (this.fileTypeTankRubberSeal === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTankRubberSeal + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
									'"/"' +
									tankNum + '"/"' + contBoxNo + '"/"' + 8
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTankRubberSeal
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							tankNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idTankerRS").setEnabled(false);
									this.getView().byId("idTankerRSObservations").setEnabled(false);
									this.getView().byId("idTankerRSCorectiveMeasures").setEnabled(false);
									this.getView().byId("idTankerRSFileUpload").setEnabled(false);
									this.getView().byId("idTankerRSPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
			if (ContWeightLodingIssue === 0) {
				payload = updatePayload;
				if (!select || select == undefined) {
					if (this.fileNameTankRubberSeal) {
						if (this.fileTypeTankRubberSeal === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTankRubberSeal + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
									'"/"' +
									tankNum + '"/"' + contBoxNo + '"/"' + 8
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTankRubberSeal
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();
						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "RD") {
						this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
							method: "POST",
							success: function(response) {
								MessageBox.success("Canvas selection details have been updated successfully", {
									onClose: function() {
										this.readHeaderEntitySet();
										this.readInspectionEntitySetforTruckandTank();
										this.getView().byId("idTankerRS").setEnabled(false);
										this.getView().byId("idTankerRSObservations").setEnabled(false);
										this.getView().byId("idTankerRSCorectiveMeasures").setEnabled(false);
										this.getView().byId("idTankerRSFileUpload").setEnabled(false);
										this.getView().byId("idTankerRSPanel").setExpanded(false);
									}.bind(this)
								});
							}.bind(this),
							error: function(error) {
								MessageBox.warning("Error occurred while updating the data");
							}
						});
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							tankNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									MessageBox.success("Vehicle details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idTankerRS").setEnabled(false);
											this.getView().byId("idTankerRSObservations").setEnabled(false);
											this.getView().byId("idTankerRSCorectiveMeasures").setEnabled(false);
											this.getView().byId("idTankerRSFileUpload").setEnabled(false);
											this.getView().byId("idTankerRSPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
				if (select) {
					if (this.fileNameTankRubberSeal) {
						if (this.fileTypeTankRubberSeal === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTankRubberSeal + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
									'"/"' +
									tankNum + '"/"' + contBoxNo + '"/"' + 8
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTankRubberSeal
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();
						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							tankNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idTankerRS").setEnabled(false);
									this.getView().byId("idTankerRSObservations").setEnabled(false);
									this.getView().byId("idTankerRSCorectiveMeasures").setEnabled(false);
									this.getView().byId("idTankerRSFileUpload").setEnabled(false);
									this.getView().byId("idTankerRSPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
			if (ContWeightLodingIssue === 2) {
				payload = updatePayload;
				if (!select || select == undefined) {
					if (this.fileNameTankRubberSeal) {
						if (this.fileTypeTankRubberSeal === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTankRubberSeal + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
									'"/"' +
									tankNum + '"/"' + contBoxNo + '"/"' + 8
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTankRubberSeal
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();
						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "RD") {
						this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
							method: "POST",
							success: function(response) {
								MessageBox.success("Canvas selection details have been updated successfully", {
									onClose: function() {
										this.readHeaderEntitySet();
										this.readInspectionEntitySetforTruckandTank();
										this.getView().byId("idTankerRS").setEnabled(false);
										this.getView().byId("idTankerRSObservations").setEnabled(false);
										this.getView().byId("idTankerRSCorectiveMeasures").setEnabled(false);
										this.getView().byId("idTankerRSFileUpload").setEnabled(false);
										this.getView().byId("idTankerRSPanel").setExpanded(false);
									}.bind(this)
								});
							}.bind(this),
							error: function(error) {
								MessageBox.warning("Error occurred while updating the data");
							}
						});
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							tankNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									MessageBox.success("Vehicle details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idTankerRS").setEnabled(false);
											this.getView().byId("idTankerRSObservations").setEnabled(false);
											this.getView().byId("idTankerRSCorectiveMeasures").setEnabled(false);
											this.getView().byId("idTankerRSFileUpload").setEnabled(false);
											this.getView().byId("idTankerRSPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
				if (select) {
					if (this.fileNameTankRubberSeal) {
						if (this.fileTypeTankRubberSeal === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTankRubberSeal + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
									'"/"' +
									tankNum + '"/"' + contBoxNo + '"/"' + 8
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTankRubberSeal
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();
						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							tankNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idTankerRS").setEnabled(false);
									this.getView().byId("idTankerRSObservations").setEnabled(false);
									this.getView().byId("idTankerRSCorectiveMeasures").setEnabled(false);
									this.getView().byId("idTankerRSFileUpload").setEnabled(false);
									this.getView().byId("idTankerRSPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
		},
		onTankRubberSealEdit: function() {
			var radio = this.getView().byId("idTankerRS").getSelectedIndex();
			if (radio === 0 || radio === 2) {
				this.getView().byId("idTankerRS").setEnabled(true);
				this.getView().byId("idTankerRSFileUpload").setEnabled(true);
			}
			if (radio === 1) {
				this.getView().byId("idTankerRS").setEnabled(true);
				this.getView().byId("idTankerRSObservations").setEnabled(true);
				this.getView().byId("idTankerRSCorectiveMeasures").setEnabled(true);
				this.getView().byId("idTankerRSFileUpload").setEnabled(true);
			}
		},
		onTankWeighBridgeSave: function() {
			var ContReadyIssue = this.getView().byId("idTankWB").getSelectedIndex();
			var ContReadyObservations = this.getView().byId("idTankWBObservations").getValue();
			var ContReadyCorrMeasure = this.getView().byId("idTankWBCorectiveMeasures").getValue();
			var check = true;
			var items = this.getView().getModel("InspectionModel").getData();
			var select = items.ContReadyChk;
			var oFileUploader = this.getView().byId("idTankWBFileUpload");
			var tankNum = this.getView().getModel("TripModel").getData().ContainerNo;
			var contBoxNo = "000";
			var payload;
			var createPayload = {
				"ContReadyIssue": ContReadyIssue,
				"ContReadyObservations": ContReadyObservations,
				"ContReadyCorrMeasure": ContReadyCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": tankNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Tank lorry",
				"ContReadyChk": check
			};
			var updatePayload = {
				"ContReadyIssue": ContReadyIssue,
				"ContReadyObservations": ContReadyObservations,
				"ContReadyCorrMeasure": ContReadyCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": tankNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Tank lorry",
				"ContReadyChk": check
			};
			if (ContReadyIssue === 1) {
				payload = createPayload;
				if (!select || select == undefined) {
					if (payload.ContReadyObservations !== "" && payload.ContReadyCorrMeasure !== "") {
						if (this.fileNameTankWeighBridge) {
							if (this.fileTypeTankWeighBridge === "image/jpeg") {
								oFileUploader.destroyHeaderParameters();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "SLUG",
									value: this.fileNameTankWeighBridge + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
										'"/"' +
										tankNum + '"/"' + contBoxNo + '"/"' + 10
								}));
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "Content-Type",
									value: this.fileTypeTankWeighBridge
								}));
								this.getOwnerComponent().getModel().refreshSecurityToken();
								oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
									name: "x-csrf-token",
									value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
								}));
								oFileUploader.setSendXHR(true);
								oFileUploader.upload();

							} else {
								MessageBox.error("File format should be JPG");
							}

							if (this.tripStatus === "RD") {
								this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
									method: "POST",
									success: function(response) {
										MessageBox.success("Canvas selection details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idTankWB").setEnabled(false);
												this.getView().byId("idTankWBObservations").setEnabled(false);
												this.getView().byId("idTankWBCorectiveMeasures").setEnabled(false);
												this.getView().byId("idTankWBFileUpload").setEnabled(false);
												this.getView().byId("idTankWBPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
							}
							if (this.tripStatus === "IP") {
								this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
									"',TripNumber='" +
									this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
									"',ContainerNo='" +
									tankNum + "')", payload, {
										method: "PUT",
										success: function(response) {
											MessageBox.success("Vehicle details have been updated successfully", {
												onClose: function() {
													this.readHeaderEntitySet();
													this.readInspectionEntitySetforTruckandTank();
													this.getView().byId("idTankWB").setEnabled(false);
													this.getView().byId("idTankWBObservations").setEnabled(false);
													this.getView().byId("idTankWBCorectiveMeasures").setEnabled(false);
													this.getView().byId("idTankWBFileUpload").setEnabled(false);
													this.getView().byId("idTankWBPanel").setExpanded(false);
												}.bind(this)
											});
										}.bind(this),
										error: function(error) {
											MessageBox.warning("Error occurred while updating the data");
										}
									});
							}
						} else {
							if (this.tripStatus === "RD") {
								this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
									method: "POST",
									success: function(response) {
										MessageBox.success("Canvas selection details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idTankWB").setEnabled(false);
												this.getView().byId("idTankWBObservations").setEnabled(false);
												this.getView().byId("idTankWBCorectiveMeasures").setEnabled(false);
												this.getView().byId("idTankWBFileUpload").setEnabled(false);
												this.getView().byId("idTankWBPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
							}
							if (this.tripStatus === "IP") {
								this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
									"',TripNumber='" +
									this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
									"',ContainerNo='" +
									tankNum + "')", payload, {
										method: "PUT",
										success: function(response) {
											MessageBox.success("Vehicle details have been updated successfully", {
												onClose: function() {
													this.readHeaderEntitySet();
													this.readInspectionEntitySetforTruckandTank();
													this.getView().byId("idTankWB").setEnabled(false);
													this.getView().byId("idTankWBObservations").setEnabled(false);
													this.getView().byId("idTankWBCorectiveMeasures").setEnabled(false);
													this.getView().byId("idTankWBFileUpload").setEnabled(false);
													this.getView().byId("idTankWBPanel").setExpanded(false);
												}.bind(this)
											});
										}.bind(this),
										error: function(error) {
											MessageBox.warning("Error occurred while updating the data");
										}
									});
							}
						}
					} else {
						MessageBox.error("Please fill all the mandatory feilds");
					}
				}
				if (select) {
					if (this.fileNameTankWeighBridge) {
						if (this.fileTypeTankWeighBridge === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTankWeighBridge + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
									'"/"' +
									tankNum + '"/"' + contBoxNo + '"/"' + 10
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTankWeighBridge
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							tankNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idTankWB").setEnabled(false);
									this.getView().byId("idTankWBObservations").setEnabled(false);
									this.getView().byId("idTankWBCorectiveMeasures").setEnabled(false);
									this.getView().byId("idTankWBFileUpload").setEnabled(false);
									this.getView().byId("idTankWBPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
			if (ContReadyIssue === 0 || ContReadyIssue === 2) {
				payload = updatePayload;
				if (!select || select == undefined) {
					if (this.fileNameTankWeighBridge) {
						if (this.fileTypeTankWeighBridge === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTankWeighBridge + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
									'"/"' +
									tankNum + '"/"' + contBoxNo + '"/"' + 10
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTankWeighBridge
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}

						if (this.tripStatus === "RD") {
							this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
								method: "POST",
								success: function(response) {
									MessageBox.success("Canvas selection details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idTankWB").setEnabled(false);
											this.getView().byId("idTankWBObservations").setEnabled(false);
											this.getView().byId("idTankWBCorectiveMeasures").setEnabled(false);
											this.getView().byId("idTankWBFileUpload").setEnabled(false);
											this.getView().byId("idTankWBPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
						}
						if (this.tripStatus === "IP") {
							this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
								"',TripNumber='" +
								this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
								"',ContainerNo='" +
								tankNum + "')", payload, {
									method: "PUT",
									success: function(response) {
										MessageBox.success("Vehicle details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idTankWB").setEnabled(false);
												this.getView().byId("idTankWBObservations").setEnabled(false);
												this.getView().byId("idTankWBCorectiveMeasures").setEnabled(false);
												this.getView().byId("idTankWBFileUpload").setEnabled(false);
												this.getView().byId("idTankWBPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
						}
					} else {
						if (this.tripStatus === "RD") {
							this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
								method: "POST",
								success: function(response) {
									MessageBox.success("Canvas selection details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idTankWB").setEnabled(false);
											this.getView().byId("idTankWBObservations").setEnabled(false);
											this.getView().byId("idTankWBCorectiveMeasures").setEnabled(false);
											this.getView().byId("idTankWBFileUpload").setEnabled(false);
											this.getView().byId("idTankWBPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
						}
						if (this.tripStatus === "IP") {
							this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
								"',TripNumber='" +
								this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
								"',ContainerNo='" +
								tankNum + "')", payload, {
									method: "PUT",
									success: function(response) {
										MessageBox.success("Vehicle details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idTankWB").setEnabled(false);
												this.getView().byId("idTankWBObservations").setEnabled(false);
												this.getView().byId("idTankWBCorectiveMeasures").setEnabled(false);
												this.getView().byId("idTankWBFileUpload").setEnabled(false);
												this.getView().byId("idTankWBPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
						}
					}
				}
				if (select) {
					if (this.fileNameTankWeighBridge) {
						if (this.fileTypeTankWeighBridge === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileNameTankWeighBridge + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
									'"/"' +
									tankNum + '"/"' + contBoxNo + '"/"' + 10
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileTypeTankWeighBridge
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							tankNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idTankWB").setEnabled(false);
									this.getView().byId("idTankWBObservations").setEnabled(false);
									this.getView().byId("idTankWBCorectiveMeasures").setEnabled(false);
									this.getView().byId("idTankWBFileUpload").setEnabled(false);
									this.getView().byId("idTankWBPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
		},
		onTankWeighBridgeEdit: function() {
			var radio = this.getView().byId("idTankWB").getSelectedIndex();
			if (radio === 0 || radio === 2) {
				this.getView().byId("idTankWB").setEnabled(true);
				this.getView().byId("idTankWBFileUpload").setEnabled(true);
			}
			if (radio === 1) {
				this.getView().byId("idTankWB").setEnabled(true);
				this.getView().byId("idTankWBObservations").setEnabled(true);
				this.getView().byId("idTankWBCorectiveMeasures").setEnabled(true);
				this.getView().byId("idTankWBFileUpload").setEnabled(true);
			}
		},
		onTankStuffingEdit: function() {
			var radio = this.getView().byId("idTankStuffing").getSelectedIndex();
			if (radio === 0 || radio === 2) {
				this.getView().byId("idTankStuffing").setEnabled(true);
				this.getView().byId("idTankWBFileUpload").setEnabled(true);
			}
			if (radio === 1) {
				this.getView().byId("idTankStuffing").setEnabled(true);
				this.getView().byId("idTankStuffingObservations").setEnabled(true);
				this.getView().byId("idTankStuffingCorectiveMeasures").setEnabled(true);
				this.getView().byId("idTankWBFileUpload").setEnabled(true);
			}
		},
		onTankStuffingSave: function() {
			var FumigationDoneIssue = this.getView().byId("idTankStuffing").getSelectedIndex();
			var FumigationDoneObservations = this.getView().byId("idTankStuffingObservations").getValue();
			var FumigationDoneCorrMeasure = this.getView().byId("idTankStuffingCorectiveMeasures").getValue();
			var check = true;
			var items = this.getView().getModel("InspectionModel").getData();
			var select = items.FumigationDoneChk;
			var oFileUploader = this.getView().byId("idTankStuffingFileUpload");
			var tankNum = this.getView().getModel("TripModel").getData().ContainerNo;
			var contBoxNo = "000";
			var payload;
			var createPayload = {
				"FumigationDoneIssue": FumigationDoneIssue,
				"FumigationDoneObservations": FumigationDoneObservations,
				"FumigationDoneCorrMeasure": FumigationDoneCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": tankNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Tank lorry",
				"FumigationDoneChk": check
			};
			var updatePayload = {
				"FumigationDoneIssue": FumigationDoneIssue,
				"FumigationDoneObservations": FumigationDoneObservations,
				"FumigationDoneCorrMeasure": FumigationDoneCorrMeasure,
				"InspectionStatus": "IP",
				"TruckNumber": this.truckNumber,
				"TripNumber": this.tripNumber,
				"ContainerBoxNo": contBoxNo,
				"ContainerNo": tankNum,
				"VehicleType": this.VehicleType,
				"VehicleTypeDesc": "Tank lorry",
				"FumigationDoneChk": check
			};
			if (FumigationDoneIssue === 1) {
				payload = createPayload;
				if (!select || select == undefined) {
					if (payload.FumigationDoneObservations !== "" && payload.FumigationDoneCorrMeasure !== "") {
						if (this.fileStuffingSize) {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileStuffingName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									tankNum + '"/"' + contBoxNo + '"/"' + 12
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileStuffingType
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

							if (this.tripStatus === "RD") {
								this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
									method: "POST",
									success: function(response) {
										MessageBox.success("Canvas selection details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idTankStuffing").setEnabled(false);
												this.getView().byId("idTankStuffingObservations").setEnabled(false);
												this.getView().byId("idTankStuffingCorectiveMeasures").setEnabled(false);
												this.getView().byId("idTankStuffingFileUpload").setEnabled(false);
												this.getView().byId("idTankStuffingPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
							}
							if (this.tripStatus === "IP") {
								this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
									"',TripNumber='" +
									this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
									"',ContainerNo='" +
									tankNum + "')", payload, {
										method: "PUT",
										success: function(response) {
											MessageBox.success("Vehicle details have been updated successfully", {
												onClose: function() {
													this.readHeaderEntitySet();
													this.readInspectionEntitySetforTruckandTank();
													this.getView().byId("idTankStuffing").setEnabled(false);
													this.getView().byId("idTankStuffingObservations").setEnabled(false);
													this.getView().byId("idTankStuffingCorectiveMeasures").setEnabled(false);
													this.getView().byId("idTankStuffingFileUpload").setEnabled(false);
													this.getView().byId("idTankStuffingPanel").setExpanded(false);
												}.bind(this)
											});
										}.bind(this),
										error: function(error) {
											MessageBox.warning("Error occurred while updating the data");
										}
									});
							}
						} else {
							if (this.tripStatus === "RD") {
								this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
									method: "POST",
									success: function(response) {
										MessageBox.success("Canvas selection details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idTankStuffing").setEnabled(false);
												this.getView().byId("idTankStuffingObservations").setEnabled(false);
												this.getView().byId("idTankStuffingCorectiveMeasures").setEnabled(false);
												this.getView().byId("idTankStuffingFileUpload").setEnabled(false);
												this.getView().byId("idTankStuffingPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
							}
							if (this.tripStatus === "IP") {
								this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
									"',TripNumber='" +
									this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
									"',ContainerNo='" +
									tankNum + "')", payload, {
										method: "PUT",
										success: function(response) {
											MessageBox.success("Vehicle details have been updated successfully", {
												onClose: function() {
													this.readHeaderEntitySet();
													this.readInspectionEntitySetforTruckandTank();
													this.getView().byId("idTankStuffing").setEnabled(false);
													this.getView().byId("idTankStuffingObservations").setEnabled(false);
													this.getView().byId("idTankStuffingCorectiveMeasures").setEnabled(false);
													this.getView().byId("idTankStuffingFileUpload").setEnabled(false);
													this.getView().byId("idTankStuffingPanel").setExpanded(false);
												}.bind(this)
											});
										}.bind(this),
										error: function(error) {
											MessageBox.warning("Error occurred while updating the data");
										}
									});
							}
						}
					} else {
						MessageBox.error("Please fill all the mandatory feilds");
					}
				}
				if (select) {
					if (this.fileStuffingName) {
						if (this.fileStuffingType === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileStuffingName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									tankNum + '"/"' + contBoxNo + '"/"' + 12
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileStuffingType
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							tankNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idTankStuffing").setEnabled(false);
									this.getView().byId("idTankStuffingObservations").setEnabled(false);
									this.getView().byId("idTankStuffingCorectiveMeasures").setEnabled(false);
									this.getView().byId("idTankStuffingFileUpload").setEnabled(false);
									this.getView().byId("idTankStuffingPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
			if (FumigationDoneIssue === 0 || FumigationDoneIssue === 2) {
				payload = updatePayload;
				if (!select || select == undefined) {
					if (this.fileStuffingName) {
						if (this.fileStuffingType === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileStuffingName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									tankNum + '"/"' + contBoxNo + '"/"' + 12
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileStuffingType
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
						if (this.tripStatus === "RD") {
							this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
								method: "POST",
								success: function(response) {
									MessageBox.success("Canvas selection details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idTankStuffing").setEnabled(false);
											this.getView().byId("idTankStuffingObservations").setEnabled(false);
											this.getView().byId("idTankStuffingCorectiveMeasures").setEnabled(false);
											this.getView().byId("idTankStuffingFileUpload").setEnabled(false);
											this.getView().byId("idTankStuffingPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
						}
						if (this.tripStatus === "IP") {
							this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
								"',TripNumber='" +
								this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
								"',ContainerNo='" +
								tankNum + "')", payload, {
									method: "PUT",
									success: function(response) {
										MessageBox.success("Vehicle details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idTankStuffing").setEnabled(false);
												this.getView().byId("idTankStuffingObservations").setEnabled(false);
												this.getView().byId("idTankStuffingCorectiveMeasures").setEnabled(false);
												this.getView().byId("idTankStuffingFileUpload").setEnabled(false);
												this.getView().byId("idTankStuffingPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
						}
					} else {
						if (this.tripStatus === "RD") {
							this.getOwnerComponent().getModel().create("/PLMS_Vehicle_InspectionSet", payload, {
								method: "POST",
								success: function(response) {
									MessageBox.success("Canvas selection details have been updated successfully", {
										onClose: function() {
											this.readHeaderEntitySet();
											this.readInspectionEntitySetforTruckandTank();
											this.getView().byId("idTankStuffing").setEnabled(false);
											this.getView().byId("idTankStuffingObservations").setEnabled(false);
											this.getView().byId("idTankStuffingCorectiveMeasures").setEnabled(false);
											this.getView().byId("idTankStuffingFileUpload").setEnabled(false);
											this.getView().byId("idTankStuffingPanel").setExpanded(false);
										}.bind(this)
									});
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
						}
						if (this.tripStatus === "IP") {
							this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
								"',TripNumber='" +
								this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
								"',ContainerNo='" +
								tankNum + "')", payload, {
									method: "PUT",
									success: function(response) {
										MessageBox.success("Vehicle details have been updated successfully", {
											onClose: function() {
												this.readHeaderEntitySet();
												this.readInspectionEntitySetforTruckandTank();
												this.getView().byId("idTankStuffing").setEnabled(false);
												this.getView().byId("idTankStuffingObservations").setEnabled(false);
												this.getView().byId("idTankStuffingCorectiveMeasures").setEnabled(false);
												this.getView().byId("idTankStuffingFileUpload").setEnabled(false);
												this.getView().byId("idTankStuffingPanel").setExpanded(false);
											}.bind(this)
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the data");
									}
								});
						}
					}
				}
				if (select) {
					if (this.fileStuffingName) {
						if (this.fileStuffingType === "image/jpeg") {
							oFileUploader.destroyHeaderParameters();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "SLUG",
								value: this.fileStuffingName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
									tankNum + '"/"' + contBoxNo + '"/"' + 12
							}));
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "Content-Type",
								value: this.fileStuffingType
							}));
							this.getOwnerComponent().getModel().refreshSecurityToken();
							oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
								name: "x-csrf-token",
								value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
							}));
							oFileUploader.setSendXHR(true);
							oFileUploader.upload();

						} else {
							MessageBox.error("File format should be JPG");
						}
					}
					if (this.tripStatus === "IP") {
						this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber + "',TripNumber='" +
							this.tripNumber + "',ContainerBoxNo='" + contBoxNo +
							"',ContainerNo='" +
							tankNum + "')", payload, {
								method: "PUT",
								success: function(response) {
									this.readHeaderEntitySet();
									this.readInspectionEntitySetforTruckandTank();
									this.getView().byId("idTankStuffing").setEnabled(false);
									this.getView().byId("idTankStuffingObservations").setEnabled(false);
									this.getView().byId("idTankStuffingCorectiveMeasures").setEnabled(false);
									this.getView().byId("idTankStuffingFileUpload").setEnabled(false);
									this.getView().byId("idTankStuffingPanel").setExpanded(false);
								}.bind(this),
								error: function(error) {
									MessageBox.warning("Error occurred while updating the data");
								}
							});
					}
				}
			}
		},
		handleTankStuffingSave: function(oEvent) {
			this.fileStuffingName = oEvent.getParameter("files")[0].name;
			this.fileStuffingType = oEvent.getParameter("files")[0].type;
			this.fileStuffingSize = oEvent.getParameter("files")[0].size;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idTankStuffingImage").setSrc(path);
			}
		},
		handleTruckCanvasImageChange: function(oEvent) {
			this.fileNameTruckCanvas = oEvent.getParameter("files")[0].name;
			this.fileTypeTruckCanvas = oEvent.getParameter("files")[0].type;
			this.fileSizeTruckCanvas = oEvent.getParameter("files")[0].size;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idTruckCanvasCheckImage").setSrc(path);
			}
		},
		handleTruckRopeImageChange: function(oEvent) {
			this.fileNameTruckRope = oEvent.getParameter("files")[0].name;
			this.fileTypeTruckRope = oEvent.getParameter("files")[0].type;
			this.fileSizeTruckRope = oEvent.getParameter("files")[0].size;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idRopeImage").setSrc(path);
			}
		},
		handleTruckFloorWalls: function(oEvent) {
			this.fileNameTruckFloorWalls = oEvent.getParameter("files")[0].name;
			this.fileTypeTruckFloorWalls = oEvent.getParameter("files")[0].type;
			this.fileSizeTruckFloorWalls = oEvent.getParameter("files")[0].size;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idFWImage").setSrc(path);
			}
		},
		handleTruckVehicle: function(oEvent) {
			this.fileNameTruckVehicle = oEvent.getParameter("files")[0].name;
			this.fileTypeTruckVehicle = oEvent.getParameter("files")[0].type;
			this.fileSizeTruckVehicle = oEvent.getParameter("files")[0].size;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idVehicleImage").setSrc(path);
			}
		},
		handleTruckCleanSave: function(oEvent) {
			this.fileNameTruckCleanSave = oEvent.getParameter("files")[0].name;
			this.fileTypeTruckCleanSave = oEvent.getParameter("files")[0].type;
			this.fileSizeTruckCleanSave = oEvent.getParameter("files")[0].size;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idVehicleCleanImage").setSrc(path);
			}
		},
		handleTruckBodySave: function(oEvent) {
			this.fileNameTruckBodySave = oEvent.getParameter("files")[0].name;
			this.fileTypeTruckBodySave = oEvent.getParameter("files")[0].type;
			this.fileSizeTruckBodySave = oEvent.getParameter("files")[0].size;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idBodyImage").setSrc(path);
			}
		},
		handleTruckCanvasAvailSave: function(oEvent) {
			this.fileNameTruckCanvasAvail = oEvent.getParameter("files")[0].name;
			this.fileTypeTruckCanvasAvail = oEvent.getParameter("files")[0].type;
			this.fileSizeTruckCanvasAvail = oEvent.getParameter("files")[0].size;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idAvailImage").setSrc(path);
			}
		},
		handleTruckLoadSave: function(oEvent) {
			this.fileNameTruckLoad = oEvent.getParameter("files")[0].name;
			this.fileTypeTruckLoad = oEvent.getParameter("files")[0].type;
			this.fileSizeTruckLoad = oEvent.getParameter("files")[0].size;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idLoadImage").setSrc(path);
			}
		},
		handleTankCleanSave: function(oEvent) {
			this.fileNameTankClean = oEvent.getParameter("files")[0].name;
			this.fileTypeTankClean = oEvent.getParameter("files")[0].type;
			this.fileSizeTankClean = oEvent.getParameter("files")[0].size;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idTankerCleanImage").setSrc(path);
			}
		},
		handleTankBottomSealSave: function(oEvent) {
			this.fileNameTankBottomSeal = oEvent.getParameter("files")[0].name;
			this.fileTypeTankBottomSeal = oEvent.getParameter("files")[0].type;
			this.fileSizeTankBottomSeal = oEvent.getParameter("files")[0].size;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idBottomSealImage").setSrc(path);
			}
		},
		handleTankForeignSave: function(oEvent) {
			this.fileNameTankForeign = oEvent.getParameter("files")[0].name;
			this.fileTypeTankForeign = oEvent.getParameter("files")[0].type;
			this.fileSizeTankForeign = oEvent.getParameter("files")[0].size;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idForeignImage").setSrc(path);
			}
		},
		handleTankCSCSave: function(oEvent) {
			this.fileNameTankCSC = oEvent.getParameter("files")[0].name;
			this.fileTypeTankCSC = oEvent.getParameter("files")[0].type;
			this.fileSizeTankCSC = oEvent.getParameter("files")[0].size;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idCSCImage").setSrc(path);
			}
		},
		handleTankRubberSealSave: function(oEvent) {
			this.fileNameTankRubberSeal = oEvent.getParameter("files")[0].name;
			this.fileTypeTankRubberSeal = oEvent.getParameter("files")[0].type;
			this.fileSizeTankRubberSeal = oEvent.getParameter("files")[0].size;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idTankerRSImage").setSrc(path);
			}
		},
		handleTankWeighBridgeSave: function(oEvent) {
			this.fileNameTankWeighBridge = oEvent.getParameter("files")[0].name;
			this.fileTypeTankWeighBridge = oEvent.getParameter("files")[0].type;
			this.fileSizeTankWeighBridge = oEvent.getParameter("files")[0].size;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idTankWBImage").setSrc(path);
			}
		},
		onSaveMultiReportDetails: function(oEvent) {
			var items = this.getView().getModel("TripOBDModel").getProperty("/Items");
			var tableItems = this.getView().byId("idMultiReportTable").getItems();
			var drName = this.getView().byId("idDriverName").getValue();
			var reg = /[a-zA-Z]/g;
			var regExp = /^[6-9]\d{9}$/;
			var regExpSpecial = /[-’/`~!#*$@_%+=.,^&(){}[\]|;:”<>?\\]/g;

			if (drName.length > 0 && reg.test(drName)) {
				if (!regExpSpecial.test(drName)) {
					var drCtNo = this.getView().byId("idDriverContact").getValue();
					if (drCtNo.length > 0 && drCtNo.length === 10 && !isNaN(drCtNo) && regExp.test(drCtNo)) {
						var drLic = this.getView().byId("idDriverLicense").getValue();
						var drLicLen = drLic.length;
						if (drLicLen > 0 && drLic !== "") {
							if (drLicLen <= 20) {
								var weightReq = this.getView().byId("idWeighmentCheckRadioGroup").getSelectedIndex();
								var lrEntered = true;

								// Check if LR number is entered for all rows
								for (var qq = 0; qq < tableItems.length; qq++) {
									if (tableItems[qq].getCells()[1].getValue() === "") {
										lrEntered = false;
										break;
									}
								}

								if (lrEntered) {
									var contNo, vehTypeDesc;
									if (this.getView().byId("idVehicleType").getText() === "Truck") {
										vehTypeDesc = "Truck";
										contNo = this.getView().byId("idTruckNumber").getValue();
									}
									if (this.getView().byId("idVehicleType").getText() === "Tank lorry") {
										vehTypeDesc = "Tank lorry";
										contNo = this.getView().byId("idTankerNumber").getValue();
									}
									if (this.getView().byId("idVehicleType").getText() === "Container+Truck") {
										vehTypeDesc = "Container+Truck";
									}

									var createPayload, updatePayload, createContainerPayload, updateContainerPayload;

									// Here, we check if a container is selected to trigger create call
									if (this.vehicleType === "YB16") {
										var contTableId = this.getView().byId("idContainerNumber").getItems();
										var contTableLen = contTableId.length;
										var noOfSelectedCont = 0;

										// Check for selected containers
										for (var gg = 0; gg < contTableLen; gg++) {
											if (contTableId[gg].getCells()[2].getSelected()) {
												noOfSelectedCont++;
											}
										}

										if (noOfSelectedCont > 0) {
											if (noOfSelectedCont === 1) {
												// Trigger create call if container is selected and the trip number is not set
												if (this.tripNumber === "0000000000" || !this.tripNumber || this.getView().getModel("TripModel").setProperty("/EditMode", true)) {
													var aCreateContainerpayload = [];
													for (var i = 0; i < items.length; i++) {
														createContainerPayload = {
															"ObdNumber": tableItems[i].getCells()[0].getText(),
															"TruckNumber": this.truckNumber,
															"TripStatus": "RD",
															"LrNumber": (items[i].LrNumber).toString().toUpperCase(),
															"LrDate": this.resolveTimeDifference(tableItems[i].getCells()[2].getDateValue()),
															"DriverName": drName,
															"DriverMobile": drCtNo,
															"DriverLicence": drLic,
															"WeighRequired": weightReq
														};
														aCreateContainerpayload.push(createContainerPayload);
													}
													this.createCallforContainer(aCreateContainerpayload);
												} else {
													// If trip number exists, continue with the update flow
													var aUpdateContainerpayload = [];
													for (var j = 0; j < items.length; j++) {
														updateContainerPayload = {
															"ObdNumber": tableItems[j].getCells()[0].getText(),
															"TruckNumber": this.truckNumber,
															"TripNumber": this.tripNumber,
															"TripStatus": "RD",
															"LrNumber": (items[j].LrNumber).toString().toUpperCase(),
															"LrDate": this.resolveTimeDifference(tableItems[j].getCells()[2].getDateValue()),
															"DriverName": drName,
															"DriverMobile": drCtNo,
															"DriverLicence": drLic,
															"WeighRequired": weightReq
														};
														aUpdateContainerpayload.push(updateContainerPayload);
													}
													this.updateCallforContainer(aUpdateContainerpayload);
												}
											} else {
												MessageBox.error("Only 1 Container should be selected");
											}
										} else {
											MessageBox.error("At least one Container should be selected");
										}
									}

									// Logic for Truck and Tank Lorry handling (with update flow)
									if (vehTypeDesc === "Truck" || vehTypeDesc === "Tank lorry") {
										if (this.tripNumber === "0000000000" || !this.tripNumber) {
											var aCreatePayload = [];
											for (var k = 0; k < items.length; k++) {
												createPayload = {
													"ObdNumber": tableItems[k].getCells()[0].getText(),
													"TruckNumber": this.truckNumber,
													"LrNumber": (items[k].LrNumber).toString().toUpperCase(),
													"LrDate": this.resolveTimeDifference(tableItems[k].getCells()[2].getDateValue()),
													"DriverName": drName,
													"DriverMobile": drCtNo,
													"ContainerNo": contNo,
													"DriverLicence": drLic,
													"VehTypeDesc": vehTypeDesc,
													"WeighRequired": weightReq
												};
												aCreatePayload.push(createPayload);
											}
											this.createCallforTruckandTank(aCreatePayload);
										} else {
											var aUpdatePayload = [];
											for (var l = 0; l < items.length; l++) {
												updatePayload = {
													"ObdNumber": tableItems[l].getCells()[0].getText(),
													"TruckNumber": this.truckNumber,
													"TripNumber": this.tripNumber,
													"TripStatus": "RD",
													"LrNumber": (items[l].LrNumber).toString().toUpperCase(),
													"LrDate": this.resolveTimeDifference(tableItems[l].getCells()[2].getDateValue()),
													"DriverName": drName,
													"DriverMobile": drCtNo,
													"ContainerNo": contNo,
													"DriverLicence": drLic,
													"WeighRequired": weightReq
												};
												aUpdatePayload.push(updatePayload);
											}
											this.updateCallforTruckandTank(aUpdatePayload);
										}
									}

								} else {
									MessageBox.error("LR number is Mandatory");
								}
							} else {
								MessageBox.error("Driver License Number should be less than or equal to 20 Characters");
							}
						} else {
							MessageBox.error("Please enter Driver License Number");
						}
					} else {
						MessageBox.error("Driver Contact Number should be a Number with 10 digits and should start with 9 or 8 or 7 or 6");
					}
				} else {
					MessageBox.error("Driver name should not contain special characters");
				}
			} else {
				MessageBox.error("Driver Name required");
			}
		},
		disableReportDetails: function() {
			var rowsNo = this.getView().byId("idMultiReportTable").getItems();
			var columnsNo = this.getView().byId("idMultiReportTable").getColumns();
			this.getView().byId("idDriverName").setEnabled(false);
			this.getView().byId("idDriverContact").setEnabled(false);
			this.getView().byId("idTruckNumber").setEnabled(false);
			this.getView().byId("idTruckSize").setEnabled(false);
			this.getView().byId("idDriverLicense").setEnabled(false);
			this.getView().byId("idDriverPhotoFileUpload").setEnabled(false);
			// this.getView().byId("idContainerNumber").setEnabled(false);
			//	this.getView().byId("idContainerSize").setEnabled(false);
			this.getView().byId("idTankerNumber").setEnabled(false);
			this.getView().byId("idTankerSize").setEnabled(false);
			for (var q = 0; q < rowsNo.length; q++) {
				for (var l = 1; l < columnsNo.length; l++) {
					rowsNo[q].getCells()[l].setEnabled(false);
				}
			}
		},
		onEditMultiReportDetails: function(oEvent) {
			var items = this.getView().byId("idMultiReportTable").getItems();
			var columnsNo = this.getView().byId("idMultiReportTable").getColumns();
			this.getView().byId("idDriverName").setEnabled(true);
			this.getView().byId("idDriverContact").setEnabled(true);
			//	this.getView().byId("idTruckNumber").setEnabled(true);
			//	this.getView().byId("idTruckSize").setEnabled(true);
			this.getView().byId("idDriverLicense").setEnabled(true);
			this.getView().byId("idWeighmentCheckRadioGroup").setEnabled(true);
			this.getView().getModel("TripModel").setProperty("/EditMode", true);
			// this.getView().byId("idContainerNumber").setEnabled(true);
			//	this.getView().byId("idContainerSize").setEnabled(true);
			//	this.getView().byId("idTankerNumber").setEnabled(true);
			//	this.getView().byId("idTankerSize").setEnabled(true);
			this.getView().byId("idDriverPhotoFileUpload").setEnabled(true);
			for (var q = 0; q < items.length; q++) {
				for (var l = 1; l < columnsNo.length; l++) {
					items[q].getCells()[l].setEnabled(true);
				}
			}
		},
		onTruckSubmit: function() {
			var aShipFilters = [],
				aShipStatusFilter = [];
			aShipFilters.push(new Filter({
				path: "TruckNumber",
				value1: this.truckNumber,
				operator: FilterOperator.EQ
			}));
			aShipFilters.push(new Filter({
				path: "TripNumber",
				value1: this.tripNumber,
				operator: FilterOperator.EQ
			}));
			var oShipFilter = new Filter(aShipFilters, true);
			aShipStatusFilter.push(oShipFilter);
			this.getOwnerComponent().getModel().read("/PLMS_Vehicle_InspectionSet", {
				filters: aShipStatusFilter,
				success: function(oContData) {
					//this.getView().getModel("RemarksModel").setProperty("/Items", oContData.results);
					this.getView().getModel("InspectionModel").setProperty("/Items", oContData.results[0]);
					if (this.tripStatus === "IP") {
						var truckNum = this.getView().byId("idTruckNumber").getValue();
						var conBoxNo = "000";
						var payload = {
							"InspectionStatus": "IC",
							"TripNumber": this.tripNumber,
							"TruckNumber": this.truckNumber
						};
						var oInspModelItems = this.getView().getModel("InspectionModel").getData();
						if (oInspModelItems.ContCleanChk === true && oInspModelItems.RubberSealChk === true && oInspModelItems.ContainerChk ===
							true &&
							oInspModelItems.VehicleCheck === true && oInspModelItems.ContLoadCleanChk === true && oInspModelItems.FumigationChk ===
							true
						) {
							this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
								"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + conBoxNo +
								"',ContainerNo='" +
								truckNum + "')", payload, {
									method: "PUT",
									success: function(response) {
										MessageBox.success("Truck Inspection has been completed successfully");
										this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
											filters: this.aStatusFilter,
											success: function(oData) {
												this.getView().getModel("TripModel").setData(oData.results[0]);
												this.getView().getModel("TripOBDModel").setProperty("/Items", oData.results);
												this.tripStatus = this.getView().getModel("TripModel").getData().TripStatus;
												this.timeLineUpdate();
												if (this.tripStatus !== "" || this.tripStatus !== undefined) {
													this.attachmentsSection();
												}
												this.getView().getModel("TripModel").refresh(true);
												this.callEnableDisableFunction();
												this.getView().byId("idLoadingMaterialsTab").destroyContent();
												var oItems = this.getView().getModel("TripOBDModel").getProperty("/Items");
												for (var ee = 0; ee < oItems.length; ee++) {
													this.createLoadingMaterialsTabContent(ee);
												}
											}.bind(this),
											error: function(oError) {
												MessageBox.warning("Error occurred while reading Header data");
											}
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the truck data");
									}
								});
						} else {
							MessageBox.error("Please fill all the checkpoints");
						}
					} else {
						MessageBox.error("Please finish the Inspection First");
					}
				}.bind(this)
			});
		},
		onTankSubmit: function() {
			var aShipFilters = [],
				aShipStatusFilter = [];
			aShipFilters.push(new Filter({
				path: "TruckNumber",
				value1: this.truckNumber,
				operator: FilterOperator.EQ
			}));
			aShipFilters.push(new Filter({
				path: "TripNumber",
				value1: this.tripNumber,
				operator: FilterOperator.EQ
			}));
			var oShipFilter = new Filter(aShipFilters, true);
			aShipStatusFilter.push(oShipFilter);
			this.getOwnerComponent().getModel().read("/PLMS_Vehicle_InspectionSet", {
				filters: aShipStatusFilter,
				success: function(oContData) {
					this.getView().getModel("InspectionModel").setProperty("/Items", oContData.results[0]);
					if (this.tripStatus === "IP") {
						var truckNum = this.getView().byId("idTruckNumber").getValue();
						var conBoxNo = "000";
						var payload = {
							"InspectionStatus": "IC",
							"TripNumber": this.tripNumber,
							"TruckNumber": this.truckNumber
						};
						var oInspModelItems = this.getView().getModel("InspectionModel").getData();
						if (oInspModelItems.VehicleCheck === true && oInspModelItems.RubberSealChk === true && oInspModelItems.ContainerChk ===
							true &&
							oInspModelItems.FumigationChk === true && oInspModelItems.ContWtChk === true) {
							this.getOwnerComponent().getModel().update("/PLMS_Vehicle_InspectionSet(TruckNumber='" + this.truckNumber +
								"',TripNumber='" + this.tripNumber + "',ContainerBoxNo='" + conBoxNo +
								"',ContainerNo='" +
								truckNum + "')", payload, {
									method: "PUT",
									success: function(response) {
										MessageBox.success("Tank Inspection has been completed successfully");
										this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
											filters: this.aStatusFilter,
											success: function(oData) {
												this.getView().getModel("TripModel").setData(oData.results[0]);
												this.getView().getModel("TripOBDModel").setProperty("/Items", oData.results);
												this.tripStatus = this.getView().getModel("TripModel").getData().TripStatus;
												this.timeLineUpdate();
												if (this.tripStatus !== "" || this.tripStatus !== undefined) {
													this.attachmentsSection();
												}
												this.getView().getModel("TripModel").refresh(true);
												this.callEnableDisableFunction();
												this.getView().byId("idLoadingMaterialsTab").destroyContent();
												var oItems = this.getView().getModel("TripOBDModel").getProperty("/Items");
												for (var ee = 0; ee < oItems.length; ee++) {
													this.createLoadingMaterialsTabContent(ee);
												}
											}.bind(this),
											error: function(oError) {
												MessageBox.warning("Error occurred while reading Header data");
											}
										});
									}.bind(this),
									error: function(error) {
										MessageBox.warning("Error occurred while updating the tanker data");
									}
								});
						} else {
							MessageBox.error("Please fill all the checkpoints");
						}
					} else {
						MessageBox.error("Please finish the Inspection First");
					}
				}.bind(this)
			});
		},
		onCustomerNamePopover: function(oEvent) {
			var oLink = oEvent.getSource();
			if (this.getView().getModel("TripOBDModel").getData().Items.length > 1) {
				if (!this._pPopover) {
					this._pPopover = Fragment.load({
						id: this.getView().getId(),
						name: "ZSonic_PLMS.view.Fragment.CustomerNamesList",
						controller: this
					}).then(function(oPopover) {
						this.getView().addDependent(oPopover);
						return oPopover;
					}.bind(this));
				}
				this._pPopover.then(function(oPopover) {
					oPopover.openBy(oLink);
				});
			}
		},
		setImageSource: function(id, filename) {
			var path = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," + "FileName=" +
				"'" +
				filename + "'" + ")/$value";
			this.getView().byId(id).setSrc(path);
		},
		setImageSourceContainer: function(panelRef, item) {
			if (item.VehImageFileName) {
				var path1 = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," + "FileName=" +
					"'" +
					item.VehImageFileName + "'" + ")/$value";
				panelRef.getContent()[0].getContent()[0].getContent()[9].setSrc(path1);
			} else {
				panelRef.getContent()[0].getContent()[0].getContent()[9].setSrc("");
			}
			if (item.RubberLeakFileName) {
				var path2 = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," + "FileName=" +
					"'" +
					item.RubberLeakFileName + "'" + ")/$value";
				panelRef.getContent()[1].getContent()[0].getContent()[9].setSrc(path2);
			} else {
				panelRef.getContent()[1].getContent()[0].getContent()[9].setSrc("");
			}
			if (item.BagStripRmvImgFileName) {
				var path3 = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," + "FileName=" +
					"'" +
					item.BagStripRmvImgFileName + "'" + ")/$value";
				panelRef.getContent()[2].getContent()[0].getContent()[9].setSrc(path3);
			} else {
				panelRef.getContent()[2].getContent()[0].getContent()[9].setSrc("");
			}
			if (item.ContImageFile) {
				var path4 = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," + "FileName=" +
					"'" +
					item.ContImageFile + "'" + ")/$value";
				panelRef.getContent()[3].getContent()[0].getContent()[9].setSrc(path4);
			} else {
				panelRef.getContent()[3].getContent()[0].getContent()[9].setSrc("");
			}
			if (item.FumigationImgFileName) {
				var path5 = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," + "FileName=" +
					"'" +
					item.FumigationImgFileName + "'" + ")/$value";
				panelRef.getContent()[4].getContent()[0].getContent()[9].setSrc(path5);
			} else {
				panelRef.getContent()[4].getContent()[0].getContent()[9].setSrc("");
			}
			if (item.ContCleanImgFileName) {
				var path6 = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," + "FileName=" +
					"'" +
					item.ContCleanImgFileName + "'" + ")/$value";
				panelRef.getContent()[5].getContent()[0].getContent()[9].setSrc(path6);
			} else {
				panelRef.getContent()[5].getContent()[0].getContent()[9].setSrc("");
			}
			/*if (item.ContReadyImgFileName) {
				var path7 = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," + "FileName=" +
					"'" +
					item.ContReadyImgFileName + "'" + ")/$value";
				panelRef.getContent()[6].getContent()[0].getContent()[9].setSrc(path7);
			} else {
				panelRef.getContent()[6].getContent()[0].getContent()[9].setSrc("");
			}
			if (item.ContLoadedImgFileName) {
				var path8 = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," + "FileName=" +
					"'" +
					item.ContLoadedImgFileName + "'" + ")/$value";
				panelRef.getContent()[7].getContent()[0].getContent()[9].setSrc(path8);
			} else {
				panelRef.getContent()[7].getContent()[0].getContent()[9].setSrc("");
			}
			if (item.ContLockImgFileName) {
				var path9 = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," + "FileName=" +
					"'" +
					item.ContLockImgFileName + "'" + ")/$value";
				panelRef.getContent()[8].getContent()[0].getContent()[9].setSrc(path9);
			} else {
				panelRef.getContent()[8].getContent()[0].getContent()[9].setSrc("");
			}*/
			if (item.CscSafetyFileName) {
				var path11 = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," + "FileName=" +
					"'" +
					item.CscSafetyFileName + "'" + ")/$value";
				panelRef.getContent()[6].getContent()[0].getContent()[9].setSrc(path11);
			} else {
				panelRef.getContent()[6].getContent()[0].getContent()[9].setSrc("");
			}
		},
		loadingUnloadingPointReadCall: function(oSelect) {
			var aGetFilters = [],
				aGetStatusFilter = [];
			aGetFilters.push(new Filter({
				path: "Werks",
				value1: this.plantCode,
				operator: FilterOperator.EQ
			}));
			aGetFilters.push(new Filter({
				path: "Lgort",
				value1: this.lGort,
				operator: FilterOperator.EQ
			}));
			var oGetFilter = new Filter(aGetFilters, true);
			aGetStatusFilter.push(oGetFilter);
			this.getOwnerComponent().getModel().read("/GetUserandRolesSet", {
				filters: aGetStatusFilter,
				success: function(oData) {
					var aFilters = [],
						aStatusFilter = [];
					var vstl = this.getView().getModel("TripModel").getData().Vstel;
					if (oData.results.length > 0) {
						var plantName = oData.results[0].Werks;
						if (plantName !== "" && plantName !== undefined) {
							aFilters.push(new Filter({
								path: "Vstel",
								value1: plantName,
								operator: FilterOperator.EQ
							}));
						}
					} else {
						aFilters.push(new Filter({
							path: "Vstel",
							value1: vstl,
							operator: FilterOperator.EQ
						}));
					}
					aFilters.push(new Filter({
						path: "Spras",
						value1: "EN",
						operator: FilterOperator.EQ
					}));
					var oFilter = new Filter(aFilters, true);
					aStatusFilter.push(oFilter);
					this.getOwnerComponent().getModel().read("/LoadingPointSet", {
						filters: aStatusFilter,
						success: function(oData1) {
							for (var i = 0; i < oData1.results.length; i++) {
								var aa = new sap.ui.core.Item({
									key: oData1.results[i].Lstel,
									text: oData1.results[i].Vtext
								});
								oSelect.addItem(aa);
							}
						}.bind(this),
						error: function(error) {
							MessageBox.error("Error in getting Loading/Unloading Gate Details");
						}
					});

				}.bind(this),
				error: function(error) {

				}
			});
		},
		onPressNavigatetoPGI: function() {
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); // get a handle on the global XAppNav service
			var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
				target: {
					semanticObject: "OutboundDelivery-manage",
					action: "display"
				}
			})) || ""; // generate the Hash to display a Supplier
			oCrossAppNavigator.toExternal({
				target: {
					shellHash: hash
				}
			}); // navigate to Supplier application
		},
		onCloseBatchDialog: function() {
			if (this.dialogBatchNo) {
				this.dialogBatchNo.close();
			}
		},
		onCloseNOBatchDialog: function() {
			if (this.dialogNOBatchNo) {
				this.dialogNOBatchNo.close();
			}
		},
		onBatchNoSelect: function(oEvent) {
			var batchNo = oEvent.getSource().getSelectedItem().getCells()[0].getText();
			var expDate = oEvent.getSource().getSelectedItem().getCells()[2].getText();
			if (new Date(expDate) < new Date()) {
				MessageBox.error("The selected batch has expired");
				return;
			}
			this.batchInput.setValue(batchNo);
			this.dialogBatchNo.close();
			this.getView().byId("idBatchTable").removeSelections();
		},
		readBatchF4Values: function(material, plant, stLoc) {
			var materialAllChar = material.length;
			if (materialAllChar < 18) {
				for (var f = 0; f < 18 - materialAllChar; f++) {
					material = "0" + material;
				}
			}
			var aFilters = [],
				aStatusFilter = [];
			aFilters.push(new Filter({
				path: "Matnr",
				value1: material,
				operator: FilterOperator.EQ
			}));
			aFilters.push(new Filter({
				path: "Werks",
				value1: plant,
				operator: FilterOperator.EQ
			}));
			aFilters.push(new Filter({
				path: "Lgort",
				value1: stLoc,
				operator: FilterOperator.EQ
			}));
			aFilters.push(new Filter({
				path: "Clabs",
				value1: "0.000",
				operator: FilterOperator.NE
			}));
			var oFilter = new Filter(aFilters, true);
			aStatusFilter.push(oFilter);
			this.getOwnerComponent().getModel().read("/BatchF4Set", {
				filters: aStatusFilter,
				success: function(oData) {
					this.getView().getModel("BatchModel").setProperty("/Items", oData.results);
				}.bind(this),
				error: function(error) {
					MessageBox.error("Error in getting batches data");
				}
			});
		},
		handleGateOutImageChange: function(oEvent) {
			this.gateoutFileName = oEvent.getParameter("files")[0].name;
			this.gateoutFileType = oEvent.getParameter("files")[0].type;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idImageGateOut").setSrc(path);
			}
		},
		onGateOutSavePress: function() {
			var oFileUploader = this.getView().byId("idFileUploadGateOut");
			var contBoxNo = "000";
			var remarks = this.getView().byId("idRemarksDropDown").getSelectedKey();
			var fumigation = this.getView().byId("idFumiButton").getSelectedIndex();
			var rfid = this.getView().byId("idRFID").getValue();
			if (rfid !== "") {
				var payload = {
					"Remarks": remarks,
					"TripStatus": "GO",
					"FumigationStdCheck": fumigation,
					"RfidSealno": rfid
				};
				oFileUploader.destroyHeaderParameters();
				oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
					name: "SLUG",
					value: this.gateoutFileName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
						this.truckNumber + '"/"' + contBoxNo + '"/"' + 1
				}));
				oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
					name: "Content-Type",
					value: this.gateoutFileType
				}));
				this.getOwnerComponent().getModel().refreshSecurityToken();
				oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
					name: "x-csrf-token",
					value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
				}));
				oFileUploader.setSendXHR(true);
				oFileUploader.upload();
				this.getOwnerComponent().getModel().update("/PLMS_outbound_HdrSet(TruckNumber='" + this.truckNumber + "',ObdNumber='" + this.obdNumber +
					"',TripNumber='" + this.tripNumber + "')", payload, {
						success: function(oData) {
							MessageBox.success("Truck Gate-out details saved successfully");
							this.readHeaderEntitySet();
						}.bind(this),
						error: function(error) {
							MessageBox.error("Error in saving the details");
						}
					});
			} else {
				MessageBox.error("RFID is required");
			}
		},
		readHeaderEntitySet: function() {
			this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
				filters: this.aStatusFilter,
				success: function(oData) {
					this.getView().getModel("TripModel").setData(oData.results[0]);
					this.getView().getModel("TripOBDModel").setProperty("/Items", oData.results);
					this.tripStatus = this.getView().getModel("TripModel").getData().TripStatus;
					this.tripNumber = this.getView().getModel("TripModel").getData().TripNumber;
					this.timeLineUpdate();
					if (this.tripStatus !== "" && this.tripStatus !== undefined) {
						this.attachmentsSection();
					}
					this.getView().getModel("TripModel").refresh(true);
					this.callEnableDisableFunction();
				}.bind(this),
				error: function(oError) {
					MessageBox.warning("Error occurred while reading Header data");
				}
			});
		},
		readInspectionEntitySet: function() {
			this.getOwnerComponent().getModel().read("/PLMS_Vehicle_InspectionSet", {
				filters: this.aStatusFilter,
				success: function(oData) {
					var data = oData.results;
					this.getView().getModel("InspectionModel").setProperty("/Items", data);
					this.getView().getModel("InspectionModel").refresh(true);
				}.bind(this),
				error: function(error) {
					MessageBox.warning("No Inspection Data available for this OBDNumber");
					this.getView().setBusy(false);
				}.bind(this)
			});
		},
		readInspectionEntitySetforTruckandTank: function() {
			this.getOwnerComponent().getModel().read("/PLMS_Vehicle_InspectionSet", {
				filters: this.aStatusFilter,
				success: function(oData) {
					var data = oData.results[0];
					this.getView().getModel("InspectionModel").setData(data);
					this.getView().setBusy(false);
				}.bind(this),
				error: function(error) {
					MessageBox.warning("No Inspection Data available for this OBDNumber");
					this.getView().setBusy(false);
				}.bind(this)
			});
		},
		readInspectionEntitySetforContainer: function() {
			this.getOwnerComponent().getModel().read("/PLMS_Vehicle_InspectionSet", {
				filters: this.aStatusFilter,
				success: function(oInspData) {
					var data = oInspData.results;
					if (data.length > 0) {
						this.getView().getModel("InspectionModel").setProperty("/Items", data);
						this.NoofContainers = this.getView().getModel("InspectionModel").getProperty("/Items").length;
						this.getView().byId("idOverAllCheckPoints").destroyContent();
						var contData1 = this.getView().getModel("InspectionModel").getProperty("/Items");
						if (contData1.length > 0) {
							for (var g = 0; g < contData1.length; g++) {
								this.createContainerCheckListPanel(contData1[g].ContainerBoxNo, contData1[g].ContainerNo, g);
							}
						}
						var checkPointPanel = this.getView().byId("idOverAllCheckPoints");
						var noofContainers = checkPointPanel.getContent().length;
						var oItems = this.getView().getModel("InspectionModel").getProperty("/Items");
						for (var o = 0; o < noofContainers; o++) {
							var headerTxt = checkPointPanel.getContent()[o].getHeaderText().split(":")[1].toString();
							if (headerTxt.includes(oItems[o].ContainerNo)) {
								this.setImageSourceContainer(checkPointPanel.getContent()[o], oItems[o]);
							}
						}
					}
					this.getView().setBusy(false);
				}.bind(this),
				error: function(error) {
					MessageBox.error("Inspection Pending");
				}.bind(this)
			});
		},
		onLRDetailsChange: function(oEvent) {
			this.getView().byId("idSaveMultiReports").setEnabled(false);
			var oItems = oEvent.getSource().getParent().getParent().getItems();
			var itemLength = oItems.length;
			var binding = oEvent.getSource().getParent().getBindingContextPath().split("/")[2];
			var lrValue = oEvent.getSource().getValue().toString().toLowerCase();
			var avail = false;
			for (var e = 0; e < itemLength; e++) {
				if (e.toString() === binding) {
					continue;
				}
				if (oItems[e].getCells()[1].getValue().toString().toLowerCase() === lrValue) {
					if (oItems[e].getCells()[1].getValue().toString().toLowerCase() && lrValue) {
						avail = true;
						break;
					}
				}
			}
			if (avail) {
				MessageBox.error("This LR Number is already available");
				this.getView().byId("idSaveMultiReports").setEnabled(false);
			} else {
				this.getView().byId("idSaveMultiReports").setEnabled(true);
			}
		},
		createCallforContainer: function(aCreateContainerpayload) {
			if (this.fileDriverName) {
				if (this.fileDriverType === "image/jpeg") {
					if (aCreateContainerpayload.length > 0) {
						var oModel = this.getOwnerComponent().getModel();
						oModel.setUseBatch(true);
						var aDeferredGroups = oModel.getDeferredGroups();
						aDeferredGroups = aDeferredGroups.concat(["CreateContReportGroup"]);
						oModel.setDeferredGroups(aDeferredGroups);
						for (var b = 0; b < aCreateContainerpayload.length; b++) {
							oModel.create("/PLMS_outbound_HdrSet", aCreateContainerpayload[b], {
								groupId: "CreateContReportGroup"
							});
						}
						oModel.submitChanges({
							groupId: "CreateContReportGroup",
							success: function(req, res) {
								oModel.setUseBatch(false);
								MessageBox.success("Reporting have been done successfully", {
									onClose: function() {
										var tripNumber = res.data.__batchResponses[0].__changeResponses[0].data.TripNumber;
										this.tripNumber = tripNumber;
										var aFilters = [],
											aStatusFilter = [];
										aFilters.push(new Filter({
											path: "TruckNumber",
											value1: this.truckNumber,
											operator: FilterOperator.EQ
										}));
										aFilters.push(new Filter({
											path: "TripNumber",
											value1: this.tripNumber,
											operator: FilterOperator.EQ
										}));
										var oFilter = new Filter(aFilters, true);
										aStatusFilter.push(oFilter);
										this.aStatusFilter = aStatusFilter;
										this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
											filters: aStatusFilter,
											success: function(oData) {
												var oFileUploader = this.getView().byId("idDriverPhotoFileUpload");
												oFileUploader.destroyHeaderParameters();
												oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
													name: "SLUG",
													value: this.fileDriverName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
														'"/"' +
														"000" +
														'"/"' + "000" + '"/"' + 17
												}));
												oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
													name: "Content-Type",
													value: this.fileDriverType
												}));
												this.getOwnerComponent().getModel().refreshSecurityToken();
												oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
													name: "x-csrf-token",
													value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
												}));
												oFileUploader.setSendXHR(true);
												oFileUploader.upload();
												this.getView().getModel("TripModel").setData(oData.results[0]);
												var plantCode = oData.results[0].Plant;
												//	this.loadingUnloadingPointReadCall(plantCode);
												this.getView().getModel("TripOBDModel").setProperty("/Items", oData.results);
												this.tripNumber = this.getView().getModel("TripModel").getData().TripNumber;
												this.tripStatus = this.getView().getModel("TripModel").getData().TripStatus;
												var containerTable = this.getView().byId("idContainerNumber").getItems();
												var containerLength = containerTable.length;
												var aPayload = [];
												var noOfCheckBoxes = 0;
												for (var h = 0; h < containerLength; h++) {
													var checked = containerTable[h].getCells()[2].getSelected();
													if (checked) {
														var contNo = containerTable[h].getCells()[0].getText();
														var contPos = noOfCheckBoxes.toString();
														var contPosLength = contPos.length;
														for (var r = 0; r < 3 - contPosLength; r++) {
															contPos = "0" + contPos;
														}
														var contSize = containerTable[h].getCells()[2].getText();
														var jsonObj = {
															ContainerNo: contNo,
															ContainerBoxNo: contPos,
															ContainerSize: contSize,
															TruckNumber: this.truckNumber,
															TripNumber: this.tripNumber,
															VehObservations: "BATCH"
														};
														aPayload.push(jsonObj);
														noOfCheckBoxes++;
													}
												}
												if (aPayload.length > 0) {
													oModel.setUseBatch(true);
													var aContDeferredGroups = oModel.getDeferredGroups();
													aContDeferredGroups = aContDeferredGroups.concat(["CreateContNoGroup"]);
													oModel.setDeferredGroups(aContDeferredGroups);
													for (var a = 0; a < aPayload.length; a++) {
														oModel.create("/PLMS_Vehicle_InspectionSet", aPayload[a], {
															groupId: "CreateContNoGroup"
														});
													}
													oModel.submitChanges({
														groupId: "CreateContNoGroup",
														success: function(reqCont, resCont) {
															oModel.setUseBatch(false);
															for (var w = 0; w < containerLength; w++) {
																containerTable[w].getCells()[2].setEnabled(false);
															}
															this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
																filters: this.aStatusFilter,
																success: function(oData1) {
																	this.getView().getModel("TripModel").setData(oData1.results[0]);
																	this.getView().getModel("TripOBDModel").setProperty("/Items", oData1.results);
																	this.tripStatus = this.getView().getModel("TripModel").getData().TripStatus;
																	this.tripNumber = this.getView().getModel("TripModel").getData().TripNumber;
																	this.timeLineUpdate();
																	this.getOwnerComponent().getModel().read("/PLMS_Vehicle_InspectionSet", {
																		filters: aStatusFilter,
																		success: function(oInspData) {
																			var data = oInspData.results;
																			this.getView().getModel("InspectionModel").setProperty("/Items", data);
																			this.getView().getModel("InspectionModel").refresh(true);
																			this.getView().byId("idOverAllCheckPoints").destroyContent();
																			var oInspectionModel = this.getView().getModel("InspectionModel").getProperty("/Items");
																			for (var x = 0; x < oInspectionModel.length; x++) {
																				this.createContainerCheckListPanel(oInspectionModel[x].ContainerBoxNo, oInspectionModel[x]
																					.ContainerNo,
																					x);
																			}
																			MessageBox.success("Container Checkpoints have been loaded successfully");
																			this.timeLineUpdate();
																			this.getView().byId("idReportDetailsPanel").setExpanded(false);
																			this.loadingItemsReadCall();
																			this.getOwnerComponent().getRouter().navTo("view2", {
																				key1: this.truckNumber,
																				key2: this.obdNumber,
																				key3: this.tripNumber
																			});
																		}.bind(this),
																		error: function(error) {
																			MessageBox.warning("No Inspection Data available for this OBDNumber");
																			this.getView().setBusy(false);
																		}.bind(this)
																	});
																	if (this.tripStatus !== "" && this.tripStatus !== undefined) {
																		this.attachmentsSection();
																	}
																	this.getView().getModel("TripModel").refresh(true);
																	this.callEnableDisableFunction();
																}.bind(this),
																error: function(oError) {
																	MessageBox.warning("Error occurred while reading Header data");
																}
															});
														}.bind(this),
														error: function(oLULError) {
															MessageBox.error("Error");
														}
													});
												}
											}.bind(this)
										});
									}.bind(this)
								});
							}.bind(this)
						});
					}

				} else {
					MessageBox.error("Driver Photo type should be JPG");
				}
			} else {
				MessageBox.error("Driver Photo is required");
			}
		},
		updateCallforContainer: function(aUpdateContainerpayload) {
			if (this.fileDriverName) {
				if (this.fileDriverType === "image/jpeg") {
					var oFileUploader = this.getView().byId("idDriverPhotoFileUpload");
					oFileUploader.destroyHeaderParameters();
					oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
						name: "SLUG",
						value: this.fileDriverName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
							"000" +
							'"/"' + "000" + '"/"' + 17
					}));
					oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
						name: "Content-Type",
						value: this.fileDriverType
					}));
					this.getOwnerComponent().getModel().refreshSecurityToken();
					oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
						name: "x-csrf-token",
						value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
					}));
					oFileUploader.setSendXHR(true);
					oFileUploader.upload();

				} else {
					MessageBox.error("Driver Photo type should be JPG");
				}
			}
			if (aUpdateContainerpayload.length > 0) {
				var oModel = this.getOwnerComponent().getModel();
				oModel.setUseBatch(true);
				var aDeferredGroups = oModel.getDeferredGroups();
				aDeferredGroups = aDeferredGroups.concat(["UpdateContReportGroup"]);
				oModel.setDeferredGroups(aDeferredGroups);
				for (var b = 0; b < aUpdateContainerpayload.length; b++) {
					oModel.create("/PLMS_outbound_HdrSet", aUpdateContainerpayload[b], {
						groupId: "UpdateContReportGroup"
					});
				}
				oModel.submitChanges({
					groupId: "UpdateContReportGroup",
					success: function(req, res) {
						oModel.setUseBatch(false);
						MessageBox.success("Container Reporting have been done successfully", {
							onClose: function() {
								this.disableReportDetails();
								this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
									filters: this.aStatusFilter,
									success: function(oData) {
										var dataHeader = oData.results[0];
										this.getView().getModel("TripModel").setData(dataHeader);
										this.getView().getModel("TripOBDModel").setProperty("/Items", oData.results);
										this.tripNumber = this.getView().getModel("TripModel").getProperty("/TripNumber");
										this.tripStatus = this.getView().getModel("TripModel").getProperty("/TripStatus");
										this.getView().byId("idOverAllCheckPoints").destroyContent();
										if (!this.tripNumber) {
											this.tripNumber = "0000000000";
										}
										this.getView().setBusy(false);
										var oContainerModel = this.getView().getModel("InspectionModel").getProperty("/Items");
										if (oContainerModel) {
											for (var x = 0; x < oContainerModel.length; x++) {
												this.createContainerCheckListPanel(oContainerModel[x].ContainerBoxNo, oContainerModel[x].ContainerNo, x);
											}
										} else {
											var containerTable = this.getView().byId("idContainerNumber").getItems();
											var containerLength = containerTable.length;
											var aPayload = [];
											var noOfCheckBoxes = 0;
											for (var h = 0; h < containerLength; h++) {
												var checked = containerTable[h].getCells()[2].getSelected();
												if (checked) {
													var contNo = containerTable[h].getCells()[0].getText();
													var contPos = noOfCheckBoxes.toString();
													var contPosLength = contPos.length;
													for (var r = 0; r < 3 - contPosLength; r++) {
														contPos = "0" + contPos;
													}
													var contSize = containerTable[h].getCells()[2].getText();
													var jsonObj = {
														ContainerNo: contNo,
														ContainerBoxNo: contPos,
														ContainerSize: contSize,
														TruckNumber: this.truckNumber,
														TripNumber: this.tripNumber,
														VehObservations: "BATCH"
													};
													aPayload.push(jsonObj);
													noOfCheckBoxes++;
												}
											}
											if (aPayload.length > 0) {
												oModel.setUseBatch(true);
												var aContUpdateDeferredGroups = oModel.getDeferredGroups();
												aContUpdateDeferredGroups = aContUpdateDeferredGroups.concat(["UpdateContNoGroup"]);
												oModel.setDeferredGroups(aContUpdateDeferredGroups);
												for (var a = 0; a < aPayload.length; a++) {
													oModel.create("/PLMS_Vehicle_InspectionSet", aPayload[a], {
														groupId: "UpdateContNoGroup"
													});
												}
												oModel.submitChanges({
													groupId: "UpdateContNoGroup",
													success: function(req, res) {
														oModel.setUseBatch(false);
														MessageBox.success("Container Details have been saved successfully");
														for (var w = 0; w < containerLength; w++) {
															containerTable[w].getCells()[2].setEnabled(false);
														}
														this.readHeaderEntitySet();
														this.getView().byId("idLoadingMaterialsTab").destroyContent();
														this.getView().byId("idLoadingUnloading").destroyContent();
														this.getView().byId("idGateInMainPanel").destroyContent();
														for (var mm = 0; mm < oData.results.length; mm++) {
															this.createLoadingMaterialsTabContent(mm);
															this.createGateInTabContent(mm);
															this.createLoadingUnloadingMaterialsTabContent(mm);
														}
														var aFilters = [],
															aStatusFilter = [];
														aFilters.push(new Filter({
															path: "TruckNumber",
															value1: this.truckNumber,
															operator: FilterOperator.EQ
														}));
														aFilters.push(new Filter({
															path: "TripNumber",
															value1: this.tripNumber,
															operator: FilterOperator.EQ
														}));
														var oFilter = new Filter(aFilters, true);
														aStatusFilter.push(oFilter);
														this.getOwnerComponent().getModel().read("/PLMS_Vehicle_InspectionSet", {
															filters: aStatusFilter,
															success: function(oInspData) {
																var data = oInspData.results;
																this.getView().getModel("InspectionModel").setProperty("/Items", data);
																this.getView().getModel("InspectionModel").refresh(true);
																this.getView().byId("idOverAllCheckPoints").destroyContent();
																var oInspectionModel = this.getView().getModel("InspectionModel").getProperty("/Items");
																for (var y = 0; y < oInspectionModel.length; y++) {
																	this.createContainerCheckListPanel(oInspectionModel[y].ContainerBoxNo, oInspectionModel[y].ContainerNo,
																		y);
																}
																this.timeLineUpdate();
																if (this.tripStatus !== "" || this.tripStatus !== undefined) {
																	this.attachmentsSection();
																}
																this.getView().byId("idReportDetailsPanel").setExpanded(false);
															}.bind(this),
															error: function(error) {
																MessageBox.warning("No Inspection Data available for this OBDNumber");
																this.getView().setBusy(false);
															}.bind(this)
														});

													}.bind(this),
													error: function(oLULError) {
														MessageBox.error("Error");
													}
												});
											}
										}
										this.timeLineUpdate();
									}.bind(this),
									error: function(error) {
										MessageBox.error("No found for this OBDNumber");
										this.getView().setBusy(false);
									}.bind(this)
								});
							}.bind(this)
						});

					}.bind(this),
					error: function(error) {
						//	MessageBox.error("Error in creating LR details of OBD Number:" + tableItems[j].getCells()[0].getText());
					}
				});
			}
		},
		createCallforTruckandTank: function(aCreatePayload) {
			if (this.fileDriverName) {
				if (this.fileDriverType === "image/jpeg") {
					if (aCreatePayload.length > 0) {
						this.reportFileUpload();
						var oModel = this.getOwnerComponent().getModel();
						oModel.setUseBatch(true);
						var aDeferredGroups = oModel.getDeferredGroups();
						aDeferredGroups = aDeferredGroups.concat(["CreateReportGroup"]);
						oModel.setDeferredGroups(aDeferredGroups);
						for (var j = 0; j < aCreatePayload.length; j++) {
							oModel.create("/PLMS_outbound_HdrSet", aCreatePayload[j], {
								groupId: "CreateReportGroup"
							});
						}
						oModel.submitChanges({
							groupId: "CreateReportGroup",
							success: function(req, res) {
								oModel.setUseBatch(false);
								var tripNumber = res.data.__batchResponses[0].__changeResponses[0].data.TripNumber;
								this.tripNumber = tripNumber;
								this.disableReportDetails();
								var aFilters = [],
									aStatusFilter = [];
								aFilters.push(new Filter({
									path: "TruckNumber",
									value1: this.truckNumber,
									operator: FilterOperator.EQ
								}));
								aFilters.push(new Filter({
									path: "TripNumber",
									value1: tripNumber,
									operator: FilterOperator.EQ
								}));
								var oFilter = new Filter(aFilters, true);
								aStatusFilter.push(oFilter);
								this.aStatusFilter = aStatusFilter;
								this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
									filters: aStatusFilter,
									success: function(oData) {
										var tr = tripNumber;
										var dataHeader = oData.results[0];
										this.getView().getModel("TripModel").setData(dataHeader);
										var plantCode = dataHeader.Plant;
										this.getView().getModel("TripOBDModel").setProperty("/Items", oData.results);
										this.tripNumber = this.getView().getModel("TripModel").getProperty("/TripNumber");
										this.tripStatus = this.getView().getModel("TripModel").getProperty("/TripStatus");
										/*	if (!this.tripNumber) {
												this.tripNumber = "0000000000";
											}
												this.getView().byId("idLoadingMaterialsTab").destroyContent();
												this.getView().byId("idLoadingUnloading").destroyContent();
												this.getView().byId("idGateInMainPanel").destroyContent();
												for (var mm = 0; mm < oData.results.length; mm++) {
													this.createLoadingMaterialsTabContent(mm);
													this.createGateInTabContent(mm);
													this.createLoadingUnloadingMaterialsTabContent(mm);
												}*/
										this.timeLineUpdate();
										this.getView().setBusy(false);
										MessageBox.success("Reporting Details Saved successfully");
										if (this.tripStatus !== "" || this.tripStatus !== undefined) {
											this.attachmentsSection();
										}
										this.getView().byId("idReportDetailsPanel").setExpanded(false);
										this.loadingItemsReadCall();
										this.getOwnerComponent().getRouter().navTo("view2", {
											key1: this.truckNumber,
											key2: this.obdNumber,
											key3: this.tripNumber
										});
									}.bind(this),
									error: function(error) {
										MessageBox.error("No found for this OBDNumber");
										this.getView().setBusy(false);
									}.bind(this)
								});
							}.bind(this),
							error: function(oGateinError) {
								MessageBox.error("Error");
							}
						});
					}

				} else {
					MessageBox.error("Driver Photo type should be JPG");
				}
			} else {
				MessageBox.error("Driver Photo is required");
			}
		},
		updateCallforTruckandTank: function(aUpdatePayload) {
			// Check if a file is provided
			if (this.fileDriverName) {
				if (this.fileDriverType === "image/jpeg") {
					var oFileUploader = this.getView().byId("idDriverPhotoFileUpload");
					oFileUploader.destroyHeaderParameters();
					oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
						name: "SLUG",
						value: this.fileDriverName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
							"000" +
							'"/"' + "000" + '"/"' + 17
					}));
					oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
						name: "Content-Type",
						value: this.fileDriverType
					}));
					this.getOwnerComponent().getModel().refreshSecurityToken();
					oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
						name: "x-csrf-token",
						value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
					}));
					oFileUploader.setSendXHR(true);
					oFileUploader.upload();
				} else {
					MessageBox.error("Driver Photo type should be JPG");
				}
			}

			if (aUpdatePayload.length > 0) {
				var oModel = this.getOwnerComponent().getModel();
				oModel.setUseBatch(true);
				var aDeferredGroups = oModel.getDeferredGroups();
				aDeferredGroups = aDeferredGroups.concat(["UpdateReportGroup"]);
				oModel.setDeferredGroups(aDeferredGroups);

				// Iterate through the payload and update status if it's "Arrived"
				for (var j = 0; j < aUpdatePayload.length; j++) {
					if (aUpdatePayload[j].TripStatus === "Arrived") {
						aUpdatePayload[j].TripStatus = "RD"; // Update TripStatus to "RD"
						aUpdatePayload[j].ReportingStatus = "RD"; // Update ReportingStatus to "RD"
					}
					oModel.update("/PLMS_outbound_HdrSet(TruckNumber='" + aUpdatePayload[j].TruckNumber + "',ObdNumber='" +
						aUpdatePayload[j].ObdNumber +
						"',TripNumber='" + aUpdatePayload[j].TripNumber + "')", aUpdatePayload[j], {
							groupId: "UpdateReportGroup"
						});
				}

				oModel.submitChanges({
					groupId: "UpdateReportGroup",
					success: function(req, res) {
						oModel.setUseBatch(false);
						this.disableReportDetails();
						this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
							filters: this.aStatusFilter,
							success: function(oData) {
								var dataHeader = oData.results[0];
								this.getView().getModel("TripModel").setData(dataHeader);
								this.getView().getModel("TripOBDModel").setProperty("/Items", oData.results);
								this.tripNumber = this.getView().getModel("TripModel").getProperty("/TripNumber");
								this.tripStatus = this.getView().getModel("TripModel").getProperty("/TripStatus");
								if (!this.tripNumber) {
									this.tripNumber = "0000000000";
								}
								this.getView().setBusy(false);
								this.timeLineUpdate();
								MessageBox.success("Reporting Details Updated successfully");
								if (this.tripStatus !== "" || this.tripStatus !== undefined) {
									this.attachmentsSection();
								}
								this.getView().byId("idReportDetailsPanel").setExpanded(false);
							}.bind(this),
							error: function(error) {
								MessageBox.error("No data found for this OBDNumber");
								this.getView().setBusy(false);
							}.bind(this)
						});
					}.bind(this)
				});
			}
		},
		callEnableDisableFunction: function() {
			var setEnableDisable = this.getView().getModel("EnableDisableModel");
			if (this.tripStatus === "IC") {
				setEnableDisable.setProperty("/InspectionFormElements", false);
				setEnableDisable.setProperty("/InspectionEditSaveButtons", false);
				setEnableDisable.setProperty("/InspectionSubmitButton", false);
			} else if (this.tripStatus === "GI") {
				setEnableDisable.setProperty("/InspectionFormElements", false);
				setEnableDisable.setProperty("/InspectionEditSaveButtons", false);
				setEnableDisable.setProperty("/InspectionSubmitButton", false);
			} else if (this.tripStatus === "WC") {
				setEnableDisable.setProperty("/InspectionFormElements", false);
				setEnableDisable.setProperty("/InspectionEditSaveButtons", false);
				setEnableDisable.setProperty("/InspectionSubmitButton", false);
				setEnableDisable.setProperty("/LoadingEditSaveandSubmitButtons", false);
				setEnableDisable.setProperty("/GateInEditSaveandSubmitButtons", false);
				setEnableDisable.setProperty("/WeighmentSlip", false);
			} else if (this.tripStatus === "LC") {
				setEnableDisable.setProperty("/InspectionFormElements", false);
				setEnableDisable.setProperty("/InspectionEditSaveButtons", false);
				setEnableDisable.setProperty("/InspectionSubmitButton", false);
				//	setEnableDisable.setProperty("/LoadingEditSaveandSubmitButtons", false);
			} else if (this.tripStatus === "GO") {
				setEnableDisable.setProperty("/InspectionFormElements", false);
				setEnableDisable.setProperty("/InspectionEditSaveButtons", false);
				setEnableDisable.setProperty("/InspectionSubmitButton", false);
				setEnableDisable.setProperty("/LoadingEditSaveandSubmitButtons", false);
				setEnableDisable.setProperty("/GateInEditSaveandSubmitButtons", false);
				setEnableDisable.setProperty("/WeighmentSlip", false);
			}
			setEnableDisable.refresh(true);
		},
		addContainersToSelect: function(oSelect) {
			if (this.vehicleType === "YB16") {
				var aShipFilters = [],
					aShipStatusFilter = [];
				aShipFilters.push(new Filter({
					path: "TruckNumber",
					value1: this.truckNumber,
					operator: FilterOperator.EQ
				}));
				aShipFilters.push(new Filter({
					path: "TripNumber",
					value1: this.tripNumber,
					operator: FilterOperator.EQ
				}));
				var oShipFilter = new Filter(aShipFilters, true);
				aShipStatusFilter.push(oShipFilter);
				this.getOwnerComponent().getModel().read("/PLMS_Vehicle_InspectionSet", {
					filters: aShipStatusFilter,
					success: function(oContData) {
						this.NoofContainers = oContData.results.length;
						this.getView().getModel("InspectionModel").setProperty("/Items", oContData.results);
						var contItems = this.getView().getModel("InspectionModel").getProperty("/Items");
						var contNo = contItems.length;
						for (var i = 0; i < contNo; i++) {
							var aa = new sap.ui.core.Item({
								key: contItems[i].ContainerNo,
								text: contItems[i].ContainerNo
							});
							oSelect.addItem(aa);
						}
					}.bind(this)
				});
			}
		},
		onAnalysisTabPress: function() {
			var aFilters = [],
				aStatusFilter = [];
			aFilters.push(new Filter({
				path: "TruckNumber",
				value1: this.truckNumber,
				operator: FilterOperator.EQ
			}));
			aFilters.push(new Filter({
				path: "TripNumber",
				value1: this.tripNumber,
				operator: FilterOperator.EQ
			}));
			var oFilter = new Filter(aFilters, true);
			aStatusFilter.push(oFilter);
			var timeGuideItems = this.getView().getModel("TimeGuideModel").getProperty("/Items");
			this.getOwnerComponent().getModel().read("/TimeLineSet", {
				filters: aStatusFilter,
				success: function(oTimeLineData) {
					this.getView().getModel("TimeLineSetModel").setProperty("/Items", oTimeLineData.results);
					var timeLineData = this.getView().getModel("TimeLineSetModel").getProperty("/Items");
					var timeGuideArray = [];
					for (var j = 0; j < timeGuideItems.length; j++) {
						if (timeGuideItems[j].Activity === "R") {
							timeGuideArray[0] = timeGuideItems[j].Time.ms;
						}
						if (timeGuideItems[j].Activity === "I") {
							timeGuideArray[1] = timeGuideItems[j].Time.ms;
						}
						if (timeGuideItems[j].Activity === "GI") {
							timeGuideArray[2] = timeGuideItems[j].Time.ms;
						}
						if (timeGuideItems[j].Activity === "W") {
							timeGuideArray[3] = timeGuideItems[j].Time.ms;
						}
						if (timeGuideItems[j].Activity === "LD") {
							timeGuideArray[4] = timeGuideItems[j].Time.ms;
						}
						if (timeGuideItems[j].Activity === "GO") {
							timeGuideArray[5] = timeGuideItems[j].Time.ms;
						}
					}
					timeLineData[0].Icon = "sap-icon://survey";
					timeLineData[1].Icon = "sap-icon://survey";
					timeLineData[2].Icon = "sap-icon://initiative";
					timeLineData[3].Icon = "sap-icon://accept";
					timeLineData[4].Icon = "sap-icon://account";
					timeLineData[6].Icon = "sap-icon://action";
					timeLineData[5].Icon = "sap-icon://my-sales-order";
					timeLineData[0].Delay = "0 mins";
					timeLineData[0].Status = "Success";
					timeLineData[0].StartTime = timeLineData[0].Time;
					timeLineData[0].StartDt = timeLineData[0].Date;
					//	timeLineData[0].StartTime = new Date();
					for (var i = 1; i < oTimeLineData.results.length; i++) {
						if (timeLineData[i].Time) {
							//delay calculation
							if (timeLineData[i].Time.ms - timeLineData[i - 1].Time.ms > timeGuideArray[i - 1]) {
								//status red 
								//delay= i+1 -i
								timeLineData[i].Delay =
									/*(((((timeLineData[i].Time.ms - timeLineData[i - 1].Time.ms) - timeGuideArray[i - 1]) / 1000) / 60))
									.toFixed(2).toString() +
									" mins";*/
									(timeLineData[i].Time.ms - timeLineData[i - 1].Time.ms) - timeGuideArray[i - 1];
								var s = timeLineData[i].Delay;
								if (s) {
									// Pad to 2 or 3 digits, default is 2
									var ms = s % 1000;
									s = (s - ms) / 1000;
									var secs = s % 60;
									s = (s - secs) / 60;
									var mins = s % 60;
									var hrs = (s - mins) / 60;
									timeLineData[i].Delay = this.pad(hrs) + ':' + this.pad(mins);
								}
								timeLineData[i].Status = "Error";
							} else {
								timeLineData[i].Delay = "0 mins";
								timeLineData[i].Status = "Success";
							}
						}
					}
					this.getView().getModel("TimeLineSetModel").refresh(true);
				}.bind(this),
				error: function(oError) {
					MessageBox.error("TimeLine Error");
				}
			});
		},
		pad: function(n, z) {
			z = z || 2;
			return ('00' + n).slice(-z);
		},
		timeLineUpdate: function() {
			var aFilters = [],
				aStatusFilter = [];
			aFilters.push(new Filter({
				path: "TruckNumber",
				value1: this.truckNumber,
				operator: FilterOperator.EQ
			}));
			aFilters.push(new Filter({
				path: "TripNumber",
				value1: this.tripNumber,
				operator: FilterOperator.EQ
			}));
			var oFilter = new Filter(aFilters, true);
			aStatusFilter.push(oFilter);
			var timeGuideItems = this.getView().getModel("TimeGuideModel").getProperty("/Items");
			this.getOwnerComponent().getModel().read("/TimeLineSet", {
				filters: aStatusFilter,
				success: function(oTimeLineData) {
					this.getView().getModel("TimeLineSetModel").setProperty("/Items", oTimeLineData.results);
					var timeLineData = this.getView().getModel("TimeLineSetModel").getProperty("/Items");
					var timeGuideArray = [];
					for (var j = 0; j < timeGuideItems.length; j++) {
						if (timeGuideItems[j].Activity === "R") {
							timeGuideArray[0] = timeGuideItems[j].Time.ms;
						}
						if (timeGuideItems[j].Activity === "I") {
							timeGuideArray[1] = timeGuideItems[j].Time.ms;
						}
						if (timeGuideItems[j].Activity === "GI") {
							timeGuideArray[2] = timeGuideItems[j].Time.ms;
						}
						if (timeGuideItems[j].Activity === "W") {
							timeGuideArray[3] = timeGuideItems[j].Time.ms;
						}
						if (timeGuideItems[j].Activity === "LD") {
							timeGuideArray[4] = timeGuideItems[j].Time.ms;
						}
						if (timeGuideItems[j].Activity === "GO") {
							timeGuideArray[5] = timeGuideItems[j].Time.ms;
						}
					}
					timeLineData[0].Icon = "sap-icon://survey";
					timeLineData[1].Icon = "sap-icon://survey";
					timeLineData[2].Icon = "sap-icon://initiative";
					timeLineData[3].Icon = "sap-icon://accept";
					timeLineData[4].Icon = "sap-icon://account";
					timeLineData[6].Icon = "sap-icon://action";
					timeLineData[5].Icon = "sap-icon://my-sales-order";
					timeLineData[0].Delay = "0 mins";
					timeLineData[0].Status = "Accept";
					timeLineData[0].StartTime = timeLineData[0].Time;
					timeLineData[0].StartDt = timeLineData[0].Date;
					var tripData = this.getView().getModel("TripModel").getData();
					if (tripData.ReportInTime) {
						timeLineData[0].Date = tripData.ReportInDate;
						timeLineData[0].Time = tripData.ReportInTime;
					}
					if (tripData.InspEndTime) {
						timeLineData[1].Date = tripData.InspEndDate;
						timeLineData[1].Time = tripData.InspEndTime;
					}
					if (tripData.GateInTime) {
						timeLineData[2].Date = tripData.GateInDt;
						timeLineData[2].Time = tripData.GateInTime;
					}
					if (tripData.WeighmentEndTime) {
						timeLineData[3].Date = tripData.WeighmentEndDt;
						timeLineData[3].Time = tripData.WeighmentEndTime;
					}
					if (tripData.LoadingEndTime) {
						timeLineData[4].Date = tripData.LoadingEndDt;
						timeLineData[4].Time = tripData.LoadingEndTime;
					}
					if (tripData.GateOutTime) {
						timeLineData[5].Date = tripData.GateOutDt;
						timeLineData[5].Time = tripData.GateOutTime;
					}
					timeLineData[0].Delay = "0 mins";
					timeLineData[0].Status = "Success";
					timeLineData[0].StartTime = tripData.ReportInTime;
					for (var i = 1; i < oTimeLineData.results.length; i++) {
						if (timeLineData[i].Time) {
							//delay calculation
							if (timeLineData[i].Time.ms - timeLineData[i - 1].Time.ms > timeGuideArray[i - 1]) {
								//status red 
								//delay= i+1 -i
								timeLineData[i].Delay =
									/* (((((timeLineData[i].Time.ms - timeLineData[i - 1].Time.ms) - timeGuideArray[i - 1]) / 1000) / 60))
																		.toFixed(2).toString() +
																		" mins";*/
									(timeLineData[i].Time.ms - timeLineData[i - 1].Time.ms) - timeGuideArray[i - 1];
								var s = timeLineData[i].Delay;
								if (s) {
									// Pad to 2 or 3 digits, default is 2
									var ms = s % 1000;
									s = (s - ms) / 1000;
									var secs = s % 60;
									s = (s - secs) / 60;
									var mins = s % 60;
									var hrs = (s - mins) / 60;
									timeLineData[i].Delay = this.pad(hrs) + "hrs:" + this.pad(mins) + "mins";
								}
								timeLineData[i].Status = "Error";
							} else {
								timeLineData[i].Delay = "0 mins";
								timeLineData[i].Status = "Success";
							}
						}
					}
					this.getView().getModel("TimeLineSetModel").refresh(true);
				}.bind(this),
				error: function(oError) {
					MessageBox.error("TimeLine Error");
				}
			});
		},
		attachmentsSection: function() {
			var aFilters = [],
				aStatusFilter = [];
			aFilters.push(new Filter({
				path: "TruckNumber",
				value1: this.truckNumber,
				operator: FilterOperator.EQ
			}));
			aFilters.push(new Filter({
				path: "TripNumber",
				value1: this.tripNumber,
				operator: FilterOperator.EQ
			}));
			var oFilter = new Filter(aFilters, true);
			aStatusFilter.push(oFilter);
			var goRepFileName = this.getView().getModel("TripModel").getData().DriverPhoto;
			var srccRep = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," + "FileName=" +
				"'" +
				goRepFileName + "'" + ")/$value";
			var oPanelRep = this.getView().byId("idReportingAttachmentsPanel");
			var oHdrRepImage = new sap.m.Image({
				src: srccRep,
				width: "200px",
				height: "200px",
				press: function(oEvent) {
					this.getView().getModel("ImageModel").setProperty("/ImageSrc", srccRep);
					var oLink = oEvent.getSource();
					if (!this._pPopover) {
						this._pPopover = Fragment.load({
							id: this.getView().getId(),
							name: "ZSonic_PLMS.view.Fragment.ImagePopover",
							controller: this
						}).then(function(oPopover) {
							this.getView().addDependent(oPopover);
							return oPopover;
						}.bind(this));
					}
					this._pPopover.then(function(oPopover) {
						oPopover.openBy(oLink);
					});
				}.bind(this)
			}).addStyleClass("sapUiSmallMarginEnd");
			oPanelRep.addContent(oHdrRepImage);

			this.getOwnerComponent().getModel().read("/PLMS_Vehicle_InspectionSet", {
				filters: aStatusFilter,
				success: function(oAttachData) {
					//	this.getView().getModel("InspectionModel").setProperty("/Items", oAttachData.results);

					var oPanel = this.getView().byId("idInspectionAttachmentsPanel");
					oPanel.destroyContent();
					/*	if (this.vehicle === "Container") {*/
					var src1 = [],
						src2 = [],
						src3 = [],
						src4 = [],
						src5 = [],
						src6 = [],
						src7 = [],
						src8 = [],
						src9 = [],
						src10 = [],
						src11 = [],
						src12 = [];
					for (var i = 0; i < oAttachData.results.length; i++) {
						src1[i] = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," + "FileName=" +
							"'" +
							oAttachData.results[i].ContCleanImgFileName + "'" + ")/$value";
						src2[i] = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," + "FileName=" +
							"'" +
							oAttachData.results[i].RubberLeakFileName + "'" + ")/$value";
						src3[i] = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," + "FileName=" +
							"'" +
							oAttachData.results[i].VehImageFileName + "'" + ")/$value";
						src4[i] = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," + "FileName=" +
							"'" +
							oAttachData.results[i].ContImageFile + "'" + ")/$value";
						src5[i] = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," + "FileName=" +
							"'" +
							oAttachData.results[i].FumigationImgFileName + "'" + ")/$value";
						src6[i] = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," + "FileName=" +
							"'" +
							oAttachData.results[i].ContWeightImgFileName + "'" + ")/$value";
						src7[i] = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," + "FileName=" +
							"'" +
							oAttachData.results[i].ContCleanImgFileName + "'" + ")/$value";
						src8[i] = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," + "FileName=" +
							"'" +
							oAttachData.results[i].ContReadyImgFileName + "'" + ")/$value";
						src9[i] = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," + "FileName=" +
							"'" +
							oAttachData.results[i].ContLoadedImgFileName + "'" + ")/$value";
						src10[i] = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," +
							"FileName=" +
							"'" +
							oAttachData.results[i].FumigationDoneImgFileName + "'" + ")/$value";
						src11[i] = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," +
							"FileName=" +
							"'" +
							oAttachData.results[i].ContLockImgFileName + "'" + ")/$value";
						src12[i] = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," +
							"FileName=" +
							"'" +
							oAttachData.results[i].BagStripRmvImgFileName + "'" + ")/$value";
						if (oAttachData.results[i].ContCleanImgFileName) {
							var oImage1 = new sap.m.Image({
								src: src1[i],
								width: "200px",
								height: "200px",
								press: function(oEvent) {
									var srcc1 = oEvent.getSource().getSrc();
									this.getView().getModel("ImageModel").setProperty("/ImageSrc", srcc1);
									var oLink = oEvent.getSource();
									if (!this._pPopover) {
										this._pPopover = Fragment.load({
											id: this.getView().getId(),
											name: "ZSonic_PLMS.view.Fragment.ImagePopover",
											controller: this
										}).then(function(oPopover) {
											this.getView().addDependent(oPopover);
											return oPopover;
										}.bind(this));
									}
									this._pPopover.then(function(oPopover) {
										oPopover.openBy(oLink);
									});
								}.bind(this)
							}).addStyleClass("sapUiSmallMarginEnd");
							oPanel.addContent(oImage1);
						}
						if (oAttachData.results[i].RubberLeakFileName) {
							var oImage2 = new sap.m.Image({
								src: src2[i],
								width: "200px",
								height: "200px",
								press: function(oEvent) {
									var srcc2 = oEvent.getSource().getSrc();
									this.getView().getModel("ImageModel").setProperty("/ImageSrc", srcc2);
									var oLink = oEvent.getSource();
									if (!this._pPopover) {
										this._pPopover = Fragment.load({
											id: this.getView().getId(),
											name: "ZSonic_PLMS.view.Fragment.ImagePopover",
											controller: this
										}).then(function(oPopover) {
											this.getView().addDependent(oPopover);
											return oPopover;
										}.bind(this));
									}
									this._pPopover.then(function(oPopover) {
										oPopover.openBy(oLink);
									});
								}.bind(this)
							}).addStyleClass("sapUiSmallMarginEnd");
							oPanel.addContent(oImage2);
						}
						if (oAttachData.results[i].VehImageFileName) {
							var oImage3 = new sap.m.Image({
								src: src3[i],
								width: "200px",
								height: "200px",
								press: function(oEvent) {
									var srcc3 = oEvent.getSource().getSrc();
									this.getView().getModel("ImageModel").setProperty("/ImageSrc", srcc3);
									var oLink = oEvent.getSource();
									if (!this._pPopover) {
										this._pPopover = Fragment.load({
											id: this.getView().getId(),
											name: "ZSonic_PLMS.view.Fragment.ImagePopover",
											controller: this
										}).then(function(oPopover) {
											this.getView().addDependent(oPopover);
											return oPopover;
										}.bind(this));
									}
									this._pPopover.then(function(oPopover) {
										oPopover.openBy(oLink);
									});
								}.bind(this)
							}).addStyleClass("sapUiSmallMarginEnd");
							oPanel.addContent(oImage3);
						}
						if (oAttachData.results[i].ContImageFile) {
							var oImage4 = new sap.m.Image({
								src: src4[i],
								width: "200px",
								height: "200px",
								press: function(oEvent) {
									var srcc4 = oEvent.getSource().getSrc();
									this.getView().getModel("ImageModel").setProperty("/ImageSrc", srcc4);
									var oLink = oEvent.getSource();
									if (!this._pPopover) {
										this._pPopover = Fragment.load({
											id: this.getView().getId(),
											name: "ZSonic_PLMS.view.Fragment.ImagePopover",
											controller: this
										}).then(function(oPopover) {
											this.getView().addDependent(oPopover);
											return oPopover;
										}.bind(this));
									}
									this._pPopover.then(function(oPopover) {
										oPopover.openBy(oLink);
									});
								}.bind(this)
							}).addStyleClass("sapUiSmallMarginEnd");
							oPanel.addContent(oImage4);
						}
						if (oAttachData.results[i].FumigationImgFileName) {
							var oImage5 = new sap.m.Image({
								src: src5[i],
								width: "200px",
								height: "200px",
								press: function(oEvent) {
									var srcc5 = oEvent.getSource().getSrc();
									this.getView().getModel("ImageModel").setProperty("/ImageSrc", srcc5);
									var oLink = oEvent.getSource();
									if (!this._pPopover) {
										this._pPopover = Fragment.load({
											id: this.getView().getId(),
											name: "ZSonic_PLMS.view.Fragment.ImagePopover",
											controller: this
										}).then(function(oPopover) {
											this.getView().addDependent(oPopover);
											return oPopover;
										}.bind(this));
									}
									this._pPopover.then(function(oPopover) {
										oPopover.openBy(oLink);
									});
								}.bind(this)
							}).addStyleClass("sapUiSmallMarginEnd");
							oPanel.addContent(oImage5);
						}
						if (oAttachData.results[i].ContWeightImgFileName) {
							var oImage6 = new sap.m.Image({
								src: src6[i],
								width: "200px",
								height: "200px",
								press: function(oEvent) {
									var srcc6 = oEvent.getSource().getSrc();
									this.getView().getModel("ImageModel").setProperty("/ImageSrc", srcc6);
									var oLink = oEvent.getSource();
									if (!this._pPopover) {
										this._pPopover = Fragment.load({
											id: this.getView().getId(),
											name: "ZSonic_PLMS.view.Fragment.ImagePopover",
											controller: this
										}).then(function(oPopover) {
											this.getView().addDependent(oPopover);
											return oPopover;
										}.bind(this));
									}
									this._pPopover.then(function(oPopover) {
										oPopover.openBy(oLink);
									});
								}.bind(this)
							}).addStyleClass("sapUiSmallMarginEnd");
							oPanel.addContent(oImage6);
						}
						if (oAttachData.results[i].ContCleanImgFileName) {
							var oImage7 = new sap.m.Image({
								src: src7[i],
								width: "200px",
								height: "200px",
								press: function(oEvent) {
									var srcc7 = oEvent.getSource().getSrc();
									this.getView().getModel("ImageModel").setProperty("/ImageSrc", srcc7);
									var oLink = oEvent.getSource();
									if (!this._pPopover) {
										this._pPopover = Fragment.load({
											id: this.getView().getId(),
											name: "ZSonic_PLMS.view.Fragment.ImagePopover",
											controller: this
										}).then(function(oPopover) {
											this.getView().addDependent(oPopover);
											return oPopover;
										}.bind(this));
									}
									this._pPopover.then(function(oPopover) {
										oPopover.openBy(oLink);
									});
								}.bind(this)
							}).addStyleClass("sapUiSmallMarginEnd");
							oPanel.addContent(oImage7);
						}
						if (oAttachData.results[i].ContReadyImgFileName) {
							var oImage8 = new sap.m.Image({
								src: src8[i],
								width: "200px",
								height: "200px",
								press: function(oEvent) {
									var srcc8 = oEvent.getSource().getSrc();
									this.getView().getModel("ImageModel").setProperty("/ImageSrc", srcc8);
									var oLink = oEvent.getSource();
									if (!this._pPopover) {
										this._pPopover = Fragment.load({
											id: this.getView().getId(),
											name: "ZSonic_PLMS.view.Fragment.ImagePopover",
											controller: this
										}).then(function(oPopover) {
											this.getView().addDependent(oPopover);
											return oPopover;
										}.bind(this));
									}
									this._pPopover.then(function(oPopover) {
										oPopover.openBy(oLink);
									});
								}.bind(this)
							}).addStyleClass("sapUiSmallMarginEnd");
							oPanel.addContent(oImage8);
						}
						if (oAttachData.results[i].ContLoadedImgFileName) {
							var oImage9 = new sap.m.Image({
								src: src9[i],
								width: "200px",
								height: "200px",
								press: function(oEvent) {
									var srcc9 = oEvent.getSource().getSrc();
									this.getView().getModel("ImageModel").setProperty("/ImageSrc", srcc9);
									var oLink = oEvent.getSource();
									if (!this._pPopover) {
										this._pPopover = Fragment.load({
											id: this.getView().getId(),
											name: "ZSonic_PLMS.view.Fragment.ImagePopover",
											controller: this
										}).then(function(oPopover) {
											this.getView().addDependent(oPopover);
											return oPopover;
										}.bind(this));
									}
									this._pPopover.then(function(oPopover) {
										oPopover.openBy(oLink);
									});
								}.bind(this)
							}).addStyleClass("sapUiSmallMarginEnd");
							oPanel.addContent(oImage9);
						}
						if (oAttachData.results[i].FumigationDoneImgFileName) {
							var oImage10 = new sap.m.Image({
								src: src10[i],
								width: "200px",
								height: "200px",
								press: function(oEvent) {
									var srcc10 = oEvent.getSource().getSrc();
									this.getView().getModel("ImageModel").setProperty("/ImageSrc", srcc10);
									var oLink = oEvent.getSource();
									if (!this._pPopover) {
										this._pPopover = Fragment.load({
											id: this.getView().getId(),
											name: "ZSonic_PLMS.view.Fragment.ImagePopover",
											controller: this
										}).then(function(oPopover) {
											this.getView().addDependent(oPopover);
											return oPopover;
										}.bind(this));
									}
									this._pPopover.then(function(oPopover) {
										oPopover.openBy(oLink);
									});
								}.bind(this)
							}).addStyleClass("sapUiSmallMarginEnd");
							oPanel.addContent(oImage10);
						}
						if (oAttachData.results[i].ContLockImgFileName) {
							var oImage11 = new sap.m.Image({
								src: src11[i],
								width: "200px",
								height: "200px",
								press: function(oEvent) {
									var srcc11 = oEvent.getSource().getSrc();
									this.getView().getModel("ImageModel").setProperty("/ImageSrc", srcc11);
									var oLink = oEvent.getSource();
									if (!this._pPopover) {
										this._pPopover = Fragment.load({
											id: this.getView().getId(),
											name: "ZSonic_PLMS.view.Fragment.ImagePopover",
											controller: this
										}).then(function(oPopover) {
											this.getView().addDependent(oPopover);
											return oPopover;
										}.bind(this));
									}
									this._pPopover.then(function(oPopover) {
										oPopover.openBy(oLink);
									});
								}.bind(this)
							}).addStyleClass("sapUiSmallMarginEnd");
							oPanel.addContent(oImage11);
						}
						if (oAttachData.results[i].BagStripRmvImgFileName) {
							var oImage12 = new sap.m.Image({
								src: src12[i],
								width: "200px",
								height: "200px",
								press: function(oEvent) {
									var srcc12 = oEvent.getSource().getSrc();
									this.getView().getModel("ImageModel").setProperty("/ImageSrc", srcc12);
									var oLink = oEvent.getSource();
									if (!this._pPopover) {
										this._pPopover = Fragment.load({
											id: this.getView().getId(),
											name: "ZSonic_PLMS.view.Fragment.ImagePopover",
											controller: this
										}).then(function(oPopover) {
											this.getView().addDependent(oPopover);
											return oPopover;
										}.bind(this));
									}
									this._pPopover.then(function(oPopover) {
										oPopover.openBy(oLink);
									});
								}.bind(this)
							}).addStyleClass("sapUiSmallMarginEnd");
							oPanel.addContent(oImage12);
						}
					}
					/*	}*/
				}.bind(this),
				error: function(oAttachError) {
					MessageBox.error("Error in getting Attachments data");
				}
			});
			var obdItems = this.getView().getModel("TripOBDModel").getProperty("/Items");
			var oPanelGI = this.getView().byId("idLoadingAttachmentsPanel");
			for (var jj = 0; jj < obdItems.length; jj++) {
				var srcPhase1 = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," +
					"FileName=" +
					"'" +
					obdItems[jj].LoadPicPhase1 + "'" + ")/$value";
				if (obdItems[jj].LoadPicPhase1) {
					var oPh1Image = new sap.m.Image({
						src: srcPhase1,
						width: "200px",
						height: "200px",
						press: function(oEvent) {
							this.getView().getModel("ImageModel").setProperty("/ImageSrc", srcPhase1);
							var oLink = oEvent.getSource();
							if (!this._pPopover) {
								this._pPopover = Fragment.load({
									id: this.getView().getId(),
									name: "ZSonic_PLMS.view.Fragment.ImagePopover",
									controller: this
								}).then(function(oPopover) {
									this.getView().addDependent(oPopover);
									return oPopover;
								}.bind(this));
							}
							this._pPopover.then(function(oPopover) {
								oPopover.openBy(oLink);
							});
						}.bind(this)
					}).addStyleClass("sapUiSmallMarginEnd");
					oPanelGI.addContent(oPh1Image);
				}
				var srcPhase2 = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," +
					"FileName=" +
					"'" +
					obdItems[jj].LoadPicPhase2 + "'" + ")/$value";
				if (obdItems[jj].LoadPicPhase2) {
					var oPh2Image = new sap.m.Image({
						src: srcPhase2,
						width: "200px",
						height: "200px",
						press: function(oEvent) {
							this.getView().getModel("ImageModel").setProperty("/ImageSrc", srcPhase2);
							var oLink = oEvent.getSource();
							if (!this._pPopover) {
								this._pPopover = Fragment.load({
									id: this.getView().getId(),
									name: "ZSonic_PLMS.view.Fragment.ImagePopover",
									controller: this
								}).then(function(oPopover) {
									this.getView().addDependent(oPopover);
									return oPopover;
								}.bind(this));
							}
							this._pPopover.then(function(oPopover) {
								oPopover.openBy(oLink);
							});
						}.bind(this)
					}).addStyleClass("sapUiSmallMarginEnd");
					oPanelGI.addContent(oPh2Image);
				}
				var srcPhase3 = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," +
					"FileName=" +
					"'" +
					obdItems[jj].LoadPicPhase3 + "'" + ")/$value";
				if (obdItems[jj].LoadPicPhase3) {
					var oPh3Image = new sap.m.Image({
						src: srcPhase3,
						width: "200px",
						height: "200px",
						press: function(oEvent) {
							this.getView().getModel("ImageModel").setProperty("/ImageSrc", srcPhase3);
							var oLink = oEvent.getSource();
							if (!this._pPopover) {
								this._pPopover = Fragment.load({
									id: this.getView().getId(),
									name: "ZSonic_PLMS.view.Fragment.ImagePopover",
									controller: this
								}).then(function(oPopover) {
									this.getView().addDependent(oPopover);
									return oPopover;
								}.bind(this));
							}
							this._pPopover.then(function(oPopover) {
								oPopover.openBy(oLink);
							});
						}.bind(this)
					}).addStyleClass("sapUiSmallMarginEnd");
					oPanelGI.addContent(oPh3Image);
				}
				var srcPhase4 = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," +
					"FileName=" +
					"'" +
					obdItems[jj].LoadPicPhase4 + "'" + ")/$value";
				if (obdItems[jj].LoadPicPhase4) {
					var oPh4Image = new sap.m.Image({
						src: srcPhase4,
						width: "200px",
						height: "200px",
						press: function(oEvent) {
							this.getView().getModel("ImageModel").setProperty("/ImageSrc", srcPhase4);
							var oLink = oEvent.getSource();
							if (!this._pPopover) {
								this._pPopover = Fragment.load({
									id: this.getView().getId(),
									name: "ZSonic_PLMS.view.Fragment.ImagePopover",
									controller: this
								}).then(function(oPopover) {
									this.getView().addDependent(oPopover);
									return oPopover;
								}.bind(this));
							}
							this._pPopover.then(function(oPopover) {
								oPopover.openBy(oLink);
							});
						}.bind(this)
					}).addStyleClass("sapUiSmallMarginEnd");
					oPanelGI.addContent(oPh4Image);
				}
				var srcPhase5 = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," +
					"FileName=" +
					"'" +
					obdItems[jj].LoadPicPhase5 + "'" + ")/$value";
				if (obdItems[jj].LoadPicPhase5) {
					var oPh5Image = new sap.m.Image({
						src: srcPhase5,
						width: "200px",
						height: "200px",
						press: function(oEvent) {
							this.getView().getModel("ImageModel").setProperty("/ImageSrc", srcPhase5);
							var oLink = oEvent.getSource();
							if (!this._pPopover) {
								this._pPopover = Fragment.load({
									id: this.getView().getId(),
									name: "ZSonic_PLMS.view.Fragment.ImagePopover",
									controller: this
								}).then(function(oPopover) {
									this.getView().addDependent(oPopover);
									return oPopover;
								}.bind(this));
							}
							this._pPopover.then(function(oPopover) {
								oPopover.openBy(oLink);
							});
						}.bind(this)
					}).addStyleClass("sapUiSmallMarginEnd");
					oPanelGI.addContent(oPh5Image);
				}
				var srcPhase6 = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," +
					"FileName=" +
					"'" +
					obdItems[jj].LoadPicPhase6 + "'" + ")/$value";
				if (obdItems[jj].LoadPicPhase6) {
					var oPh6Image = new sap.m.Image({
						src: srcPhase6,
						width: "200px",
						height: "200px",
						press: function(oEvent) {
							this.getView().getModel("ImageModel").setProperty("/ImageSrc", srcPhase6);
							var oLink = oEvent.getSource();
							if (!this._pPopover) {
								this._pPopover = Fragment.load({
									id: this.getView().getId(),
									name: "ZSonic_PLMS.view.Fragment.ImagePopover",
									controller: this
								}).then(function(oPopover) {
									this.getView().addDependent(oPopover);
									return oPopover;
								}.bind(this));
							}
							this._pPopover.then(function(oPopover) {
								oPopover.openBy(oLink);
							});
						}.bind(this)
					}).addStyleClass("sapUiSmallMarginEnd");
					oPanelGI.addContent(oPh6Image);
				}
			}
			if (this.tripStatus === "GO") {
				var goFileName = this.getView().getModel("TripModel").getData().ImageFileName;
				var srcc = "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + this.obdNumber + "'" + "," + "FileName=" +
					"'" +
					goFileName + "'" + ")/$value";
				var oPanelGO = this.getView().byId("idGateOutAttachmentsPanel");
				var oHdrImage = new sap.m.Image({
					src: srcc,
					width: "200px",
					height: "200px",
					press: function(oEvent) {
						this.getView().getModel("ImageModel").setProperty("/ImageSrc", srcc);
						var oLink = oEvent.getSource();
						if (!this._pPopover) {
							this._pPopover = Fragment.load({
								id: this.getView().getId(),
								name: "ZSonic_PLMS.view.Fragment.ImagePopover",
								controller: this
							}).then(function(oPopover) {
								this.getView().addDependent(oPopover);
								return oPopover;
							}.bind(this));
						}
						this._pPopover.then(function(oPopover) {
							oPopover.openBy(oLink);
						});
					}.bind(this)
				}).addStyleClass("sapUiSmallMarginEnd");
				oPanelGO.addContent(oHdrImage);
			}
		},
		onCancelTripPress: function() {
			var payload = {
				"Markasdelete": true,
				"TripStatus": "CL"
			};
			this.getOwnerComponent().getModel().update("/PLMS_outbound_HdrSet(TruckNumber='" + this.truckNumber + "',ObdNumber='" + this.obdNumber +
				"',TripNumber='" + this.tripNumber + "')", payload, {
					success: function(oData) {
						//	this.readHeaderEntitySet();
						MessageBox.success("This Trip has been cancelled successfully");
						this.goToMain();
					}.bind(this),
					error: function(error) {
						MessageBox.error("Error in cancelling the trip");
					}
				});
		},
		createLULNewRow: function(oNewItem) {
			var oCell = [];
			oCell[0] = new sap.m.Text({
				text: oNewItem.Maktx
			});
			oCell[1] = new sap.m.Text({
				text: oNewItem.ObdItem
			});
			oCell[2] = new sap.m.Text({
				text: oNewItem.Lgort
			});
			oCell[3] = new sap.m.Text({
				text: oNewItem.Quantity
			});
			oCell[4] = new sap.m.Text({
				text: oNewItem.SalesUnit
			});
			oCell[5] = new sap.m.Select({
				//	visible: setEnableDisable.getProperty("/Select"),
				//	width: setEnableDisable.getProperty("/SelectWidth")
			});
			this.addContainersToSelect(oCell[5]);
			oCell[6] = new sap.m.Input({
				width: "9rem",
				valueHelpRequest: function(oEvent) {
					var material = oNewItem.Matnr;
					var plant = oNewItem.Plant;
					var stLoc = oNewItem.Lgort;
					this.batchInput = oEvent.getSource();
					if (oNewItem.BatchEnabled) {
						this.readBatchF4Values(material, plant, stLoc);
						if (!this.dialogBatchNo) {
							this.dialogBatchNo = sap.ui.xmlfragment(this.getView().getId(), "ZSonic_PLMS.view.Fragment.BatchcNoFragment", this);
							this.getView().addDependent(this.dialogBatchNo);
						}
						this.dialogBatchNo.open();
					}
				}.bind(this),
				showValueHelp: true,
				enabled: this.checkLoadingUnloadingLineItemsBatchEnabled(oNewItem.BatchEnabled, oNewItem.WeighStatus)
			});
			oCell[7] = new sap.m.Input({});
			oCell[8] = new sap.m.Input({});
			oCell[9] = new sap.m.Input({});
			oCell[10] = new sap.m.Text({
				width: "7rem"
			});
			oCell[11] = new sap.m.Text({
				width: "7rem"
			});
			oCell[12] = new sap.m.Button({
				icon: "sap-icon://edit",
				type: "Emphasized",
				press: function(oEvent) {
					var oItems = oEvent.getSource().getParent().getCells();
					if (oNewItem.BatchEnabled) {
						for (var t = 6; t < 10; t++) {
							oItems[t].setEnabled(true);
						}
					} else {
						for (var tt = 7; tt < 10; tt++) {
							oItems[tt].setEnabled(true);
						}
					}

				}.bind(this)
			});
			oCell[13] = new sap.m.Button({
				icon: "sap-icon://save",
				type: "Accept",
				press: function(oEvent) {
					var oParent = oEvent.getSource().getParent();
					var combinedStatus = this.getView().getModel("TripModel").getData().CombinedWeightValue;
					if (combinedStatus === 0) {
						MessageBox.error("Please Save Combined Weight status");
					} else if (combinedStatus === 1) {
						this.saveNewLineItems(oNewItem, oParent, combinedStatus);
					} else {
						var aItemFilters = [],
							aItemsAllFilters = [];
						aItemFilters.push(new Filter({
							path: "TruckNumber",
							value1: this.truckNumber,
							operator: FilterOperator.EQ
						}));
						aItemFilters.push(new Filter({
							path: "TripNumber",
							value1: this.tripNumber,
							operator: FilterOperator.EQ
						}));
						var oItemFilter = new Filter(aItemFilters, true);
						aItemsAllFilters.push(oItemFilter);
						this.getOwnerComponent().getModel().read("/PLMS_Obd_ItemSet", {
							filters: aItemsAllFilters,
							success: function(oData) {
								var totalLineItems = oData.results;
								var anyOneLoaded = false;
								for (var qqq = 0; qqq < totalLineItems.length; qqq++) {
									if (totalLineItems[qqq].LineItemLoaded) {
										anyOneLoaded = true;
										break;
									}
								}
								if (!anyOneLoaded) {
									//first line item loading
									this.saveNewLineItems(oNewItem, oParent, combinedStatus);
								} else {
									//if current lineitem is one among the already loaded line items
									var contains = false;
									for (var kkk = 0; kkk < totalLineItems.length; kkk++) {
										if (totalLineItems[kkk].LineItemLoaded) {
											if (totalLineItems[kkk].ObdItem === oParent.getCells()[1].getText()) {
												contains = true;
											}
										}
									}
									if (contains) {
										this.saveNewLineItems(oNewItem, oParent, combinedStatus);
									} else {
										var weighmentNotDone = false;
										for (var hhh = 0; hhh < totalLineItems.length; hhh++) {
											if (totalLineItems[hhh].LineItemLoaded) {
												if (totalLineItems[hhh].WeighStatus === "" || totalLineItems[hhh].WeighStatus === undefined) {
													weighmentNotDone = true;
													break;
												}
											}
										}
										if (weighmentNotDone) {
											MessageBox.error("Weighment for one of the line items is pending.Please check again");
										} else {
											if (this.getView().getModel("TripModel").getData().TripStatus === "WR") {
												if (oNewItem.WeighStatus === "REJECTED") {
													this.saveNewLineItems(oNewItem, oParent, combinedStatus);
												} else {
													MessageBox.error("Please load the Rejected Line Item");
												}
											} else {
												this.saveNewLineItems(oNewItem, oParent, combinedStatus);

											}
										}
									}
								}
							}.bind(this),
							error: function(oError) {

							}
						});
					}
				}.bind(this)
			});
			oCell[14] = new sap.m.Button({
				icon: "sap-icon://delete",
				type: "Reject",
				press: function(oEvent) {
					var tabelObj = oEvent.getSource().getParent().getParent();
					tabelObj.removeItem(oEvent.getSource().getParent());
				}.bind(this)
			});
			oCell[15] = new sap.m.Text({
				text: oNewItem.WeighStatus
			});
			var aColList = new sap.m.ColumnListItem({
				cells: oCell
			});
			return aColList;
		},
		enablePlus: function(results, weighStatus) {
			if (this.tripStatus === "LC" || this.tripStatus === "WC" || this.tripStatus === "GO" || this.tripStatus === "PG") {
				return false;
			} else {
				if (results.BatchAdded === "000") {
					/*var role = this.getOwnerComponent().getModel("RoleModel").getProperty("/Roles");
					var activity = this.getOwnerComponent().getModel("RoleModel").getProperty("/Activities");
					var inspOK = this.getView().getModel("TripModel").getData().InspectionOkFlag;
					if (inspOK === "X") {
						if (role && activity) {
							var Role = false;
							for (var aa = 0; aa < role.length; aa++) {
								if (role[aa] === "Loading") {
									if (activity[aa] === "1" || activity[aa] === "2") {
										Role = true;
									}
								}
							}
							if (Role && weighStatus !== "ACCEPTED") {
								return true;
							} else {
								return false;
							}
						}
					} else {
						return false;
					}*/
					var Role = false;
					var inspOK = this.getView().getModel("TripModel").getData().InspectionOkFlag;
					var items = this.getOwnerComponent().getModel("AuthorizationModel").getProperty("/Items");
					var plant = this.getView().getModel("TripModel").getData().Plant;
					if (inspOK === "X") {
						if (items) {
							var auth = items;
							if (auth) {
								var authl = auth.length;
								/*	return true;*/
								for (var i = 0; i < authl; i++) {
									if (auth[i].Werks === plant) {
										if (auth[i].Module === "Loading") {
											if (auth[i].Actvt === "1" || auth[i].Actvt === "2") {
												Role = true;
												break;
											}
										}
									}
								}

								if (Role && weighStatus !== "ACCEPTED") {
									return true;
								} else {
									return false;
								}
							} else {
								return false;
							}
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			}
		},
		GateInFileUpload: function(obdNo) {
			var role = this.getOwnerComponent().getModel("RoleModel").getProperty("/Roles");
			var activity = this.getOwnerComponent().getModel("RoleModel").getProperty("/Activities");
			var items = this.getView().getModel("TripOBDModel").getProperty("/Items");
			for (var i = 0; i < items.length; i++) {
				if ("00" + items[i].ObdNumber === obdNo) {
					if (items[i].ManualCheck === "X") {
						if (this.tripStatus === "LC") {
							if (role && activity) {
								var Role = false;
								for (var aa = 0; aa < role.length; aa++) {
									if (role[aa] === "Weighment") {
										if (activity[aa] === "1" || activity[aa] === "2") {
											Role = true;
										}
									}
								}
								if (Role) {
									return true;
								} else {
									return false;
								}
							}
						} else {
							return false;
						}
					} else {
						return false;
					}
				}
			}
		},
		onLoadingCompletedPress: function() {
			MessageBox.confirm("Are you sure the loading has been completed?", {
				title: "Confirm",
				onClose: function(oPressEvent) {
					var oPressText = oPressEvent;
					if (oPressText === "OK") {
						var rem = this.getView().byId("idLoadingCompletedRemarks").getSelectedKey();
						this.getOwnerComponent().getModel().read("/PLMS_Obd_ItemSet", {
							filters: this.aStatusFilter,
							success: function(oLoadingBatchData) {
								this.getView().getModel("LoadingItemsBatchModel").setProperty("/Items", oLoadingBatchData.results);
								var loadingItems = this.getView().getModel("LoadingItemsBatchModel").getProperty("/Items");
								var loadingLength = loadingItems.length;
								var batch = true;
								for (var i = 0; i < loadingLength; i++) {
									if (loadingItems[i].BatchEnabled) {
										if (loadingItems[i].Batch === "") {
											batch = false;
											break;
										}
									}
								}
								if (batch) {
									var payload = {
										"LoadinCmptRemarks": rem,
										"TripStatus": "LC"
									};
									this.getOwnerComponent().getModel().update("/PLMS_outbound_HdrSet(TruckNumber='" + this.truckNumber +
										"',ObdNumber='" +
										this.obdNumber +
										"',TripNumber='" + this.tripNumber + "')", payload, {
											method: "PUT",
											success: function(response) {
												MessageBox.success("Loading Details saved successfully");
												this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
													filters: this.aStatusFilter,
													success: function(oData) {
														this.getView().getModel("TripModel").setData(oData.results[0]);
														this.getView().getModel("TripOBDModel").setProperty("/Items", oData.results);
														this.tripStatus = this.getView().getModel("TripModel").getData().TripStatus;
														this.timeLineUpdate();
														if (this.tripStatus !== "" || this.tripStatus !== undefined) {
															this.attachmentsSection();
														}
														this.getView().getModel("TripModel").refresh(true);
														this.callEnableDisableFunction();
														this.getView().byId("idGateInMainPanel").destroyContent();
														this.getView().byId("idLoadingUnloading").destroyContent();
														var oItems = this.getView().getModel("TripOBDModel").getProperty("/Items");
														for (var ee = 0; ee < oItems.length; ee++) {
															this.createGateInTabContent(ee);
															this.createLoadingUnloadingMaterialsTabContent(ee);
														}
														this.loadingCompleted = true;
													}.bind(this),
													error: function(oError) {
														MessageBox.warning("Error occurred while reading Header data");
													}
												});
											}.bind(this)
										});
								} else {
									MessageBox.error("Please enter Batch Number for all the Line Items");
								}
							}.bind(this)
						});
					}
				}.bind(this)
			});
		},
		onDoPGIPress: function() {
			var aFilters = [],
				aStatusFilter = [];
			aFilters.push(new Filter({
				path: "TruckNumber",
				value1: this.truckNumber,
				operator: FilterOperator.EQ
			}));
			aFilters.push(new Filter({
				path: "TripNumber",
				value1: this.tripNumber,
				operator: FilterOperator.EQ
			}));
			var oFilter = new Filter(aFilters, true);
			aStatusFilter.push(oFilter);
			this.aStatusFilter = aStatusFilter;
			this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
				filters: aStatusFilter,
				success: function(oExtData) {
					this.getView().getModel("TripOBDModel").setProperty("/Items", oExtData.results);
					var items = this.getView().getModel("TripOBDModel").getProperty("/Items");
					var itemsLength = items.length;
					var payloadString = ""; //items[0].ObdNumber;
					for (var i = 0; i < itemsLength; i++) {
						if (!(items[i].PgiDone)) {
							if (payloadString.length === 0) {
								payloadString = items[i].ObdNumber;
							} else {
								payloadString = payloadString + "," + items[i].ObdNumber;
							}
						}
					}
					//payloadString.substring(1);
					if (payloadString.length > 0) {
						var payload = {
							"Vbeln": payloadString,
							"TruckNumber": this.truckNumber,
							"TripNumber": this.tripNumber
						};
						this.getOwnerComponent().getModel().create("/PLMS_OBD_PGISet", payload, {
							success: function(oData) {
								MessageBox.success("Data has been sent to PGI Successfully");
								this.getView().byId("idPGIButton").setEnabled(false);
								this.readHeaderEntitySet();
							}.bind(this),
							error: function(oError) {
								var jsonData = JSON.parse(oError.responseText).error.innererror.errordetails;
								var jsonLength = jsonData.length - 1;
								if (jsonLength >= 0) {
									var finalError = jsonData[0].message;
									for (var jj = 1; jj < jsonLength; jj++) {
										finalError = finalError + "\n" + jsonData[jj].message;
									}
									MessageBox.error(finalError);
								}
							}
						});
					}
				}.bind(this),
				error: function(oExterror) {
					//	MessageBox.error("No data is available for selected filters.Please select valid Filters");
				}.bind(this)
			});

			/* var aPayload = [];
			aPayload.push(payload);
			for (var i = 0; i < itemsLength; i++) {
				var payload = {
					"Vbeln": items[i].ObdNumber
				};
				aPayload.push(payload);
			}
			if (aPayload.length > 0) {
				var oModel = this.getOwnerComponent().getModel();
				oModel.setUseBatch(true);
				var aDeferredGroups = oModel.getDeferredGroups();
				aDeferredGroups = aDeferredGroups.concat(["PGIGroup"]);
				oModel.setDeferredGroups(aDeferredGroups);
				for (var j = 0; j < aPayload.length; j++) {
					oModel.create("/PLMS_OBD_PGISet", aPayload[j], {
						groupId: "PGIGroup"
					});
				}
				oModel.submitChanges({
					groupId: "PGIGroup",
					success: function(req, res) {
						MessageBox.success("Data sent to PGI Successfully");
					},
					error: function(error) {
						MessageBox.error(error);
						if (error) {
							this.getView().getModel("PGIModel").setProperty("/Items", error.results);
							if (!this.dialogPGI) {
								this.dialogPGI = sap.ui.xmlfragment(this.getView().getId(), "ZSonic_PLMS.view.Fragment.PGIErrors", this);
								this.getView().addDependent(this.dialogPGI);
							}
							this.dialogPGI.open();
						}
					}
				});
			}*/
		},
		onClosePGIDialog: function() {
			this.dialogPGI.close();
		},
		checkWeighmentCompleted: function() {
			if (this.tripStatus === "LC") {
				var rem = this.getView().byId("idWeightmentRemarks").getSelectedKey();
				var weighReq = this.getView().getModel("TripModel").getData().WeighRequired;
				var payload = {
					"WeightmentRemarks": rem,
					"TripStatus": ""
				};
				if (weighReq === 0) {
					var imProper = false;
					var weighmentStatus = "";
					var aItemsFilters = [],
						aItemsAllFilter = [];
					aItemsFilters.push(new Filter({
						path: "TruckNumber",
						value1: this.truckNumber,
						operator: FilterOperator.EQ
					}));
					aItemsFilters.push(new Filter({
						path: "TripNumber",
						value1: this.tripNumber,
						operator: FilterOperator.EQ
					}));
					aItemsFilters.push(new Filter({
						path: "BatchAdded",
						value1: "000",
						operator: FilterOperator.EQ
					}));
					var oItemsFilter = new Filter(aItemsFilters, true);
					aItemsAllFilter.push(oItemsFilter);
					this.getOwnerComponent().getModel().read("/PLMS_Obd_ItemSet", {
						filters: aItemsAllFilter,
						success: function(oLoadingData) {
							this.getView().getModel("LoadingItemsModel").setProperty("/Items", oLoadingData.results);
							var items = this.getView().getModel("LoadingItemsModel").getProperty("/Items");
							var combWeightStatus = this.getView().getModel("LoadingItemsModel").getProperty("/CombinedWeight");
							var combinedImproper = false;
							if (combWeightStatus) {
								for (var s = 0; s < items.length; s++) {
									if (items[s].WeighStatus === "" || items[s].WeighStatus === "REJECTED" || items[s].WeighStatus === undefined) {
										combinedImproper = true;
										break;
									}
								}
								if (!combinedImproper) {
									weighmentStatus = "WC";
								}
							} else {
								for (var kk = 0; kk < items.length; kk++) {
									if (items[kk].WeighStatus === "" || items[
											kk].WeighStatus === "REJECTED" || items[kk].WeighStatus === undefined) {
										imProper = true;
										break;
									}
								}
								if (!imProper) {
									weighmentStatus = "WC";
								}
							}
							if (weighmentStatus === "WC") {
								if (rem !== "") {
									payload.TripStatus = "WC";
									this.weightmentCompleteUpdateCall(payload);
								} else {
									MessageBox.error("Please enter Remarks");
								}
							} else {
								MessageBox.error("Please ensure all the weights are entered and accepted");
							}
						}.bind(this)
					});
				} else {
					if (rem !== "") {
						payload.TripStatus = "WC";
						this.weightmentCompleteUpdateCall(payload);
					} else {
						MessageBox.error("Please enter Remarks");
					}
				}
			} else {
				MessageBox.error("Please complete loading first");
			}
		},
		enableApprovalNeeded: function(needed, check) {
			if (check) {
				return needed;
			} else {
				return 1;
			}
		},
		createLoadingMaterialsTabContent: function(i) {
			if (this.tripNumber !== "0000000000" && this.tripNumber) {
				var obdNo = this.getView().getModel("TripOBDModel").getData().Items[i].ObdNumber;
				var count = obdNo.length;
				if (count !== 10) {
					for (var h = 0; h < 10 - count; h++) {
						obdNo = "0" + obdNo;
					}
				}
				var cutName = this.getView().getModel("TripOBDModel").getData().Items[i].Name1;
				var aItemFilters = [],
					aItemsAllFilters = [];
				aItemFilters.push(new Filter({
					path: "TruckNumber",
					value1: this.truckNumber,
					operator: FilterOperator.EQ
				}));
				aItemFilters.push(new Filter({
					path: "TripNumber",
					value1: this.tripNumber,
					operator: FilterOperator.EQ
				}));
				aItemFilters.push(new Filter({
					path: "ObdNumber",
					value1: obdNo,
					operator: FilterOperator.EQ
				}));
				aItemFilters.push(new Filter({
					path: "BatchAdded",
					value1: "000",
					operator: FilterOperator.EQ
				}));
				/*aItemFilters.push(new Filter({
					path: "CombinedFlag",
					value1: "false",
					operator: FilterOperator.EQ
				}));*/
				var oItemFilter = new Filter(aItemFilters, true);
				aItemsAllFilters.push(oItemFilter);
				this.getOwnerComponent().getModel().read("/PLMS_Obd_ItemSet", {
					filters: aItemsAllFilters,
					success: function(oData) {
						this.itemOdata = oData;
						this.plantCode = oData.results[0].Werks;
						this.lGort = oData.results[0].Lgort;
						var tableid = "id" + obdNo + "Table";
						var panelId = "id" + obdNo + "Panel";
						var panelHeader = "OBD Number :" + obdNo + "(" + cutName + ")";
						var oTable = new sap.m.Table(tableid, {
							columns: [
								new sap.m.Column({
									header: new sap.m.Text({
										text: "Sale Order No"
									})
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "OBD Number"
									})
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "Material"
									})
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "Material Description"
									})
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "Quantity"
									})
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "Measuring Unit"
									})
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "Loading/Unloading Gate"
									}),
									width: "15rem"
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "OBD Item"
									}),
									visible: false
								}),
								new sap.m.Column({
									header: new sap.m.Text({
										text: "Lgort"
									}),
									visible: false
								})
							]
						});
						for (var ll = 0; ll < oData.results.length; ll++) {
							var aColList = this.createTableRows(ll, oData.results);
							oTable.addItem(aColList);
						}
						var oPanel = new sap.m.Panel({
							id: panelId,
							headerText: panelHeader,
							expanded: true,
							expandable: true,
							content: [oTable]
						});
						this.getView().byId("idLoadingMaterialsTab").addContent(oPanel);
					}.bind(this),
					error: function(error) {
						/*var err = "No Loading Materials details for OBD: " + obdNo;
						MessageBox.warning(err);*/
					}
				});
			}
		},
		addRemarksGateInDropDown: function(oCell) {
			var aShipFilters = [],
				aShipStatusFilter = [];
			aShipFilters.push(new Filter({
				path: "Activity",
				value1: "GI",
				operator: FilterOperator.EQ
			}));
			var oShipFilter = new Filter(aShipFilters, true);
			aShipStatusFilter.push(oShipFilter);
			this.getOwnerComponent().getModel().read("/RemarksSet", {
				filters: aShipStatusFilter,
				success: function(oContData) {
					var contNo = oContData.results.length;
					var contItems = oContData.results;
					for (var i = 0; i < contNo; i++) {
						var aa = new sap.ui.core.Item({
							key: contItems[i].RemarkCode,
							text: contItems[i].RemarkDesc
						});
						oCell.addItem(aa);
					}
				}.bind(this)
			});
		},
		addRemarksLULDropDown: function(oCell) {
			var aShipFilters = [],
				aShipStatusFilter = [];
			aShipFilters.push(new Filter({
				path: "Activity",
				value1: "LD",
				operator: FilterOperator.EQ
			}));
			var oShipFilter = new Filter(aShipFilters, true);
			aShipStatusFilter.push(oShipFilter);
			this.getOwnerComponent().getModel().read("/RemarksSet", {
				filters: aShipStatusFilter,
				success: function(oContData) {
					var contNo = oContData.results.length;
					var contItems = oContData.results;
					for (var i = 0; i < contNo; i++) {
						var aa = new sap.ui.core.Item({
							key: contItems[i].RemarkCode,
							text: contItems[i].RemarkDesc
						});
						oCell.addItem(aa);
					}
				}.bind(this)
			});
		},
		onPressRefreshWeights: function() {
			this.getView().byId("idGateInMainPanel").destroyContent();
			this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
				filters: this.aStatusFilter,
				success: function(oData) {
					for (var mm = 0; mm < oData.results.length; mm++) {
						this.createGateInTabContent(mm);
					}
				}.bind(this),
				error: function(error) {
					MessageBox.error("Error in getting Weighments Data");
				}
			});
		},
		checkInspectionParameters: function() {
			var status = this.tripStatus;
			/*	var role = this.getOwnerComponent().getModel("RoleModel").getProperty("/Roles");
				var activity = this.getOwnerComponent().getModel("RoleModel").getProperty("/Activities");*/
			var items = this.getOwnerComponent().getModel("AuthorizationModel").getProperty("/Items");
			var auth = items;
			var plant = this.getView().getModel("TripModel").getData().Plant;
			var Role = false;
			if (status === "IP" || status === "RD") {
				/*if (role && activity) {
					var Role = false;
					for (var aa = 0; aa < role.length; aa++) {
						if (role[aa] === "Inspection") {
							if (activity[aa] === "1" || activity[aa] === "2") {
								Role = true;
							}
						}
					}
					if (Role) {
						return true;
					} else {
						return false;
					}
				}*/
				if (items) {
					if (auth) {
						var authl = auth.length;
						for (var i = 0; i < authl; i++) {
							if (auth[i].Werks === plant) {
								if (auth[i].Module === "Inspection") {
									if (auth[i].Actvt === "1" || auth[i].Actvt === "2") {
										Role = true;
										break;
									}
								}
							}
						}
						if (Role) {
							return true;
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}

			} else {
				return false;
			}
		},
		checkNewInspectionParameters: function(radio) {
			var status = this.tripStatus;
			/*	var role = this.getOwnerComponent().getModel("RoleModel").getProperty("/Roles");
				var activity = this.getOwnerComponent().getModel("RoleModel").getProperty("/Activities");*/
			var items = this.getOwnerComponent().getModel("AuthorizationModel").getProperty("/Items");
			var auth = items;
			var plant = this.getView().getModel("TripModel").getData().Plant;
			if (radio === 1) {
				if (status === "IP" || status === "RD") {
					/*if (role && activity) {
						var Role = false;
						for (var aa = 0; aa < role.length; aa++) {
							if (role[aa] === "Inspection") {
								if (activity[aa] === "1" || activity[aa] === "2") {
									Role = true;
								}
							}
						}
						if (Role) {
							return true;
						} else {
							return false;
						}
					}*/
					if (items) {
						var Role = false;
						for (var i = 0; i < auth.length; i++) {
							if (auth[i].Werks === plant) {
								if (auth[i].Module === "Inspection") {
									if (auth[i].Actvt === "1" || auth[i].Actvt === "2") {
										Role = true;
									}
								}
							}
						}
						if (Role) {
							return true;
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		checkNewSHInspectionParameters: function(radio) {
			var status = this.tripStatus;
			/*var role = this.getOwnerComponent().getModel("RoleModel").getProperty("/Roles");
			var activity = this.getOwnerComponent().getModel("RoleModel").getProperty("/Activities");*/
			var items = this.getOwnerComponent().getModel("AuthorizationModel").getProperty("/Items");
			var plant = this.getView().getModel("TripModel").getData().Plant;
			if (radio === 0) {
				if (status === "IP" || status === "RD") {
					/*	if (role && activity) {
							var Role = false;
							for (var aa = 0; aa < role.length; aa++) {
								if (role[aa] === "Inspection") {
									if (activity[aa] === "1" || activity[aa] === "2") {
										Role = true;
									}
								}
							}
							if (Role) {
								return true;
							} else {
								return false;
							}
						}*/
					if (items) {
						var Role = false;
						var auth = items;
						for (var i = 0; i < auth.length; i++) {
							if (auth[i].Werks === plant) {
								if (auth[i].Module === "Inspection") {
									if (auth[i].Actvt === "1" || auth[i].Actvt === "2") {
										Role = true;
										break;
									}
								}
							}
						}
						if (Role) {
							return true;
						} else {
							return false;
						}
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		checkInspectionApprParameters: function(apprlneeded, chk) {
			var status = this.tripStatus;
			var role = this.getOwnerComponent().getModel("RoleModel").getProperty("/Roles");
			var activity = this.getOwnerComponent().getModel("RoleModel").getProperty("/Activities");
			if (status === "IP" || status === "RD") {
				if (role && activity) {
					var Role = false;
					for (var aa = 0; aa < role.length; aa++) {
						if (role[aa] === "InspectionAppr") {
							if (activity[aa] === "1" || activity[aa] === "2") {
								Role = true;
							}
						}
					}
					if (Role && apprlneeded === 0 && chk) {
						return true;
					} else {
						return false;
					}
				}
			} else {
				return false;
			}
		},
		inspectionButtonParameters: function() {
			var status = this.tripStatus;
			var items = this.getOwnerComponent().getModel("AuthorizationModel").getProperty("/Items");
			var plant = this.getView().getModel("TripModel").getData().Plant;
			if (status === "" || status === "RD" || status === "IP") {
				var Role = false;
				/*	if (role && activity) {
						var Role = false;
						for (var aa = 0; aa < role.length; aa++) {
							if (role[aa] === "InspectionAppr" || role[aa] === "Inspection") {
								if (activity[aa] === "1" || activity[aa] === "2") {
									Role = true;
								}
							}
						}
						if (Role) {
							return true;
						} else {
							return false;
						}
					}*/
				if (items) {
					var auth = items;
					if (auth) {
						var authl = auth.length;
						for (var i = 0; i < authl; i++) {
							if (auth[i].Werks === plant) {
								if (auth[i].Module === "Inspection") {
									if (auth[i].Actvt === "1" || auth[i].Actvt === "2") {
										Role = true;
										break;
									}
								}
							}
						}
						if (Role) {
							return true;
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}

			} else {
				return false;
			}
		},
		checkLoadingUnloadingLineItems: function(weighStatus) {
			var status = this.tripStatus;
			/*var role = this.getOwnerComponent().getModel("RoleModel").getProperty("/Roles");
			var activity = this.getOwnerComponent().getModel("RoleModel").getProperty("/Activities");*/
			var inspOK = this.getView().getModel("TripModel").getData().InspectionOkFlag;
			var items = this.getOwnerComponent().getModel("AuthorizationModel").getProperty("/Items");
			var plant = this.getView().getModel("TripModel").getData().Plant;
			var Role = false;
			if (status === "LP" || status === "WR") {
				if (inspOK === "X") {
					/*if (role && activity) {
						for (var aa = 0; aa < role.length; aa++) {
							if (role[aa] === "Loading") {
								if (activity[aa] === "1" || activity[aa] === "2") {
									Role = true;
									break;
								}
							}
						}
						if (Role && weighStatus !== "ACCEPTED") {
							return true;
						} else {
							return false;
						}*/
					if (items) {
						var auth = items;
						if (auth) {
							var authl = auth.length;
							/*	return true;*/
							for (var i = 0; i < authl; i++) {
								if (auth[i].Werks === plant) {
									if (auth[i].Module === "Loading") {
										if (auth[i].Actvt === "1" || auth[i].Actvt === "2") {
											Role = true;
											break;
										}
									}
								}
							}
							if (Role && weighStatus !== "ACCEPTED") {
								return true;
							} else {
								return false;
							}
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		checkLoadingUnloadingLineItemsBatchEnabled: function(batchEnabled, weighstatus) {
			var status = this.tripStatus;
			/*var role = this.getOwnerComponent().getModel("RoleModel").getProperty("/Roles");
			var activity = this.getOwnerComponent().getModel("RoleModel").getProperty("/Activities");*/
			var Role = false;
			var items = this.getOwnerComponent().getModel("AuthorizationModel").getProperty("/Items");
			var plant = this.getView().getModel("TripModel").getData().Plant;
			var inspOK = this.getView().getModel("TripModel").getData().InspectionOkFlag;
			if (status === "LP" || status === "WR") {
				if (inspOK === "X") {
					if (batchEnabled) {
						/*if (role && activity) {
							for (var aa = 0; aa < role.length; aa++) {
								if (role[aa] === "Loading") {
									if (activity[aa] === "1" || activity[aa] === "2") {
										Role = true;
									}
								}
							}
							if (Role && weighstatus !== "ACCEPTED") {
								return true;
							} else {
								return false;
							}
						}*/
						if (items) {
							var auth = items;
							if (auth) {
								var authl = auth.length;
								/*	return true;*/
								for (var i = 0; i < authl; i++) {
									if (auth[i].Werks === plant) {
										if (auth[i].Module === "Loading") {
											if (auth[i].Actvt === "1" || auth[i].Actvt === "2") {
												Role = true;
												break;
											}
										}
									}
								}

								if (Role && weighstatus !== "ACCEPTED") {
									return true;
								} else {
									return false;
								}
							} else {
								return false;
							}
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		checkGateinButtons: function() {
			var status = this.tripStatus;
			var role = this.getOwnerComponent().getModel("RoleModel").getProperty("/Roles");
			var activity = this.getOwnerComponent().getModel("RoleModel").getProperty("/Activities");
			if (status === "LC") {
				if (role && activity) {
					var Role = false;
					for (var aa = 0; aa < role.length; aa++) {
						if (role[aa] === "Weighment") {
							if (activity[aa] === "1" || activity[aa] === "2") {
								Role = true;
							}
						}
					}
					if (Role) {
						return true;
					} else {
						return false;
					}
				}
			} else {
				return false;
			}
		},
		onChangeDriverLicence: function() {
			var licence = this.getView().byId("idDriverLicense").getValue();
			licence = licence.toString().toUpperCase();
			this.getView().byId("idDriverLicense").setValue(licence);
		},
		enableApproved: function(appvd, cmt) {
			if (cmt === "") {
				return 1;
			} else {
				return appvd;
			}
		},
		onRejectTruck: function() {
			MessageBox.confirm("Do you want to Reject the Truck?", {
				title: "Confirm",
				onClose: function(oPressEvent) {
					var oPressText = oPressEvent;
					if (oPressText === "OK") {
						var payload = {
							"Markasdelete": true,
							"TripStatus": "CL"
						};
						this.getOwnerComponent().getModel().update("/PLMS_outbound_HdrSet(TruckNumber='" + this.truckNumber + "',ObdNumber='" +
							this.obdNumber +
							"',TripNumber='" + this.tripNumber + "')", payload, {
								success: function(oData1) {
									this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
										filters: this.aStatusFilter,
										success: function(oData) {
											this.getView().getModel("TripModel").setData(oData.results[0]);
											this.getView().getModel("TripOBDModel").setProperty("/Items", oData.results);
											this.tripStatus = this.getView().getModel("TripModel").getData().TripStatus;
											this.tripNumber = this.getView().getModel("TripModel").getData().TripNumber;
											this.timeLineUpdate();
											this.goToMain();
											if (this.tripStatus !== "" || this.tripStatus !== undefined) {
												this.attachmentsSection();
											}
											this.getView().getModel("TripModel").refresh(true);
											this.callEnableDisableFunction();
										}.bind(this),
										error: function(oError) {
											MessageBox.warning("Error occurred while reading Header data");
										}
									});
								}.bind(this),
								error: function(error) {
									MessageBox.error("Error in cancelling the trip");
								}
							});
					}
				}.bind(this)
			});
		},
		onRejectTank: function() {
			MessageBox.confirm("Do you want to Reject the Tank?", {
				title: "Confirm",
				onClose: function(oPressEvent) {
					var oPressText = oPressEvent;
					if (oPressText === "OK") {
						var payload = {
							"Markasdelete": true,
							"TripStatus": "CL"
						};
						this.getOwnerComponent().getModel().update("/PLMS_outbound_HdrSet(TruckNumber='" + this.truckNumber + "',ObdNumber='" +
							this.obdNumber +
							"',TripNumber='" + this.tripNumber + "')", payload, {
								success: function(oData) {
									this.readHeaderEntitySet();
									this.goToMain();
								}.bind(this),
								error: function(error) {
									MessageBox.error("Error in cancelling the trip");
								}
							});
					}
				}
			});
		},
		/*checkEnableTareWeight: function(obdNo, lineItem) {
			var role = this.getOwnerComponent().getModel("RoleModel").getProperty("/Roles");
			var activity = this.getOwnerComponent().getModel("RoleModel").getProperty("/Activities");
			if (this.tripStatus === "LC") {
				var oItems = this.getView().getModel("LoadingItemsModel").getProperty("/Items");
				if (oItems) {
					var grossEnable = false;
					for (var i = 0; i < oItems.length; i++) {
						if (oItems[i].ObdNumber === obdNo) {
							if (oItems[i].ObdItem === lineItem) {
								if (oItems[i].ManualReasonCode !== "000" && oItems[i].GrossWeight === "0.000" && oItems[i].ManualAppr === 1) {
									grossEnable = true;
								}
							}
						}
					}
					if (grossEnable) {
						if (role && activity) {
							var Role = false;
							for (var aa = 0; aa < role.length; aa++) {
								if (role[aa] === "Weighment") {
									if (activity[aa] === "1") {
										Role = true;
									}
								}
							}
							if (Role) {
								return true;
							} else {
								return false;
							}
						}
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		checkEnableGrossWeight: function(obdNo, lineItem) {
			var role = this.getOwnerComponent().getModel("RoleModel").getProperty("/Roles");
			var activity = this.getOwnerComponent().getModel("RoleModel").getProperty("/Activities");
			if (this.tripStatus === "LC") {
				var oItems = this.getView().getModel("LoadingItemsModel").getProperty("/Items");
				if (oItems) {
					var headerOItem = this.getView().getModel("TripOBDModel").getProperty("/Items");
					var manualAppr = 0;
					var grossEnable = false;
					for (var j = 0; j < headerOItem; j++) {
						if (headerOItem[j].ObdNumber === obdNo) {
							manualAppr = headerOItem[j].ManualAppr;
						}
					}
					for (var i = 0; i < oItems.length; i++) {
						if (oItems[i].ObdNumber === obdNo) {
							if (oItems[i].ObdItem === lineItem) {
								if (oItems[i].ManualReasonCode !== "000" && oItems[i].TareWeight === "0.000" && manualAppr === 1) {
									grossEnable = true;
								}
							}
						}
					}
					if (grossEnable) {
						if (role && activity) {
							var Role = false;
							for (var aa = 0; aa < role.length; aa++) {
								if (role[aa] === "Weighment") {
									if (activity[aa] === "1") {
										Role = true;
									}
								}
							}
							if (Role) {
								return true;
							} else {
								return false;
							}
						}
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		},*/
		onLRDetailsChangePress: function(oEvent) {
			var aa = oEvent.getSource().getValue();
			aa = aa.toString().toUpperCase();
			oEvent.getSource().setValue(aa);
		},
		loadingItemsReadCall: function() {
			var aItemFilters = [],
				aItemsAllFilters = [];
			aItemFilters.push(new Filter({
				path: "TruckNumber",
				value1: this.truckNumber,
				operator: FilterOperator.EQ
			}));
			aItemFilters.push(new Filter({
				path: "TripNumber",
				value1: this.tripNumber,
				operator: FilterOperator.EQ
			}));
			aItemFilters.push(new Filter({
				path: "BatchAdded",
				value1: "000",
				operator: FilterOperator.EQ
			}));
			var oItemFilter = new Filter(aItemFilters, true);
			aItemsAllFilters.push(oItemFilter);
			this.getOwnerComponent().getModel().read("/PLMS_Obd_ItemSet", {
				filters: aItemsAllFilters,
				success: function(oData) {
					this.getView().getModel("LoadingItemsModel").setProperty("/Items", oData.results);
				}.bind(this),
				error: function(error) {
					MessageBox.error("Error in getting Line Items Data");
				}
			});
		},
		readLoadingItemsModel: function() {
			var aItemFilters = [],
				aItemsAllFilters = [];
			aItemFilters.push(new Filter({
				path: "TruckNumber",
				value1: this.truckNumber,
				operator: FilterOperator.EQ
			}));
			aItemFilters.push(new Filter({
				path: "TripNumber",
				value1: this.tripNumber,
				operator: FilterOperator.EQ
			}));
			aItemFilters.push(new Filter({
				path: "BatchAdded",
				value1: "000",
				operator: FilterOperator.EQ
			}));
			var oItemFilter = new Filter(aItemFilters, true);
			aItemsAllFilters.push(oItemFilter);
			this.getOwnerComponent().getModel().read("/PLMS_Obd_ItemSet", {
				filters: aItemsAllFilters,
				success: function(oData) {
					this.getView().getModel("LoadingItemsModel").setProperty("/Items", oData.results);
				}.bind(this),
				error: function(error) {
					MessageBox.error("Error in getting items data");
				}
			});
		},
		/*checkWeighmentEnable: function(obdNo) {
			if (this.tripStatus === "LC") {
				var oItems = this.getView().getModel("LoadingItemsModel").getProperty("/Items");
				if (oItems) {
					for (var i = 0; i < oItems.length; i++) {
						if (oItems[i].ObdNumber === "00" + obdNo) {
							if (oItems[i].ManualAppr === 1) {
								if (oItems[i].ObdItemImgFileName === "") {
									return true;
								} else {
									return false;
								}
							} else {
								return false;
							}
						}
					}
				}
			} else {
				return false;
			}
		},*/
		handleDriverPhotoChange: function(oEvent) {
			this.fileDriverName = oEvent.getParameter("files")[0].name;
			this.fileDriverType = oEvent.getParameter("files")[0].type;
			this.fileDriverSize = oEvent.getParameter("files")[0].size;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idDriverPhotoImage").setSrc(path);
			}
		},
		handleDriverPhotoUpload: function(oEvent) {
			var status = oEvent.getParameters().status;
			if (status === 200) {

			}
		},
		handleDriverPhotoTypeMissmatch: function(oEvent) {
			var fileType = oEvent.getSource().getProperty("fileType")[0];
			if (fileType != "jpg") {
				MessageBox.error("Only JPG format file is allowed");
			}
		},
		enableLoadingGate: function() {
			if (this.tripStatus === "IC") {
				var items = this.getOwnerComponent().getModel("AuthorizationModel").getProperty("/Items");
				var plant = this.getView().getModel("TripModel").getData().Plant;
				/*	return true;*/
				var Role = false;
				if (items) {
					var auth = items;
					if (auth) {
						var authl = auth.length;
						/*	return true;*/
						for (var i = 0; i < authl; i++) {
							if (auth[i].Werks === plant) {
								if (auth[i].Module === "GateIn") {
									if (auth[i].Actvt === "1" || auth[i].Actvt === "2") {
										Role = true;
										break;
									}
								}
							}
						}
						if (Role) {
							return true;
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		handlePhase1ImageChange: function(oEvent) {
			this.filePhase1Name = oEvent.getParameter("files")[0].name;
			this.filePhase1Type = oEvent.getParameter("files")[0].type;
			this.filePhase1Size = oEvent.getParameter("files")[0].size;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idLoadingPhase1Image").setSrc(path);
			}
		},
		handlePhase2ImageChange: function(oEvent) {
			this.filePhase2Name = oEvent.getParameter("files")[0].name;
			this.filePhase2Type = oEvent.getParameter("files")[0].type;
			this.filePhase2Size = oEvent.getParameter("files")[0].size;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idLoadingPhase2Image").setSrc(path);
			}
		},
		handlePhase3ImageChange: function(oEvent) {
			this.filePhase3Name = oEvent.getParameter("files")[0].name;
			this.filePhase3Type = oEvent.getParameter("files")[0].type;
			this.filePhase3Size = oEvent.getParameter("files")[0].size;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idLoadingPhase3Image").setSrc(path);
			}
		},
		handlePhase4ImageChange: function(oEvent) {
			this.filePhase4Name = oEvent.getParameter("files")[0].name;
			this.filePhase4Type = oEvent.getParameter("files")[0].type;
			this.filePhase4Size = oEvent.getParameter("files")[0].size;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idLoadingPhase4Image").setSrc(path);
			}
		},
		handlePhase5ImageChange: function(oEvent) {
			this.filePhase5Name = oEvent.getParameter("files")[0].name;
			this.filePhase5Type = oEvent.getParameter("files")[0].type;
			this.filePhase5Size = oEvent.getParameter("files")[0].size;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idLoadingPhase5Image").setSrc(path);
			}
		},
		handlePhase6ImageChange: function(oEvent) {
			this.filePhase6Name = oEvent.getParameter("files")[0].name;
			this.filePhase6Type = oEvent.getParameter("files")[0].type;
			this.filePhase6Size = oEvent.getParameter("files")[0].size;
			if (oEvent.getSource().oFileUpload.files.length > 0) {
				var file = oEvent.getSource().oFileUpload.files;
				var blobObj = new Blob(file, {
					type: "	image/jpeg"
				});
				var path = URL.createObjectURL(blobObj);
				this.getView().byId("idLoadingPhase6Image").setSrc(path);
			}
		},
		onDispatchActivityPress: function() {
			var rem = this.getView().byId("idDispatchActivityRemarks").getSelectedKey();
			if (rem !== "") {
				var payload = {
					"PgiRemarks": rem,
					"TripStatus": "PG"
				};
				this.getOwnerComponent().getModel().update("/PLMS_outbound_HdrSet(TruckNumber='" + this.truckNumber + "',ObdNumber='" + this.obdNumber +
					"',TripNumber='" + this.tripNumber + "')", payload, {
						method: "PUT",
						success: function(response) {
							MessageBox.success("Dispatch Activity Completed successfully");
							this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
								filters: this.aStatusFilter,
								success: function(oData) {
									this.getView().getModel("TripModel").setData(oData.results[0]);
									this.getView().getModel("TripOBDModel").setProperty("/Items", oData.results);
									this.tripStatus = this.getView().getModel("TripModel").getData().TripStatus;
									this.timeLineUpdate();
									if (this.tripStatus !== "" || this.tripStatus !== undefined) {
										this.attachmentsSection();
									}
									this.getView().getModel("TripModel").refresh(true);
									this.callEnableDisableFunction();
								}.bind(this),
								error: function(oError) {
									MessageBox.warning("Error occurred while reading Header data");
								}
							});
						}.bind(this)
					});
			} else {
				MessageBox.error("Please enter Remarks");
			}
		},
		onLoadingOKSelectionChange: function(oEvent) {
			var buttonPressed = oEvent.getSource().getSelectedButton().getText();
			if (buttonPressed === "YES") {
				this.getView().byId("idLoadingObservations").setEnabled(false);
				//	this.getView().byId("idLoadingObservations").setValue("");
			} else {
				this.getView().byId("idLoadingObservations").setEnabled(true);
			}
		},
		onLoadingInspectionOKPress: function() {
			var aFilters = [],
				aStatusFilter = [];
			aFilters.push(new Filter({
				path: "TruckNumber",
				value1: this.truckNumber,
				operator: FilterOperator.EQ
			}));
			aFilters.push(new Filter({
				path: "TripNumber",
				value1: this.tripNumber,
				operator: FilterOperator.EQ
			}));
			var oFilter = new Filter(aFilters, true);
			aStatusFilter.push(oFilter);
			var index = this.getView().byId("idLoadingOKButton").getSelectedIndex();
			var obs = this.getView().byId("idLoadingObservations").getValue();
			if (index === 0) {
				var yesPayload = {
					"LoadingInspOk": index,
					"LoadinObserva": obs,
					"InspectionOkFlag": "X",
					"TripStatus": "LP"
				};
				this.getOwnerComponent().getModel().update("/PLMS_outbound_HdrSet(TruckNumber='" + this.truckNumber + "',ObdNumber='" +
					this.obdNumber +
					"',TripNumber='" + this.tripNumber + "')", yesPayload, {
						success: function(oData) {
							//refresh loading unloading table
							this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
								filters: aStatusFilter,
								success: function(oExtData) {
									var items = oExtData.results;
									this.getView().getModel("TripModel").setData(items[0]);
									this.tripStatus = this.getView().getModel("TripModel").getData().TripStatus;
									this.getView().getModel("TripOBDModel").setProperty("/Items", items);
									var itemLength = items.length;
									this.getView().byId("idLoadingUnloading").destroyContent();
									for (var mm = 0; mm < itemLength; mm++) {
										this.createLoadingUnloadingMaterialsTabContent(mm);
									}
								}.bind(this),
								error: function(oExterror) {
									MessageBox.error("No data is available for selected filters.Please select valid Filters");
								}.bind(this)
							});
						}.bind(this),
						error: function(error) {
							MessageBox.error("Error in cancelling the trip");
						}
					});
			} else {
				//	var obs = this.getView().byId("idLoadingObservations").getValue();
				var noPayload = {
					"LoadingInspOk": index,
					"LoadinObserva": obs,
					"InspectionOkFlag": ""
				};
				this.getOwnerComponent().getModel().update("/PLMS_outbound_HdrSet(TruckNumber='" + this.truckNumber + "',ObdNumber='" +
					this.obdNumber +
					"',TripNumber='" + this.tripNumber + "')", noPayload, {
						success: function(oData) {
							//refresh loading unloading table
							this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
								filters: aStatusFilter,
								success: function(oExtData) {
									var items = oExtData.results;
									var itemLength = items.length;
									this.getView().byId("idLoadingUnloading").destroyContent();
									for (var mm = 0; mm < itemLength; mm++) {
										this.createLoadingUnloadingMaterialsTabContent(mm);
									}
								}.bind(this),
								error: function(oExterror) {
									MessageBox.error("No data is available for selected filters.Please select valid Filters");
								}.bind(this)
							});
						}.bind(this),
						error: function(error) {
							MessageBox.error("Error in cancelling the trip");
						}
					});
			}
		},
		onBillingDocPress: function() {
			var aa =
				"https://s4appprd.sonicbiochem.co.in:9443/sap/bc/gui/sap/its/webgui?%7etransaction=VF01&sap-client=900&sap-language=EN&sap-ui-tech-hint=GUI";
			window.open(aa);
		},
		onDSignPress: function() {
			var aa =
				"https://s4appprd.sonicbiochem.co.in:9443/sap/bc/gui/sap/its/webgui?%7etransaction=YDSC&sap-client=900&sap-language=EN";
			window.open(aa);
		},
		onEWayPress: function() {
			var aa =
				"https://s4appprd.sonicbiochem.co.in:9443/sap/bc/gui/sap/its/webgui?%7etransaction=%2fINCASP%2fEWBMONITOR&sap-client=900&sap-language=EN";
			window.open(aa);
		},
		onEInvoicePress: function() {
			var aa =
				"https://s4appprd.sonicbiochem.co.in:9443/sap/bc/gui/sap/its/webgui?%7etransaction=%2fINCASP%2fEINVMONITOR&sap-client=900&sap-language=EN";
			window.open(aa);
		},
		onChangeOutBound: function() {
			var aa =
				"https://s4appprd.sonicbiochem.co.in:9443/sap/bc/gui/sap/its/webgui?%7etransaction=VL02N&sap-client=900&sap-language=EN&sap-ui-tech-hint=GUI";
			window.open(aa);
		},
		onTruckCanvasChange: function(oEvent) {
			var buttonSelected = oEvent.getSource().getSelectedIndex();
			if (buttonSelected === 1) {
				this.getView().byId("idCanvasCheckObservations").setEnabled(true);
				this.getView().byId("idCanvasCheckCorectiveMeasures").setEnabled(true);
			}
			if (buttonSelected === 0 || buttonSelected === 2) {
				this.getView().byId("idCanvasCheckObservations").setEnabled(false);
				this.getView().byId("idCanvasCheckCorectiveMeasures").setEnabled(false);
				/*this.getView().byId("idCanvasCheckObservations").setValue("");
				this.getView().byId("idCanvasCheckCorectiveMeasures").setValue("");*/
			}
		},
		onTruckRopeChange: function(oEvent) {
			var buttonSelected = oEvent.getSource().getSelectedIndex();
			if (buttonSelected === 1) {
				this.getView().byId("idRopeObservations").setEnabled(true);
				this.getView().byId("idRopeCorectiveMeasures").setEnabled(true);
			}
			if (buttonSelected === 0 || buttonSelected === 2) {
				this.getView().byId("idRopeObservations").setEnabled(false);
				this.getView().byId("idRopeCorectiveMeasures").setEnabled(false);
				/*this.getView().byId("idRopeObservations").setValue("");
				this.getView().byId("idRopeCorectiveMeasures").setValue("");*/
			}
		},
		onTruckFloorChange: function(oEvent) {
			var buttonSelected = oEvent.getSource().getSelectedIndex();
			if (buttonSelected === 1) {
				this.getView().byId("idFWObservations").setEnabled(true);
				this.getView().byId("idFWCorectiveMeasures").setEnabled(true);
			}
			if (buttonSelected === 0 || buttonSelected === 2) {
				this.getView().byId("idFWObservations").setEnabled(false);
				this.getView().byId("idFWCorectiveMeasures").setEnabled(false);
				/*this.getView().byId("idFWObservations").setValue("");
				this.getView().byId("idFWCorectiveMeasures").setValue("");*/
			}
		},
		onTruckVehicleChange: function(oEvent) {
			var buttonSelected = oEvent.getSource().getSelectedIndex();
			if (buttonSelected === 1) {
				this.getView().byId("idVehicleObservations").setEnabled(true);
				this.getView().byId("idVehicleCorectiveMeasures").setEnabled(true);
			}
			if (buttonSelected === 0 || buttonSelected === 2) {
				this.getView().byId("idVehicleObservations").setEnabled(false);
				this.getView().byId("idVehicleCorectiveMeasures").setEnabled(false);
				/*this.getView().byId("idVehicleObservations").setValue("");
				this.getView().byId("idVehicleCorectiveMeasures").setValue("");*/
			}
		},
		onTruckCleanChange: function(oEvent) {
			var buttonSelected = oEvent.getSource().getSelectedIndex();
			if (buttonSelected === 1) {
				this.getView().byId("idVehicleCleanObservations").setEnabled(true);
				this.getView().byId("idVehicleCleanCorectiveMeasures").setEnabled(true);
			}
			if (buttonSelected === 0 || buttonSelected === 2) {
				this.getView().byId("idVehicleCleanObservations").setEnabled(false);
				this.getView().byId("idVehicleCleanCorectiveMeasures").setEnabled(false);
				/*this.getView().byId("idVehicleCleanObservations").setValue("");
				this.getView().byId("idVehicleCleanCorectiveMeasures").setValue("");*/
			}
		},
		onTruckBodyChange: function(oEvent) {
			var buttonSelected = oEvent.getSource().getSelectedIndex();
			if (buttonSelected === 1) {
				this.getView().byId("idBodyObservations").setEnabled(true);
				this.getView().byId("idBodyCorectiveMeasures").setEnabled(true);
			}
			if (buttonSelected === 0 || buttonSelected === 2) {
				this.getView().byId("idBodyObservations").setEnabled(false);
				this.getView().byId("idBodyCorectiveMeasures").setEnabled(false);
				/*this.getView().byId("idBodyObservations").setValue("");
				this.getView().byId("idBodyCorectiveMeasures").setValue("");*/
			}
		},
		onTankReportChange: function(oEvent) {
			var buttonSelected = oEvent.getSource().getSelectedIndex();
			if (buttonSelected === 1) {
				this.getView().byId("idTankerCleanObservations").setEnabled(true);
				this.getView().byId("idTankerCleanCorectiveMeasures").setEnabled(true);
			}
			if (buttonSelected === 0 || buttonSelected === 2) {
				this.getView().byId("idTankerCleanObservations").setEnabled(false);
				this.getView().byId("idTankerCleanCorectiveMeasures").setEnabled(false);
				/*this.getView().byId("idTankerCleanObservations").setValue("");
				this.getView().byId("idTankerCleanCorectiveMeasures").setValue("");*/
			}
		},
		onTankBottomChange: function(oEvent) {
			var buttonSelected = oEvent.getSource().getSelectedIndex();
			if (buttonSelected === 1) {
				this.getView().byId("idBottomSealObservations").setEnabled(true);
				this.getView().byId("idBottomSealCorectiveMeasures").setEnabled(true);
			}
			if (buttonSelected === 0 || buttonSelected === 2) {
				this.getView().byId("idBottomSealObservations").setEnabled(false);
				this.getView().byId("idBottomSealCorectiveMeasures").setEnabled(false);
				/*this.getView().byId("idBottomSealObservations").setValue("");
				this.getView().byId("idBottomSealCorectiveMeasures").setValue("");*/
			}
		},
		onTankFloorChange: function(oEvent) {
			var buttonSelected = oEvent.getSource().getSelectedIndex();
			if (buttonSelected === 1) {
				this.getView().byId("idForeignObservations").setEnabled(true);
				this.getView().byId("idForeignCorectiveMeasures").setEnabled(true);
			}
			if (buttonSelected === 0 || buttonSelected === 2) {
				this.getView().byId("idForeignObservations").setEnabled(false);
				this.getView().byId("idForeignCorectiveMeasures").setEnabled(false);
				/*this.getView().byId("idForeignObservations").setValue("");
				this.getView().byId("idForeignCorectiveMeasures").setValue("");*/
			}
		},
		onTankCSCChange: function(oEvent) {
			var buttonSelected = oEvent.getSource().getSelectedIndex();
			if (buttonSelected === 1) {
				this.getView().byId("idCSCObservations").setEnabled(true);
				this.getView().byId("idCSCCorectiveMeasures").setEnabled(true);
			}
			if (buttonSelected === 0 || buttonSelected === 2) {
				this.getView().byId("idCSCObservations").setEnabled(false);
				this.getView().byId("idCSCCorectiveMeasures").setEnabled(false);
				/*this.getView().byId("idCSCObservations").setValue("");
				this.getView().byId("idCSCCorectiveMeasures").setValue("");*/
			}
		},
		onTankRubberChange: function(oEvent) {
			var buttonSelected = oEvent.getSource().getSelectedIndex();
			if (buttonSelected === 1) {
				this.getView().byId("idTankerRSObservations").setEnabled(true);
				this.getView().byId("idTankerRSCorectiveMeasures").setEnabled(true);
			}
			if (buttonSelected === 0 || buttonSelected === 2) {
				this.getView().byId("idTankerRSObservations").setEnabled(false);
				this.getView().byId("idTankerRSCorectiveMeasures").setEnabled(false);
				/*this.getView().byId("idTankerRSObservations").setValue("");
				this.getView().byId("idTankerRSCorectiveMeasures").setValue("");*/
			}
		},
		onTankStuffChange: function(oEvent) {
			var buttonSelected = oEvent.getSource().getSelectedIndex();
			if (buttonSelected === 1) {
				this.getView().byId("idTankStuffingObservations").setEnabled(true);
				this.getView().byId("idTankStuffingCorectiveMeasures").setEnabled(true);
			}
			if (buttonSelected === 0 || buttonSelected === 2) {
				this.getView().byId("idTankStuffingObservations").setEnabled(false);
				this.getView().byId("idTankStuffingCorectiveMeasures").setEnabled(false);
				/*	this.getView().byId("idTankStuffingObservations").setValue("");
					this.getView().byId("idTankStuffingCorectiveMeasures").setValue("");*/
			}
		},
		onPhase1PhotoPress: function() {
			var oFileUploaderPhase1 = this.getView().byId("idLoadingPhase1");
			oFileUploaderPhase1.destroyHeaderParameters();
			oFileUploaderPhase1.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "SLUG",
				value: this.filePhase1Name + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
					"000" +
					'"/"' + "000" + '"/"' + 18
			}));
			oFileUploaderPhase1.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "Content-Type",
				value: this.filePhase1Type
			}));
			this.getOwnerComponent().getModel().refreshSecurityToken();
			oFileUploaderPhase1.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "x-csrf-token",
				value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
			}));
			oFileUploaderPhase1.setSendXHR(true);
			oFileUploaderPhase1.upload();

		},
		onPhase2PhotoPress: function() {
			var oFileUploaderPhase2 = this.getView().byId("idLoadingPhase2");
			oFileUploaderPhase2.destroyHeaderParameters();
			oFileUploaderPhase2.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "SLUG",
				value: this.filePhase2Name + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
					"000" +
					'"/"' + "000" + '"/"' + 19
			}));
			oFileUploaderPhase2.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "Content-Type",
				value: this.filePhase2Type
			}));
			this.getOwnerComponent().getModel().refreshSecurityToken();
			oFileUploaderPhase2.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "x-csrf-token",
				value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
			}));
			oFileUploaderPhase2.setSendXHR(true);
			oFileUploaderPhase2.upload();
		},
		onPhase3PhotoPress: function() {
			var oFileUploaderPhase3 = this.getView().byId("idLoadingPhase3");
			oFileUploaderPhase3.destroyHeaderParameters();
			oFileUploaderPhase3.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "SLUG",
				value: this.filePhase3Name + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
					"000" +
					'"/"' + "000" + '"/"' + 20
			}));
			oFileUploaderPhase3.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "Content-Type",
				value: this.filePhase3Type
			}));
			this.getOwnerComponent().getModel().refreshSecurityToken();
			oFileUploaderPhase3.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "x-csrf-token",
				value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
			}));
			oFileUploaderPhase3.setSendXHR(true);
			oFileUploaderPhase3.upload();
		},
		onPhase4PhotoPress: function() {
			var oFileUploaderPhase4 = this.getView().byId("idLoadingPhase4");
			oFileUploaderPhase4.destroyHeaderParameters();
			oFileUploaderPhase4.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "SLUG",
				value: this.filePhase4Name + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
					"000" +
					'"/"' + "000" + '"/"' + 21
			}));
			oFileUploaderPhase4.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "Content-Type",
				value: this.filePhase4Type
			}));
			this.getOwnerComponent().getModel().refreshSecurityToken();
			oFileUploaderPhase4.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "x-csrf-token",
				value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
			}));
			oFileUploaderPhase4.setSendXHR(true);
			oFileUploaderPhase4.upload();
		},
		onPhase5PhotoPress: function() {
			var oFileUploaderPhase5 = this.getView().byId("idLoadingPhase5");
			oFileUploaderPhase5.destroyHeaderParameters();
			oFileUploaderPhase5.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "SLUG",
				value: this.filePhase5Name + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
					"000" +
					'"/"' + "000" + '"/"' + 22
			}));
			oFileUploaderPhase5.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "Content-Type",
				value: this.filePhase5Type
			}));
			this.getOwnerComponent().getModel().refreshSecurityToken();
			oFileUploaderPhase5.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "x-csrf-token",
				value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
			}));
			oFileUploaderPhase5.setSendXHR(true);
			oFileUploaderPhase5.upload();
		},
		onPhase6PhotoPress: function() {
			var oFileUploaderPhase6 = this.getView().byId("idLoadingPhase6");
			oFileUploaderPhase6.destroyHeaderParameters();
			oFileUploaderPhase6.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "SLUG",
				value: this.filePhase6Name + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber + '"/"' +
					"000" +
					'"/"' + "000" + '"/"' + 23
			}));
			oFileUploaderPhase6.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "Content-Type",
				value: this.filePhase6Type
			}));
			this.getOwnerComponent().getModel().refreshSecurityToken();
			oFileUploaderPhase6.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "x-csrf-token",
				value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
			}));
			oFileUploaderPhase6.setSendXHR(true);
			oFileUploaderPhase6.upload();
		},
		handlePhase1ImageUploadComplete: function() {
			MessageBox.success("Phase 1 File uploaded successfully");
		},
		handlePhase2ImageUploadComplete: function() {
			MessageBox.success("Phase 2 File uploaded successfully");
		},
		handlePhase3ImageUploadComplete: function() {
			MessageBox.success("Phase 3 File uploaded successfully");
		},
		handlePhase4ImageUploadComplete: function() {
			MessageBox.success("Phase 4 File uploaded successfully");
		},
		handlePhase5ImageUploadComplete: function() {
			MessageBox.success("Phase 5 File uploaded successfully");
		},
		handlePhase6ImageUploadComplete: function() {
			MessageBox.success("Phase 6 File uploaded successfully");
		},
		reportFileUpload: function() {
			var oFileUploader = this.getView().byId("idDriverPhotoFileUpload");
			oFileUploader.destroyHeaderParameters();
			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "SLUG",
				value: this.fileDriverName + '"/"' + this.truckNumber + '"/"' + this.tripNumber + '"/"' + this.obdNumber +
					'"/"' +
					"000" +
					'"/"' + "000" + '"/"' + 17
			}));
			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "Content-Type",
				value: this.fileDriverType
			}));
			this.getOwnerComponent().getModel().refreshSecurityToken();
			oFileUploader.addHeaderParameter(new sap.ui.unified.FileUploaderParameter({
				name: "x-csrf-token",
				value: this.getOwnerComponent().getModel().getHeaders()['x-csrf-token']
			}));
			oFileUploader.setSendXHR(true);
			oFileUploader.upload();
		},
		weightmentCompleteUpdateCall: function(payload) {
			this.getOwnerComponent().getModel().update("/PLMS_outbound_HdrSet(TruckNumber='" + this.truckNumber + "',ObdNumber='" +
				this
				.obdNumber +
				"',TripNumber='" + this.tripNumber + "')", payload, {
					method: "PUT",
					success: function(oData) {
						this.readHeaderEntitySet();
						this.getView().byId("idLoadingUnloading").destroyContent();
						this.getView().byId("idGateInMainPanel").destroyContent();
						var oItems = this.getView().getModel("TripOBDModel").getProperty("/Items");
						for (var ee = 0; ee < oItems.length; ee++) {
							this.createGateInTabContent(ee);
							this.createLoadingUnloadingMaterialsTabContent(ee);
						}
					}.bind(this),
					error: function(error) {
						MessageBox.error("Error in updating weighment status");
					}
				});
		},
		onPostLoadingInspectionOKPress: function() {
			var aFilters = [],
				aStatusFilter = [];
			aFilters.push(new Filter({
				path: "TruckNumber",
				value1: this.truckNumber,
				operator: FilterOperator.EQ
			}));
			aFilters.push(new Filter({
				path: "TripNumber",
				value1: this.tripNumber,
				operator: FilterOperator.EQ
			}));

			var oFilter = new Filter(aFilters, true);
			aStatusFilter.push(oFilter);
			this.getOwnerComponent().getModel().read("/PLMS_Obd_ItemSet", {
				filters: aStatusFilter,
				success: function(oLoadingBatchData) {
					var isCombined = this.getView().getModel("TripModel").getData().CombinedWeightValue;
					this.getView().getModel("LoadingItemsBatchModel").setProperty("/Items", oLoadingBatchData.results);
					var loadingItems = this.getView().getModel("LoadingItemsBatchModel").getProperty("/Items");
					var loadingLength = loadingItems.length;
					var combinedWeighAccepted = true;
					var postLoading = this.getView().byId("idPostLoadingOKButton").getSelectedIndex();
					var payload = {
						PostLoading: postLoading
					};
					if (isCombined === 1) {
						for (var j = 0; j < loadingLength; j++) {
							if (loadingItems[j].BatchEnabled) {
								if (loadingItems[j].Batch === "") {
									combinedWeighAccepted = false;
									break;
								}
							} else {
								if (loadingItems[j].BagQuantity === 0) {
									combinedWeighAccepted = false;
									break;
								}
							}
						}
						if (combinedWeighAccepted) {
							this.getOwnerComponent().getModel().update("/PLMS_outbound_HdrSet(TruckNumber='" + this.truckNumber + "',ObdNumber='" +
								this.obdNumber +
								"',TripNumber='" + this.tripNumber + "')", payload, {
									method: "PUT",
									success: function(response) {
										this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
											filters: this.aStatusFilter,
											success: function(oData) {
												MessageBox.success("Post Loading Details have been saved successfully");
												this.getView().getModel("TripModel").setData(oData.results[0]);
												this.getView().getModel("TripOBDModel").setProperty("/Items", oData.results);
												this.tripStatus = this.getView().getModel("TripModel").getData().TripStatus;
												this.getView().getModel("TripModel").refresh(true);
											}.bind(this),
											error: function(oError) {
												MessageBox.error("Error in reading details");
											}
										});
									}.bind(this),
									error: function(oError1) {
										MessageBox.error("Error in updating post loading details");
									}
								});
						} else {
							MessageBox.error("Please ensure all the required batches and  weights are entered");
						}
					}
					if (isCombined === 2) {
						var batch = true,
							weighmentAccepted = true;
						for (var i = 0; i < loadingLength; i++) {
							if (loadingItems[i].BatchEnabled) {
								if (loadingItems[i].Batch === "") {
									batch = false;
									break;
								}
							}
						}
						for (var k = 0; k < loadingLength; k++) {
							//ensuring last line item
							if ( /*loadingItems[k].WeighStatus === "ACCEPTED"*/ loadingItems[k].LineItemLoaded !== true && loadingItems[k].WeighStatus ===
								"") {
								weighmentAccepted = false;
								break;
							}
							if (loadingItems[k].WeighStatus === "REJECTED") {
								weighmentAccepted = false;
								break;
							}
							/*else {
								weighmentAccepted = false;
							}*/
						}
						if (batch) {
							if (weighmentAccepted) {
								this.getOwnerComponent().getModel().update("/PLMS_outbound_HdrSet(TruckNumber='" + this.truckNumber + "',ObdNumber='" +
									this.obdNumber +
									"',TripNumber='" + this.tripNumber + "')", payload, {
										method: "PUT",
										success: function(response) {
											this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
												filters: this.aStatusFilter,
												success: function(oData) {
													MessageBox.success("Post Loading Details have been saved successfully");
													this.getView().getModel("TripModel").setData(oData.results[0]);
													this.getView().getModel("TripOBDModel").setProperty("/Items", oData.results);
													this.tripStatus = this.getView().getModel("TripModel").getData().TripStatus;
													this.getView().getModel("TripModel").refresh(true);
													if (this.getView().getModel("TripModel").getProperty("/PostLoading") === 1) {
														var panelContents = this.getView().byId("idLoadingUnloading").getContent();
														var noofTables = this.getView().byId("idLoadingUnloading").getContent().length;
														for (var hh = 0; hh < noofTables; hh++) {
															var noofRows = panelContents[hh].getContent()[0].getItems().length;
															for (var uu = 0; uu < noofRows; uu++) {
																for (var oo = 5; oo < 10; oo++) {
																	panelContents[hh].getContent()[0].getItems()[uu].getCells()[oo].setEnabled(false);
																}
															}
														}
													}
												}.bind(this),
												error: function(oError) {
													MessageBox.warning("Error occurred while reading Header data");
												}
											});
										}.bind(this)
									});
							} else {
								MessageBox.error("Please ensure all the weights are accepted");
							}
						} else {
							MessageBox.error("Please enter Batch Number for all the Line Items");
						}
					}
				}.bind(this)
			});
		},
		removeLeadingZero: function(input) {
			if (input) {
				return input.replace(/^0+/, "");
			} else {
				return "0";
			}
		},
		onUpdateFinished: function() {
			var contItems = this.getView().byId("idContainerNumber").getItems();
			this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
				filters: this.aStatusFilter,
				success: function(oData) {

				}
			});
		},
		saveLineItems: function(results, i, oParent, combinedStatus) {
			var material = oParent.getCells()[0].getText();
			var materialAllChar = results[i].Matnr.length;
			var matnr = results[i].Matnr;
			if (materialAllChar < 18) {
				for (var f = 0; f < 18 - materialAllChar; f++) {
					matnr = "0" + matnr;
				}
			}
			var aFilters = [],
				aStatusFilter = [];
			aFilters.push(new Filter({
				path: "Matnr",
				value1: matnr,
				operator: FilterOperator.EQ
			}));
			aFilters.push(new Filter({
				path: "Werks",
				value1: results[i].Werks,
				operator: FilterOperator.EQ
			}));
			aFilters.push(new Filter({
				path: "Lgort",
				value1: results[i].Lgort,
				operator: FilterOperator.EQ
			}));
			aFilters.push(new Filter({
				path: "Clabs",
				value1: "0.000",
				operator: FilterOperator.NE
			}));
			var oFilter = new Filter(aFilters, true);
			aStatusFilter.push(oFilter);
			this.getOwnerComponent().getModel().read("/BatchF4Set", {
				filters: aStatusFilter,
				success: function(oData) {
					this.getView().getModel("BatchModel").setProperty("/Items", oData.results);
					var bgsQty, bagInt, lgort, obditem, containerNo, batchValue,
						batchCheck,
						batchItems,
						batchLength,
						totalQty = oParent.getCells()[10].getText();
					this.oLULTEvent = oParent.getCells();
					if (this.vehicleType === "YB16") {
						bgsQty = oParent.getCells()[8].getValue();
						bagInt = bgsQty.includes(".");
						lgort = results[i].Lgort;
						obditem = results[i].ObdItem;
						containerNo = oParent.getCells()[5].getSelectedKey();
						batchValue = oParent.getCells()[6].getValue();
						batchCheck = false;
						batchItems = this.getView().getModel("BatchModel").getProperty("/Items");
						batchLength = batchItems.length;
						if (results[i].BatchEnabled) {
							for (var kkk = 0; kkk < batchLength; kkk++) {
								if (batchItems[kkk].Charg === batchValue) {
									batchCheck = true;
								}
							}
						} else {
							batchCheck = true;
						}
						if (batchCheck) {
							if (bgsQty != 0 && bgsQty !== undefined) {
								var payloadContainer = {
									"Batch": oParent.getCells()[6].getValue(),
									"BagType": oParent.getCells()[7].getValue(),
									"BagsChkWeight": parseFloat(oParent.getCells()[9].getValue()).toFixed(3),
									"BagQuantity": parseInt(bgsQty, 10),
									"ContainerNo": containerNo,
									"WeighStatus": ""
								};
								if (combinedStatus === 1) {
									payloadContainer.LineItemLoaded = false;
								} else {
									payloadContainer.LineItemLoaded = true;
								}
								this.getOwnerComponent().getModel().update("/PLMS_Obd_ItemSet(TruckNumber='" + this.truckNumber +
									"',ObdNumber='" + results[i].ObdNumber + "',BatchAdded='" + "000" + "',TripNumber='" + this.tripNumber +
									"',ObdItem='" +
									obditem +
									"',Lgort='" +
									lgort + "')", payloadContainer, {
										success: function(oData1) {
											var oItems = this.oLULTEvent;
											for (var t = 5; t < 10; t++) {
												oItems[t].setEnabled(false);
											}
											MessageBox.success("Saved " + material + " data Successfully");
											/*this.getView().byId("idLoadingUnloading").destroyContent();
											var iItems = this.getView().getModel("TripOBDModel").getProperty("/Items");
											for (var ee = 0; ee < iItems.length; ee++) {
												this.createLoadingUnloadingMaterialsTabContent(ee);
											}*/
											this.changeStatustoLP("LP");
											lineItemsBuffer.push({
												"OBDNo": results[i].ObdNo,
												"OBDItem": results[i].ObdItem
											});
										}.bind(this),
										error: function(oError) {
											MessageBox.error("Error in saving " + material + " data");
										}
									});
							} else {
								MessageBox.error("Please enter Quantity");
							}
						} else {
							MessageBox.error("Please enter a Valid Batch Number");
						}
					}
					if (this.vehicle === "Truck" || this.vehicle === "Tank lorry") {
						bgsQty = oParent.getCells()[8].getValue();
						bagInt = bgsQty.includes(".");
						lgort = results[i].Lgort;
						obditem = results[i].ObdItem;
						containerNo = "000";
						material = oParent.getCells()[0].getText();
						batchValue = oParent.getCells()[6].getValue();
						batchCheck = false;
						batchItems = this.getView().getModel("BatchModel").getProperty("/Items");
						batchLength = batchItems.length;
						if (results[i].BatchEnabled) {
							for (var qqq = 0; qqq < batchLength; qqq++) {
								if (batchItems[qqq].Charg === batchValue) {
									batchCheck = true;
								}
							}
						} else {
							batchCheck = true;
						}
						if (batchCheck) {
							if (bgsQty != 0 && bgsQty !== undefined) {
								var payloadTrucknandTank = {
									"Batch": oParent.getCells()[6].getValue(),
									"BagType": oParent.getCells()[7].getValue(),
									"BagsChkWeight": parseFloat(oParent.getCells()[9].getValue()).toFixed(3),
									"BagQuantity": parseInt(bgsQty, 10),
									"ContainerNo": containerNo,
									"BatchAdded": results[i].BatchAdded,
									"LineItemLoaded": true,
									"WeighStatus": ""
								};
								if (combinedStatus === 1) {
									payloadTrucknandTank.LineItemLoaded = false;
								} else {
									payloadTrucknandTank.LineItemLoaded = true;
								}
								this.getOwnerComponent().getModel().update("/PLMS_Obd_ItemSet(TruckNumber='" + this.truckNumber +
									"',ObdNumber='" + results[i].ObdNumber + "',BatchAdded='" + results[i].BatchAdded + "',TripNumber='" + this.tripNumber +
									"',ObdItem='" +
									obditem +
									"',Lgort='" +
									lgort + "')", payloadTrucknandTank, {
										success: function(oData4) {
											var oItems = this.oLULTEvent;
											for (var t = 5; t < 10; t++) {
												oItems[t].setEnabled(false);
											}
											MessageBox.success("Saved " + material + " data Successfully");
											/*this.getView().byId("idLoadingUnloading").destroyContent();
											var iItems = this.getView().getModel("TripOBDModel").getProperty("/Items");
											for (var ee = 0; ee < iItems.length; ee++) {
												this.createLoadingUnloadingMaterialsTabContent(ee);
											}*/
											this.changeStatustoLP("LP");
											lineItemsBuffer.push({
												"OBDNo": results[i].ObdNo,
												"OBDItem": results[i].ObdItem
											});
										}.bind(this),
										error: function(oError) {
											MessageBox.error("Error in saving " + material + " data");
										}
									});
							} else {
								MessageBox.error("Please enter Quantity");
							}
						} else {
							MessageBox.error("Please enter a Valid Batch Number");
						}
					}
					this.getView().byId("idCombinedWeightButton").setEnabled(false);
					this.getView().byId("idCombineWeightSave").setEnabled(false);
				}.bind(this),
				error: function(error) {
					MessageBox.error("Error in getting batches data");
				}
			});
		},
		saveNewLineItems: function(oNewItem, oParent, combinedStatus) {
			var materialAllChar = oNewItem.Matnr.length;
			var matnr = oNewItem.Matnr;
			if (materialAllChar < 18) {
				for (var f = 0; f < 18 - materialAllChar; f++) {
					matnr = "0" + matnr;
				}
			}
			var aFilters = [],
				aStatusFilter = [];
			aFilters.push(new Filter({
				path: "Matnr",
				value1: matnr,
				operator: FilterOperator.EQ
			}));
			aFilters.push(new Filter({
				path: "Werks",
				value1: oNewItem.Plant,
				operator: FilterOperator.EQ
			}));
			aFilters.push(new Filter({
				path: "Lgort",
				value1: oNewItem.Lgort,
				operator: FilterOperator.EQ
			}));
			aFilters.push(new Filter({
				path: "Clabs",
				value1: "0.000",
				operator: FilterOperator.NE
			}));
			var oFilter = new Filter(aFilters, true);
			aStatusFilter.push(oFilter);
			this.getOwnerComponent().getModel().read("/BatchF4Set", {
				filters: aStatusFilter,
				success: function(oData) {
					this.getView().getModel("BatchModel").setProperty("/Items", oData.results);
					var bgsQty, bagInt, lgort, obditem, material, containerNo, batchCheck,
						batchItems,
						batchLength,
						sumQty = oParent.getCells()[10].getText();
					if (this.vehicleType === "YB16") {
						var batch = oParent.getCells()[6].getValue();
						bgsQty = oParent.getCells()[8].getValue();
						bagInt = bgsQty.includes(".");
						var BagsChkWeight = oParent.getCells()[9].getValue();
						if (BagsChkWeight !== "") {
							lgort = oParent.getCells()[2].getText();
							obditem = oParent.getCells()[1].getText();
							containerNo = oParent.getCells()[5].getSelectedKey();
							material = oParent.getCells()[0].getText();
							batchCheck = false;
							batchItems = this.getView().getModel("BatchModel").getProperty("/Items");
							batchLength = batchItems.length;
							if (oNewItem.BatchEnabled) {
								for (var kkk = 0; kkk < batchLength; kkk++) {
									if (batchItems[kkk].Charg === batch) {
										batchCheck = true;
									}
								}
							} else {
								batchCheck = true;
							}
							if (batchCheck) {
								if (bgsQty != 0 && bgsQty !== undefined) {
									var payloadContainer = {
										"Batch": oParent.getCells()[6].getValue(),
										"BagType": oParent.getCells()[7].getValue(),
										"BagsChkWeight": parseFloat(BagsChkWeight).toFixed(3),
										"BagQuantity": parseInt(bgsQty, 10),
										"ContainerNo": containerNo,
										"TruckNumber": this.truckNumber,
										"ObdNumber": oNewItem.obdNo,
										"BatchAdded": oNewItem.BatchAdded,
										"TripNumber": this.tripNumber,
										"ObdItem": obditem,
										"Lgort": lgort,
										"Maktx": material,
										"SalesUnit": oParent.getCells()[4].getText(),
										"Quantity": oParent.getCells()[3].getText(),
										"Werks": oNewItem.Plant,
										"Matnr": oNewItem.Matnr,
										"BatchEnabled": oNewItem.BatchEnabled,
										"WeighStatus": ""
									};
									if (combinedStatus === 1) {
										payloadContainer.LineItemLoaded = false;
									} else {
										payloadContainer.LineItemLoaded = true;
									}
									if (oNewItem.BatchAdded === "000") {
										this.getOwnerComponent().getModel().update("/PLMS_Obd_ItemSet(TruckNumber='" + this.truckNumber + "',ObdNumber='" +
											oNewItem.obdNo +
											"',TripNumber='" + this.tripNumber + "',BatchAdded='" + "000" + "',ObdItem='" + obditem +
											"',Lgort='" +
											lgort + "')", payloadContainer, {
												success: function(oData) {
													var oItems = oParent.getCells();
													for (var t = 5; t < 10; t++) {
														oItems[t].setEnabled(false);
													}
													MessageBox.success("Saved " + material + " data Successfully");
													this.getView().byId("idLoadingUnloading").destroyContent();
													var iItems = this.getView().getModel("TripOBDModel").getProperty("/Items");
													for (var ee = 0; ee < iItems.length; ee++) {
														this.createLoadingUnloadingMaterialsTabContent(ee);
													}
												}.bind(this),
												error: function(oError) {
													MessageBox.error("Error in saving " + material + " data");
												}
											});
									} else {
										this.getOwnerComponent().getModel().create("/PLMS_Obd_ItemSet", payloadContainer, {
											success: function(oData1) {
												var oItems = oParent.getCells();
												for (var t = 5; t < 10; t++) {
													oItems[t].setEnabled(false);
												}
												MessageBox.success("Saved " + material + " data Successfully");
												this.getView().byId("idLoadingUnloading").destroyContent();
												var iItems = this.getView().getModel("TripOBDModel").getProperty("/Items");
												for (var ee = 0; ee < iItems.length; ee++) {
													this.createLoadingUnloadingMaterialsTabContent(ee);
												}
											}.bind(this),
											error: function(oError) {
												MessageBox.error("Error in saving " + material + " data");
											}
										});
									}
								} else {
									MessageBox.error("Please enter Quantity");
								}
							} else {
								MessageBox.error("Please enter a Valid Batch Number");
							}
						} else {
							MessageBox.error("Please enter Weight");
						}
					}
					if (this.vehicle === "Truck" || this.vehicle === "Tank lorry") {
						bgsQty = oParent.getCells()[8].getValue();
						bagInt = bgsQty.includes(".");
						var batchTruck = oParent.getCells()[6].getValue();
						var BagsChkWeightTruck = oParent.getCells()[9].getValue();
						if (BagsChkWeight !== "") {
							lgort = oParent.getCells()[2].getText();
							obditem = oParent.getCells()[1].getText();
							containerNo = "000";
							material = oParent.getCells()[0].getText();
							batchCheck = false;
							batchItems = this.getView().getModel("BatchModel").getProperty("/Items");
							batchLength = batchItems.length;
							if (oNewItem.BatchEnabled) {
								for (var qqq = 0; qqq < batchLength; qqq++) {
									if (batchItems[qqq].Charg === batchTruck) {
										batchCheck = true;
									}
								}
							} else {
								batchCheck = true;
							}
							if (batchCheck) {
								if (bgsQty != 0 && bgsQty !== undefined) {
									var payloadTrucknandTank = {
										"Batch": oParent.getCells()[6].getValue(),
										"BagType": oParent.getCells()[7].getValue(),
										"BagsChkWeight": parseFloat(BagsChkWeightTruck).toFixed(3),
										"BagQuantity": parseInt(bgsQty, 10),
										"ContainerNo": containerNo,
										"TruckNumber": this.truckNumber,
										"ObdNumber": oNewItem.obdNo,
										"BatchAdded": oNewItem.BatchAdded,
										"TripNumber": this.tripNumber,
										"ObdItem": obditem,
										"Lgort": lgort,
										"Maktx": material,
										"SalesUnit": oParent.getCells()[4].getText(),
										"Quantity": oParent.getCells()[3].getText(),
										"Werks": oNewItem.Plant,
										"Matnr": oNewItem.Matnr,
										"BatchEnabled": oNewItem.BatchEnabled,
										"WeighStatus": ""
									};
									if (combinedStatus === 1) {
										payloadTrucknandTank.LineItemLoaded = false;
									} else {
										payloadTrucknandTank.LineItemLoaded = true;
									}
									if (oNewItem.BatchAdded === "000") {
										this.getOwnerComponent().getModel().update("/PLMS_Obd_ItemSet(TruckNumber='" + this.truckNumber + "',ObdNumber='" +
											oNewItem.obdNo +
											"',TripNumber='" + this.tripNumber + "',BatchAdded='" + "000" + "',ObdItem='" + obditem +
											"',Lgort='" +
											lgort + "')", payloadTrucknandTank, {
												success: function(oData2) {
													var oItems = oParent.getCells();
													for (var t = 6; t < 10; t++) {
														oItems[t].setEnabled(false);
													}
													MessageBox.success("Saved " + material + " data Successfully");
													/*	this.getView().byId("idLoadingUnloading").destroyContent();
														var iItems = this.getView().getModel("TripOBDModel").getProperty("/Items");
														for (var ee = 0; ee < iItems.length; ee++) {
															this.createLoadingUnloadingMaterialsTabContent(ee);
														}*/
													this.changeStatustoLP("LP");
												}.bind(this),
												error: function(oError) {
													MessageBox.error("Error in saving " + material + " data");
												}
											});
									} else {
										this.getOwnerComponent().getModel().create("/PLMS_Obd_ItemSet", payloadTrucknandTank, {
											success: function(oData3) {
												var oItems = oParent.getCells();
												for (var t = 5; t < 10; t++) {
													oItems[t].setEnabled(false);
												}
												MessageBox.success("Saved " + material + " data Successfully");
												/*this.getView().byId("idLoadingUnloading").destroyContent();
												var iItems = this.getView().getModel("TripOBDModel").getProperty("/Items");
												for (var ee = 0; ee < iItems.length; ee++) {
													this.createLoadingUnloadingMaterialsTabContent(ee);
												}*/
												this.changeStatustoLP("LP");
											}.bind(this),
											error: function(oError) {
												MessageBox.error("Error in saving " + material + " data");
											}
										});
									}
								} else {
									MessageBox.error("Please enter Quantity");
								}
							} else {
								MessageBox.error("Please enter a valid Batch Number");
							}
						} else {
							MessageBox.error("Please enter Weight");
						}
					}
					this.getView().byId("idCombinedWeightButton").setEnabled(false);
					this.getView().byId("idCombineWeightSave").setEnabled(false);
				}.bind(this),
				error: function(oError) {

				}
			});
		},
		onPostNotes: function() {
			var feedValue = this.getView().byId("idformFeed").getValue();
			var payload = {
				"TripNumber": this.tripNumber,
				"UserComments": feedValue
			};
			this.getOwnerComponent().getModel().create("/FeedsSet", payload, {
				success: function(oData) {
					MessageBox.success("Notes saved successfully");
					this.callNotes();
				}.bind(this),
				error: function(oError) {
					MessageBox.error("Error in saving notes");
				}
			});
		},
		callNotes: function() {
			var aFilters = [],
				aStatusFilter = [];
			aFilters.push(new Filter({
				path: "TripNumber",
				value1: this.tripNumber,
				operator: FilterOperator.EQ
			}));
			var oFilter = new Filter(aFilters, true);
			aStatusFilter.push(oFilter);
			this.getOwnerComponent().getModel().read("/FeedsSet", {
				filters: aStatusFilter,
				success: function(oData) {
					var data = oData.results;
					this.getView().getModel("NotesModel").setProperty("/Items", data);
					this.getView().setBusy(false);
				}.bind(this),
				error: function(oError) {
					sap.m.MessageToast.show("Error in getting OBD numbers data");
					this.getView().setBusy(false);
				}.bind(this)
			});
		},
		onCombinedWeightAccept: function() {
			var grossValue = this.getView().byId("idGrossCombined").getText();
			var tareValue = this.getView().byId("idTareCombined").getText();
			var netValue = this.getView().byId("idNetCombined").getText();
			if (grossValue !== "0.000" && tareValue !== "0.000" && netValue !== "0.000") {
				var payload = {
					"WeighStatus": "ACCEPTED",
					"CombinedFlag": true
				};
				var anyObdItemArray = this.getView().getModel("TripModel").getData().ObdNumber; //this.getView().getModel("LoadingItemsModel").getProperty("/Items");
				var aItemFilters = [],
					aItemsAllFilters = [];
				aItemFilters.push(new Filter({
					path: "TruckNumber",
					value1: this.truckNumber,
					operator: FilterOperator.EQ
				}));
				aItemFilters.push(new Filter({
					path: "TripNumber",
					value1: this.tripNumber,
					operator: FilterOperator.EQ
				}));
				aItemFilters.push(new Filter({
					path: "ObdNumber",
					value1: "00" + anyObdItemArray,
					operator: FilterOperator.EQ
				}));
				var oItemFilter = new Filter(aItemFilters, true);
				aItemsAllFilters.push(oItemFilter);
				this.getOwnerComponent().getModel().read("/PLMS_Obd_ItemSet", {
					filters: aItemsAllFilters,
					success: function(oData3) {
						var anyItem;
						for (var jj = 0; jj < oData3.results.length; jj++) {
							if (oData3.results[jj].ObdNumber === anyObdItemArray) {
								anyItem = oData3.results[jj].ObdItem;
								break;
							}
						}
						//anyObdItemArray[0].ObdItem;
						this.getOwnerComponent().getModel().update("/PLMS_Obd_ItemSet(TruckNumber='" + this.truckNumber + "',ObdNumber='" +
							this.obdNumber +
							"',TripNumber='" + this.tripNumber + "',BatchAdded='" + "000" + "',ObdItem='" + anyItem +
							"',Lgort='" +
							this.lGort + "')", payload, {
								success: function(oData2) {
									MessageBox.success("Details saved Successfully");
									this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
										filters: this.aStatusFilter,
										success: function(oData) {
											this.getView().getModel("TripModel").setData(oData.results[0]);
											this.getView().getModel("TripOBDModel").setProperty("/Items", oData.results);
											this.tripStatus = this.getView().getModel("TripModel").getData().TripStatus;
											this.tripNumber = this.getView().getModel("TripModel").getData().TripNumber;
											this.timeLineUpdate();
											if (this.tripStatus !== "" && this.tripStatus !== undefined) {
												this.attachmentsSection();
											}
											this.getView().getModel("TripModel").refresh(true);
											this.callEnableDisableFunction();
											this.getView().byId("idLoadingUnloading").destroyContent();
											this.getView().byId("idGateInMainPanel").destroyContent();
											var iItems = this.getView().getModel("TripOBDModel").getProperty("/Items");
											for (var ee = 0; ee < iItems.length; ee++) {
												this.createGateInTabContent(ee);
												this.createLoadingUnloadingMaterialsTabContent(ee);
											}
										}.bind(this),
										error: function(oError1) {

										}
									});
								}.bind(this),
								error: function(oError) {
									MessageBox.error("Error in saving data");
								}
							});
					}.bind(this),
					error: function(oError) {

					}
				});
			} else {
				MessageBox.error("Weights are Empty");
			}
		},
		onCombinedWeightReject: function() {
			var grossValue = this.getView().byId("idGrossCombined").getText();
			var tareValue = this.getView().byId("idTareCombined").getText();
			var netValue = this.getView().byId("idNetCombined").getText();
			if (grossValue !== "0.000" && tareValue !== "0.000" && netValue !== "0.000") {
				if (!this.dialogUnlistedText) {
					this.dialogUnlistedText = sap.ui.xmlfragment(this.getView().getId(), "ZSonic_PLMS.view.Fragment.RejectionText", this);
					this.getView().addDependent(this.dialogUnlistedText);
				}
				this.dialogUnlistedText.open();
			} else {
				MessageBox.error("Weights are Empty");
			}
		},
		onCombinedWeightRejectReasonsList: function() {
			var aItemFilters = [],
				aItemsAllFilters = [];
			aItemFilters.push(new Filter({
				path: "Traid",
				value1: this.truckNumber,
				operator: FilterOperator.EQ
			}));
			aItemFilters.push(new Filter({
				path: "TripNumber",
				value1: this.tripNumber,
				operator: FilterOperator.EQ
			}));
			/*	aItemFilters.push(new Filter({
					path: "Vbeln",
					value1: this.obdNumber,
					operator: FilterOperator.EQ
				}));*/
			var oItemFilter = new Filter(aItemFilters, true);
			aItemsAllFilters.push(oItemFilter);
			if (this.getView().getModel("LoadingItemsModel").getProperty("/CombinedWeight")) {
				this.getOwnerComponent().getModel().read("/WeightCancelSet", {
					filters: aItemsAllFilters,
					success: function(oData) {
						var totalLineItems = oData.results;
						this.getView().getModel("RejectReasonModel").setProperty("/Items", totalLineItems);
						this.getView().getModel("RejectReasonModel").refresh(true);
					}.bind(this),
					error: function(oError) {
						MessageBox.error("Error in getting Reject Reasons");
					}
				});
				if (!this.dialogUnlisted) {
					this.dialogUnlisted = sap.ui.xmlfragment(this.getView().getId(), "ZSonic_PLMS.view.Fragment.RejectReasons", this);
					this.getView().addDependent(this.dialogUnlisted);
				}
				this.dialogUnlisted.open();
			}
		},
		checkWeightAcceptEnabled: function(results, i) {
			if ( /*this.tripStatus === "LC" || */ this.tripStatus === "WC" || this.tripStatus === "GO" || this.tripStatus === "PG" || this.tripStatus ===
				"WR") {
				return false;
			} else {
				if (results[i].BatchAdded === "000") {
					/*var loaded = false;
					var role = this.getOwnerComponent().getModel("RoleModel").getProperty("/Roles");
					var activity = this.getOwnerComponent().getModel("RoleModel").getProperty("/Activities");
					if (role && activity) {
						var Role = false;
						for (var aa = 0; aa < role.length; aa++) {
							if (role[aa] === "Weighment") {
								if (activity[aa] === "1" || activity[aa] === "2") {
									Role = true;
								}
							}
						}
						if (results[i].LineItemLoaded) {
							loaded = true;
						}
						if (Role && loaded) {
							return true;
						} else {
							return false;
						}
					}*/
					var Role = false;
					var loaded = false;
					var items = this.getOwnerComponent().getModel("AuthorizationModel").getProperty("/Items");
					var plant = this.getView().getModel("TripModel").getData().Plant;
					if (items) {
						var auth = items;
						if (auth) {
							var authl = auth.length;
							/*	return true;*/
							for (var j = 0; j < authl; j++) {
								if (auth[j].Werks === plant) {
									if (auth[j].Module === "Weighment") {
										if (auth[j].Actvt === "1" || auth[j].Actvt === "2") {
											Role = true;
											break;
										}
									}
								}
							}
							if (results[i].LineItemLoaded) {
								loaded = true;
							}
							if (Role && loaded) {
								return true;
							} else {
								return false;
							}
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			}
		},
		checkWeightRejectEnabled: function(results, i) {
			if ( /*this.tripStatus === "LC" || */ this.tripStatus === "WC" || this.tripStatus === "GO" || this.tripStatus === "PG" || this.tripStatus ===
				"WR") {
				return false;
			} else {
				if (results[i].BatchAdded === "000") {
					/*var loaded = false;
					var role = this.getOwnerComponent().getModel("RoleModel").getProperty("/Roles");
					var activity = this.getOwnerComponent().getModel("RoleModel").getProperty("/Activities");
					if (role && activity) {
						var Role = false;
						for (var aa = 0; aa < role.length; aa++) {
							if (role[aa] === "Weighment") {
								if (activity[aa] === "1" || activity[aa] === "2") {
									Role = true;
								}
							}
						}
						if (results[i].LineItemLoaded) {
							loaded = true;
						}
						if (Role && loaded) {
							return true;
						} else {
							return false;
						}
					}*/
					var Role = false;
					var loaded = false;
					var items = this.getOwnerComponent().getModel("AuthorizationModel").getProperty("/Items");
					var plant = this.getView().getModel("TripModel").getData().Plant;
					if (items) {
						var auth = items;
						if (auth) {
							var authl = auth.length;
							/*	return true;*/
							for (var j = 0; j < authl; j++) {
								if (auth[j].Werks === plant) {
									if (auth[j].Module === "Weighment") {
										if (auth[j].Actvt === "1" || auth[j].Actvt === "2") {
											Role = true;
											break;
										}
									}
								}
							}
							if (results[i].LineItemLoaded) {
								loaded = true;
							}
							if (Role && loaded) {
								return true;
							} else {
								return false;
							}
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			}
		},
		checkWeightRejectReasonsEnabled: function(results, i) {
			if ( /*this.tripStatus === "LC" || */ this.tripStatus === "GI" || this.tripStatus === "" || this.tripStatus === "RD" || this.tripStatus ===
				"IP" || this.tripStatus === "IC") {
				return false;
			} else {
				var combined = this.getView().getModel("LoadingItemsModel").getProperty("/CombinedWeight");
				if (results[i].BatchAdded === "000") {
					/*var role = this.getOwnerComponent().getModel("RoleModel").getProperty("/Roles");
					var activity = this.getOwnerComponent().getModel("RoleModel").getProperty("/Activities");
					if (role && activity) {
						var Role = false;
						for (var aa = 0; aa < role.length; aa++) {
							if (role[aa] === "Loading") {
								if (activity[aa] === "1" || activity[aa] === "2") {
									Role = true;
								}
							}
						}
						if (Role && !combined) {
							return true;
						} else {
							return false;
						}
					}*/
					var Role = false;
					var items = this.getOwnerComponent().getModel("AuthorizationModel").getProperty("/Items");
					var plant = this.getView().getModel("TripModel").getData().Plant;
					if (items) {
						var auth = items;
						if (auth) {
							var authl = auth.length;
							for (var j = 0; j < authl; j++) {
								if (auth[j].Werks === plant) {
									Role = true;
									break;
								}
							}
							if (Role && !combined) {
								return true;
							} else {
								return false;
							}
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			}
		},
		changeStatustoLP: function(status) {
			var payload = {
				"TripStatus": status
			};
			this.getOwnerComponent().getModel().update("/PLMS_outbound_HdrSet(TruckNumber='" + this.truckNumber + "',ObdNumber='" +
				this.obdNumber +
				"',TripNumber='" + this.tripNumber + "')", payload, {
					method: "PUT",
					success: function(response) {
						//read call
						this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
							filters: this.aStatusFilter,
							success: function(oData) {
								this.getView().getModel("TripModel").setData(oData.results[0]);
								this.getView().getModel("TripOBDModel").setProperty("/Items", oData.results);
								this.tripStatus = this.getView().getModel("TripModel").getData().TripStatus;
								this.tripNumber = this.getView().getModel("TripModel").getData().TripNumber;
								this.timeLineUpdate();
								if (this.tripStatus !== "" && this.tripStatus !== undefined) {
									this.attachmentsSection();
								}
								this.getView().getModel("TripModel").refresh(true);
								this.callEnableDisableFunction();
								this.getView().byId("idLoadingUnloading").destroyContent();
								this.getView().byId("idGateInMainPanel").destroyContent();
								var iItems = this.getView().getModel("TripOBDModel").getProperty("/Items");
								for (var ee = 0; ee < iItems.length; ee++) {
									this.createGateInTabContent(ee);
									this.createLoadingUnloadingMaterialsTabContent(ee);
								}
							}.bind(this),
							error: function(oError1) {

							}
						});
					}.bind(this),
					error: function(oError) {

					}
				});
		},
		onPressCombinedWeightButton: function() {
			var getCombinedSelection = this.getView().byId("idCombinedWeightButton").getSelectedIndex();
			var payload = {
				"CombinedWeightValue": 0
			};
			if (getCombinedSelection === 0) {
				payload.CombinedWeightValue = 2;
			}
			if (getCombinedSelection === 1) {
				payload.CombinedWeightValue = 1;
			}
			this.getOwnerComponent().getModel().update("/PLMS_outbound_HdrSet(TruckNumber='" + this.truckNumber + "',ObdNumber='" +
				this
				.obdNumber +
				"',TripNumber='" + this.tripNumber + "')", payload, {
					method: "PUT",
					success: function(response) {
						this.readHeaderEntitySet();
						MessageBox.success("Selection saved successfully");
						this.getView().byId("idLoadingUnloading").destroyContent();
						this.getView().byId("idGateInMainPanel").destroyContent();
						var oItems = this.getView().getModel("TripOBDModel").getProperty("/Items");
						for (var ee = 0; ee < oItems.length; ee++) {
							this.createGateInTabContent(ee);
							this.createLoadingUnloadingMaterialsTabContent(ee);
						}
					}.bind(this),
					error: function(oError) {
						MessageBox.error("");
					}
				});
		},
		formatWeighmentColor: function(text, oCell) {
			if (text === "REJECTED") {

				oCell.addStyleClass("RedText");
				return text;
			}
			if (text === "ACCEPTED") {
				return text;
			}
		},
		onCloseRejectName: function() {
			if (this.dialogUnlisted) {
				this.dialogUnlisted.close();
			}
		},
		onCloseRejectTextName: function() {
			if (this.dialogUnlistedText) {
				this.dialogUnlistedText.close();
			}
		},
		onSaveRejectionReason: function() {
			var rej = this.getView().byId("idRejectText").getValue();
			if (rej === "") {
				MessageBox.error("Please enter reason");
			} else {
				if (this.getView().getModel("LoadingItemsModel").getProperty("/CombinedWeight")) {
					var payload = {
						"WeighStatus": "REJECTED",
						"CombinedFlag": true,
						"WeighRejCmnt": rej
					};
					/*	var anyObdItemArray = this.getView().getModel("LoadingItemsModel").getProperty("/Items");
						var anyItem = anyObdItemArray[0].ObdItem;*/
					var anyObdItemArray = this.getView().getModel("TripModel").getData().ObdNumber; //this.getView().getModel("LoadingItemsModel").getProperty("/Items");
					var aItemFilters = [],
						aItemsAllFilters = [];
					aItemFilters.push(new Filter({
						path: "TruckNumber",
						value1: this.truckNumber,
						operator: FilterOperator.EQ
					}));
					aItemFilters.push(new Filter({
						path: "TripNumber",
						value1: this.tripNumber,
						operator: FilterOperator.EQ
					}));
					aItemFilters.push(new Filter({
						path: "ObdNumber",
						value1: "00" + anyObdItemArray,
						operator: FilterOperator.EQ
					}));
					var oItemFilter = new Filter(aItemFilters, true);
					aItemsAllFilters.push(oItemFilter);
					this.getOwnerComponent().getModel().read("/PLMS_Obd_ItemSet", {
						filters: aItemsAllFilters,
						success: function(oData3) {
							var anyItem;
							for (var jj = 0; jj < oData3.results.length; jj++) {
								if (oData3.results[jj].ObdNumber === anyObdItemArray) {
									anyItem = oData3.results[jj].ObdItem;
									break;
								}
							}
							this.getOwnerComponent().getModel().update("/PLMS_Obd_ItemSet(TruckNumber='" + this.truckNumber + "',ObdNumber='" +
								this.obdNumber +
								"',TripNumber='" + this.tripNumber + "',BatchAdded='" + "000" + "',ObdItem='" + anyItem +
								"',Lgort='" +
								this.lGort + "')", payload, {
									success: function(oData2) {
										MessageBox.success("Details saved Successfully");
										var tripPayload = {
											"TripStatus": "WR"
										};
										this.getOwnerComponent().getModel().update("/PLMS_outbound_HdrSet(TruckNumber='" + this.truckNumber +
											"',ObdNumber='" +
											this.obdNumber +
											"',TripNumber='" + this.tripNumber + "')", tripPayload, {
												success: function(oData1) {
													this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
														filters: this.aStatusFilter,
														success: function(oData) {
															this.getView().getModel("TripModel").setData(oData.results[0]);
															this.getView().getModel("TripOBDModel").setProperty("/Items", oData.results);
															this.tripStatus = this.getView().getModel("TripModel").getData().TripStatus;
															this.tripNumber = this.getView().getModel("TripModel").getData().TripNumber;
															this.timeLineUpdate();
															if (this.tripStatus !== "" && this.tripStatus !== undefined) {
																this.attachmentsSection();
															}
															this.getView().getModel("TripModel").refresh(true);
															this.callEnableDisableFunction();
															this.getView().byId("idLoadingUnloading").destroyContent();
															this.getView().byId("idGateInMainPanel").destroyContent();
															var oItems = this.getView().getModel("TripOBDModel").getProperty("/Items");
															for (var ee = 0; ee < oItems.length; ee++) {
																this.createGateInTabContent(ee);
																this.createLoadingUnloadingMaterialsTabContent(ee);
															}
															this.onCloseRejectTextName();
															this.getView().byId("idRejectText").setValue("");
														}.bind(this),
														error: function(oError) {
															MessageBox.warning("Error occurred while reading Header data");
														}
													});
												}.bind(this),
												error: function(error) {
													MessageBox.error("error while updating the trip status");
												}
											});
									}.bind(this),
									error: function(oError) {
										MessageBox.error("Error in saving data");
									}
								});
						}.bind(this),
						error: function(oError) {

						}
					});
				} else {
					var payload1 = {
						"ObdItem": this.resultsObdItem,
						"WeighStatus": "REJECTED",
						"WeighRejCmnt": rej
					};
					this.getOwnerComponent().getModel().update("/PLMS_Obd_ItemSet(TruckNumber='" + this.truckNumber + "',ObdNumber='" + "00" +
						this.resultOBDNo +
						"',TripNumber='" + this.tripNumber + "',BatchAdded='" + "000" + "',ObdItem='" + this.resultsObdItem +
						"',Lgort='" +
						this.resultLgort + "')", payload1, {
							success: function(oData2) {
								var tripPayload = {
									"TripStatus": "WR"
								};
								this.getOwnerComponent().getModel().update("/PLMS_outbound_HdrSet(TruckNumber='" + this.truckNumber +
									"',ObdNumber='" +
									this.obdNumber +
									"',TripNumber='" + this.tripNumber + "')", tripPayload, {
										success: function(oData1) {
											this.getOwnerComponent().getModel().read("/PLMS_outbound_HdrSet", {
												filters: this.aStatusFilter,
												success: function(oData) {
													this.getView().getModel("TripModel").setData(oData.results[0]);
													this.getView().getModel("TripOBDModel").setProperty("/Items", oData.results);
													this.tripStatus = this.getView().getModel("TripModel").getData().TripStatus;
													this.tripNumber = this.getView().getModel("TripModel").getData().TripNumber;
													this.timeLineUpdate();
													if (this.tripStatus !== "" && this.tripStatus !== undefined) {
														this.attachmentsSection();
													}
													this.getView().getModel("TripModel").refresh(true);
													this.callEnableDisableFunction();
													this.getView().byId("idLoadingUnloading").destroyContent();
													this.getView().byId("idGateInMainPanel").destroyContent();
													var oItems = this.getView().getModel("TripOBDModel").getProperty("/Items");
													for (var ee = 0; ee < oItems.length; ee++) {
														this.createGateInTabContent(ee);
														this.createLoadingUnloadingMaterialsTabContent(ee);
													}
													this.onCloseRejectTextName();
													this.getView().byId("idRejectText").setValue("");
												}.bind(this),
												error: function(oError) {
													MessageBox.warning("Error occurred while reading Header data");
												}
											});
										}.bind(this),
										error: function(error) {
											MessageBox.error("error while updating the trip status");
										}
									});
							}.bind(this),
							error: function(oerror) {

							}
						});
				}
			}
		}
	});
});