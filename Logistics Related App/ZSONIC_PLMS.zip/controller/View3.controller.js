sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/Fragment",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"ZSonic_PLMS/model/formatter"
], function(Controller, JSONModel, Fragment, History, Filter, FilterOperator, MessageBox, formatter) {
	"use strict";
	var actvtObj = {},
		PLCode, loggedInUser;
	return Controller.extend("ZSonic_PLMS.controller.View3", {
		f: formatter,
		onInit: function() {
			this.getOwnerComponent().getRouter().getRoute("view3").attachPatternMatched(this.onPatternMatched, this);
			this.getView().addStyleClass("sapUiSizeCompact");

			//soc
			// var oTransporternameModel = this.getOwnerComponent().getModel("TransporterNamesModel");
			// if (!oTransporternameModel) {
			// 	sap.m.MessageBox.error("Transporter model not found!");
			// 	return;
			// }

			// oTransporternameModel.read("/TransporterSet", {
			// 	success: function(oData) {
			// 		debugger;
			// 		var transP = new sap.ui.model.json.JSONModel(oData.results);
			// 		oView.setModel(transP, "TransporterNamesModel");
			// 		console.log("Transporter data loaded successfully.");
			// 	},
			// 	error: function(oError) {
			// 		sap.m.MessageBox.error("Failed to load transporters");
			// 		console.error("Transporter data error:", oError);
			// 	}
			// });
			//Eoc Bhavesh

			//SOC NIGAM
			//Fetch user roles for plantcode and actvt id.
			var aUserFilters = [],
				aUserStatusFilter = [];
			aUserFilters.push(new Filter({
				path: "Pernr",
				value1: "00000000",
				operator: FilterOperator.EQ
			}));
			var oUserFilter = new Filter(aUserFilters, true);
			aUserStatusFilter.push(oUserFilter);
			this.getOwnerComponent().getModel().read("/GetUserandRolesSet", {
				filters: aUserStatusFilter,
				success: function(oData) {
					var data = oData.results;
					actvtObj = {};
					for (var i = 0; i < data.length; i++) {
						var item = data[i];
						//storing logged in user
						if (!loggedInUser) {
							loggedInUser = item.Usrid;
						}
						if (item.Module === "Un-Assigned") {

							if (!actvtObj.hasOwnProperty(item.Werks)) {
								actvtObj[item.Werks] = item.Actvt;
							} else {
								continue;
							}
						}

					}
					console.log("actvties", actvtObj);
					console.log("Logged in user", loggedInUser);

				}
			});

			//EOC NIGAM
			//...
			// plantActvtData = this.getOwnerComponent().getModel("ActvtModel").getProperty("/items");
			// console.log("actvt data", plantActvtData);
			var timeModel = new JSONModel({
				timePickers: {
					TP1: {
						format: "HH:mm:ss",
						placeholder: "Enter meeting start time"
					}
				}
			});
			this.getView().setModel(timeModel, "TimeModel");

			var plantNam = new JSONModel();
			this.getView().setModel(plantNam, "PlantsCodesModel");

		},
		onAfterRendering: function() {

			// setTimeout(() => {

			// 	if (PLCode === "NA") {
			// 		var plantC = "Select Code"
			// 		this.readUnListedModel(plantC);
			// 	} else {
			// 		this.readUnListedModel(PLCode);
			// 	}
			// 	this.resetInputFields();
			// }, 1000)

		},

		onPatternMatched: function(oEvent) {
			PLCode = oEvent.getParameters().arguments.plantCode;

			if (PLCode !== "NA") {
				this.byId("idPlantCodeSelect").setSelectedKey(PLCode);
				//reading the data for selected plant code.
				setTimeout(() => {
					this.onPlantCodeChange();

				}, 1000)

			} else {
				this.byId("idPlantCodeSelect").setSelectedKey("Select Code");
				setTimeout(() => {
					this.onPlantCodeChange();

				}, 1000)
			}
		},

		onCloseRegisterButton: function() {
			this.resetInputFields();
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.navTo("view1", {}, true);
		},

		// soc by bhavesh
		preventManualEntry: function(oEvent) {

			var input = oEvent.getSource();
			var value = input.getValue(); // Get the current value of the input
			// Replace any non-digit characters and limit to 4 digits
			var sanitizedValue = value.replace(/\D/g, "").slice(0, 4);

			// Set the sanitized value back to the input
			if (sanitizedValue !== value) {
				input.setValue(sanitizedValue);
			}
		},

		// Eoc by bhavesh
		onReportDateChange: function(oEvent) {
			// Get the DatePicker instance and the selected date
			var reportDateField = oEvent.getSource();
			var reportDate = reportDateField.getDateValue(); // Get the newly selected date
			var currentDate = new Date(); // Current date

			// Reset time to ensure only the date is compared
			currentDate.setHours(0, 0, 0, 0);
			if (reportDate) {
				reportDate.setHours(0, 0, 0, 0);
			}

			// Clear previous error state
			reportDateField.setValueState("None");
			reportDateField.setValueStateText("");

			// If no date is selected (shouldn't occur in most cases), return early
			if (!reportDate) {
				return;
			}

			// Validate the selected date
			if (reportDate < currentDate) {
				// Past date validation
				reportDateField.setValueState("Error");
				reportDateField.setValueStateText("Reported Date cannot be in the past");
				MessageBox.error("Reported Date cannot be in the past");
				return;
			}

			if (reportDate > currentDate) {
				// Future date validation
				reportDateField.setValueState("Error");
				reportDateField.setValueStateText("Reported Date cannot be greater than today's date");
				MessageBox.error("Reported Date cannot be greater than today's date");
				return;
			}

			// If the date is valid, proceed without error
			// console.log("Valid date selected:", reportDate);
		},

		onRegisterUnlistedVehicle: function() {
			var type = this.getView().byId("idVehicleTypeDropdown").getSelectedKey();
			var typeDesc = this.getView().byId("idVehicleTypeDropdown").getSelectedItem().getText();
			var truckNo = this.getView().byId("idUnlistedTruckNumber").getValue();
			var transporterName = this.getView().byId("idTransporterName").getValue();
			var plantName = this.getView().byId("idPlantName").getValue();
			var buttonText = this.getView().byId("idRegisterUpdate").getText();
			var reportDateField = this.getView().byId("idReportDate"); // Get the date picker control
			var reportDate = reportDateField.getDateValue(); // Get the value of the date picker
			var reportTime = this.getView().byId("idReportTime").getValue();
			var movement = this.byId("movement").getSelectedItem().getKey();

			// Validate the report date
			if (!reportDate) {
				MessageBox.error("Please enter Reported Date");
				return;
			}
			//SOC NIGAM

			//validate the movement type
			if (movement === "Select") {
				MessageBox.information("Please select a Movement type (Inward/Outward).");
				return;
			}

			//EOC NIGAM

			// // Validate if the report date is valid (not in the past or future)
			// var currentDate = new Date(); // Get the current system date
			// // currentDate.setHours(0, 0, 0, 0); // Reset time to 00:00:00 for comparison

			// if (reportDate) {
			// 	reportDate.setHours(0, 0, 0, 0);
			// }

			// // Ensure the reportDate is also reset to 00:00:00
			// if (reportDate) {
			// 	reportDate.setHours(0, 0, 0, 0);
			// }

			// // Clear previous validation error state
			// reportDateField.setValueState("None");
			// reportDateField.setValueStateText("");

			// // Handle cases where no date is selected
			// if (!reportDate) {
			// 	return; // Exit if no date is selected
			// }

			// // Validate the newly selected date
			// if (reportDate < currentDate) {
			// 	reportDateField.setValueState("Error");
			// 	reportDateField.setValueStateText("Reported Date cannot be in the past");
			// 	MessageBox.error("Reported Date cannot be in the past");
			// 	return; // Exit after showing the error
			// }

			// if (reportDate > currentDate) {
			// 	reportDateField.setValueState("Error");
			// 	reportDateField.setValueStateText("Reported Date cannot be greater than today's date");
			// 	MessageBox.error("Reported Date cannot be greater than today's date");
			// 	return; // Exit after showing the error
			// }

			// // If the date is valid, proceed
			// console.log("Valid date selected:", reportDate);

			// // If valid, clear error state and accept the date
			// reportDateField.setValueState("None");

			// Validate the report time
			if (!reportTime || reportTime === "") {
				MessageBox.error("Please enter report time");
				return; // Exit if the time is invalid
			}

			// Split the report time and ensure seconds are set
			var timeArray = reportTime.split(":");
			if (timeArray.length < 3) {
				timeArray[2] = "00"; // Set seconds to 00 if not provided
			} else if (timeArray.length === 2) {
				timeArray.push("00"); // Add seconds if only hours and minutes are provided
			}

			// Adjust the hour based on AM/PM
			var containsAM = reportTime.includes("AM");
			var containsPM = reportTime.includes("PM");
			var hour = parseInt(timeArray[0], 10);
			if (containsAM && hour === 12) {
				hour = 0; // Convert 12 AM to 00 hours
			} else if (containsPM && hour < 12) {
				hour += 12; // Convert PM hours to 24-hour format
			}

			// Set time to the report date
			reportDate.setHours(hour, parseInt(timeArray[1], 10), parseInt(timeArray[2], 10));

			// Format the time correctly (HH:mm:ss)
			var formattedReportTime =
				hour.toString().padStart(2, "0") + ":" +
				timeArray[1].padStart(2, "0") + ":" +
				timeArray[2].padStart(2, "0");

			// Prepare the payload
			var payload = {
				VehicleType: type,
				TruckNumber: truckNo.toString().toUpperCase(),
				Transporter: this.selectedTravelCategory,
				TransportName: transporterName,
				Werks: plantName,
				VehTypeDesc: typeDesc,
				ReportInDate: reportDate, // This will have the correct date
				ReportTime: formattedReportTime, // Use the correctly formatted time as HH:mm:ss
				InOutMode: movement
			};

			// Check if the plant is valid
			var plantArray = this.getView().getModel("PlantsModel").getProperty("/plantValues");
			var plantAvailable = plantArray.some(function(plant) {
				return plant.PlantCode === plantName;
			});

			// Validate input fields
			if (!truckNo) {
				MessageBox.error("Truck Number is Mandatory");
			} else if (!transporterName) {
				MessageBox.error("Transporter Name is Mandatory");
			} else if (!plantName) {
				MessageBox.error("Plant Name is Mandatory");
			} else if (!plantAvailable) {
				MessageBox.error("Please enter a valid plant");
			} else {
				// Perform create or update based on button text
				if (buttonText === "Register") {
					this.getOwnerComponent().getModel().create("/UnassignVehiclesSet", payload, {
						success: function(oData) {
							MessageBox.success("Vehicle has been registered Successfully");
							var selectedPlantCode = this.byId("idPlantCodeSelect").getSelectedItem().getKey();
							this.readUnListedModel(selectedPlantCode);
						}.bind(this),
						error: function(oError) {
							// Check if backend message is available
							if (oError.responseText) {
								var errMsg = JSON.parse(oError.responseText).error.message.value;
								MessageBox.information(errMsg); // Show the backend error message
							} else {
								MessageBox.error("Error occurred while registering the vehicle"); // Default error message
							}
							// Refresh the data after error
							var selectedPlantCode = this.byId("idPlantCodeSelect").getSelectedItem().getKey();
							this.readUnListedModel(selectedPlantCode);
						}.bind(this)
					});
					this.resetForm();

				} else if (buttonText === "Update") {
					this.getOwnerComponent().getModel().update("/UnassignVehiclesSet(TruckNumber='" + truckNo + "',SerialNo=" + this.serialNo +
						",Werks='" + plantName + "')",
						payload, {
							method: "PUT",
							success: function(oData) {
								MessageBox.success("Vehicle details have been Updated Successfully");
								this.resetForm();
								this.getView().byId("idRegisterUpdate").setText("Register");
								var selectedPlantCode = this.byId("idPlantCodeSelect").getSelectedItem().getKey();
								this.readUnListedModel(selectedPlantCode);

							}.bind(this),
							error: function(oError) {
								// Check if backend message is available
								if (oError.responseText) {
									var errMsg = JSON.parse(oError.responseText).error.message.value;
									MessageBox.information(errMsg); // Show the backend error message
								} else {
									MessageBox.error("Error occurred while registering the vehicle"); // Default error message
								}
								// Refresh the data after error
								var selectedPlantCode = this.byId("idPlantCodeSelect").getSelectedItem().getKey();
								this.readUnListedModel(selectedPlantCode);
							}.bind(this)
						});
					this.resetForm();
				}
			}
		},

		resetInputFields: function() {
			this.getView().byId("idUnlistedTruckNumber").setValue("");
			this.getView().byId("idTransporterName").setValue("");
			this.getView().byId("idPlantName").setValue("");
			this.getView().byId("idVehicleTypeDropdown").setSelectedKey("0000");
			this.getView().byId("idReportDate").setDateValue(null);
			this.getView().byId("idReportTime").setValue(null);
			this.getView().byId("movement").setSelectedKey("Select");

		},

		resetForm: function() {
			this.resetInputFields();
			this.getView().byId("idUnlistedTruckNumber").setEnabled(true);
		},
		//Soc By Bhavesh
		transporterListValueHelp: function() {
			var that = this;

			// Check if the fragment is already created
			if (!this.dialogUnlisted) {
				this.dialogUnlisted = sap.ui.xmlfragment(
					this.getView().getId(),
					"ZSonic_PLMS.view.Fragment.UnlistedVehicle",
					this
				);
				this.getView().addDependent(this.dialogUnlisted);
			}

			// GET call to fetch data
			var sServiceUrl = "/sap/opu/odata/sap/ZPLMS_SRV/";
			var oModel = new sap.ui.model.odata.v2.ODataModel(sServiceUrl, {
				json: true,
				loadMetadataAsync: true
			});

			// Read data from the OData service
			sap.ui.core.BusyIndicator.show(0);
			oModel.read("/TransporterSet", {
				success: function(oData) {
					// Correctly set the data by accessing "d.results"
					sap.ui.core.BusyIndicator.hide();
					// console.log("Fetched Transporter Data:", oData.results);
					var oJSONModel = new sap.ui.model.json.JSONModel({
						results: oData.results

					});
					that.getView().setModel(oJSONModel, "transporterModel");

					// Bind data to the fragment
					var oTable = sap.ui.core.Fragment.byId(that.getView().getId(), "transporterNameslist");
					if (oTable) {
						oTable.setModel(that.getView().getModel("transporterModel"));
					} else {
						console.error("Table not found");
					}
				},
				error: function(oError) {
					sap.m.MessageToast.show("Failed to fetch data");
					console.error("Error fetching transporter data:", oError);
				}
			});

			// Open the dialog
			this.dialogUnlisted.open();
		},

		//Eoc by Bhavesh

		onSelectionChange: function(oEvent) {
			this.selectedTravelCategory = oEvent.getSource().getSelectedItem().getNumber();
			var travelCat = oEvent.getSource().getSelectedItem().getTitle();
			this.getView().byId("idTransporterName").setValue(travelCat);
			if (this.dialogUnlisted) {
				this.dialogUnlisted.close();
			}
		},

		onCloseTransporterName: function() {
			if (this.dialogUnlisted) {
				this.dialogUnlisted.close();
			}
		},
		// <!--SOC dt:07-11-2024-->
		onPlantFilterTickets: function(oEvent) {
			// Get the search term entered by the user
			var sQuery = oEvent.getParameter("newValue").toLowerCase();

			// Access the table and binding
			var oTable = this.byId("idPlantNameTable");
			var oBinding = oTable.getBinding("items");

			// Define filters for the search query against PlantName and PlantCode
			var aFilters = [];
			if (sQuery) {
				// Filter by PlantName or PlantCode, if the query is not empty
				var oPlantNameFilter = new sap.ui.model.Filter("PlantName", sap.ui.model.FilterOperator.Contains, sQuery);
				var oPlantCodeFilter = new sap.ui.model.Filter("PlantCode", sap.ui.model.FilterOperator.Contains, sQuery);

				// Combine filters using OR operator
				aFilters.push(new sap.ui.model.Filter({
					filters: [oPlantNameFilter, oPlantCodeFilter],
					and: false
				}));
			}

			// Apply the filters to the table binding
			oBinding.filter(aFilters);
		},
		//Soc by Bhavesh
		onTransporterName: function(oEvent) {
			var sQuery = oEvent.getParameter("newValue").trim(); // Get the search term

			// Access the list control
			var oList = this.byId("transporterNameslist");
			var oBinding = oList.getBinding("items");

			if (sQuery) {
				// Create filters for both Name1 and Lifnr using a case-insensitive filter
				var aFilters = [
					new sap.ui.model.Filter({
						path: "Name1",
						operator: sap.ui.model.FilterOperator.Contains,
						value1: sQuery,
						caseSensitive: false // Case insensitive
					}),
					new sap.ui.model.Filter({
						path: "Lifnr",
						operator: sap.ui.model.FilterOperator.Contains,
						value1: sQuery,
						caseSensitive: false // Case insensitive
					})
				];

				// Combine filters using OR
				var oFilter = new sap.ui.model.Filter({
					filters: aFilters,
					and: false
				});

				// Apply the filter to the list binding
				oBinding.filter(oFilter);
			} else {
				// Clear filters if the search field is empty
				oBinding.filter([]);
			}
		},

		// <!--EOC by Bhavesh -->
		onEditDetails: function(oEvent) {

			//restricting edit if owner of the entry is not the logged in user
			var createdBy = oEvent.getSource().getParent().getCells()[13].getText();
			if (createdBy !== loggedInUser) {
				MessageBox.information("Entry can't be Edited. Authorized user:" + createdBy);
				return;
			}
			//enable the update button
			this.getView().byId("idRegisterUpdate").setEnabled(true);
			console.log("oEvent", oEvent.getSource().getParent().getCells());
			var vehType = oEvent.getSource().getParent().getCells()[10].getText();
			var truckNo = oEvent.getSource().getParent().getCells()[1].getText();
			var movement = oEvent.getSource().getParent().getCells()[2].getText().toUpperCase();
			var transName = oEvent.getSource().getParent().getCells()[3].getText();
			var werks = oEvent.getSource().getParent().getCells()[4].getText();
			var reportDate = oEvent.getSource().getParent().getCells()[5].getText();
			var reportTime = oEvent.getSource().getParent().getCells()[6].getText();

			this.getView().byId("idTransporterName").setValue(transName);
			this.getView().byId("idUnlistedTruckNumber").setEnabled(false);
			this.getView().byId("idPlantName").setEnabled(false);
			this.getView().byId("idUnlistedTruckNumber").setValue(truckNo);
			this.getView().byId("idPlantName").setValue(werks);
			this.getView().byId("movement").setSelectedKey(movement);

			var reportDateArray = reportDate.split("/");
			this.getView().byId("idVehicleTypeDropdown").setSelectedKey(vehType);
			this.getView().byId("idReportDate").setDateValue(new Date(reportDateArray[2], reportDateArray[1] - 1, reportDateArray[0]));

			this.getView().byId("idReportTime").setValue(reportTime);
			this.getView().byId("idRegisterUpdate").setText("Update");
			this.serialNo = oEvent.getSource().getParent().getCells()[12].getText(); // Assuming SerialNo is in the first cell
		},
		onDeleteDetails: function(oEvent) {
			//restricting delete if owner of the entry is not the logged in user
			var createdBy = oEvent.getSource().getParent().getCells()[13].getText();
			if (createdBy !== loggedInUser) {
				MessageBox.information("Entry can't be deleted. Authorized user:" + createdBy);
				return;
			}
			var truckNo = oEvent.getSource().getParent().getCells()[1].getText();
			var truckSerialNo = oEvent.getSource().getParent().getCells()[12].getText();

			var payload = {
				"DelInd": true
			};
			var werks = oEvent.getSource().getParent().getCells()[4].getText();
			MessageBox.confirm("Do you really want to delete this TruckNumber?", {
				title: "Confirm",
				onClose: function(oPressEvent) {
					var pressedValue = oPressEvent;
					if (pressedValue === "OK") {
						this.getOwnerComponent().getModel().update("/UnassignVehiclesSet(TruckNumber='" + truckNo + "',SerialNo=" +
							truckSerialNo + ",Werks='" + werks + "')",
							payload, {
								success: function(oData) {
									MessageBox.success("Vehicle has been deleted Successfully");
									var selectedPlantCode = this.byId("idPlantCodeSelect").getSelectedItem().getKey();
									this.readUnListedModel(selectedPlantCode);
								}.bind(this),
								error: function(oError) {
									MessageBox.error("Error occured while registering the vehicle");
								}
							});
					}
				}.bind(this)
			});
		},
		plantListValueHelp: function(oEvent) {
			if (!this.dialogUnlistedPlant) {
				this.dialogUnlistedPlant = sap.ui.xmlfragment(this.getView().getId(), "ZSonic_PLMS.view.Fragment.PlantHelpFragment", this);
				this.getView().addDependent(this.dialogUnlistedPlant);
			}
			this.dialogUnlistedPlant.open();

		},
		onClosePlantDialog: function() {
			if (this.dialogUnlistedPlant) {
				this.dialogUnlistedPlant.close();
			}
		},
		onPlantSelect: function(oEvent) {
			var plantCode = oEvent.getSource().getSelectedItem().getCells()[1].getText();
			this.getView().byId("idPlantName").setValue(plantCode);
			this.dialogUnlistedPlant.close();
			this.getView().byId("idPlantNameTable").removeSelections();
			//passing value for authorization
			this.onPlantChange(plantCode);
		},
		readUnListedModelBtn: function() {
			var selectedPlantCode = this.byId("idPlantCodeSelect").getSelectedItem().getKey();
			this.readUnListedModel(selectedPlantCode);
		},
		// <!--SOC by Bhavesh dt:29-11-2024-->
		readUnListedModel: function(plantCode) {
			//get all plants from value help.
			var plantValues = this.getView().getModel("sPlantsModel").getProperty("/plantValues");
			var plantArr = [];
			plantValues.forEach(e => {
				if (e.PlantCode !== "Select Code") {
					plantArr.push(e.PlantCode);
				}
			});
			//making filter based on selected plant code

			var aUnListedStatusFilter = [];
			if (plantCode === "Select Code" || !plantCode) {
				var aUnListedFilters = [];
				aUnListedFilters.push(new Filter({
					path: "DelInd",
					value1: "false",
					operator: FilterOperator.EQ
				}));

				var aPlantCodeFilters = [];
				plantArr.forEach(function(plantCode) {
					aPlantCodeFilters.push(new Filter({
						path: "Werks",
						value1: plantCode,
						operator: FilterOperator.EQ
					}));
				});

				// Combine plant code filters with OR condition
				var oPlantCodeFilter = new Filter(aPlantCodeFilters, false); // false means OR condition
				aUnListedFilters.push(oPlantCodeFilter);

				var oUnListedFilter = new Filter(aUnListedFilters, true); // true means AND condition
				aUnListedStatusFilter.push(oUnListedFilter);

			} else {
				var aUnListedFilters = [];
				aUnListedFilters.push(new Filter({
					path: "DelInd",
					value1: "false",
					operator: FilterOperator.EQ
				}));
				// Adding the new condition for Werks eq plantCode
				aUnListedFilters.push(new Filter({
					path: "Werks",
					value1: plantCode,
					operator: FilterOperator.EQ
				}));
				var oUnListedFilter = new Filter(aUnListedFilters, true);
				aUnListedStatusFilter.push(oUnListedFilter);
			}

			//Making Get Call
			this.getOwnerComponent().getModel().read("/UnassignVehiclesSet", {
				filters: aUnListedStatusFilter,
				success: function(oData) {
					var selectedPlantCode = this.byId("idPlantCodeSelect").getSelectedItem().getKey();
					var data = oData.results;

					//SOC NIGAM

					//finding the data which belongs to the logged in user.
					// data = data.filter(item => item.CreatedBy === loggedInUser);
					// console.log("loggininuserData",data);

					//adding an extra field 'actvt' to the received data. 
					data.forEach(function(item) {
						let plantCode = item.Werks + "";
						if (actvtObj[plantCode]) {
							item.actvt = actvtObj[plantCode];
						} else {
							item.actvt = 'default_value';
						}
					});

					//binding the data to table in view
					if (data.length > 0) {

						this.getOwnerComponent().getModel("UnListedModel").setProperty("/Items", data);
						this.getOwnerComponent().getModel("UnListedModel").refresh(true);
					} else {
						this.getOwnerComponent().getModel("UnListedModel").setProperty("/Items", data);
						this.getOwnerComponent().getModel("UnListedModel").refresh(true);
						MessageBox.information("No data found for the selected plant code.");
					}

					// if (selectedPlantCode === "Select Code") {
					// 	if (data.length === 0) {
					// 		this.getOwnerComponent().getModel("UnListedModel").setProperty("/Items", []);
					// 		this.getOwnerComponent().getModel("UnListedModel").refresh(true);
					// 	} else {

					// 		this.getOwnerComponent().getModel("UnListedModel").setProperty("/Items", data);
					// 		this.getOwnerComponent().getModel("UnListedModel").refresh(true);
					// 	}

					// } else {

					// 	var filteredData = data.filter(function(item) {
					// 		return item.Werks === selectedPlantCode;
					// 	});
					// 	// console.log("fdata", filteredData);
					// 	if (filteredData.length > 0) {
					// 		this.getOwnerComponent().getModel("UnListedModel").setProperty("/Items", filteredData);
					// 		this.getOwnerComponent().getModel("UnListedModel").refresh(true);
					// 	} else {
					// 		MessageBox.information("No data found for the selected plant code.");
					// 		this.getOwnerComponent().getModel("UnListedModel").setProperty("/Items", []);
					// 		this.getOwnerComponent().getModel("UnListedModel").refresh(true);
					// 	}

					// }

					//EOC BY NIGAM

				}.bind(this),
				error: function() {
					MessageBox.error("Error in getting Unlisted Vehicle Data");
				}
			});

		},
		// readUnListedModel: function() {
		// 	var aUnListedFilters = [],
		// 		aOrFilters = [];
		// 	var plantModel = this.getOwnerComponent().getModel("PlantModel");
		// 	if (!plantModel) {
		// 		MessageBox.error("Plant Model is not initialized.");
		// 		return;
		// 	}

		// 	var plantValues = plantModel.getProperty("/plantValues");

		// 	if (!Array.isArray(plantValues) || plantValues.length === 0) {
		// 		MessageBox.error("You are not Authorized to access this Application");
		// 		return;
		// 	}

		// 	plantValues.forEach(function(plant) {
		// 		aOrFilters.push(new Filter({
		// 			path: "Werks",
		// 			value1: plant.PlantCode,
		// 			operator: FilterOperator.EQ
		// 		}));
		// 	});

		// 	if (aOrFilters.length > 0) {
		// 		var oOrFilter = new Filter(aOrFilters, false);
		// 		aUnListedFilters.push(oOrFilter);
		// 	}

		// 	this.getOwnerComponent().getModel().read("/UnassignVehiclesSet", {
		// 		filters: aUnListedFilters.length > 0 ? [new Filter(aUnListedFilters, true)] : [],
		// 		success: function(oData) {
		// 			var data = oData.results;
		// 			var unListedModel = this.getOwnerComponent().getModel("UnListedModel");
		// 			unListedModel.setProperty("/Items", data);

		// 			// Refresh the binding on the table to reflect changes
		// 			var oTable = this.getView().byId("unAssignedTable");
		// 			if (oTable) {
		// 				oTable.getBinding("items").refresh(true); // Force refresh to ensure latest data
		// 			}
		// 		}.bind(this),
		// 		error: function() {
		// 			MessageBox.error("Error in getting Unlisted Vehicle Data");
		// 		}
		// 	});
		// },

		onClearRegisterButton: function() {
			this.getView().byId("idVehicleTypeDropdown").setSelectedKey("0000");
			this.getView().byId("idUnlistedTruckNumber").setValue("");
			this.getView().byId("idUnlistedTruckNumber").setEnabled(true);
			this.getView().byId("idTransporterName").setValue("");
			this.getView().byId("idPlantName").setValue("");
			this.getView().byId("idReportDate").setDateValue(null);
			this.getView().byId("idReportTime").setValue(null);
			this.getView().byId("idRegisterUpdate").setText("Register");
			this.getView().byId("movement").setSelectedKey("Select");
		},
		changeColor: function(oEvent) {
			var oItems = oEvent.getSource().getItems();
			if (oItems) {
				for (var i = 0; i < oItems.length; i++) {
					var sColorCode = oItems[i].getBindingContext("UnListedModel").getProperty("ColorCode");
					var oTruckNumberCell = oItems[i].getCells()[1]; // Access the Truck Number cell

					switch (sColorCode) {
						case "A":
							oTruckNumberCell.addStyleClass("statusStarted");
							break;
						case "B":
							oTruckNumberCell.addStyleClass("statusYetToRemove");
							break;
						case "C":
							oTruckNumberCell.addStyleClass("statusRemoving");
							break;
						case "D":
							oTruckNumberCell.addStyleClass("statusRemoved");
							break;
						default:
							break;
					}
				}
			}
		},

			onFilterTickets: function(oEvent) {
			var searchString = this.getView().byId("searchField").getValue();
			var aFilters = [];
			if (searchString) {
				var oFilter = new Filter("TruckNumber", FilterOperator.Contains, searchString);
				aFilters.push(oFilter);
			}
			this.getView().byId("unAssignedTable").getBinding("items").filter(aFilters);
		},
		// <!--EOC by Bhavesh  dt:29-11-2024-->

		//SOC NIGAM
		onPlantChange: function(plantCode) {
			//checking Authorization for selected plantcode to register vehicle
			if (plantCode) {
				var authCode = actvtObj[plantCode];
				if (authCode === '1') {
					this.getView().byId("idRegisterUpdate").setEnabled(true);
				} else {
					// MessageBox.information("You're not authorized to register");
					MessageBox.information("Selected plant is not authorized to Register");
					this.getView().byId("idRegisterUpdate").setEnabled(false);
					return;
				}
			}

		},

		onPlantCodeChange: function(oEvent) {
			var selectedPlantCode;
			//if invoked through chenge event
			if (oEvent) {

				var oSelectedItem = oEvent.getSource().getSelectedItem();
				var selectedKey = oSelectedItem.getKey();
				selectedPlantCode = selectedKey;
			}
			//if invoked through route argument
			else {

				if (PLCode === 'NA') {
					selectedPlantCode = "Select Code";
				} else {
					selectedPlantCode = PLCode;
				}
			}

			//passing plant code to the function
			this.readUnListedModel(selectedPlantCode);

			this.onClearRegisterButton();
			//get actvt against plant code and adjusting the visibility of register
			var actvt = actvtObj[selectedPlantCode];
			if (actvt === '1' || selectedPlantCode === "Select Code") {
				this.getView().byId("idRegisterUpdate").setEnabled(true);
			} else {
				this.getView().byId("idRegisterUpdate").setEnabled(false);
			}

		}

		//EOC NIGAM

	});
});