sap.ui.define([], function() {
	"use strict";
	return {
		formatDate: function(Doj) {
			if (Doj !== undefined && Doj !== null && Doj !== "") {
				var offSet = Doj.getTimezoneOffset();
				var offSetVal = Doj.getTimezoneOffset() / 60;
				var h = Math.floor(Math.abs(offSetVal));
				var m = Math.floor((Math.abs(offSetVal) * 60) % 60);
				Doj = new Date(Doj.setHours(h, m, 0, 0));
			}
			var oDataFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "dd/MM/yyyy HH:MM:SS"
			}, sap.ui.getCore().getConfiguration().getLocale());
			return oDataFormat.format(Doj, true);
		},
		formatContCheckBox: function(status, editMode) {
			// Enable checkbox explicitly for "AR" status
			if (status === "AR" && editMode) {
				return true;
			}

			// Enable checkbox for fresh case (status is undefined or empty)
			if ((status === undefined || status === "")) {
				return true;
			}

			// Disable checkbox for all other cases
			return false;
		},
		formatContCheckBoxSelected: function(status) {
			if (status === undefined || status === "") {
				return false;
			} else {
				return true;
			}
		},
		formatRadioButtonSelection: function(vi) {
			if (vi === 0) {
				return 0;
			}
			if (vi === 1) {
				return 1;
			} else {
				return 1;
			}
		},
		formatTripStatus: function(status) {
			if (status === "PL") {
				return "Planned";
			}
			// <!--SOC dt:07-11-2024-->
			if (status === "AR") {
				return "Arrived";
			}
			// <!--EOC dt:07-11-2024-->
			if (status === "RE") {
				return "Reporting";
			}
			if (status === "RD") {
				return "Reported";
			}
			if (status === "IP") {
				return "Inspection in Progress";
			}
			if (status === "IC") {
				return "Inspection Completed";
			}
			if (status === "GI") {
				return "Gate-In";
			}
			if (status === "TP") {
				return "Tare Weighment in Progress";
			}
			if (status === "TC") {
				return "Tare Weighment Completed";
			}
			if (status === "WR") {
				return "Weighment Rejected";
			}
			if (status === "GC") {
				return "Gross Weighment Completed";
			}
			if (status === "LP") {
				return "Loading in Progress";
			}
			if (status === "WC") {
				return "Weighment Completed";
			}
			if (status === "LC") {
				return "Loading Completed";
			}
			if (status === "PG") {
				return "PGI Completed";
			}
			if (status === "IN") {
				return "Invoiced";
			}
			if (status === "GO") {
				return "Gate-Out";
			}
			if (status === "CL") {
				return "Cancelled";
			}
		},
		formatReportForm: function(tripNumber) {
			if (tripNumber === undefined || tripNumber === "0000000000") {
				return true;
			}
			if (!isNaN(parseInt(tripNumber))) {
				return false;
			}
		},
		formatInspectionOpen: function(tripNumber, vehType) {
			if (!isNaN(parseInt(tripNumber)) && vehType === "YB16" && tripNumber !== "0000000000") {
				return true;
			} else {
				return false;
			}
		},
		formatTruckOpen: function(tripNumber, vehType) {
			if (!isNaN(parseInt(tripNumber)) && vehType === "Truck" && tripNumber !== "0000000000") {
				return true;
			} else {
				return false;
			}
		},
		formatTankerOpen: function(tripNumber, vehType) {
			if (!isNaN(parseInt(tripNumber)) && vehType === "Tank lorry" && tripNumber !== "0000000000") {
				return true;
			} else {
				return false;
			}
		},
		formatAddNewContBoxTableRows: function(contBoxNo) {
			if (!contBoxNo) {
				return true;
			} else {
				return false;
			}
		},
		formatLRDate: function(lrDate) {
			if (lrDate) {
				return lrDate;
			} else {
				return new Date();
			}
		},
		formatOBDDisplayNumber: function(OBD, ZHR) {
			if (ZHR) {
				if (ZHR.results) {
					if (ZHR.results.length > 0) {
						var len = ZHR.results.length;
						return OBD + "+" + len;
					} else {
						return OBD + "";
					}
				} else {
					return OBD + "";
				}
			}
		},
		formatVehicleTypeTruck: function(vehType) {
			if (vehType === "Truck") {
				return true;
			} else {
				return false;
			}
		},

		formatVehicleTypeTank: function(vehType) {
			if (vehType === "Tank lorry") {
				return true;
			} else {
				return false;
			}
		},
		formatVehicleTypeContainer: function(vehType) {
			if (vehType === "YB16") {
				return true;
			} else {
				return false;
			}
		},
		formatCommaOBDNumber: function(OBD, ZHR) {
			if (ZHR) {
				if (ZHR.results.length >= 1) {
					var obd = OBD;
					for (var k = 0; k < ZHR.results.length; k++) {
						obd = obd + "," + ZHR.results[k].ObdNumber;
					}
					return obd;
				} else {
					return OBD + "";
				}
			} else {
				return OBD + "";
			}
		},
		formatGateIn: function(gatein) {
			if (gatein === "X") {
				return true;
			} else {
				return false;
			}
		},
		// <!--SOC dt:07-11-2024-->
		formatNewContainerBox: function(status) {
			if (status === "RD" || status === "AR" || status === "IP" || status === "IC" || status === "RE" || status === "PL") {
				return true;
			} else {
				return false;
			}
		},
		// <!--EOC dt:07-11-2024-->
		formatDeleteButton: function(status, plant, items) {
			if (status === "PG") {
				var Role = false;
				if (items) {
					var auth = items;
					if (auth) {
						var authl = auth.length;
						/*	return true;*/
						for (var i = 0; i < authl; i++) {
							if (auth[i].Werks === plant) {
								if (auth[i].Module === "GateOut") {
									if (auth[i].Actvt === "1" || auth[i].Actvt === "2") {
										Role = true;
										break;
									}
								}
							}
						}
						if (Role) {
							return true;
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		formatIcons: function(status) {
			if (status === "IC" || status === "GI" || status === "LC" || status === "WC" || status === "PG" || status === "GO" || status === "LP" ||
				status === "WR") {
				return true;
			} else {
				return false;
			}
		},
		formatMainIcons: function(status) {
			if (status === "IC" || status === "WI" || status === "WC") {
				return true;
			} else {
				return false;
			}
		},
		formatReportingFormElements: function(status, plant, items) {
			/*if (role && activity) {
				var Role = false;
				for (var aa = 0; aa < role.length; aa++) {
					if (role[aa] === "Reporting") {
						if (status === "") {
							if (activity[aa] === "1") {
								Role = true;
							}
						}
						if (status === "RD") {
							if (activity[aa] === "2") {
								Role = true;
							}
						}
					}
				}
				if (Role) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}*/
			var Role = false;
			if (items) {
				var auth = items;
				var authl = auth.length;
				/*	return true;*/
				for (var i = 0; i < authl; i++) {
					if (auth[i].Werks === plant) {
						if (auth[i].Module === "Reporting") {
							if (status === "") {
								if (auth[i].Actvt === "1") {
									Role = true;
								}
							}
							if (status === "RD" || status === "AR") {
								if (auth[i].Actvt === "2") {
									Role = true;
								}
							}
						}
					}
				}
				if (Role) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		formatReportingButtons: function(status, plant, items) {
			/*if (status === "" || status === "RD") {
				if (role && activity) {
					var Role = false;
					for (var aa = 0; aa < role.length; aa++) {
						if (role[aa] === "Reporting") {
							if (activity[aa] === "1" || activity[aa] === "2") {
								Role = true;
							}
						}
					}
					if (Role) {
						return true;
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}*/
			var Role = false;
			if (status === "" || status === "RD" || status === "AR") {
				if (items) {
					var auth = items;
					var authl = auth.length;
					/*	return true;*/
					for (var i = 0; i < authl; i++) {
						if (auth[i].Werks === plant) {
							if (auth[i].Module === "Reporting") {
								if (auth[i].Actvt === "1" || auth[i].Actvt === "2") {
									Role = true;
									break;
								}
							}
						}
					}
					if (Role) {
						return true;
					} else {
						return false;
					}

				} else {
					return false;
				}

			} else {
				return false;
			}
		},
		formatInspectionNewButtons: function(status, plant, items, radio) {
			if (radio === 1) {
				/*	if (role && activity) {
						var Role = false;
						for (var aa = 0; aa < role.length; aa++) {
							if (role[aa] === "Inspection") {
								if (status === "IP" || status === "RD") {
									if (activity[aa] === "1") {
										Role = true;
									}
								}
								if (status === "IP") {
									if (activity[aa] === "2") {
										Role = true;
									}
								}
							}
						}
						if (Role) {
							return true;
						} else {
							return false;
						}
					} else {
						return false;
					}*/
				if (items) {
					var Role = false;
					var auth = items;
					for (var i = 0; i < auth.length; i++) {
						if (auth[i].Werks === plant) {
							if (auth[i].Module === "Inspection") {
								if (status === "IP" || status === "RD" || status === "AR") {
									if (auth[i].Actvt === "1") {
										Role = true;
									}
								}
								if (status === "IP") {
									if (auth[i].Actvt === "2") {
										Role = true;
									}
								}
							}
						}
					}
					if (Role) {
						return true;
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		formatInspectionButtons: function(status, plant, items) {
			/*if (role && activity) {
				var Role = false;
				for (var aa = 0; aa < role.length; aa++) {
					if (role[aa] === "Inspection") {
						if (status === "IP" || status === "RD") {
							if (activity[aa] === "1") {
								Role = true;
							}
						}
						if (status === "IP") {
							if (activity[aa] === "2") {
								Role = true;
							}
						}
					}
				}
				if (Role) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}*/
			if (items) {
				var Role = false;
				var auth = items;
				for (var i = 0; i < auth.length; i++) {
					if (auth[i].Werks === plant) {
						if (auth[i].Module === "Inspection") {
							if (status === "IP" || status === "RD" || status === "AR") {
								if (auth[i].Actvt === "1") {
									Role = true;
								}
							}
							if (status === "IP") {
								if (auth[i].Actvt === "2") {
									Role = true;
								}
							}
						}
					}
				}
				if (Role) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		formatApproved: function(approved, comments) {
			if (comments !== "") {
				return approved;
			} else {
				return 1;
			}
		},
		formatInspectionApprover: function(status, role, activity, needed, checked) {
			if (status === "IP" || status === "RD" || status === "AR") {
				if (role && activity) {
					var Role = false;
					for (var aa = 0; aa < role.length; aa++) {
						if (role[aa] === "InspectionAppr") {
							if (activity[aa] === "1") {
								Role = true;
							} else {
								return false;
							}
						}
					}
					if (Role && needed === 0 && checked) {
						return true;
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		formatGateInTab: function(status) {
			if (status === "" || status === "RD" || status === "IP" || status === undefined) {
				return false;
			} else {
				return true;
			}
		},
		formatLoadingUnloadingTab: function(status) {
			if (status === "RD" || status === "IP" || status === "IC" || status === "") {
				return false;
			}
			if (status === "WC" || status === "LC" || status === "LP" || status === "GO" || status === "WP" || status === "GI" || status === "PG" ||
				status === "WR") {
				return true;
			}
		},
		formatGateOut: function(status) {
			if (status === "RD" || status === "IP" || status === "IC" || status === "GI" || status === "WC" || status === "" ||
				status === "LP" || status === "LC" || status === "WR") {
				return false;
			}
			if (status === "GO" || status === "PG") {
				return true;
			}
		},
		formatInspTruckButtons: function(status, plant, items) {
			/*	if (role && activity) {
					var Role = false;
					for (var aa = 0; aa < role.length; aa++) {
						if (role[aa] === "InspectionAppr" || role[aa] === "Inspection") {
							if (status === "" || status === "RD" || status === "IP") {
								if (activity[aa] === "1") {
									Role = true;
								}
							}
							if (status === "IP") {
								if (activity[aa] === "2") {
									Role = true;
								}
							}
						}
					}
					if (Role) {
						return true;
					} else {
						return false;
					}
				} else {
					return false;
				}*/
			if (items) {
				var Role = false;
				var auth = items;
				for (var i = 0; i < auth.length; i++) {
					if (auth[i].Werks === plant) {
						if (auth[i].Module === "InspectionAppr" || auth[i].Module === "Inspection") {
							if (status === "" || status === "RD" || status === "AR" || status === "IP") {
								if (auth[i].Actvt === "1") {
									Role = true;
								}
							}
							if (status === "IP") {
								if (auth[i].Actvt === "2") {
									Role = true;
								}
							}
						}
					}
				}
				if (Role) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		formatAllowGateIn: function(status, plant, items) {
			if (status === "IC") {
				var Role = false;
				if (items) {
					var auth = items;
					if (auth) {
						var authl = auth.length;
						/*	return true;*/
						for (var i = 0; i < authl; i++) {
							if (auth[i].Werks === plant) {
								if (auth[i].Module === "GateIn") {
									if (auth[i].Actvt === "1" || auth[i].Actvt === "2") {
										Role = true;
										break;
									}
								}
							}
						}
						if (Role) {
							return true;
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
				//	return true;
			} else {
				return false;
			}
		},
		formatLoadingGate: function(status) {
			if (status === "IC") {
				return true;
			} else {
				return false;
			}
		},
		formatTimeLine: function(Time) {
			var s = Time.ms;
			if (s) {
				function pad(n, z) {
					z = z || 2;
					return ('00' + n).slice(-z);
				}
				var ms = s % 1000;
				s = (s - ms) / 1000;
				var secs = s % 60;
				s = (s - secs) / 60;
				var mins = s % 60;
				var hrs = (s - mins) / 60;
				return pad(hrs) + ':' + pad(mins);
			}
		},
		formatTimeDate: function(strtDate, Time) {
			//	return new Date(time.ms);
			if (Time) {
				var s = Time.ms;
				/*if (s) {
					function pad(n, z) {
						z = z || 2;
						return ('00' + n).slice(-z);
					}
					var ms = s % 1000;
					s = (s - ms) / 1000;
					var secs = s % 60;
					s = (s - secs) / 60;
					var mins = s % 60;
					var hrs = (s - mins) / 60;
				}*/
				if (strtDate) {
					var Doj = new Date(strtDate.getFullYear(), strtDate.getMonth(), strtDate.getDate(), strtDate.getHours(), strtDate.getMinutes(),
						strtDate
						.getSeconds());
					/*if (Doj !== undefined && Doj !== null && Doj !== "") {
						var offSet = Doj.getTimezoneOffset();
						var offSetVal = Doj.getTimezoneOffset() / 60;
						var h = Math.floor(Math.abs(offSetVal));
						var m = Math.floor((Math.abs(offSetVal) * 60) % 60);
						Doj = new Date(Doj.setHours(h, m, 0, 0));
					}*/
					var oDataFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
						pattern: "dd/MM/yyyy   "
					}, sap.ui.getCore().getConfiguration().getLocale());
					return oDataFormat.format(Doj, true);
				}
			}
		},
		formatAttachments: function(obd, filename) {
			return "/sap/opu/odata/SAP/ZPLMS_SRV/PLMS_AttachmentsSet(ObdNumber=" + "'" + "00" + obd + "'" + "," + "FileName=" + "'" +
				filename + "'" + ")/$value";
		},
		formatTileVisible: function(time) {
			if (time.ms !== 0) {
				return true;
			} else {
				return false;
			}
		},
		formatWeighmentSlipButton: function(manualcode) {
			if (manualcode === "X") {
				return true;
			} else {
				return false;
			}
		},
		formatPGI: function(status, role, activity) {
			if (status === "WC") {
				if (role && activity) {
					var Role = false;
					for (var aa = 0; aa < role.length; aa++) {
						if (role[aa] === "Weighment") {
							if (activity[aa] === "1" || activity[aa] === "2") {
								Role = true;
							}
						}
					}
					if (Role) {
						return true;
					} else {
						return false;
					}
				} else {
					return false;
				}
				//	return true;
			} else {
				return false;
			}
		},
		formatSelectedIndex: function(index, check) {
			if (check) {
				return index;
			} else {
				return 1;
			}
		},
		formatWeighmentTable: function(status) {
			if (status === "LC" || status === "WC" || status === "GO" || status === "PG" || status === "GI" || status === "LP" || status === "WR") {
				return true;
			} else {
				return false;
			}
		},
		formatCancelTrip: function(status, role, activity) {
			if (status === "RD" || status === "AR" || status === "IP" || status === "IC" || status === "GI" || status === "LP" || status === "WR") {
				if (role && activity) {
					var Role = false;
					for (var aa = 0; aa < role.length; aa++) {
						if (role[aa] === "PGI-Invoice") {
							if (activity[aa] === "1" || activity[aa] === "2") {
								Role = true;
								break;
							}
						}
					}
					if (Role) {
						return true;
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		formatWeighmentButton: function(status, plant, items) {
			/*if (status === "LC") {
				if (role && activity) {
					var Role = false;
					for (var aa = 0; aa < role.length; aa++) {
						if (role[aa] === "Weighment") {
							if (activity[aa] === "1" || activity[aa] === "2") {
								Role = true;
							}
						}
					}
					if (Role) {
						return true;
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}*/
			if (status === "LC") {
				var Role = false;
				if (items) {
					var auth = items;
					if (auth) {
						var authl = auth.length;
						/*	return true;*/
						for (var i = 0; i < authl; i++) {
							if (auth[i].Werks === plant) {
								if (auth[i].Module === "Weighment") {
									if (auth[i].Actvt === "1" || auth[i].Actvt === "2") {
										Role = true;
										break;
									}
								}
							}
						}
						if (Role) {
							return true;
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		formatLoadingCompleteButton: function(status, plant, items, inspOK) {
			/*	if (status === "LP" || status === "WR") {
					if (inspOK === "X") {
						if (role && activity) {
							var Role = false;
							for (var aa = 0; aa < role.length; aa++) {
								if (role[aa] === "Loading") {
									if (activity[aa] === "1" || activity[aa] === "2") {
										Role = true;
									}
								}
							}
							if (Role) {
								return true;
							} else {
								return false;
							}
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}*/
			if (status === "LP" || status === "WR") {
				if (inspOK === "X") {
					var Role = false;
					if (items) {
						var auth = items;
						if (auth) {
							var authl = auth.length;
							/*	return true;*/
							for (var i = 0; i < authl; i++) {
								if (auth[i].Werks === plant) {
									if (auth[i].Module === "Loading") {
										if (auth[i].Actvt === "1" || auth[i].Actvt === "2") {
											Role = true;
											break;
										}
									}
								}
							}
							if (Role) {
								return true;
							} else {
								return false;
							}
						} else {
							return false;
						}
					} else {
						return false;
					}

				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		formatPostLoadingRadioButtonEnable: function(status, plant, items) {
			/*	if (status === "LP") {
					if (role && activity) {
						var Role = false;
						for (var aa = 0; aa < role.length; aa++) {
							if (role[aa] === "Loading") {
								if (activity[aa] === "1" || activity[aa] === "2") {
									Role = true;
								}
							}
						}
						if (Role) {
							return true;
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}*/
			if (status === "LP") {
				var Role = false;
				if (items) {
					var auth = items;
					if (auth) {
						var authl = auth.length;
						/*	return true;*/
						for (var i = 0; i < authl; i++) {
							if (auth[i].Werks === plant) {
								if (auth[i].Module === "Loading") {
									if (auth[i].Actvt === "1" || auth[i].Actvt === "2") {
										Role = true;
										break;
									}
								}
							}
						}
						if (Role) {
							return true;
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		formatLoadingRadioButton: function(status, plant, items) {
			/*	if (status === "GI" || status === "LP") {
					if (role && activity) {
						var Role = false;
						for (var aa = 0; aa < role.length; aa++) {
							if (role[aa] === "Loading") {
								if (activity[aa] === "1" || activity[aa] === "2") {
									Role = true;
								}
							}
						}
						if (Role) {
							return true;
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}*/
			if (status === "GI" || status === "LP") {
				var Role = false;
				if (items) {
					var auth = items;
					if (auth) {
						var authl = auth.length;
						/*	return true;*/
						for (var i = 0; i < authl; i++) {
							if (auth[i].Werks === plant) {
								if (auth[i].Module === "Loading") {
									if (auth[i].Actvt === "1" || auth[i].Actvt === "2") {
										Role = true;
										break;
									}
								}
							}
						}
						if (Role) {
							return true;
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		formatApproveManualEntry: function(status, manualentry) {
			if (status === "LC") {
				if (manualentry === "X") {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		formatLatestWeights: function(status) {
			if (status === "LC" || status === "GI" || status === "LP") {
				return true;
			} else {
				return false;
			}
		},
		TruckCanvasPanelText: function(flag) {
			var h1 = "Canvas Selection and Check";
			var h2 = "Canvas Selection and Check(Finished)";
			if (flag) {
				return h2;
			} else {
				return h1;
			}
		},
		TruckRopeCheck: function(flag) {
			var h1 = "Rope Check";
			var h2 = "Rope Check(Finished)";
			if (flag) {
				return h2;
			} else {
				return h1;
			}
		},
		TruckFloorWallsCheck: function(flag) {
			var h1 = "Floor and Walls Check";
			var h2 = "Floor and Walls Check(Finished)";
			if (flag) {
				return h2;
			} else {
				return h1;
			}
		},
		TruckVehicleCheck: function(flag) {
			var h1 = "Vehicle Check";
			var h2 = "Vehicle Check(Finished)";
			if (flag) {
				return h2;
			} else {
				return h1;
			}
		},
		TruckVehicleCleanlinessCheck: function(flag) {
			var h1 = "Vehicle Cleanliness Check";
			var h2 = "Vehicle Cleanliness Check(Finished)";
			if (flag) {
				return h2;
			} else {
				return h1;
			}
		},
		TruckVehicleBodyCheck: function(flag) {
			var h1 = "Vehicle Cleanliness Check";
			var h2 = "Vehicle Cleanliness Check(Finished)";
			if (flag) {
				return h2;
			} else {
				return h1;
			}
		},
		TruckCanvasAvailableCheck: function(flag) {
			var h1 = "Canvas Available Check";
			var h2 = "Canvas Available Check(Finished)";
			if (flag) {
				return h2;
			} else {
				return h1;
			}
		},
		TruckVehicleLoadedCheck: function(flag) {
			var h1 = "Vehicle to be loaded Check";
			var h2 = "Vehicle to be loaded Check(Finished)";
			if (flag) {
				return h2;
			} else {
				return h1;
			}
		},
		TankCleaningReportCheck: function(flag) {
			var h1 = "Cleaning Report Check";
			var h2 = "Cleaning Report Check(Finished)";
			if (flag) {
				return h2;
			} else {
				return h1;
			}
		},
		TankBottomValveSealAirventCheck: function(flag) {
			var h1 = "Bottom Valve Seal and Airvent Check";
			var h2 = "Bottom Valve Seal and Airvent Check(Finished)";
			if (flag) {
				return h2;
			} else {
				return h1;
			}
		},
		TankSmellForeignMaterialsCheck: function(flag) {
			var h1 = "Smell and Foreign Materials Check";
			var h2 = "Smell and Foreign Materials Check(Finished)";
			if (flag) {
				return h2;
			} else {
				return h1;
			}
		},
		TankCSCSafetyPlateCheck: function(flag) {
			var h1 = "CSC Safety Plate Check";
			var h2 = "CSC Safety Plate Check(Finished)";
			if (flag) {
				return h2;
			} else {
				return h1;
			}
		},
		TankRubberSealingCheck: function(flag) {
			var h1 = "Rubber Sealing Check";
			var h2 = "Rubber Sealing Check(Finished)";
			if (flag) {
				return h2;
			} else {
				return h1;
			}
		},
		TankSendISOTankWeighbridge: function(flag) {
			var h1 = "Send ISO Tank to Weighbridge";
			var h2 = "Send ISO Tank to Weighbridge(Finished)";
			if (flag) {
				return h2;
			} else {
				return h1;
			}
		},
		TankStuffingISOTank: function(flag) {
			var h1 = "Stuffing ISO Tank";
			var h2 = "Stuffing ISO Tank(Finished)";
			if (flag) {
				return h2;
			} else {
				return h1;
			}
		},
		formatInspectionApproved: function(apprvd, appneeded) {
			if (appneeded === 1) {
				return 1;
			}
			if (appneeded === 0) {
				if (apprvd !== undefined) {
					return apprvd;
				} else {
					return 1;
				}

			}
		},
		formatInitialRadioButton: function(radio, chk) {
			if (chk === true) {
				return radio;
			} else {
				return 0;
			}
		},
		formatPhaseButton: function(status) {
			if (status === "LC" || status === "PG" || status === "GO") {
				return false;
			} else {
				return true;
			}
		},
		formatDispatchButton: function(status, plant, items) {
			var Role = false;
			if (status === "WC") {
				if (items) {
					var auth = items;
					if (auth) {
						var authl = auth.length;
						/*	return true;*/
						for (var i = 0; i < authl; i++) {
							if (auth[i].Werks === plant) {
								if (auth[i].Module === "PGI-Invoice") {
									if (auth[i].Actvt === "1" || auth[i].Actvt === "2") {
										Role = true;
										break;
									}
								}
							}
						}
						if (Role) {
							return true;
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}

			} else {
				return false;
			}
		},
		formatLoadingSaveButton: function(status, plant, items, inspOK) {
			/*if (status === "LP" || status === "GI" || status === "WR") {
				if (inspOK === "") {
					if (role && activity) {
						var Role = false;
						for (var aa = 0; aa < role.length; aa++) {
							if (role[aa] === "Loading") {
								if (activity[aa] === "1" || activity[aa] === "2") {
									Role = true;
								}
							}
						}
						if (Role) {
							return true;
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}*/
			if (status === "LP" || status === "GI" || status === "WR") {
				if (inspOK === "") {
					var Role = false;
					if (items) {
						var auth = items;
						if (auth) {
							var authl = auth.length;
							/*	return true;*/
							for (var i = 0; i < authl; i++) {
								if (auth[i].Werks === plant) {
									if (auth[i].Module === "Loading") {
										if (auth[i].Actvt === "1" || auth[i].Actvt === "2") {
											Role = true;
											break;
										}
									}
								}
							}
							if (Role) {
								return true;
							} else {
								return false;
							}
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		formatPGITab: function(status) {
			if (status === "WC" || status === "GO" || status === "PG") {
				return true;
			} else {
				return false;
			}
		},
		formatInspOkRadioButton: function(inspFlag) {
			if (inspFlag === "X") {
				return 0;
			} else {
				return 1;
			}
		},
		formatPanelCheck: function(chk, radio) {
			if (chk === true) {
				if (radio === 1) {
					return "        (Completed with Observations)";
				} else {
					return " (COMPLETED)";
				}
			}
			if (chk === false || chk == undefined) {
				return "        (PENDING)";
			}
		},
		formatPostLoadingSaveButton: function(status, plant, items, postInsp) {
			/*if (status === "LP") {
				if (postInsp === 0 || postInsp === undefined) {
					if (role && activity) {
						var Role = false;
						for (var aa = 0; aa < role.length; aa++) {
							if (role[aa] === "Loading") {
								if (activity[aa] === "1" || activity[aa] === "2") {
									Role = true;
								}
							}
						}
						if (Role) {
							return true;
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}*/
			if (status === "LP") {
				if (postInsp === 0 || postInsp === undefined) {
					var Role = false;
					if (items) {
						var auth = items;
						if (auth) {
							var authl = auth.length;
							/*	return true;*/
							for (var i = 0; i < authl; i++) {
								if (auth[i].Werks === plant) {
									if (auth[i].Module === "Loading") {
										if (auth[i].Actvt === "1" || auth[i].Actvt === "2") {
											Role = true;
											break;
										}
									}
								}
							}
							if (Role) {
								return true;
							} else {
								return false;
							}
						} else {
							return false;
						}
					} else {
						return false;
					}

				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		formatWeighmentRadio: function(weight) {
			if (weight) {
				return weight;
			} else {
				return 0;
			}
		},
		formatPostLoadingRadioButton: function(flag) {
			if (flag) {
				return flag;
			} else {
				return 0;
			}
		},
		formatPostLoadingCompleteButton: function(status, role, activity, inspOK) {
			if (status === "LP") {
				if (inspOK === 1) {
					if (role && activity) {
						var Role = false;
						for (var aa = 0; aa < role.length; aa++) {
							if (role[aa] === "Loading") {
								if (activity[aa] === "1" || activity[aa] === "2") {
									Role = true;
								}
							}
						}
						if (Role) {
							return true;
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		formatCombinedWeighmentAccepted: function(status, plant, items) {
			if (status === "GI" || status === "LP" || status === "LC") {
				/*	return true;*/
				var Role = false;
				if (items) {
					var auth = items;
					if (auth) {
						var authl = auth.length;
						for (var i = 0; i < authl; i++) {
							if (auth[i].Werks === plant) {
								if (auth[i].Module === "Weighment") {
									if (auth[i].Actvt === "1" || auth[i].Actvt === "2") {
										Role = true;
										break;
									}
								}
							}
						}
						if (Role) {
							return true;
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		formatWeighmentRejected: function(status, plant, items) {
			if (status === "GI" || status === "LP" || status === "LC") {
				/*	return true;*/
				var Role = false;
				if (items) {
					var auth = items;
					if (auth) {
						var authl = auth.length;
						for (var i = 0; i < authl; i++) {
							if (auth[i].Werks === plant) {
								if (auth[i].Module === "Weighment") {
									if (auth[i].Actvt === "1" || auth[i].Actvt === "2") {
										Role = true;
										break;
									}
								}
							}
						}
						if (Role) {
							return true;
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		formatOnlyDate: function(Doj) {
			if (Doj !== undefined && Doj !== null && Doj !== "") {
				var offSet = Doj.getTimezoneOffset();
				var offSetVal = Doj.getTimezoneOffset() / 60;
				var h = Math.floor(Math.abs(offSetVal));
				var m = Math.floor((Math.abs(offSetVal) * 60) % 60);
				Doj = new Date(Doj.setHours(h, m, 0, 0));
			}
			var oDataFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
				pattern: "dd/MM/yyyy"
			}, sap.ui.getCore().getConfiguration().getLocale());
			return oDataFormat.format(Doj, true);
		},
		formatCombinedWeightRadioButton: function(flag) {
			if (flag === 0 || flag === 2) {
				return 0;
			}
			if (flag === 1) {
				return 1;
			}
		},
		formatVehicleStatus: function(status) {
			if (status === "A") {
				return "ASSIGNED";
			}
			if (status === "C") {
				return "CANCELLED";
			}
			if (status === "U" || status === "") {
				return "UNASSIGNED";
			}
			if (status === "E") {
				return "Error in Auto Reporting";
			}
			if (status === "N") {
				return "No open OBD";
			}
		},
		formatEditDeleteButtons: function(status,actvt) {
			// console.log("formatter called",status,"--",actvt);
			// if (status === "A" || status === "C" ) {
			// 	return false;
			// } else {
			// 	return true;
			// }
			//SOC NIGAM
			const isActvtValid = !(actvt === '3' || actvt === "default_value");
            const isStatusValid = !(status === "A" || status === "C");
            return isActvtValid && isStatusValid;
            //EOC NIGAM
		},
		formatOnlyTime: function(time) {
			return time.toString();
		},
		formatCombinedLoadingRadioButton: function(status, plant, items, combined) {
			/*if (status === "GI" || status === "LP") {
				if (role && activity) {
					var Role = false;
					for (var aa = 0; aa < role.length; aa++) {
						if (role[aa] === "Loading") {
							if (activity[aa] === "1" || activity[aa] === "2") {
								Role = true;
							}
						}
					}
					if (Role && (combined === 0 || combined === undefined)) {
						return true;
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}*/
			if (status === "GI" || status === "LP") {
				var Role = false;
				if (items) {
					var auth = items;
					if (auth) {
						var authl = auth.length;
						/*	return true;*/
						for (var i = 0; i < authl; i++) {
							if (auth[i].Werks === plant) {
								if (auth[i].Module === "Loading") {
									if (auth[i].Actvt === "1" || auth[i].Actvt === "2") {
										Role = true;
										break;
									}
								}
							}
						}
						if (Role && (combined === 0 || combined === undefined)) {
							return true;
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		},
		formatNotesTab: function(status) {
			if (status !== "" && status !== undefined) {
				return true;
			} else {
				return false;
			}
		},
		formatRejectObjectItem: function(cmt) {
			if (cmt) {
				return true;
			} else {
				return false;
			}
		},
		formatCombinedWeighmentRejectedReasons: function(status, plant, items) {
			if (status === "GO" || status === "LP" || status === "LC" || status === "WR" || status === "WC" || status === "PG") {
				/*	return true;*/
				var Role = false;
				if (items) {
					var auth = items;
					if (auth) {
						var authl = auth.length;
						for (var i = 0; i < authl; i++) {
							if (auth[i].Werks === plant) {
								Role = true;
								break;
							}
						}
						if (Role) {
							return true;
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		}
	};
});