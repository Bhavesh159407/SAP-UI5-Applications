sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"ZSonic_PLMS/model/models",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox"
], function(UIComponent, Device, models, JSONModel, Filter, FilterOperator, MessageBox) {
	"use strict";

	return UIComponent.extend("ZSonic_PLMS.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			this.getRouter().initialize();
			//new code
			var trip = new JSONModel();
			this.setModel(trip, "TripDisplayModel");
			var role = new JSONModel();
			this.setModel(role, "RoleModel");
			var plant = new JSONModel();
			this.setModel(plant, "PlantModel");
			var plants = new JSONModel();
			this.setModel(plants, "PlantsModel");
			//...SOC NIGAM
			var plants_select = new JSONModel();
			this.setModel(plants_select, "sPlantsModel");
			//...EOC NIGAM
			var unList = new JSONModel();
			this.setModel(unList, "UnListedModel");
			var auth = new JSONModel();
			this.setModel(auth, "AuthorizationModel");
			var aUserFilters = [],
				aOrFilters = [],
				aUserStatusFilter = [];
			aUserFilters.push(new Filter({
				path: "Pernr",
				value1: "00000000",
				operator: FilterOperator.EQ
			}));
			var oUserFilter = new Filter(aUserFilters, true);
			aUserStatusFilter.push(oUserFilter);
			var aUnListedFilters = [],
				aUnListedStatusFilter = [];
			aUnListedFilters.push(new Filter({
				path: "DelInd",
				value1: "false",
				operator: FilterOperator.EQ
			}));
			var oUnListedFilter = new Filter(aUnListedFilters, true);
			aUnListedStatusFilter.push(oUnListedFilter);
			this.getModel().read("/GetUserandRolesSet", {
				filters: aUserStatusFilter,
				success: function(oData) {
					var data = oData.results;
					this.getModel("AuthorizationModel").setProperty("/Items", data);
					var rolesArray = [];
					var actArray = [];
					var plantObj = [];

					for (var i = 0; i < data.length; i++) {
						rolesArray.push(data[i].Module);
						actArray.push(data[i].Actvt);
						plantObj.push({
							"PlantCode": data[i].Werks,
							"PlantName": data[i].PlantName
						});

					}

					this.getModel("PlantModel").setProperty("/plantValues", plantObj);
					this.getModel("RoleModel").setProperty("/Roles", rolesArray);
					this.getModel("RoleModel").setProperty("/Activities", actArray);
					var InspectionRole = false;
					var roles = this.getModel("RoleModel").getProperty("/Roles");
					var InspectionAprrover = false;
					for (var q = 0; q < roles.length; q++) {
						if (roles[q] === "Inspection") {
							InspectionRole = true;
							break;
						}
					}
					for (var r = 0; r < roles.length; r++) {
						if (roles[r] === "InspectionAppr") {
							InspectionAprrover = true;
						}
					}
					if (InspectionRole === true) {
						this.getModel("RoleModel").setProperty("/InspectionRole", true);
					}
					if (InspectionAprrover === true) {
						this.getModel("RoleModel").setProperty("/InspectionAprrover", true);
					}
					var aFilters = [],
						aStatusFilter = [];
					aFilters.push(new Filter({
						path: "ObdDate",
						value1: new Date("01/01/2019"),
						operator: FilterOperator.GT
					}));
					aFilters.push(new Filter({
						path: "ObdDate",
						value1: new Date(),
						operator: FilterOperator.LT
					}));
					var plantValues = this.getModel("PlantModel").getProperty("/plantValues");
					var plantsLen = plantValues.length;
					var newPlants = [];
					newPlants.push(plantValues[0]);
					for (var k = 1; k < plantsLen; k++) {
						var present = false;
						for (var g = 0; g < newPlants.length; g++) {
							if (newPlants[g].PlantCode === plantValues[k].PlantCode) {
								present = true;
								break;
							}
						}
						if (!present) {
							newPlants.push(plantValues[k]);
						}
					}
					this.getModel("PlantsModel").setProperty("/plantValues", newPlants);

					//...SOC NIGAM
					var sNewPlants = [...newPlants];
					sNewPlants.unshift({
						PlantCode: "Select Code",
						PlantName: "Select Code"
					});
					this.getModel("sPlantsModel").setProperty("/plantValues", sNewPlants);
					//...EOC NIGAM

					var plantValues1 = this.getModel("PlantsModel").getProperty("/plantValues");
					var plantsLength = this.getModel("PlantsModel").getProperty("/plantValues").length;
					if (plantsLength > 0) {
						for (var f = 0; f < plantsLength; f++) {
							aOrFilters.push(new Filter({
								path: "Plant",
								value1: plantValues1[f].PlantCode,
								operator: FilterOperator.EQ
							}));
						}
					} else {
						MessageBox.error("You are not Authorized to access this Application");
					}
					var oOrFilter = new Filter(aOrFilters, false);
					aFilters.push(oOrFilter);
					var oFilter = new Filter(aFilters, true);
					aStatusFilter.push(oFilter);
					this.getModel().read("/PLMS_outbound_HdrSet", {
						filters: aStatusFilter,
						urlParameters: {
							"$expand": "ZHDR_HDR"
						},
						success: function(oDataHDR) {
							var dataHDR = oDataHDR.results;
							this.getModel("TripDisplayModel").setProperty("/Items", dataHDR);
						}.bind(this),
						error: function(error) {
							MessageBox.error("No data is available for selected filters.Please select valid Filters");
						}.bind(this)
					});
				}.bind(this),
				error: function(error) {
					MessageBox.error("Error in getting User Role");
				}
			});
			// 	this.getModel().read("/UnassignVehiclesSet", {
			// 		filters: aUnListedStatusFilter,
			// 		success: function(oData) {
			// 			var data = oData.results;
			// 			this.getModel("UnListedModel").setProperty("/Items", data);
			// 		}.bind(this),
			// 		error: function() {
			// 			MessageBox.error("Error in getting Unlisted Vehicle Data");
			// 		}
			// 	});
		}
	});
});