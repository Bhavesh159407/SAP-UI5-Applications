sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/ui/core/Fragment"
], function(Controller, MessageBox, Fragment) {
	"use strict";

	return Controller.extend("reset_Password.controller.View1", {
		onInit: function() {
			this._otpDialog = null;

			// Regular expression to validate password (2 uppercase, 2 lowercase, 2 numbers, 2 special characters, and 12 characters minimum)
			this._passwordPattern = /^(?=(.*[A-Z]){2})(?=(.*[a-z]){2})(?=(.*[0-9]){2})(?=(.*[!@#$%^&*()_+{}\[\]:;"'<>,.?/\\|`~]){2}).{12,}$/;
		},

		onSubmit: function() {
			var submitButton = this.getView().byId("submitButton");
			submitButton.setEnabled(false);

			// Check User and Email fields are not empty
			var userField = this.getView().byId("user");
			var emailField = this.getView().byId("email");

			var user = userField.getValue();
			var email = emailField.getValue();

			if (!user || !email) {
				MessageBox.error("User and Email fields cannot be empty.");
				submitButton.setEnabled(true);
				return false;
			}

			// Check if password fields are visible (after OTP is verified)
			var confirmPasswordField = this.getView().byId("confirmPassword");
			var resetPasswordField = this.getView().byId("resetPassword");

			if (confirmPasswordField && resetPasswordField && confirmPasswordField.getVisible() && resetPasswordField.getVisible()) {
				// Password reset phase
				var confirmPassword = confirmPasswordField.getValue();
				var resetPassword = resetPasswordField.getValue();

				// Validate password fields
				if (!this._validatePassword(resetPassword, confirmPassword)) {
					submitButton.setEnabled(true);
					return false;
				}

				// Perform the password reset
				return this._resetPassword(resetPassword)
					.then(() => {
						MessageBox.success("Your password has been successfully updated.", {
							onClose: () => {
								this._showPasswordFields(false); // Hide password fields
								// Reset User and Email fields
								userField.setValue("");
								emailField.setValue("");
							}
						});
					})
					.catch(() => {
						MessageBox.error("Failed to update password. Please try again.");
					})
					.finally(() => {
						sap.ui.core.BusyIndicator.hide();
						submitButton.setEnabled(true);
					});
			} else {
				// OTP creation phase
				sap.ui.core.BusyIndicator.show(0);

				this._createOTP(user, email)
					.then(() => {
						// MessageBox.success("An OTP has been sent to your email.");
						this._openOTPDialog();
					})
					.catch(() => {
						MessageBox.error("Incorrect User ID or Email please try again!!");
					})
					.finally(() => {
						sap.ui.core.BusyIndicator.hide();
						submitButton.setEnabled(true);
					});
			}
		},

		_createOTP: function(user, email) {
			var oModel = this.getOwnerComponent().getModel();
			var oEntry = {
				"User": user,
				"Email": email
			};

			return new Promise((resolve, reject) => {
				oModel.create("/ResetPassword", oEntry, {
					success: resolve,
					error: reject
				});
			});
		},
		_resetPassword: function(resetPassword) {
			var oModel = this.getOwnerComponent().getModel();
			var user = this.getView().byId("user").getValue(); // Retrieve user input
			var email = this.getView().byId("email").getValue(); // Retrieve email input

			var oEntry = {
				"Password": resetPassword,
				"User": user,
				"Email": email
			};

			return new Promise((resolve, reject) => {
				oModel.create("/ResetPassword", oEntry, {
					success: function() {
						// Redirect to the Fiori Launchpad upon success
						sap.m.URLHelper.redirect("/sap/bc/ui5_ui5/ui2/ushell/shells/abap/FioriLaunchpad.html#Shell-home");
						resolve();
					},
					error: reject
				});
			});
		},
		_validatePassword: function(resetPassword, confirmPassword) {
			// Check if both passwords match
			if (resetPassword !== confirmPassword) {
				MessageBox.error("Passwords do not match.");
				return false;
			}

			// Check if passwords meet the complexity criteria
			if (!this._passwordPattern.test(resetPassword)) {
				MessageBox.error(
					"Password must contain at least 2 uppercase letters, 2 lowercase letters, 2 numbers, 2 special characters, and be at least 12 characters long."
				);
				return false;
			}

			return true;
		},

		onCloseOTPDialog: function() {
			// Get the OTP input field
			var otpInput = sap.ui.getCore().byId(this.getView().getId() + "--otpInput");

			// Clear the OTP input field and reset its value state
			if (otpInput) {
				otpInput.setValue("");
				otpInput.setValueState("None"); // Reset the value state
			}

			// Close the OTP dialog
			if (this._otpDialog) {
				this._otpDialog.close();
			}
		},

		onVerifyOTP: function() {
			var otpInput = sap.ui.getCore().byId(this.getView().getId() + "--otpInput");
			var otp = otpInput.getValue();
			var user = this.getView().byId("user").getValue();
			var email = this.getView().byId("email").getValue();

			// Validate OTP input
			if (!otp || otp.length !== 6 || !/^\d+$/.test(otp)) {
				otpInput.setValueState("Error");
				otpInput.setValueStateText("OTP must be 6 numeric digits.");
				return;
			}

			// Show busy indicator
			sap.ui.core.BusyIndicator.show(0);

			try {
				var oModel = this.getOwnerComponent().getModel();
				var oEntry = {
					"OTP": otp,
					"User": user,
					"Email": email
				};

				// Call the backend service to verify OTP
				oModel.create("/ResetPassword", oEntry, {
					success: function() {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.success("OTP verified successfully.");

						// Clear the OTP input field
						if (otpInput) {
							otpInput.setValue("");
							otpInput.setValueState("None"); // Reset the value state
						}

						// Close the dialog if it's open
						if (this._otpDialog) {
							this._otpDialog.close();
						}

						// Enable password fields after OTP verification
						this._showPasswordFields(true);
					}.bind(this),
					error: function() {
						sap.ui.core.BusyIndicator.hide();
						MessageBox.error("Invalid OTP or mismatched details. Please try again.");
					}
				});
			} catch (err) {
				sap.ui.core.BusyIndicator.hide();
				console.error("Error during OTP verification:", err);
				MessageBox.error("An unexpected error occurred. Please try again.");
			}
		},

		_openOTPDialog: function() {
			if (!this._otpDialog) {
				Fragment.load({
					id: this.getView().getId(),
					name: "reset_Password.Fragment.OTPFragment",
					controller: this
				}).then(function(oDialog) {
					this._otpDialog = oDialog;
					this.getView().addDependent(this._otpDialog);
					this._otpDialog.open();
				}.bind(this));
			} else {
				this._otpDialog.open();
			}
		},

		_showPasswordFields: function(visible) {
			// Show or hide the password fields based on the OTP verification success
			this.getView().byId("resetPasswordLabel").setVisible(visible);
			this.getView().byId("resetPassword").setVisible(visible);
			this.getView().byId("confirmPasswordLabel").setVisible(visible);
			this.getView().byId("confirmPassword").setVisible(visible);

			// Hide User and Email fields
			this.getView().byId("userLabel").setVisible(!visible);
			this.getView().byId("user").setVisible(!visible);
			this.getView().byId("emailLabel").setVisible(!visible);
			this.getView().byId("email").setVisible(!visible);
		},

		onReset: function() {
			this.getView().byId("user").setValue("");
			this.getView().byId("email").setValue("");
			this._showPasswordFields(false); // Hide and reset password fields
		},

		inputValidation: function() {
			var user = this.getView().byId("user").getValue();
			var email = this.getView().byId("email").getValue();
			var validationError = false;

			if (!user) {
				this.getView().byId("user").setValueState("Error");
				validationError = true;
			} else {
				this.getView().byId("user").setValueState("None");
			}

			if (!email) {
				this.getView().byId("email").setValueState("Error");
				validationError = true;
			} else {
				this.getView().byId("email").setValueState("None");
			}

			return validationError;
		},
		// _resetPassword: function(resetPassword) {
		// 	var oModel = this.getOwnerComponent().getModel();
		// 	var oEntry = {
		// 		"Password": encodeURIComponent(resetPassword) // URL encode the password
		// 	};

		// 	return new Promise((resolve, reject) => {
		// 		oModel.create("/ResetPassword", oEntry, {
		// 			success: resolve,
		// 			error: reject
		// 		});
		// 	});
		// },
		onCancel: function() {
			// Reset the input fields to null
			this.getView().byId("user").setValue("");
			this.getView().byId("email").setValue("");
			this.getView().byId("resetPassword").setValue("");
			this.getView().byId("confirmPassword").setValue("");

			// Optionally hide password fields if they are visible
			this._showPasswordFields(false);

			// Reset any validation states if needed
			this.getView().byId("user").setValueState("None");
			this.getView().byId("email").setValueState("None");
			this.getView().byId("resetPassword").setValueState("None");
			this.getView().byId("confirmPassword").setValueState("None");
		},

		onOtpChange: function(oEvent) {
			var oInput = oEvent.getSource();
			var value = oInput.getValue();

			// Ensure the value is numeric and doesn't exceed 6 digits
			if (!/^\d{1,6}$/.test(value)) {
				// Optionally, reset the value to the last valid input
				oInput.setValue(value.slice(0, 6)); // Keep only the first 6 digits
				oInput.setValueState(sap.ui.core.ValueState.Error); // Set error state
			} else {
				oInput.setValueState(sap.ui.core.ValueState.None); // Clear error state
			}
		}

	});
});